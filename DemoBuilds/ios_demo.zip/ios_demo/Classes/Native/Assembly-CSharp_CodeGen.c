﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void ConsentEventHandler::Awake()
extern void ConsentEventHandler_Awake_m814660283E70E14E5B6CFA7E64EF858590755C8D (void);
// 0x00000002 System.Void ConsentEventHandler::OnConsentUIReady()
extern void ConsentEventHandler_OnConsentUIReady_mF0FF16271392E0556473AD05C47454C7B7495258 (void);
// 0x00000003 System.Void ConsentEventHandler::OnConsentAction(ConsentManagementProviderLib.CONSENT_ACTION_TYPE)
extern void ConsentEventHandler_OnConsentAction_m54BE66B355CB35CD9130639A9A939AFAD5404D4D (void);
// 0x00000004 System.Void ConsentEventHandler::OnConsentError(System.Exception)
extern void ConsentEventHandler_OnConsentError_mEB9EC50AA4195B9AB50A8E3ADB91B256935EB252 (void);
// 0x00000005 System.Void ConsentEventHandler::OnConsentUIFinished()
extern void ConsentEventHandler_OnConsentUIFinished_m4694366AE7078B56265BC4D84BFB6659A9D1DE05 (void);
// 0x00000006 System.Void ConsentEventHandler::OnConsentReady(ConsentManagementProviderLib.SpConsents)
extern void ConsentEventHandler_OnConsentReady_m19668B5813FE4FA51803A3A2434C109DDBDFAA5E (void);
// 0x00000007 System.Void ConsentEventHandler::OnDestroy()
extern void ConsentEventHandler_OnDestroy_m4F79D0A2D6584FD6DC643A28FE1884AC3D96D68B (void);
// 0x00000008 System.Void ConsentEventHandler::.ctor()
extern void ConsentEventHandler__ctor_mAF3E0C8CA42531A592CF9AA7624EA73303CE910B (void);
// 0x00000009 System.Void ConsentMessageProvider::Awake()
extern void ConsentMessageProvider_Awake_m2B7FA04326E287EB832CD3A724327BD2FD52F4B5 (void);
// 0x0000000A System.Void ConsentMessageProvider::Start()
extern void ConsentMessageProvider_Start_m14BFAD1EDD51C888656B08CDF7F0B4C8EE956FAD (void);
// 0x0000000B System.Void ConsentMessageProvider::OnDestroy()
extern void ConsentMessageProvider_OnDestroy_mE8BFE342724E6A76E7891A41CEF0C470A9719BB9 (void);
// 0x0000000C System.Void ConsentMessageProvider::.ctor()
extern void ConsentMessageProvider__ctor_m0EC25F3820168F56E044887B2D7733EADB82918F (void);
// 0x0000000D System.Void CustomConsentButtonCaller::OnCustomConsentButtonClick()
extern void CustomConsentButtonCaller_OnCustomConsentButtonClick_mF771CB39C3696F9C7B48DF73065BB6E959FAB1BC (void);
// 0x0000000E System.Void CustomConsentButtonCaller::SuccessDelegate(ConsentManagementProviderLib.GdprConsent)
extern void CustomConsentButtonCaller_SuccessDelegate_m540DCD79E9EBE8B506A3C7433F8B74B0F3A13C66 (void);
// 0x0000000F System.Void CustomConsentButtonCaller::.ctor()
extern void CustomConsentButtonCaller__ctor_m5B5BF8FC92BCD5FD8AB0CF6D2E9B8A977FBBE8A2 (void);
// 0x00000010 System.Void PrivacyManagerButtonCaller::OnPrivacyManagerButtonClick()
extern void PrivacyManagerButtonCaller_OnPrivacyManagerButtonClick_m9BCB18FCB44B5A1BE84430A06A3270607F3AB688 (void);
// 0x00000011 System.Void PrivacyManagerButtonCaller::.ctor()
extern void PrivacyManagerButtonCaller__ctor_mE6D06A18FEDF8804B63ECB1613E17FAA3249ACAF (void);
// 0x00000012 System.Void ClickStubCmpButton::LogStubOnClick()
extern void ClickStubCmpButton_LogStubOnClick_m04EAC5CE63C9BADDA654B7503FBC1EB5E0A1F251 (void);
// 0x00000013 System.Void ClickStubCmpButton::.ctor()
extern void ClickStubCmpButton__ctor_mE6B72FB8EBD9397F73806632420F46E45B44ADA5 (void);
// 0x00000014 System.Void CmpButtonAnimatorController::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void CmpButtonAnimatorController_OnPointerEnter_m77B3C9B7FE99549C3BF7A9E44C7CA40F8CD5DDEA (void);
// 0x00000015 System.Void CmpButtonAnimatorController::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void CmpButtonAnimatorController_OnPointerExit_m07C21B843E1D97E628FFCAAABE2A4E3AD7FA6947 (void);
// 0x00000016 System.Void CmpButtonAnimatorController::.ctor()
extern void CmpButtonAnimatorController__ctor_m31F00DEA8AB04C233CC58017F4EDB1D9BB3EC5C3 (void);
// 0x00000017 System.Void CmpCellAnimatorController::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void CmpCellAnimatorController_OnPointerEnter_m594B87E7EBF5D7BCBD38D461F0503E8021DEE40B (void);
// 0x00000018 System.Void CmpCellAnimatorController::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void CmpCellAnimatorController_OnPointerExit_mE52FCEF155D7D763683CB74BE5F26EB085859025 (void);
// 0x00000019 System.Void CmpCellAnimatorController::SetIdle()
extern void CmpCellAnimatorController_SetIdle_mDE6DF2A3A814B5343836AD40C1A33DD1EAE8064B (void);
// 0x0000001A System.Void CmpCellAnimatorController::SetActive()
extern void CmpCellAnimatorController_SetActive_m3EA21E217D34BBA8988CA93894D42D80FACD9EFC (void);
// 0x0000001B System.Void CmpCellAnimatorController::.ctor()
extern void CmpCellAnimatorController__ctor_mE509DB559A9E8D653C3D1C3AC41784C174C1368B (void);
// 0x0000001C System.Void CmpPartnersCounter::Awake()
extern void CmpPartnersCounter_Awake_m3A3242E11CCB31E5348E2456A79B1FAE418B73FE (void);
// 0x0000001D System.Void CmpPartnersCounter::.ctor()
extern void CmpPartnersCounter__ctor_m6BF43D6F4B43F7C730C0FCA1F82FE33BC013D6FF (void);
// 0x0000001E System.Void CmpSwitch::Awake()
extern void CmpSwitch_Awake_m69F161110533B12B2CA475D28FC0DBFE59FEB1E4 (void);
// 0x0000001F System.Void CmpSwitch::OnButtonClick(CmpSwitch/BUTTON_SELECTED)
extern void CmpSwitch_OnButtonClick_m1A723AAB12C72BAE1D2A5A237FC09DFE0D660200 (void);
// 0x00000020 System.Void CmpSwitch::MoveActiveBackground(UnityEngine.Transform,UnityEngine.Vector3)
extern void CmpSwitch_MoveActiveBackground_mFDBC1F9611F78FF6E697E816B159D5466ECD1418 (void);
// 0x00000021 System.Void CmpSwitch::.ctor()
extern void CmpSwitch__ctor_mABD14F4F4ECE9F83D34A2403A1E24559AB99EBC0 (void);
// 0x00000022 System.Void CmpSwitch::<Awake>b__9_0()
extern void CmpSwitch_U3CAwakeU3Eb__9_0_mD9747EB3821223611516456D11A21A4CFD0B2AEF (void);
// 0x00000023 System.Void CmpSwitch::<Awake>b__9_1()
extern void CmpSwitch_U3CAwakeU3Eb__9_1_mB3C9D92977DB5E44CBE7503DEC593DBAF2A519D6 (void);
// 0x00000024 System.Void TextColorAnimationController::SetIdleState()
extern void TextColorAnimationController_SetIdleState_m6569C515CBDEA0870D6A8C96075BC84EF573BE94 (void);
// 0x00000025 System.Void TextColorAnimationController::SetActiveState()
extern void TextColorAnimationController_SetActiveState_m159BD4FC195F13AA96DD96AF1CA2EFED3E1ABE89 (void);
// 0x00000026 System.Void TextColorAnimationController::.ctor()
extern void TextColorAnimationController__ctor_mFBEB26607D593CAFC2BDE1674DCE203DC906B67A (void);
// 0x00000027 System.Collections.IEnumerator Assets.UI.Scripts.Util.GraphicExtenstion::ChangeColor(UnityEngine.UI.Graphic,UnityEngine.Color)
extern void GraphicExtenstion_ChangeColor_mBF25F61D8CAE5A27565FB1E3EB1976F5E14B7454 (void);
// 0x00000028 System.Collections.IEnumerator Assets.UI.Scripts.Util.GraphicExtenstion::TriggerAnimation(UnityEngine.Animator,System.String,System.Action)
extern void GraphicExtenstion_TriggerAnimation_mD85FFFC60D383C242B245CDE9AC31278E9931E97 (void);
// 0x00000029 System.Collections.IEnumerator Assets.UI.Scripts.Util.GraphicExtenstion::ChangeLocalPosition(UnityEngine.Transform,UnityEngine.Vector3,System.Single)
extern void GraphicExtenstion_ChangeLocalPosition_mEF1C08A0A159E5B1A27F0305A8C4C06A72C62796 (void);
// 0x0000002A System.Void Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeColor>d__0::.ctor(System.Int32)
extern void U3CChangeColorU3Ed__0__ctor_mC98A5F45333621BAFA7DF61349485BEB0E5396A3 (void);
// 0x0000002B System.Void Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeColor>d__0::System.IDisposable.Dispose()
extern void U3CChangeColorU3Ed__0_System_IDisposable_Dispose_mC5EF5C50E39600935EA2CD0ECAB21BC463C37ECF (void);
// 0x0000002C System.Boolean Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeColor>d__0::MoveNext()
extern void U3CChangeColorU3Ed__0_MoveNext_mA5447CB03E30D24EC61758F913DF945DCA6593B8 (void);
// 0x0000002D System.Object Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeColor>d__0::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CChangeColorU3Ed__0_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8B27C6CCF4DDB20AA95B4C07859F3E5C7F6ED6A3 (void);
// 0x0000002E System.Void Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeColor>d__0::System.Collections.IEnumerator.Reset()
extern void U3CChangeColorU3Ed__0_System_Collections_IEnumerator_Reset_m6A627F248D2D1039C3C61326372B45F37C0A429D (void);
// 0x0000002F System.Object Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeColor>d__0::System.Collections.IEnumerator.get_Current()
extern void U3CChangeColorU3Ed__0_System_Collections_IEnumerator_get_Current_m68597AD312422B82095C4C19989EFA8DF2EDFB9B (void);
// 0x00000030 System.Void Assets.UI.Scripts.Util.GraphicExtenstion/<TriggerAnimation>d__1::.ctor(System.Int32)
extern void U3CTriggerAnimationU3Ed__1__ctor_m5792FEDEDC38C12879044163D836D19681C3626C (void);
// 0x00000031 System.Void Assets.UI.Scripts.Util.GraphicExtenstion/<TriggerAnimation>d__1::System.IDisposable.Dispose()
extern void U3CTriggerAnimationU3Ed__1_System_IDisposable_Dispose_m0C61D41ADE60DFE11DD1188CB796940783B7D288 (void);
// 0x00000032 System.Boolean Assets.UI.Scripts.Util.GraphicExtenstion/<TriggerAnimation>d__1::MoveNext()
extern void U3CTriggerAnimationU3Ed__1_MoveNext_m0B0A8FBE394FC01372CCA935C4E89D317FA2343B (void);
// 0x00000033 System.Object Assets.UI.Scripts.Util.GraphicExtenstion/<TriggerAnimation>d__1::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CTriggerAnimationU3Ed__1_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF1D8477D990512D4427630B05BBB587504D4491B (void);
// 0x00000034 System.Void Assets.UI.Scripts.Util.GraphicExtenstion/<TriggerAnimation>d__1::System.Collections.IEnumerator.Reset()
extern void U3CTriggerAnimationU3Ed__1_System_Collections_IEnumerator_Reset_m13EF902C54F4B7EFA7271790A410A6DE00A6A09D (void);
// 0x00000035 System.Object Assets.UI.Scripts.Util.GraphicExtenstion/<TriggerAnimation>d__1::System.Collections.IEnumerator.get_Current()
extern void U3CTriggerAnimationU3Ed__1_System_Collections_IEnumerator_get_Current_m7E30A51C6500F4ABC43818F531592FDFA12850AF (void);
// 0x00000036 System.Void Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeLocalPosition>d__2::.ctor(System.Int32)
extern void U3CChangeLocalPositionU3Ed__2__ctor_m92F0DBA0A5C63C7C0E03D62C02C3CD5DDA60068B (void);
// 0x00000037 System.Void Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeLocalPosition>d__2::System.IDisposable.Dispose()
extern void U3CChangeLocalPositionU3Ed__2_System_IDisposable_Dispose_m59FE8DB3F78A8E4149CA0B2500DD0B71B09A93E7 (void);
// 0x00000038 System.Boolean Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeLocalPosition>d__2::MoveNext()
extern void U3CChangeLocalPositionU3Ed__2_MoveNext_m818E2D5B09F4D758E368284322C436365BF9FD9C (void);
// 0x00000039 System.Object Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeLocalPosition>d__2::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CChangeLocalPositionU3Ed__2_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB5B0CD0CE6922C8491CB0091B1C16CF0F83E133D (void);
// 0x0000003A System.Void Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeLocalPosition>d__2::System.Collections.IEnumerator.Reset()
extern void U3CChangeLocalPositionU3Ed__2_System_Collections_IEnumerator_Reset_m3B3DFBCE2C9041386A2AEAB8A49AFEA8B0F36683 (void);
// 0x0000003B System.Object Assets.UI.Scripts.Util.GraphicExtenstion/<ChangeLocalPosition>d__2::System.Collections.IEnumerator.get_Current()
extern void U3CChangeLocalPositionU3Ed__2_System_Collections_IEnumerator_get_Current_m6F78BEA03300744F2882F498B706CE06374BC0C2 (void);
// 0x0000003C System.Void ConsentManagementProviderLib.CMP::Initialize(System.Collections.Generic.List`1<ConsentManagementProviderLib.SpCampaign>,System.Int32,System.String,ConsentManagementProviderLib.MESSAGE_LANGUAGE,ConsentManagementProviderLib.CAMPAIGN_ENV,System.Int64)
extern void CMP_Initialize_m7907A81B6744345E1C5B6CC89B30B644C98BBD9A (void);
// 0x0000003D System.Void ConsentManagementProviderLib.CMP::LoadMessage(System.String)
extern void CMP_LoadMessage_m036EF93AE1C92C9918C3DAF9907DDBFC73FAA83C (void);
// 0x0000003E System.Void ConsentManagementProviderLib.CMP::LoadPrivacyManager(ConsentManagementProviderLib.CAMPAIGN_TYPE,System.String,ConsentManagementProviderLib.PRIVACY_MANAGER_TAB)
extern void CMP_LoadPrivacyManager_mAF332F8B3D25F6092F7C51215830FAEF814FDBED (void);
// 0x0000003F System.Void ConsentManagementProviderLib.CMP::CustomConsentGDPR(System.String[],System.String[],System.String[],System.Action`1<ConsentManagementProviderLib.GdprConsent>)
extern void CMP_CustomConsentGDPR_m9E16F21B7582F5E673F9A10F18DD733637F7EAF9 (void);
// 0x00000040 ConsentManagementProviderLib.SpConsents ConsentManagementProviderLib.CMP::GetSpConsents()
extern void CMP_GetSpConsents_mF22EE2D3807BFC889B33827AC937922EB026DBFD (void);
// 0x00000041 ConsentManagementProviderLib.GdprConsent ConsentManagementProviderLib.CMP::GetCustomConsent()
extern void CMP_GetCustomConsent_m267235E514B1FC41312EA9B42E5D55B0632E4178 (void);
// 0x00000042 System.Void ConsentManagementProviderLib.CMP::Dispose()
extern void CMP_Dispose_m0DA166412DF92FB8D9A102B6F52B12884EB99E0F (void);
// 0x00000043 System.Void ConsentManagementProviderLib.CMP::CreateBroadcastExecutorGO()
extern void CMP_CreateBroadcastExecutorGO_m345983EBA65B90B469396EF9999F8A27CC66E9E6 (void);
// 0x00000044 System.Void ConsentManagementProviderLib.CMP::RemoveIos14SpCampaign(System.Collections.Generic.List`1<ConsentManagementProviderLib.SpCampaign>&)
extern void CMP_RemoveIos14SpCampaign_mA3E921DF7E81CD9775846B80E14D28255701C124 (void);
// 0x00000045 System.Boolean ConsentManagementProviderLib.CMP::IsSpCampaignsValid(System.Collections.Generic.List`1<ConsentManagementProviderLib.SpCampaign>)
extern void CMP_IsSpCampaignsValid_mFB62DB0DE215C700DF576FABC93DF88DE118BBE7 (void);
// 0x00000046 System.Void ConsentManagementProviderLib.CMP/<>c::.cctor()
extern void U3CU3Ec__cctor_mC546C6CB39BE4C2A2C9624525CAD6307D2EA42DC (void);
// 0x00000047 System.Void ConsentManagementProviderLib.CMP/<>c::.ctor()
extern void U3CU3Ec__ctor_m4FDD840D36A8599B77C24109F57F7F571155F466 (void);
// 0x00000048 System.Boolean ConsentManagementProviderLib.CMP/<>c::<RemoveIos14SpCampaign>b__9_0(ConsentManagementProviderLib.SpCampaign)
extern void U3CU3Ec_U3CRemoveIos14SpCampaignU3Eb__9_0_mC3191719C71C29D829A45153CA4336B4C8949D55 (void);
// 0x00000049 System.Void ConsentManagementProviderLib.IOnConsentAction::OnConsentAction(ConsentManagementProviderLib.CONSENT_ACTION_TYPE)
// 0x0000004A System.Void ConsentManagementProviderLib.IOnConsentError::OnConsentError(System.Exception)
// 0x0000004B System.Void ConsentManagementProviderLib.IOnConsentReady::OnConsentReady(ConsentManagementProviderLib.SpConsents)
// 0x0000004C System.Void ConsentManagementProviderLib.IOnConsentUIFinished::OnConsentUIFinished()
// 0x0000004D System.Void ConsentManagementProviderLib.IOnConsentUIReady::OnConsentUIReady()
// 0x0000004E ConsentManagementProviderLib.CAMPAIGN_TYPE ConsentManagementProviderLib.SpCampaign::get_CampaignType()
extern void SpCampaign_get_CampaignType_m9046FA64A454961E5D787EAE2FED73BCFB9D02A4 (void);
// 0x0000004F System.Collections.Generic.List`1<ConsentManagementProviderLib.TargetingParam> ConsentManagementProviderLib.SpCampaign::get_TargetingParams()
extern void SpCampaign_get_TargetingParams_m6A8AF52B24827BD38C24C9400142EEEFB4F99685 (void);
// 0x00000050 System.Void ConsentManagementProviderLib.SpCampaign::.ctor(ConsentManagementProviderLib.CAMPAIGN_TYPE,System.Collections.Generic.List`1<ConsentManagementProviderLib.TargetingParam>)
extern void SpCampaign__ctor_m407B4443651590F93272DFF2D653D95C6896CDD8 (void);
// 0x00000051 System.Void ConsentManagementProviderLib.SpConsents::.ctor(ConsentManagementProviderLib.SpGdprConsent,ConsentManagementProviderLib.SpCcpaConsent)
extern void SpConsents__ctor_m589E47129B9637CE641503FCCF77FD2700C8B1BD (void);
// 0x00000052 System.String ConsentManagementProviderLib.TargetingParam::get_Key()
extern void TargetingParam_get_Key_m5BF5F9840ED0FB291B65FA9FFD33029CEB005D21 (void);
// 0x00000053 System.String ConsentManagementProviderLib.TargetingParam::get_Value()
extern void TargetingParam_get_Value_mCB969B3E19D2D3BBE21EF98D472C428F58F80B0B (void);
// 0x00000054 System.Void ConsentManagementProviderLib.TargetingParam::.ctor(System.String,System.String)
extern void TargetingParam__ctor_m058BF6A9F13033C5C7960D981F11E60E75829064 (void);
// 0x00000055 System.Void ConsentManagementProviderLib.CcpaConsent::.ctor(System.String,System.String,System.String,System.Collections.Generic.List`1<System.String>,System.Collections.Generic.List`1<System.String>)
extern void CcpaConsent__ctor_mCD1BE40EB6ABB179F38D13CE11F7AD4CB97150A4 (void);
// 0x00000056 System.Void ConsentManagementProviderLib.CcpaConsent::.ctor(System.String,System.String,System.String,System.String[],System.String[])
extern void CcpaConsent__ctor_mDE63517B23E66ED3658EF26DB8FC766B74370303 (void);
// 0x00000057 System.Void ConsentManagementProviderLib.GdprConsent::.ctor()
extern void GdprConsent__ctor_m5C9BCA8E693571FFBD321665576B5EBF905271B4 (void);
// 0x00000058 System.Void ConsentManagementProviderLib.SpCcpaConsent::.ctor(ConsentManagementProviderLib.CcpaConsent)
extern void SpCcpaConsent__ctor_mD0D50A2DC5CEA97962E98ECFB5A995BE3B8CBA57 (void);
// 0x00000059 System.Void ConsentManagementProviderLib.SpGdprConsent::.ctor(ConsentManagementProviderLib.GdprConsent)
extern void SpGdprConsent__ctor_mDA601023AFDAB501ED9E1A3F41D49922DEA1F5F7 (void);
// 0x0000005A System.Void ConsentManagementProviderLib.SpVendorGrant::.ctor(System.Collections.Generic.Dictionary`2<System.String,System.Boolean>)
extern void SpVendorGrant__ctor_m47D2CE7BEB5E9562290E28FAA67682D72C70EA57 (void);
// 0x0000005B System.Void ConsentManagementProviderLib.ConsentMessenger::AddListener(UnityEngine.GameObject)
// 0x0000005C System.Void ConsentManagementProviderLib.ConsentMessenger::RemoveListener(UnityEngine.GameObject)
// 0x0000005D System.Void ConsentManagementProviderLib.ConsentMessenger::Broadcast(System.Object[])
// 0x0000005E System.Void ConsentManagementProviderLib.ConsentMessenger/<>c__DisplayClass2_0`1::.ctor()
// 0x0000005F System.Void ConsentManagementProviderLib.ConsentMessenger/<>c__DisplayClass2_0`1::<Broadcast>b__0(ConsentManagementProviderLib.IOnConsentReady,UnityEngine.EventSystems.BaseEventData)
// 0x00000060 System.Void ConsentManagementProviderLib.ConsentMessenger/<>c__DisplayClass2_0`1::<Broadcast>b__1(ConsentManagementProviderLib.IOnConsentAction,UnityEngine.EventSystems.BaseEventData)
// 0x00000061 System.Void ConsentManagementProviderLib.ConsentMessenger/<>c__DisplayClass2_0`1::<Broadcast>b__2(ConsentManagementProviderLib.IOnConsentError,UnityEngine.EventSystems.BaseEventData)
// 0x00000062 System.Void ConsentManagementProviderLib.ConsentMessenger/<>c__2`1::.cctor()
// 0x00000063 System.Void ConsentManagementProviderLib.ConsentMessenger/<>c__2`1::.ctor()
// 0x00000064 System.Void ConsentManagementProviderLib.ConsentMessenger/<>c__2`1::<Broadcast>b__2_3(ConsentManagementProviderLib.IOnConsentUIReady,UnityEngine.EventSystems.BaseEventData)
// 0x00000065 System.Void ConsentManagementProviderLib.ConsentMessenger/<>c__2`1::<Broadcast>b__2_4(ConsentManagementProviderLib.IOnConsentUIFinished,UnityEngine.EventSystems.BaseEventData)
// 0x00000066 System.Void ConsentManagementProviderLib.CmpDebugUtil::.cctor()
extern void CmpDebugUtil__cctor_m80EC4504AFC55B149CFB9A2D10D58586C304610B (void);
// 0x00000067 System.Void ConsentManagementProviderLib.CmpDebugUtil::EnableCmpLogs(System.Boolean)
extern void CmpDebugUtil_EnableCmpLogs_mE1F369B8066338B8D28191998DDCA423E9198459 (void);
// 0x00000068 System.Void ConsentManagementProviderLib.CmpDebugUtil::EnableGarbageCollectorDebugging(System.Boolean)
extern void CmpDebugUtil_EnableGarbageCollectorDebugging_m50FF2714C6195CDB1E5FF13A5EB8AF3BCE1F6B0D (void);
// 0x00000069 System.Void ConsentManagementProviderLib.CmpDebugUtil::Log(System.String)
extern void CmpDebugUtil_Log_mE8745E8065943A0C48C1C602D37A5E3C816E67CA (void);
// 0x0000006A System.Void ConsentManagementProviderLib.CmpDebugUtil::LogWarning(System.String)
extern void CmpDebugUtil_LogWarning_m0791EBB110268288BE6A27A974A1E11D1318D9B7 (void);
// 0x0000006B System.Void ConsentManagementProviderLib.CmpDebugUtil::LogError(System.String)
extern void CmpDebugUtil_LogError_m62D4C5C648C86E9F0FF21809106B261E067143BC (void);
// 0x0000006C System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::_setUnityCallback(System.String)
extern void CMPiOSListenerHelper__setUnityCallback_mB901E72D07AD34CDDDA154FC2F4E137DA64696AE (void);
// 0x0000006D System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::Awake()
extern void CMPiOSListenerHelper_Awake_m5431A1B5E3E8BC43985FCE3679F58AFE215C0AD1 (void);
// 0x0000006E System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::SetCustomConsentsGDPRSuccessAction(System.Action`1<ConsentManagementProviderLib.GdprConsent>)
extern void CMPiOSListenerHelper_SetCustomConsentsGDPRSuccessAction_m26D8B9F76E4D0C356CD5B187295F59B6463499E7 (void);
// 0x0000006F System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::Callback(System.String)
extern void CMPiOSListenerHelper_Callback_m48273542AE0E4F681A4633E27418940080E6B502 (void);
// 0x00000070 System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::OnConsentReady(System.String)
extern void CMPiOSListenerHelper_OnConsentReady_mCF3FCCAC41A98BBCF3257F9C9453B2099E1FE66E (void);
// 0x00000071 System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::OnConsentUIReady(System.String)
extern void CMPiOSListenerHelper_OnConsentUIReady_m58AEDEE33171939C9610D60078D67D8765C82C81 (void);
// 0x00000072 System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::OnConsentAction(System.String)
extern void CMPiOSListenerHelper_OnConsentAction_m5140CD47CC69DF0F4AC31E35A45901B9C0DA258F (void);
// 0x00000073 System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::OnConsentUIFinished(System.String)
extern void CMPiOSListenerHelper_OnConsentUIFinished_mAE5E0F5D123266DF509D1882EB8351ECB37D7DC3 (void);
// 0x00000074 System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::OnErrorCallback(System.String)
extern void CMPiOSListenerHelper_OnErrorCallback_m2DC5E7BDDB17B78CBE8DB7FAD2749CC8664B3371 (void);
// 0x00000075 System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::OnCustomConsentGDPRCallback(System.String)
extern void CMPiOSListenerHelper_OnCustomConsentGDPRCallback_m93681B2AB3EF7044EF0C0D6B7A100D0B7C136317 (void);
// 0x00000076 System.Void ConsentManagementProviderLib.iOS.CMPiOSListenerHelper::.ctor()
extern void CMPiOSListenerHelper__ctor_mA77E1FB50FF77F245CD89997B5CD28B43B42FA49 (void);
// 0x00000077 ConsentManagementProviderLib.iOS.ConsentWrapperIOS ConsentManagementProviderLib.iOS.ConsentWrapperIOS::get_Instance()
extern void ConsentWrapperIOS_get_Instance_m37DFD1FEB9D1086947CB8E153F705E4E2ED6FE5A (void);
// 0x00000078 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::set_Instance(ConsentManagementProviderLib.iOS.ConsentWrapperIOS)
extern void ConsentWrapperIOS_set_Instance_m28F7B56109C496E16AAAC0F6C62FFC698F7BA7A4 (void);
// 0x00000079 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_loadMessage(System.String)
extern void ConsentWrapperIOS__loadMessage_m72D60EF4F4581383DB3BBD7DF14BDF4BD2CC00FD (void);
// 0x0000007A System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_addTargetingParamForCampaignType(System.Int32,System.String,System.String)
extern void ConsentWrapperIOS__addTargetingParamForCampaignType_m3A59F78D744EB67127CD60D1718AADEF3866E15D (void);
// 0x0000007B System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_consrtuctLib(System.Int32,System.String,System.Int32,System.Int32[],System.Int32,System.Int64)
extern void ConsentWrapperIOS__consrtuctLib_mFB28397C1E402693DC641996CBDE8A65EA0EB2A8 (void);
// 0x0000007C System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_setMessageLanguage(System.Int32)
extern void ConsentWrapperIOS__setMessageLanguage_m7670D36862F9563D571BB62DEF55B8738D7B2A4C (void);
// 0x0000007D System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_loadGDPRPrivacyManager(System.String,System.Int32)
extern void ConsentWrapperIOS__loadGDPRPrivacyManager_m8D3BA0D3F9F471713C9D8FF3BD0385D04ADA4DCF (void);
// 0x0000007E System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_loadCCPAPrivacyManager(System.String,System.Int32)
extern void ConsentWrapperIOS__loadCCPAPrivacyManager_mDC5549E54AEDB73C46144D7F82BB8B881FC9D4DF (void);
// 0x0000007F System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_cleanDict()
extern void ConsentWrapperIOS__cleanDict_mC11829A26E364E82A9E7AC628D045CC6A4D638D9 (void);
// 0x00000080 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_cleanArrays()
extern void ConsentWrapperIOS__cleanArrays_m7BC357194E3C9CEC9C62434F0D5274066D85E910 (void);
// 0x00000081 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_customConsentGDPRWithVendors()
extern void ConsentWrapperIOS__customConsentGDPRWithVendors_m0ED81B9C478D92458704A23B5C79D5368CA5D1BC (void);
// 0x00000082 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_addVendor(System.String)
extern void ConsentWrapperIOS__addVendor_mB082D2DA5AE29D65261B85D7058DA74BBF236FC7 (void);
// 0x00000083 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_addLegIntCategory(System.String)
extern void ConsentWrapperIOS__addLegIntCategory_mDBAD31F9B3E18435D90AAE1F4490D3FCF25B66B6 (void);
// 0x00000084 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::_addCategory(System.String)
extern void ConsentWrapperIOS__addCategory_mB99386CE2568DE636A23DB8D0F5BE738F0A19D96 (void);
// 0x00000085 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::.ctor()
extern void ConsentWrapperIOS__ctor_m8D04D96B3EE6AD63224FFB4721C39169E1D423AF (void);
// 0x00000086 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::CreateHelperIOSListener()
extern void ConsentWrapperIOS_CreateHelperIOSListener_m6817136754FF0FF73921FFB0FAC619097BBAFD7D (void);
// 0x00000087 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::InitializeLib(System.Collections.Generic.List`1<ConsentManagementProviderLib.SpCampaign>,System.Int32,System.String,ConsentManagementProviderLib.MESSAGE_LANGUAGE,ConsentManagementProviderLib.CAMPAIGN_ENV,System.Int64)
extern void ConsentWrapperIOS_InitializeLib_m55DC343E0BE7F8B098A3F4338D5DCD9E6D5FC65A (void);
// 0x00000088 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::LoadMessage(System.String)
extern void ConsentWrapperIOS_LoadMessage_m9C2008B9D90848F32BE2B616F39283F41A37BB7F (void);
// 0x00000089 System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::LoadGDPRPrivacyManager(System.String,ConsentManagementProviderLib.PRIVACY_MANAGER_TAB)
extern void ConsentWrapperIOS_LoadGDPRPrivacyManager_mA2C7D800D14019B1E7C6BA31F51EB4A3ABD197A3 (void);
// 0x0000008A System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::LoadCCPAPrivacyManager(System.String,ConsentManagementProviderLib.PRIVACY_MANAGER_TAB)
extern void ConsentWrapperIOS_LoadCCPAPrivacyManager_mC3FF732E6830A193927475B69405839D3FA4FB8A (void);
// 0x0000008B System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::CustomConsentGDPR(System.String[],System.String[],System.String[],System.Action`1<ConsentManagementProviderLib.GdprConsent>)
extern void ConsentWrapperIOS_CustomConsentGDPR_mCEA787B397BCDD921FC9FEAA22C097A38EF8A0F0 (void);
// 0x0000008C ConsentManagementProviderLib.GdprConsent ConsentManagementProviderLib.iOS.ConsentWrapperIOS::GetCustomGdprConsent()
extern void ConsentWrapperIOS_GetCustomGdprConsent_m437212C7F79F5A975C693C7EF5DBACCE932FEE16 (void);
// 0x0000008D ConsentManagementProviderLib.SpConsents ConsentManagementProviderLib.iOS.ConsentWrapperIOS::GetSpConsents()
extern void ConsentWrapperIOS_GetSpConsents_m7E0CABF4406E6F4D15A2B9E522CDED01434ACDA1 (void);
// 0x0000008E System.Void ConsentManagementProviderLib.iOS.ConsentWrapperIOS::Dispose()
extern void ConsentWrapperIOS_Dispose_m76CA54CA019A97F6DBB01D61B2F8F5315C17738F (void);
// 0x0000008F System.Void ConsentManagementProviderLib.Android.AndroidJavaConstruct::.ctor()
extern void AndroidJavaConstruct__ctor_m5121468CF25809AC54ED11A301BB97A6EB305780 (void);
// 0x00000090 UnityEngine.AndroidJavaObject ConsentManagementProviderLib.Android.AndroidJavaConstruct::GetActivity()
extern void AndroidJavaConstruct_GetActivity_m41A2DBD16207DA124FE7B9E17CC7BDBFC3B26F3D (void);
// 0x00000091 UnityEngine.AndroidJavaObject ConsentManagementProviderLib.Android.AndroidJavaConstruct::ConsrtuctLib(UnityEngine.AndroidJavaObject,UnityEngine.AndroidJavaObject,ConsentManagementProviderLib.Android.SpClientProxy)
extern void AndroidJavaConstruct_ConsrtuctLib_m15A13B58CA8F14C682B3DACC815268F03439827C (void);
// 0x00000092 UnityEngine.AndroidJavaObject ConsentManagementProviderLib.Android.AndroidJavaConstruct::ConstructPrivacyManagerTab(ConsentManagementProviderLib.PRIVACY_MANAGER_TAB)
extern void AndroidJavaConstruct_ConstructPrivacyManagerTab_m351816683C83BF7DE45FD22C3880E049ABD56BBD (void);
// 0x00000093 UnityEngine.AndroidJavaObject ConsentManagementProviderLib.Android.AndroidJavaConstruct::ConstructCampaign(UnityEngine.AndroidJavaObject,UnityEngine.AndroidJavaObject,ConsentManagementProviderLib.CAMPAIGN_TYPE)
extern void AndroidJavaConstruct_ConstructCampaign_m5372D32EF946016921F07591023CA0D5C3B707F1 (void);
// 0x00000094 UnityEngine.AndroidJavaObject ConsentManagementProviderLib.Android.AndroidJavaConstruct::ConstructCampaignType(ConsentManagementProviderLib.CAMPAIGN_TYPE)
extern void AndroidJavaConstruct_ConstructCampaignType_mAEF4FD4F447FB17459A6E90A7FAA22DDCF2C47C6 (void);
// 0x00000095 UnityEngine.AndroidJavaObject ConsentManagementProviderLib.Android.AndroidJavaConstruct::ConstructMessageLanguage(ConsentManagementProviderLib.MESSAGE_LANGUAGE)
extern void AndroidJavaConstruct_ConstructMessageLanguage_m93AF06F89A41AE19531A165104F56D161D67AB10 (void);
// 0x00000096 UnityEngine.AndroidJavaObject ConsentManagementProviderLib.Android.AndroidJavaConstruct::ConstructSpConfig(System.Int32,System.String,System.Int64,UnityEngine.AndroidJavaObject,ConsentManagementProviderLib.CAMPAIGN_ENV,UnityEngine.AndroidJavaObject[])
extern void AndroidJavaConstruct_ConstructSpConfig_m60551D9E991FFBFFE43982D86486CBE8E1856445 (void);
// 0x00000097 UnityEngine.AndroidJavaObject ConsentManagementProviderLib.Android.AndroidJavaConstruct::ConstructTargetingParam(System.String,System.String)
extern void AndroidJavaConstruct_ConstructTargetingParam_m9ECB8D6289085D880321AD8119139158FAF63358 (void);
// 0x00000098 UnityEngine.AndroidJavaObject ConsentManagementProviderLib.Android.AndroidJavaConstruct::ConstructCampaignEnv(ConsentManagementProviderLib.CAMPAIGN_ENV)
extern void AndroidJavaConstruct_ConstructCampaignEnv_mF2AEED39E3592B1AC9CD9A2A78D8880F62319318 (void);
// 0x00000099 System.Void ConsentManagementProviderLib.Android.AndroidJavaConstruct::Dispose()
extern void AndroidJavaConstruct_Dispose_m83E914334964297572ADB868A2AE5D4DA80D3DC7 (void);
// 0x0000009A System.Void ConsentManagementProviderLib.Android.AndroidJavaConstruct::.cctor()
extern void AndroidJavaConstruct__cctor_m98E5900377210226E853BF452DD10573BC514893 (void);
// 0x0000009B UnityEngine.AndroidJavaObject ConsentManagementProviderLib.Android.CmpJavaToUnityUtils::ConvertArrayToList(UnityEngine.AndroidJavaObject[])
extern void CmpJavaToUnityUtils_ConvertArrayToList_mD2533E492DF66053D5F6EE5F2996EF2B6878EE81 (void);
// 0x0000009C System.Exception ConsentManagementProviderLib.Android.CmpJavaToUnityUtils::ConvertThrowableToError(UnityEngine.AndroidJavaObject)
extern void CmpJavaToUnityUtils_ConvertThrowableToError_mCCDC62B4F3502DDEA295649C6DE49B4711B23D4B (void);
// 0x0000009D ConsentManagementProviderLib.Android.ConsentWrapperAndroid ConsentManagementProviderLib.Android.ConsentWrapperAndroid::get_Instance()
extern void ConsentWrapperAndroid_get_Instance_mCFD28FEE776E45BEE8F13BAAD36EBE0C1FC7F46E (void);
// 0x0000009E System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::set_Instance(ConsentManagementProviderLib.Android.ConsentWrapperAndroid)
extern void ConsentWrapperAndroid_set_Instance_mD31AC76647F8862E62EEF2DC02D8934F590495A2 (void);
// 0x0000009F System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::.ctor()
extern void ConsentWrapperAndroid__ctor_m62B418FB792A88C143EF49573C0AE184C7623530 (void);
// 0x000000A0 System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::InitializeLib(System.Collections.Generic.List`1<ConsentManagementProviderLib.SpCampaign>,System.Int32,System.String,ConsentManagementProviderLib.MESSAGE_LANGUAGE,ConsentManagementProviderLib.CAMPAIGN_ENV,System.Int64)
extern void ConsentWrapperAndroid_InitializeLib_mE275FFD1CC15366C7005FA19D10DBA0CF712EAB1 (void);
// 0x000000A1 System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::LoadMessage(System.String)
extern void ConsentWrapperAndroid_LoadMessage_mDBBD302944A07DCED60F42D20483036EB786E7E7 (void);
// 0x000000A2 System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::LoadPrivacyManager(ConsentManagementProviderLib.CAMPAIGN_TYPE,System.String,ConsentManagementProviderLib.PRIVACY_MANAGER_TAB)
extern void ConsentWrapperAndroid_LoadPrivacyManager_m123A19FEE53F91F66F0092F8FCBDF401BA353AB2 (void);
// 0x000000A3 System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::CustomConsentGDPR(System.String[],System.String[],System.String[],System.Action`1<ConsentManagementProviderLib.GdprConsent>)
extern void ConsentWrapperAndroid_CustomConsentGDPR_mEC620B72A87577A9D3017CCE044E01695734F513 (void);
// 0x000000A4 ConsentManagementProviderLib.GdprConsent ConsentManagementProviderLib.Android.ConsentWrapperAndroid::GetCustomGdprConsent()
extern void ConsentWrapperAndroid_GetCustomGdprConsent_m70F5707998200B04A5A6E1295CFA10334F9BD313 (void);
// 0x000000A5 System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::Dispose()
extern void ConsentWrapperAndroid_Dispose_mFB0A682A61F3C80C90B5596AE47FB97A492E19E9 (void);
// 0x000000A6 System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::CallShowView(UnityEngine.AndroidJavaObject)
extern void ConsentWrapperAndroid_CallShowView_m4411C5C59F49D2E915BEECDDCDF4AC3D1253FA2F (void);
// 0x000000A7 System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::CallRemoveView(UnityEngine.AndroidJavaObject)
extern void ConsentWrapperAndroid_CallRemoveView_m5D1CE623FEEC81612C8F19B16C4DD3F202D3A391 (void);
// 0x000000A8 System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::RunOnUiThread(System.Action)
extern void ConsentWrapperAndroid_RunOnUiThread_mB428DC31FC7AE07491D7C0679CBA0341F19EAD84 (void);
// 0x000000A9 System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::InvokeLoadMessage()
extern void ConsentWrapperAndroid_InvokeLoadMessage_m8660CD9DAB1402CEE7A03B942A50B1D6B81F2A52 (void);
// 0x000000AA System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::InvokeLoadPrivacyManager(System.String,UnityEngine.AndroidJavaObject,UnityEngine.AndroidJavaObject,ConsentManagementProviderLib.CAMPAIGN_TYPE)
extern void ConsentWrapperAndroid_InvokeLoadPrivacyManager_mBCD13239F55EB8C58E1A23C730A08737F53739E9 (void);
// 0x000000AB System.Void ConsentManagementProviderLib.Android.ConsentWrapperAndroid::InvokeLoadMessageWithAuthID(System.String)
extern void ConsentWrapperAndroid_InvokeLoadMessageWithAuthID_m716E6215BB1C63E6B5D116A53EFEEAA9B549840C (void);
// 0x000000AC ConsentManagementProviderLib.SpConsents ConsentManagementProviderLib.Android.ConsentWrapperAndroid::GetSpConsents()
extern void ConsentWrapperAndroid_GetSpConsents_m51F88961A4F135B1BACD150DFFC3802529CC4B3E (void);
// 0x000000AD System.Void ConsentManagementProviderLib.Android.CustomConsentClient::.ctor(System.Action`1<ConsentManagementProviderLib.GdprConsent>)
extern void CustomConsentClient__ctor_m326C968B1D8D1C93E4FA6D4CBABB8EC8B46EA48E (void);
// 0x000000AE System.Void ConsentManagementProviderLib.Android.CustomConsentClient::transferCustomConsentToUnity(System.String)
extern void CustomConsentClient_transferCustomConsentToUnity_m8ECC850FEA5FB497413F5E7B2694E98A9A07481C (void);
// 0x000000AF System.Void ConsentManagementProviderLib.Android.CustomConsentClient::.cctor()
extern void CustomConsentClient__cctor_m4B21EC863B502B88562C2E9006CD596F019196B1 (void);
// 0x000000B0 System.Void ConsentManagementProviderLib.Android.SpClientProxy::.ctor()
extern void SpClientProxy__ctor_m96DCF449AA103A3B5C7A5E281A1EAF68AD58A3C1 (void);
// 0x000000B1 System.Void ConsentManagementProviderLib.Android.SpClientProxy::onUIReady(UnityEngine.AndroidJavaObject)
extern void SpClientProxy_onUIReady_m355F99312DAD8F41510027CEB8541BF12961BB40 (void);
// 0x000000B2 System.Void ConsentManagementProviderLib.Android.SpClientProxy::onUIFinished(UnityEngine.AndroidJavaObject)
extern void SpClientProxy_onUIFinished_mEA9EE9927A046EC2322F8B548009F110B41D8BBF (void);
// 0x000000B3 System.Void ConsentManagementProviderLib.Android.SpClientProxy::onAction(UnityEngine.AndroidJavaObject,UnityEngine.AndroidJavaObject)
extern void SpClientProxy_onAction_mB75B8A42BD42A7802457FE0924182F3189DC8BBC (void);
// 0x000000B4 System.Void ConsentManagementProviderLib.Android.SpClientProxy::onConsentReady(System.String)
extern void SpClientProxy_onConsentReady_mDD264AAA6257317AE752726C25895CB2CC8638BE (void);
// 0x000000B5 System.Void ConsentManagementProviderLib.Android.SpClientProxy::onError(UnityEngine.AndroidJavaObject)
extern void SpClientProxy_onError_mFC05E6E8C2238318541593BE163FDC81335D7C8D (void);
// 0x000000B6 System.Void ConsentManagementProviderLib.Android.SpClientProxy::onConsentReady(UnityEngine.AndroidJavaObject)
extern void SpClientProxy_onConsentReady_mC177D14AF6243D9E8E24BB7826EFBD2E468FF572 (void);
// 0x000000B7 System.Void ConsentManagementProviderLib.Android.SpClientProxy::onMessageReady(UnityEngine.AndroidJavaObject)
extern void SpClientProxy_onMessageReady_mB5B8B57A2DB0994CADCF4B806E3CAE8F64E0FEA0 (void);
// 0x000000B8 System.Void ConsentManagementProviderLib.Android.SpClientProxy::.cctor()
extern void SpClientProxy__cctor_m463861359639EDA4CE07B035CB8AC8636F17A5A5 (void);
// 0x000000B9 System.Void ConsentManagementProviderLib.Observer.BroadcastEventDispatcher::Execute(UnityEngine.EventSystems.BaseEventData,UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<T>)
// 0x000000BA System.Void ConsentManagementProviderLib.Observer.BroadcastEventDispatcher::.cctor()
extern void BroadcastEventDispatcher__cctor_mA36784AB3F39C1BF74288783AD6512C11FBADBF8 (void);
// 0x000000BB System.Void ConsentManagementProviderLib.Observer.BroadcastEventDispatcher/<>c__DisplayClass1_0`1::.ctor()
// 0x000000BC System.Void ConsentManagementProviderLib.Observer.BroadcastEventDispatcher/<>c__DisplayClass1_1`1::.ctor()
// 0x000000BD System.Void ConsentManagementProviderLib.Observer.BroadcastEventDispatcher/<>c__DisplayClass1_1`1::<Execute>b__0()
// 0x000000BE System.Void ConsentManagementProviderLib.Observer.BroadcastEventsExecutor::Awake()
extern void BroadcastEventsExecutor_Awake_mB9D6C5233F4875391A64CAF0733A44BB9DB000B5 (void);
// 0x000000BF System.Void ConsentManagementProviderLib.Observer.BroadcastEventsExecutor::Update()
extern void BroadcastEventsExecutor_Update_m1C9FA3F6B38C9CD7D8FBD1CCDD67C667C48ECDC7 (void);
// 0x000000C0 System.Void ConsentManagementProviderLib.Observer.BroadcastEventsExecutor::.ctor()
extern void BroadcastEventsExecutor__ctor_mF1328F911B2898B0F7A721E32C6932F70BECFFD3 (void);
// 0x000000C1 System.Collections.Generic.IList`1<UnityEngine.GameObject> ConsentManagementProviderLib.Observer.BroadcastReceivers::GetHandlersForEvent()
// 0x000000C2 System.Void ConsentManagementProviderLib.Observer.BroadcastReceivers::RegisterBroadcastReceiver(UnityEngine.GameObject)
// 0x000000C3 System.Void ConsentManagementProviderLib.Observer.BroadcastReceivers::UnregisterBroadcastReceiver(UnityEngine.GameObject)
// 0x000000C4 System.Void ConsentManagementProviderLib.Observer.BroadcastReceivers::.cctor()
extern void BroadcastReceivers__cctor_m3F0853AA3F4B6E04C249E8960CDD15464E225331 (void);
// 0x000000C5 ConsentManagementProviderLib.SpConsents ConsentManagementProviderLib.Json.JsonUnwrapper::UnwrapSpConsentsAndroid(System.String)
extern void JsonUnwrapper_UnwrapSpConsentsAndroid_m1F91C31480A740C4702CE239BA540228E06EF8BB (void);
// 0x000000C6 ConsentManagementProviderLib.SpCcpaConsent ConsentManagementProviderLib.Json.JsonUnwrapper::UnwrapSpCcpaConsentAndroid(ConsentManagementProviderLib.Json.CcpaConsentWrapper)
extern void JsonUnwrapper_UnwrapSpCcpaConsentAndroid_m9A219AC638B5C40D2F13BA3863CB9F7C1C1A510D (void);
// 0x000000C7 ConsentManagementProviderLib.SpGdprConsent ConsentManagementProviderLib.Json.JsonUnwrapper::UnwrapSpGdprConsentAndroid(ConsentManagementProviderLib.Json.SpGdprConsentWrapperAndroid)
extern void JsonUnwrapper_UnwrapSpGdprConsentAndroid_mD7BBAA8995FE280A3B840C224ABBD6CC77920CC0 (void);
// 0x000000C8 ConsentManagementProviderLib.Json.SpCustomConsentAndroid ConsentManagementProviderLib.Json.JsonUnwrapper::UnwrapSpCustomConsentAndroid(System.String)
extern void JsonUnwrapper_UnwrapSpCustomConsentAndroid_m3E2D92638C616671F787324A3D9779D67AC542C7 (void);
// 0x000000C9 ConsentManagementProviderLib.GdprConsent ConsentManagementProviderLib.Json.JsonUnwrapper::UnwrapGdprConsent(System.String)
extern void JsonUnwrapper_UnwrapGdprConsent_mAC0E57B4BE6B84077AF71E72069C98CBBBB822DB (void);
// 0x000000CA ConsentManagementProviderLib.SpConsents ConsentManagementProviderLib.Json.JsonUnwrapper::UnwrapSpConsents(System.String)
extern void JsonUnwrapper_UnwrapSpConsents_m9A1F513D30C11CD6127B36E16E92FF7B0FB95196 (void);
// 0x000000CB ConsentManagementProviderLib.SpGdprConsent ConsentManagementProviderLib.Json.JsonUnwrapper::UnwrapSpGdprConsent(ConsentManagementProviderLib.Json.SpGdprConsentWrapper)
extern void JsonUnwrapper_UnwrapSpGdprConsent_mD39FFDCDBBAB308014F7059EAC3A830B17BCB197 (void);
// 0x000000CC ConsentManagementProviderLib.GdprConsent ConsentManagementProviderLib.Json.JsonUnwrapper::UnwrapGdprConsent(ConsentManagementProviderLib.Json.GdprConsentWrapper)
extern void JsonUnwrapper_UnwrapGdprConsent_m21B54BF8A03E7829FACAC90747EF540E59956056 (void);
// 0x000000CD ConsentManagementProviderLib.SpCcpaConsent ConsentManagementProviderLib.Json.JsonUnwrapper::UnwrapSpCcpaConsent(ConsentManagementProviderLib.Json.SpCcpaConsentWrapper)
extern void JsonUnwrapper_UnwrapSpCcpaConsent_m25B71D55B89B229B9D1F94FAC34A1058AB94F160 (void);
// 0x000000CE ConsentManagementProviderLib.CcpaConsent ConsentManagementProviderLib.Json.JsonUnwrapper::UnwrapCcpaConsent(ConsentManagementProviderLib.Json.CcpaConsentWrapper)
extern void JsonUnwrapper_UnwrapCcpaConsent_mE5BA775D3F6A0E10E3C1992FF29967A6B4C1257D (void);
// 0x000000CF System.Void ConsentManagementProviderLib.Json.GdprConsentWrapper::.ctor()
extern void GdprConsentWrapper__ctor_m28BC52DC2892CFFF3B93F6EAD9DCAAE9314D8DB3 (void);
// 0x000000D0 System.Void ConsentManagementProviderLib.Json.SpVendorGrantWrapper::.ctor()
extern void SpVendorGrantWrapper__ctor_m1C1D0EEA93CFCBD0CAE86E7A3A640CCA2573D1FB (void);
// 0x000000D1 System.Void ConsentManagementProviderLib.Json.SpConsentsWrapperAndroid::.ctor()
extern void SpConsentsWrapperAndroid__ctor_m598B698B1C6476CE14023239530E8F68017D29B2 (void);
// 0x000000D2 System.Void ConsentManagementProviderLib.Json.SpCustomConsentAndroid::.ctor()
extern void SpCustomConsentAndroid__ctor_mBAE7B78B764DEE8F4095770EB6D2850D25DD8BD4 (void);
// 0x000000D3 System.Void ConsentManagementProviderLib.Json.SpGdprConsentWrapperAndroid::.ctor()
extern void SpGdprConsentWrapperAndroid__ctor_m90955F31A7EB4651B6FDCBBABC0082BFB18945E8 (void);
// 0x000000D4 System.Void ConsentManagementProviderLib.Json.CcpaConsentWrapper::.ctor()
extern void CcpaConsentWrapper__ctor_m31E0082B711F21288F6B2A592D726CA54F284D04 (void);
// 0x000000D5 System.Void ConsentManagementProviderLib.Json.SpCcpaConsentWrapper::.ctor()
extern void SpCcpaConsentWrapper__ctor_mA9D85B93B32315CF61E653E0F29FBFF87A2E2DBE (void);
// 0x000000D6 System.Void ConsentManagementProviderLib.Json.SpConsentsWrapper::.ctor()
extern void SpConsentsWrapper__ctor_mA602147B92EBE351FD2F91AC0FF06B1768DE72EE (void);
// 0x000000D7 System.Void ConsentManagementProviderLib.Json.SpGdprConsentWrapper::.ctor()
extern void SpGdprConsentWrapper__ctor_m6B1F714626EA036EAEA67F521621CC999BB0BA20 (void);
// 0x000000D8 System.Void ConsentManagementProviderLib.Enum.CSharp2JavaStringEnumMapper::.cctor()
extern void CSharp2JavaStringEnumMapper__cctor_mFC39332C52F38F0086E5A938CF5456050D6652AC (void);
// 0x000000D9 System.String ConsentManagementProviderLib.Enum.CSharp2JavaStringEnumMapper::GetMessageLanguageKey(ConsentManagementProviderLib.MESSAGE_LANGUAGE)
extern void CSharp2JavaStringEnumMapper_GetMessageLanguageKey_mD9F610BDF615051D4AE0FE5090EAD50CA00AAA2D (void);
// 0x000000DA System.String ConsentManagementProviderLib.Enum.CSharp2JavaStringEnumMapper::GetCampaignEnvKey(ConsentManagementProviderLib.CAMPAIGN_ENV)
extern void CSharp2JavaStringEnumMapper_GetCampaignEnvKey_mECA33D5F46B89E99EE50D8D9A668E42BE34D3626 (void);
// 0x000000DB System.String ConsentManagementProviderLib.Enum.CSharp2JavaStringEnumMapper::GetPrivacyManagerTabKey(ConsentManagementProviderLib.PRIVACY_MANAGER_TAB)
extern void CSharp2JavaStringEnumMapper_GetPrivacyManagerTabKey_m771475AA1FFC24AA4FD87547E3019D3E6B713A5D (void);
// 0x000000DC System.Void ConsentManagementProviderLib.Enum.CSharp2JavaStringEnumMapper::InitializeMapping()
extern void CSharp2JavaStringEnumMapper_InitializeMapping_m1A48FF69F9A7D04C49FE9FA8D088D22D25925983 (void);
// 0x000000DD System.Void ConsentManagementProviderLib.Enum.CSharp2JavaStringEnumMapper::InitializeMessageLanguageMapping()
extern void CSharp2JavaStringEnumMapper_InitializeMessageLanguageMapping_m06681AD0F1F09FA00451F872D4FD7D391A353251 (void);
// 0x000000DE System.Void ConsentManagementProviderLib.Enum.CSharp2JavaStringEnumMapper::InitializeCampaignEnvMapping()
extern void CSharp2JavaStringEnumMapper_InitializeCampaignEnvMapping_mB338AE9D11E9BD92020B5D8A6146A7126D8411B3 (void);
// 0x000000DF System.Void ConsentManagementProviderLib.Enum.CSharp2JavaStringEnumMapper::InitializePrivacyManagerTabMapping()
extern void CSharp2JavaStringEnumMapper_InitializePrivacyManagerTabMapping_m2CA995F2599481156395F5635869A47E979EB105 (void);
static Il2CppMethodPointer s_methodPointers[223] = 
{
	ConsentEventHandler_Awake_m814660283E70E14E5B6CFA7E64EF858590755C8D,
	ConsentEventHandler_OnConsentUIReady_mF0FF16271392E0556473AD05C47454C7B7495258,
	ConsentEventHandler_OnConsentAction_m54BE66B355CB35CD9130639A9A939AFAD5404D4D,
	ConsentEventHandler_OnConsentError_mEB9EC50AA4195B9AB50A8E3ADB91B256935EB252,
	ConsentEventHandler_OnConsentUIFinished_m4694366AE7078B56265BC4D84BFB6659A9D1DE05,
	ConsentEventHandler_OnConsentReady_m19668B5813FE4FA51803A3A2434C109DDBDFAA5E,
	ConsentEventHandler_OnDestroy_m4F79D0A2D6584FD6DC643A28FE1884AC3D96D68B,
	ConsentEventHandler__ctor_mAF3E0C8CA42531A592CF9AA7624EA73303CE910B,
	ConsentMessageProvider_Awake_m2B7FA04326E287EB832CD3A724327BD2FD52F4B5,
	ConsentMessageProvider_Start_m14BFAD1EDD51C888656B08CDF7F0B4C8EE956FAD,
	ConsentMessageProvider_OnDestroy_mE8BFE342724E6A76E7891A41CEF0C470A9719BB9,
	ConsentMessageProvider__ctor_m0EC25F3820168F56E044887B2D7733EADB82918F,
	CustomConsentButtonCaller_OnCustomConsentButtonClick_mF771CB39C3696F9C7B48DF73065BB6E959FAB1BC,
	CustomConsentButtonCaller_SuccessDelegate_m540DCD79E9EBE8B506A3C7433F8B74B0F3A13C66,
	CustomConsentButtonCaller__ctor_m5B5BF8FC92BCD5FD8AB0CF6D2E9B8A977FBBE8A2,
	PrivacyManagerButtonCaller_OnPrivacyManagerButtonClick_m9BCB18FCB44B5A1BE84430A06A3270607F3AB688,
	PrivacyManagerButtonCaller__ctor_mE6D06A18FEDF8804B63ECB1613E17FAA3249ACAF,
	ClickStubCmpButton_LogStubOnClick_m04EAC5CE63C9BADDA654B7503FBC1EB5E0A1F251,
	ClickStubCmpButton__ctor_mE6B72FB8EBD9397F73806632420F46E45B44ADA5,
	CmpButtonAnimatorController_OnPointerEnter_m77B3C9B7FE99549C3BF7A9E44C7CA40F8CD5DDEA,
	CmpButtonAnimatorController_OnPointerExit_m07C21B843E1D97E628FFCAAABE2A4E3AD7FA6947,
	CmpButtonAnimatorController__ctor_m31F00DEA8AB04C233CC58017F4EDB1D9BB3EC5C3,
	CmpCellAnimatorController_OnPointerEnter_m594B87E7EBF5D7BCBD38D461F0503E8021DEE40B,
	CmpCellAnimatorController_OnPointerExit_mE52FCEF155D7D763683CB74BE5F26EB085859025,
	CmpCellAnimatorController_SetIdle_mDE6DF2A3A814B5343836AD40C1A33DD1EAE8064B,
	CmpCellAnimatorController_SetActive_m3EA21E217D34BBA8988CA93894D42D80FACD9EFC,
	CmpCellAnimatorController__ctor_mE509DB559A9E8D653C3D1C3AC41784C174C1368B,
	CmpPartnersCounter_Awake_m3A3242E11CCB31E5348E2456A79B1FAE418B73FE,
	CmpPartnersCounter__ctor_m6BF43D6F4B43F7C730C0FCA1F82FE33BC013D6FF,
	CmpSwitch_Awake_m69F161110533B12B2CA475D28FC0DBFE59FEB1E4,
	CmpSwitch_OnButtonClick_m1A723AAB12C72BAE1D2A5A237FC09DFE0D660200,
	CmpSwitch_MoveActiveBackground_mFDBC1F9611F78FF6E697E816B159D5466ECD1418,
	CmpSwitch__ctor_mABD14F4F4ECE9F83D34A2403A1E24559AB99EBC0,
	CmpSwitch_U3CAwakeU3Eb__9_0_mD9747EB3821223611516456D11A21A4CFD0B2AEF,
	CmpSwitch_U3CAwakeU3Eb__9_1_mB3C9D92977DB5E44CBE7503DEC593DBAF2A519D6,
	TextColorAnimationController_SetIdleState_m6569C515CBDEA0870D6A8C96075BC84EF573BE94,
	TextColorAnimationController_SetActiveState_m159BD4FC195F13AA96DD96AF1CA2EFED3E1ABE89,
	TextColorAnimationController__ctor_mFBEB26607D593CAFC2BDE1674DCE203DC906B67A,
	GraphicExtenstion_ChangeColor_mBF25F61D8CAE5A27565FB1E3EB1976F5E14B7454,
	GraphicExtenstion_TriggerAnimation_mD85FFFC60D383C242B245CDE9AC31278E9931E97,
	GraphicExtenstion_ChangeLocalPosition_mEF1C08A0A159E5B1A27F0305A8C4C06A72C62796,
	U3CChangeColorU3Ed__0__ctor_mC98A5F45333621BAFA7DF61349485BEB0E5396A3,
	U3CChangeColorU3Ed__0_System_IDisposable_Dispose_mC5EF5C50E39600935EA2CD0ECAB21BC463C37ECF,
	U3CChangeColorU3Ed__0_MoveNext_mA5447CB03E30D24EC61758F913DF945DCA6593B8,
	U3CChangeColorU3Ed__0_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8B27C6CCF4DDB20AA95B4C07859F3E5C7F6ED6A3,
	U3CChangeColorU3Ed__0_System_Collections_IEnumerator_Reset_m6A627F248D2D1039C3C61326372B45F37C0A429D,
	U3CChangeColorU3Ed__0_System_Collections_IEnumerator_get_Current_m68597AD312422B82095C4C19989EFA8DF2EDFB9B,
	U3CTriggerAnimationU3Ed__1__ctor_m5792FEDEDC38C12879044163D836D19681C3626C,
	U3CTriggerAnimationU3Ed__1_System_IDisposable_Dispose_m0C61D41ADE60DFE11DD1188CB796940783B7D288,
	U3CTriggerAnimationU3Ed__1_MoveNext_m0B0A8FBE394FC01372CCA935C4E89D317FA2343B,
	U3CTriggerAnimationU3Ed__1_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF1D8477D990512D4427630B05BBB587504D4491B,
	U3CTriggerAnimationU3Ed__1_System_Collections_IEnumerator_Reset_m13EF902C54F4B7EFA7271790A410A6DE00A6A09D,
	U3CTriggerAnimationU3Ed__1_System_Collections_IEnumerator_get_Current_m7E30A51C6500F4ABC43818F531592FDFA12850AF,
	U3CChangeLocalPositionU3Ed__2__ctor_m92F0DBA0A5C63C7C0E03D62C02C3CD5DDA60068B,
	U3CChangeLocalPositionU3Ed__2_System_IDisposable_Dispose_m59FE8DB3F78A8E4149CA0B2500DD0B71B09A93E7,
	U3CChangeLocalPositionU3Ed__2_MoveNext_m818E2D5B09F4D758E368284322C436365BF9FD9C,
	U3CChangeLocalPositionU3Ed__2_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB5B0CD0CE6922C8491CB0091B1C16CF0F83E133D,
	U3CChangeLocalPositionU3Ed__2_System_Collections_IEnumerator_Reset_m3B3DFBCE2C9041386A2AEAB8A49AFEA8B0F36683,
	U3CChangeLocalPositionU3Ed__2_System_Collections_IEnumerator_get_Current_m6F78BEA03300744F2882F498B706CE06374BC0C2,
	CMP_Initialize_m7907A81B6744345E1C5B6CC89B30B644C98BBD9A,
	CMP_LoadMessage_m036EF93AE1C92C9918C3DAF9907DDBFC73FAA83C,
	CMP_LoadPrivacyManager_mAF332F8B3D25F6092F7C51215830FAEF814FDBED,
	CMP_CustomConsentGDPR_m9E16F21B7582F5E673F9A10F18DD733637F7EAF9,
	CMP_GetSpConsents_mF22EE2D3807BFC889B33827AC937922EB026DBFD,
	CMP_GetCustomConsent_m267235E514B1FC41312EA9B42E5D55B0632E4178,
	CMP_Dispose_m0DA166412DF92FB8D9A102B6F52B12884EB99E0F,
	CMP_CreateBroadcastExecutorGO_m345983EBA65B90B469396EF9999F8A27CC66E9E6,
	CMP_RemoveIos14SpCampaign_mA3E921DF7E81CD9775846B80E14D28255701C124,
	CMP_IsSpCampaignsValid_mFB62DB0DE215C700DF576FABC93DF88DE118BBE7,
	U3CU3Ec__cctor_mC546C6CB39BE4C2A2C9624525CAD6307D2EA42DC,
	U3CU3Ec__ctor_m4FDD840D36A8599B77C24109F57F7F571155F466,
	U3CU3Ec_U3CRemoveIos14SpCampaignU3Eb__9_0_mC3191719C71C29D829A45153CA4336B4C8949D55,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	SpCampaign_get_CampaignType_m9046FA64A454961E5D787EAE2FED73BCFB9D02A4,
	SpCampaign_get_TargetingParams_m6A8AF52B24827BD38C24C9400142EEEFB4F99685,
	SpCampaign__ctor_m407B4443651590F93272DFF2D653D95C6896CDD8,
	SpConsents__ctor_m589E47129B9637CE641503FCCF77FD2700C8B1BD,
	TargetingParam_get_Key_m5BF5F9840ED0FB291B65FA9FFD33029CEB005D21,
	TargetingParam_get_Value_mCB969B3E19D2D3BBE21EF98D472C428F58F80B0B,
	TargetingParam__ctor_m058BF6A9F13033C5C7960D981F11E60E75829064,
	CcpaConsent__ctor_mCD1BE40EB6ABB179F38D13CE11F7AD4CB97150A4,
	CcpaConsent__ctor_mDE63517B23E66ED3658EF26DB8FC766B74370303,
	GdprConsent__ctor_m5C9BCA8E693571FFBD321665576B5EBF905271B4,
	SpCcpaConsent__ctor_mD0D50A2DC5CEA97962E98ECFB5A995BE3B8CBA57,
	SpGdprConsent__ctor_mDA601023AFDAB501ED9E1A3F41D49922DEA1F5F7,
	SpVendorGrant__ctor_m47D2CE7BEB5E9562290E28FAA67682D72C70EA57,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CmpDebugUtil__cctor_m80EC4504AFC55B149CFB9A2D10D58586C304610B,
	CmpDebugUtil_EnableCmpLogs_mE1F369B8066338B8D28191998DDCA423E9198459,
	CmpDebugUtil_EnableGarbageCollectorDebugging_m50FF2714C6195CDB1E5FF13A5EB8AF3BCE1F6B0D,
	CmpDebugUtil_Log_mE8745E8065943A0C48C1C602D37A5E3C816E67CA,
	CmpDebugUtil_LogWarning_m0791EBB110268288BE6A27A974A1E11D1318D9B7,
	CmpDebugUtil_LogError_m62D4C5C648C86E9F0FF21809106B261E067143BC,
	CMPiOSListenerHelper__setUnityCallback_mB901E72D07AD34CDDDA154FC2F4E137DA64696AE,
	CMPiOSListenerHelper_Awake_m5431A1B5E3E8BC43985FCE3679F58AFE215C0AD1,
	CMPiOSListenerHelper_SetCustomConsentsGDPRSuccessAction_m26D8B9F76E4D0C356CD5B187295F59B6463499E7,
	CMPiOSListenerHelper_Callback_m48273542AE0E4F681A4633E27418940080E6B502,
	CMPiOSListenerHelper_OnConsentReady_mCF3FCCAC41A98BBCF3257F9C9453B2099E1FE66E,
	CMPiOSListenerHelper_OnConsentUIReady_m58AEDEE33171939C9610D60078D67D8765C82C81,
	CMPiOSListenerHelper_OnConsentAction_m5140CD47CC69DF0F4AC31E35A45901B9C0DA258F,
	CMPiOSListenerHelper_OnConsentUIFinished_mAE5E0F5D123266DF509D1882EB8351ECB37D7DC3,
	CMPiOSListenerHelper_OnErrorCallback_m2DC5E7BDDB17B78CBE8DB7FAD2749CC8664B3371,
	CMPiOSListenerHelper_OnCustomConsentGDPRCallback_m93681B2AB3EF7044EF0C0D6B7A100D0B7C136317,
	CMPiOSListenerHelper__ctor_mA77E1FB50FF77F245CD89997B5CD28B43B42FA49,
	ConsentWrapperIOS_get_Instance_m37DFD1FEB9D1086947CB8E153F705E4E2ED6FE5A,
	ConsentWrapperIOS_set_Instance_m28F7B56109C496E16AAAC0F6C62FFC698F7BA7A4,
	ConsentWrapperIOS__loadMessage_m72D60EF4F4581383DB3BBD7DF14BDF4BD2CC00FD,
	ConsentWrapperIOS__addTargetingParamForCampaignType_m3A59F78D744EB67127CD60D1718AADEF3866E15D,
	ConsentWrapperIOS__consrtuctLib_mFB28397C1E402693DC641996CBDE8A65EA0EB2A8,
	ConsentWrapperIOS__setMessageLanguage_m7670D36862F9563D571BB62DEF55B8738D7B2A4C,
	ConsentWrapperIOS__loadGDPRPrivacyManager_m8D3BA0D3F9F471713C9D8FF3BD0385D04ADA4DCF,
	ConsentWrapperIOS__loadCCPAPrivacyManager_mDC5549E54AEDB73C46144D7F82BB8B881FC9D4DF,
	ConsentWrapperIOS__cleanDict_mC11829A26E364E82A9E7AC628D045CC6A4D638D9,
	ConsentWrapperIOS__cleanArrays_m7BC357194E3C9CEC9C62434F0D5274066D85E910,
	ConsentWrapperIOS__customConsentGDPRWithVendors_m0ED81B9C478D92458704A23B5C79D5368CA5D1BC,
	ConsentWrapperIOS__addVendor_mB082D2DA5AE29D65261B85D7058DA74BBF236FC7,
	ConsentWrapperIOS__addLegIntCategory_mDBAD31F9B3E18435D90AAE1F4490D3FCF25B66B6,
	ConsentWrapperIOS__addCategory_mB99386CE2568DE636A23DB8D0F5BE738F0A19D96,
	ConsentWrapperIOS__ctor_m8D04D96B3EE6AD63224FFB4721C39169E1D423AF,
	ConsentWrapperIOS_CreateHelperIOSListener_m6817136754FF0FF73921FFB0FAC619097BBAFD7D,
	ConsentWrapperIOS_InitializeLib_m55DC343E0BE7F8B098A3F4338D5DCD9E6D5FC65A,
	ConsentWrapperIOS_LoadMessage_m9C2008B9D90848F32BE2B616F39283F41A37BB7F,
	ConsentWrapperIOS_LoadGDPRPrivacyManager_mA2C7D800D14019B1E7C6BA31F51EB4A3ABD197A3,
	ConsentWrapperIOS_LoadCCPAPrivacyManager_mC3FF732E6830A193927475B69405839D3FA4FB8A,
	ConsentWrapperIOS_CustomConsentGDPR_mCEA787B397BCDD921FC9FEAA22C097A38EF8A0F0,
	ConsentWrapperIOS_GetCustomGdprConsent_m437212C7F79F5A975C693C7EF5DBACCE932FEE16,
	ConsentWrapperIOS_GetSpConsents_m7E0CABF4406E6F4D15A2B9E522CDED01434ACDA1,
	ConsentWrapperIOS_Dispose_m76CA54CA019A97F6DBB01D61B2F8F5315C17738F,
	AndroidJavaConstruct__ctor_m5121468CF25809AC54ED11A301BB97A6EB305780,
	AndroidJavaConstruct_GetActivity_m41A2DBD16207DA124FE7B9E17CC7BDBFC3B26F3D,
	AndroidJavaConstruct_ConsrtuctLib_m15A13B58CA8F14C682B3DACC815268F03439827C,
	AndroidJavaConstruct_ConstructPrivacyManagerTab_m351816683C83BF7DE45FD22C3880E049ABD56BBD,
	AndroidJavaConstruct_ConstructCampaign_m5372D32EF946016921F07591023CA0D5C3B707F1,
	AndroidJavaConstruct_ConstructCampaignType_mAEF4FD4F447FB17459A6E90A7FAA22DDCF2C47C6,
	AndroidJavaConstruct_ConstructMessageLanguage_m93AF06F89A41AE19531A165104F56D161D67AB10,
	AndroidJavaConstruct_ConstructSpConfig_m60551D9E991FFBFFE43982D86486CBE8E1856445,
	AndroidJavaConstruct_ConstructTargetingParam_m9ECB8D6289085D880321AD8119139158FAF63358,
	AndroidJavaConstruct_ConstructCampaignEnv_mF2AEED39E3592B1AC9CD9A2A78D8880F62319318,
	AndroidJavaConstruct_Dispose_m83E914334964297572ADB868A2AE5D4DA80D3DC7,
	AndroidJavaConstruct__cctor_m98E5900377210226E853BF452DD10573BC514893,
	CmpJavaToUnityUtils_ConvertArrayToList_mD2533E492DF66053D5F6EE5F2996EF2B6878EE81,
	CmpJavaToUnityUtils_ConvertThrowableToError_mCCDC62B4F3502DDEA295649C6DE49B4711B23D4B,
	ConsentWrapperAndroid_get_Instance_mCFD28FEE776E45BEE8F13BAAD36EBE0C1FC7F46E,
	ConsentWrapperAndroid_set_Instance_mD31AC76647F8862E62EEF2DC02D8934F590495A2,
	ConsentWrapperAndroid__ctor_m62B418FB792A88C143EF49573C0AE184C7623530,
	ConsentWrapperAndroid_InitializeLib_mE275FFD1CC15366C7005FA19D10DBA0CF712EAB1,
	ConsentWrapperAndroid_LoadMessage_mDBBD302944A07DCED60F42D20483036EB786E7E7,
	ConsentWrapperAndroid_LoadPrivacyManager_m123A19FEE53F91F66F0092F8FCBDF401BA353AB2,
	ConsentWrapperAndroid_CustomConsentGDPR_mEC620B72A87577A9D3017CCE044E01695734F513,
	ConsentWrapperAndroid_GetCustomGdprConsent_m70F5707998200B04A5A6E1295CFA10334F9BD313,
	ConsentWrapperAndroid_Dispose_mFB0A682A61F3C80C90B5596AE47FB97A492E19E9,
	ConsentWrapperAndroid_CallShowView_m4411C5C59F49D2E915BEECDDCDF4AC3D1253FA2F,
	ConsentWrapperAndroid_CallRemoveView_m5D1CE623FEEC81612C8F19B16C4DD3F202D3A391,
	ConsentWrapperAndroid_RunOnUiThread_mB428DC31FC7AE07491D7C0679CBA0341F19EAD84,
	ConsentWrapperAndroid_InvokeLoadMessage_m8660CD9DAB1402CEE7A03B942A50B1D6B81F2A52,
	ConsentWrapperAndroid_InvokeLoadPrivacyManager_mBCD13239F55EB8C58E1A23C730A08737F53739E9,
	ConsentWrapperAndroid_InvokeLoadMessageWithAuthID_m716E6215BB1C63E6B5D116A53EFEEAA9B549840C,
	ConsentWrapperAndroid_GetSpConsents_m51F88961A4F135B1BACD150DFFC3802529CC4B3E,
	CustomConsentClient__ctor_m326C968B1D8D1C93E4FA6D4CBABB8EC8B46EA48E,
	CustomConsentClient_transferCustomConsentToUnity_m8ECC850FEA5FB497413F5E7B2694E98A9A07481C,
	CustomConsentClient__cctor_m4B21EC863B502B88562C2E9006CD596F019196B1,
	SpClientProxy__ctor_m96DCF449AA103A3B5C7A5E281A1EAF68AD58A3C1,
	SpClientProxy_onUIReady_m355F99312DAD8F41510027CEB8541BF12961BB40,
	SpClientProxy_onUIFinished_mEA9EE9927A046EC2322F8B548009F110B41D8BBF,
	SpClientProxy_onAction_mB75B8A42BD42A7802457FE0924182F3189DC8BBC,
	SpClientProxy_onConsentReady_mDD264AAA6257317AE752726C25895CB2CC8638BE,
	SpClientProxy_onError_mFC05E6E8C2238318541593BE163FDC81335D7C8D,
	SpClientProxy_onConsentReady_mC177D14AF6243D9E8E24BB7826EFBD2E468FF572,
	SpClientProxy_onMessageReady_mB5B8B57A2DB0994CADCF4B806E3CAE8F64E0FEA0,
	SpClientProxy__cctor_m463861359639EDA4CE07B035CB8AC8636F17A5A5,
	NULL,
	BroadcastEventDispatcher__cctor_mA36784AB3F39C1BF74288783AD6512C11FBADBF8,
	NULL,
	NULL,
	NULL,
	BroadcastEventsExecutor_Awake_mB9D6C5233F4875391A64CAF0733A44BB9DB000B5,
	BroadcastEventsExecutor_Update_m1C9FA3F6B38C9CD7D8FBD1CCDD67C667C48ECDC7,
	BroadcastEventsExecutor__ctor_mF1328F911B2898B0F7A721E32C6932F70BECFFD3,
	NULL,
	NULL,
	NULL,
	BroadcastReceivers__cctor_m3F0853AA3F4B6E04C249E8960CDD15464E225331,
	JsonUnwrapper_UnwrapSpConsentsAndroid_m1F91C31480A740C4702CE239BA540228E06EF8BB,
	JsonUnwrapper_UnwrapSpCcpaConsentAndroid_m9A219AC638B5C40D2F13BA3863CB9F7C1C1A510D,
	JsonUnwrapper_UnwrapSpGdprConsentAndroid_mD7BBAA8995FE280A3B840C224ABBD6CC77920CC0,
	JsonUnwrapper_UnwrapSpCustomConsentAndroid_m3E2D92638C616671F787324A3D9779D67AC542C7,
	JsonUnwrapper_UnwrapGdprConsent_mAC0E57B4BE6B84077AF71E72069C98CBBBB822DB,
	JsonUnwrapper_UnwrapSpConsents_m9A1F513D30C11CD6127B36E16E92FF7B0FB95196,
	JsonUnwrapper_UnwrapSpGdprConsent_mD39FFDCDBBAB308014F7059EAC3A830B17BCB197,
	JsonUnwrapper_UnwrapGdprConsent_m21B54BF8A03E7829FACAC90747EF540E59956056,
	JsonUnwrapper_UnwrapSpCcpaConsent_m25B71D55B89B229B9D1F94FAC34A1058AB94F160,
	JsonUnwrapper_UnwrapCcpaConsent_mE5BA775D3F6A0E10E3C1992FF29967A6B4C1257D,
	GdprConsentWrapper__ctor_m28BC52DC2892CFFF3B93F6EAD9DCAAE9314D8DB3,
	SpVendorGrantWrapper__ctor_m1C1D0EEA93CFCBD0CAE86E7A3A640CCA2573D1FB,
	SpConsentsWrapperAndroid__ctor_m598B698B1C6476CE14023239530E8F68017D29B2,
	SpCustomConsentAndroid__ctor_mBAE7B78B764DEE8F4095770EB6D2850D25DD8BD4,
	SpGdprConsentWrapperAndroid__ctor_m90955F31A7EB4651B6FDCBBABC0082BFB18945E8,
	CcpaConsentWrapper__ctor_m31E0082B711F21288F6B2A592D726CA54F284D04,
	SpCcpaConsentWrapper__ctor_mA9D85B93B32315CF61E653E0F29FBFF87A2E2DBE,
	SpConsentsWrapper__ctor_mA602147B92EBE351FD2F91AC0FF06B1768DE72EE,
	SpGdprConsentWrapper__ctor_m6B1F714626EA036EAEA67F521621CC999BB0BA20,
	CSharp2JavaStringEnumMapper__cctor_mFC39332C52F38F0086E5A938CF5456050D6652AC,
	CSharp2JavaStringEnumMapper_GetMessageLanguageKey_mD9F610BDF615051D4AE0FE5090EAD50CA00AAA2D,
	CSharp2JavaStringEnumMapper_GetCampaignEnvKey_mECA33D5F46B89E99EE50D8D9A668E42BE34D3626,
	CSharp2JavaStringEnumMapper_GetPrivacyManagerTabKey_m771475AA1FFC24AA4FD87547E3019D3E6B713A5D,
	CSharp2JavaStringEnumMapper_InitializeMapping_m1A48FF69F9A7D04C49FE9FA8D088D22D25925983,
	CSharp2JavaStringEnumMapper_InitializeMessageLanguageMapping_m06681AD0F1F09FA00451F872D4FD7D391A353251,
	CSharp2JavaStringEnumMapper_InitializeCampaignEnvMapping_mB338AE9D11E9BD92020B5D8A6146A7126D8411B3,
	CSharp2JavaStringEnumMapper_InitializePrivacyManagerTabMapping_m2CA995F2599481156395F5635869A47E979EB105,
};
static const int32_t s_InvokerIndices[223] = 
{
	1782,
	1782,
	1522,
	1536,
	1782,
	1536,
	1782,
	1782,
	1782,
	1782,
	1782,
	1782,
	1782,
	1536,
	1782,
	1782,
	1782,
	1782,
	1782,
	1536,
	1536,
	1782,
	1536,
	1536,
	1782,
	1782,
	1782,
	1782,
	1782,
	1782,
	1522,
	989,
	1782,
	1782,
	1782,
	1782,
	1782,
	1782,
	2462,
	2230,
	2236,
	1522,
	1782,
	1768,
	1745,
	1782,
	1745,
	1522,
	1782,
	1768,
	1745,
	1782,
	1745,
	1522,
	1782,
	1768,
	1745,
	1782,
	1745,
	1882,
	2876,
	2318,
	2134,
	2931,
	2931,
	2943,
	2943,
	2869,
	2833,
	2943,
	1782,
	1367,
	1522,
	1536,
	1536,
	1782,
	1782,
	1727,
	1745,
	911,
	983,
	1745,
	1745,
	983,
	152,
	152,
	1782,
	1536,
	1536,
	1536,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	2943,
	2878,
	2878,
	2876,
	2876,
	2876,
	2876,
	1782,
	1536,
	1536,
	1536,
	1536,
	1536,
	1536,
	1536,
	1536,
	1782,
	2931,
	2876,
	2876,
	2319,
	1878,
	2873,
	2628,
	2628,
	2943,
	2943,
	2943,
	2876,
	2876,
	2876,
	1782,
	2943,
	87,
	1536,
	977,
	977,
	355,
	1745,
	1745,
	1782,
	1782,
	2931,
	441,
	1230,
	440,
	1230,
	1230,
	59,
	723,
	1230,
	1782,
	2943,
	2811,
	2811,
	2931,
	2876,
	1782,
	87,
	1536,
	542,
	355,
	1745,
	1782,
	1536,
	1536,
	1536,
	1782,
	354,
	1536,
	1745,
	1536,
	1536,
	2943,
	1782,
	1536,
	1536,
	983,
	1536,
	1536,
	1536,
	1536,
	2943,
	-1,
	2943,
	-1,
	-1,
	-1,
	1782,
	1782,
	1782,
	-1,
	-1,
	-1,
	2943,
	2811,
	2811,
	2811,
	2811,
	2811,
	2811,
	2811,
	2811,
	2811,
	2811,
	1782,
	1782,
	1782,
	1782,
	1782,
	1782,
	1782,
	1782,
	1782,
	2943,
	2808,
	2808,
	2808,
	2943,
	2943,
	2943,
	2943,
};
static const Il2CppTokenRangePair s_rgctxIndices[9] = 
{
	{ 0x02000027, { 11, 3 } },
	{ 0x02000032, { 21, 1 } },
	{ 0x0600005B, { 0, 1 } },
	{ 0x0600005C, { 1, 1 } },
	{ 0x0600005D, { 2, 9 } },
	{ 0x060000B9, { 14, 7 } },
	{ 0x060000C1, { 22, 1 } },
	{ 0x060000C2, { 23, 1 } },
	{ 0x060000C3, { 24, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[25] = 
{
	{ (Il2CppRGCTXDataType)3, 11627 },
	{ (Il2CppRGCTXDataType)3, 11629 },
	{ (Il2CppRGCTXDataType)1, 87 },
	{ (Il2CppRGCTXDataType)2, 697 },
	{ (Il2CppRGCTXDataType)3, 34 },
	{ (Il2CppRGCTXDataType)3, 35 },
	{ (Il2CppRGCTXDataType)3, 36 },
	{ (Il2CppRGCTXDataType)3, 37 },
	{ (Il2CppRGCTXDataType)2, 689 },
	{ (Il2CppRGCTXDataType)3, 17 },
	{ (Il2CppRGCTXDataType)3, 18 },
	{ (Il2CppRGCTXDataType)2, 690 },
	{ (Il2CppRGCTXDataType)3, 19 },
	{ (Il2CppRGCTXDataType)2, 690 },
	{ (Il2CppRGCTXDataType)2, 693 },
	{ (Il2CppRGCTXDataType)3, 24 },
	{ (Il2CppRGCTXDataType)3, 11625 },
	{ (Il2CppRGCTXDataType)1, 69 },
	{ (Il2CppRGCTXDataType)2, 696 },
	{ (Il2CppRGCTXDataType)3, 30 },
	{ (Il2CppRGCTXDataType)3, 31 },
	{ (Il2CppRGCTXDataType)3, 11739 },
	{ (Il2CppRGCTXDataType)1, 70 },
	{ (Il2CppRGCTXDataType)1, 71 },
	{ (Il2CppRGCTXDataType)1, 72 },
};
extern const CustomAttributesCacheGenerator g_AssemblyU2DCSharp_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	223,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	9,
	s_rgctxIndices,
	25,
	s_rgctxValues,
	NULL,
	g_AssemblyU2DCSharp_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
