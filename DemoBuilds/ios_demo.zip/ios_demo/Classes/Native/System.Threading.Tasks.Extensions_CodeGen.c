﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Microsoft.CodeAnalysis.EmbeddedAttribute::.ctor()
extern void EmbeddedAttribute__ctor_mCB1F3EC182E4244375AA5860196B7174464296EB (void);
// 0x00000002 System.Void System.Runtime.CompilerServices.IsReadOnlyAttribute::.ctor()
extern void IsReadOnlyAttribute__ctor_m9022BF8F3F70511C759CB64F33D936A09C568E82 (void);
// 0x00000003 System.Void System.ThrowHelper::ThrowArgumentNullException(System.ExceptionArgument)
extern void ThrowHelper_ThrowArgumentNullException_m58505DB8941A68CDC7B5C9E720456C6464DDA71F (void);
// 0x00000004 System.ArgumentNullException System.ThrowHelper::GetArgumentNullException(System.ExceptionArgument)
extern void ThrowHelper_GetArgumentNullException_m6C50728A84EC19B63F00E38CA823AD065D172971 (void);
// 0x00000005 System.String System.ThrowHelper::GetArgumentName(System.ExceptionArgument)
extern void ThrowHelper_GetArgumentName_m39B4DDE930E1C01D25E88D7615CBD4D95435FB67 (void);
// 0x00000006 System.Void System.Threading.Tasks.ValueTask::.ctor(System.Threading.Tasks.Task)
extern void ValueTask__ctor_m975D708070BC01E6BCEE8C2E61E3DE928F8B20E4 (void);
// 0x00000007 System.Int32 System.Threading.Tasks.ValueTask::GetHashCode()
extern void ValueTask_GetHashCode_m158970B1DD3DAF5234C01F4432725726CBBE220B (void);
// 0x00000008 System.Boolean System.Threading.Tasks.ValueTask::Equals(System.Object)
extern void ValueTask_Equals_m7A88C17E06E7B9CA1414C8CB8803951E7144ACC9 (void);
// 0x00000009 System.Boolean System.Threading.Tasks.ValueTask::Equals(System.Threading.Tasks.ValueTask)
extern void ValueTask_Equals_m4BF54849B66845D4746F32108CA53127D15D9DB0 (void);
// 0x0000000A System.Void System.Threading.Tasks.ValueTask::.cctor()
extern void ValueTask__cctor_m01240BD4BAF620AF055D7C8BE12B543C18F6DB70 (void);
// 0x0000000B System.Void System.Threading.Tasks.ValueTask`1::.ctor(TResult)
// 0x0000000C System.Void System.Threading.Tasks.ValueTask`1::.ctor(System.Threading.Tasks.Task`1<TResult>)
// 0x0000000D System.Int32 System.Threading.Tasks.ValueTask`1::GetHashCode()
// 0x0000000E System.Boolean System.Threading.Tasks.ValueTask`1::Equals(System.Object)
// 0x0000000F System.Boolean System.Threading.Tasks.ValueTask`1::Equals(System.Threading.Tasks.ValueTask`1<TResult>)
// 0x00000010 System.Boolean System.Threading.Tasks.ValueTask`1::get_IsCompletedSuccessfully()
// 0x00000011 TResult System.Threading.Tasks.ValueTask`1::get_Result()
// 0x00000012 System.String System.Threading.Tasks.ValueTask`1::ToString()
// 0x00000013 System.Threading.Tasks.Sources.ValueTaskSourceStatus System.Threading.Tasks.Sources.IValueTaskSource`1::GetStatus(System.Int16)
// 0x00000014 TResult System.Threading.Tasks.Sources.IValueTaskSource`1::GetResult(System.Int16)
// 0x00000015 System.Void System.Runtime.CompilerServices.AsyncMethodBuilderAttribute::.ctor(System.Type)
extern void AsyncMethodBuilderAttribute__ctor_m4E3C84FE67413BD5777E5944C811C904D7DED2CB (void);
// 0x00000016 System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::Create()
extern void AsyncValueTaskMethodBuilder_Create_m91AA50E74EDEADF35C50D6AC01C4677755A3F869 (void);
// 0x00000017 System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::Start(TStateMachine&)
// 0x00000018 System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void AsyncValueTaskMethodBuilder_SetStateMachine_m3188B03A10264F946C66E4219B762F5E8DA834DF (void);
// 0x00000019 System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::SetResult()
extern void AsyncValueTaskMethodBuilder_SetResult_m965DBAD8BBA26DB5B979D5CE7A8D30B2ED6D4AA1 (void);
// 0x0000001A System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::SetException(System.Exception)
extern void AsyncValueTaskMethodBuilder_SetException_m9B47529F90B538885E5FE9B831021AB356858933 (void);
// 0x0000001B System.Threading.Tasks.ValueTask System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::get_Task()
extern void AsyncValueTaskMethodBuilder_get_Task_m2B6F5A6C131C7300C907BA7E8F39EF07B0A9501E (void);
// 0x0000001C System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::AwaitUnsafeOnCompleted(TAwaiter&,TStateMachine&)
// 0x0000001D System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1<TResult> System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1::Create()
// 0x0000001E System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1::Start(TStateMachine&)
// 0x0000001F System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
// 0x00000020 System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1::SetResult(TResult)
// 0x00000021 System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1::SetException(System.Exception)
// 0x00000022 System.Threading.Tasks.ValueTask`1<TResult> System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1::get_Task()
// 0x00000023 System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder`1::AwaitUnsafeOnCompleted(TAwaiter&,TStateMachine&)
static Il2CppMethodPointer s_methodPointers[35] = 
{
	EmbeddedAttribute__ctor_mCB1F3EC182E4244375AA5860196B7174464296EB,
	IsReadOnlyAttribute__ctor_m9022BF8F3F70511C759CB64F33D936A09C568E82,
	ThrowHelper_ThrowArgumentNullException_m58505DB8941A68CDC7B5C9E720456C6464DDA71F,
	ThrowHelper_GetArgumentNullException_m6C50728A84EC19B63F00E38CA823AD065D172971,
	ThrowHelper_GetArgumentName_m39B4DDE930E1C01D25E88D7615CBD4D95435FB67,
	ValueTask__ctor_m975D708070BC01E6BCEE8C2E61E3DE928F8B20E4,
	ValueTask_GetHashCode_m158970B1DD3DAF5234C01F4432725726CBBE220B,
	ValueTask_Equals_m7A88C17E06E7B9CA1414C8CB8803951E7144ACC9,
	ValueTask_Equals_m4BF54849B66845D4746F32108CA53127D15D9DB0,
	ValueTask__cctor_m01240BD4BAF620AF055D7C8BE12B543C18F6DB70,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	AsyncMethodBuilderAttribute__ctor_m4E3C84FE67413BD5777E5944C811C904D7DED2CB,
	AsyncValueTaskMethodBuilder_Create_m91AA50E74EDEADF35C50D6AC01C4677755A3F869,
	NULL,
	AsyncValueTaskMethodBuilder_SetStateMachine_m3188B03A10264F946C66E4219B762F5E8DA834DF,
	AsyncValueTaskMethodBuilder_SetResult_m965DBAD8BBA26DB5B979D5CE7A8D30B2ED6D4AA1,
	AsyncValueTaskMethodBuilder_SetException_m9B47529F90B538885E5FE9B831021AB356858933,
	AsyncValueTaskMethodBuilder_get_Task_m2B6F5A6C131C7300C907BA7E8F39EF07B0A9501E,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
extern void ValueTask__ctor_m975D708070BC01E6BCEE8C2E61E3DE928F8B20E4_AdjustorThunk (void);
extern void ValueTask_GetHashCode_m158970B1DD3DAF5234C01F4432725726CBBE220B_AdjustorThunk (void);
extern void ValueTask_Equals_m7A88C17E06E7B9CA1414C8CB8803951E7144ACC9_AdjustorThunk (void);
extern void ValueTask_Equals_m4BF54849B66845D4746F32108CA53127D15D9DB0_AdjustorThunk (void);
extern void AsyncValueTaskMethodBuilder_SetStateMachine_m3188B03A10264F946C66E4219B762F5E8DA834DF_AdjustorThunk (void);
extern void AsyncValueTaskMethodBuilder_SetResult_m965DBAD8BBA26DB5B979D5CE7A8D30B2ED6D4AA1_AdjustorThunk (void);
extern void AsyncValueTaskMethodBuilder_SetException_m9B47529F90B538885E5FE9B831021AB356858933_AdjustorThunk (void);
extern void AsyncValueTaskMethodBuilder_get_Task_m2B6F5A6C131C7300C907BA7E8F39EF07B0A9501E_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[8] = 
{
	{ 0x06000006, ValueTask__ctor_m975D708070BC01E6BCEE8C2E61E3DE928F8B20E4_AdjustorThunk },
	{ 0x06000007, ValueTask_GetHashCode_m158970B1DD3DAF5234C01F4432725726CBBE220B_AdjustorThunk },
	{ 0x06000008, ValueTask_Equals_m7A88C17E06E7B9CA1414C8CB8803951E7144ACC9_AdjustorThunk },
	{ 0x06000009, ValueTask_Equals_m4BF54849B66845D4746F32108CA53127D15D9DB0_AdjustorThunk },
	{ 0x06000018, AsyncValueTaskMethodBuilder_SetStateMachine_m3188B03A10264F946C66E4219B762F5E8DA834DF_AdjustorThunk },
	{ 0x06000019, AsyncValueTaskMethodBuilder_SetResult_m965DBAD8BBA26DB5B979D5CE7A8D30B2ED6D4AA1_AdjustorThunk },
	{ 0x0600001A, AsyncValueTaskMethodBuilder_SetException_m9B47529F90B538885E5FE9B831021AB356858933_AdjustorThunk },
	{ 0x0600001B, AsyncValueTaskMethodBuilder_get_Task_m2B6F5A6C131C7300C907BA7E8F39EF07B0A9501E_AdjustorThunk },
};
static const int32_t s_InvokerIndices[35] = 
{
	1782,
	1782,
	2871,
	2806,
	2806,
	1530,
	1727,
	1362,
	1393,
	2941,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	1530,
	2916,
	-1,
	1530,
	1782,
	1530,
	1777,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
};
static const Il2CppTokenRangePair s_rgctxIndices[6] = 
{
	{ 0x02000007, { 0, 13 } },
	{ 0x0200000C, { 15, 7 } },
	{ 0x06000017, { 13, 1 } },
	{ 0x0600001C, { 14, 1 } },
	{ 0x0600001E, { 22, 1 } },
	{ 0x06000023, { 23, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[24] = 
{
	{ (Il2CppRGCTXDataType)2, 444 },
	{ (Il2CppRGCTXDataType)2, 2330 },
	{ (Il2CppRGCTXDataType)3, 10250 },
	{ (Il2CppRGCTXDataType)3, 3190 },
	{ (Il2CppRGCTXDataType)2, 1043 },
	{ (Il2CppRGCTXDataType)3, 3189 },
	{ (Il2CppRGCTXDataType)2, 2262 },
	{ (Il2CppRGCTXDataType)3, 12445 },
	{ (Il2CppRGCTXDataType)2, 1603 },
	{ (Il2CppRGCTXDataType)3, 9850 },
	{ (Il2CppRGCTXDataType)3, 9799 },
	{ (Il2CppRGCTXDataType)3, 10251 },
	{ (Il2CppRGCTXDataType)3, 10252 },
	{ (Il2CppRGCTXDataType)3, 11697 },
	{ (Il2CppRGCTXDataType)3, 11691 },
	{ (Il2CppRGCTXDataType)3, 922 },
	{ (Il2CppRGCTXDataType)3, 921 },
	{ (Il2CppRGCTXDataType)3, 920 },
	{ (Il2CppRGCTXDataType)2, 2329 },
	{ (Il2CppRGCTXDataType)3, 10248 },
	{ (Il2CppRGCTXDataType)3, 923 },
	{ (Il2CppRGCTXDataType)3, 10249 },
	{ (Il2CppRGCTXDataType)3, 919 },
	{ (Il2CppRGCTXDataType)3, 918 },
};
extern const CustomAttributesCacheGenerator g_System_Threading_Tasks_Extensions_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_System_Threading_Tasks_Extensions_CodeGenModule;
const Il2CppCodeGenModule g_System_Threading_Tasks_Extensions_CodeGenModule = 
{
	"System.Threading.Tasks.Extensions.dll",
	35,
	s_methodPointers,
	8,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	6,
	s_rgctxIndices,
	24,
	s_rgctxValues,
	NULL,
	g_System_Threading_Tasks_Extensions_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
