﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>
#include <stdint.h>



// System.Char[]
struct CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34;
// System.Runtime.CompilerServices.CompilationRelaxationsAttribute
struct CompilationRelaxationsAttribute_t661FDDC06629BDA607A42BD660944F039FE03AFF;
// System.Runtime.CompilerServices.CompilerGeneratedAttribute
struct CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C;
// System.Diagnostics.DebuggableAttribute
struct DebuggableAttribute_tA8054EBD0FC7511695D494B690B5771658E3191B;
// System.Text.Json.Serialization.JsonIncludeAttribute
struct JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45;
// System.ParamArrayAttribute
struct ParamArrayAttribute_t9DCEB4CDDB8EDDB1124171D4C51FA6069EEA5C5F;
// System.Runtime.CompilerServices.RuntimeCompatibilityAttribute
struct RuntimeCompatibilityAttribute_tFF99AB2963098F9CBCD47A20D9FD3D51C17C1C80;
// UnityEngine.SerializeField
struct SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25;
// System.String
struct String_t;



IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object


// System.Attribute
struct  Attribute_t037CA9D9F3B742C063DB364D2EEBBF9FC5772C71  : public RuntimeObject
{
public:

public:
};


// System.ValueType
struct  ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_com
{
};

// System.Boolean
struct  Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Runtime.CompilerServices.CompilationRelaxationsAttribute
struct  CompilationRelaxationsAttribute_t661FDDC06629BDA607A42BD660944F039FE03AFF  : public Attribute_t037CA9D9F3B742C063DB364D2EEBBF9FC5772C71
{
public:
	// System.Int32 System.Runtime.CompilerServices.CompilationRelaxationsAttribute::m_relaxations
	int32_t ___m_relaxations_0;

public:
	inline static int32_t get_offset_of_m_relaxations_0() { return static_cast<int32_t>(offsetof(CompilationRelaxationsAttribute_t661FDDC06629BDA607A42BD660944F039FE03AFF, ___m_relaxations_0)); }
	inline int32_t get_m_relaxations_0() const { return ___m_relaxations_0; }
	inline int32_t* get_address_of_m_relaxations_0() { return &___m_relaxations_0; }
	inline void set_m_relaxations_0(int32_t value)
	{
		___m_relaxations_0 = value;
	}
};


// System.Runtime.CompilerServices.CompilerGeneratedAttribute
struct  CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C  : public Attribute_t037CA9D9F3B742C063DB364D2EEBBF9FC5772C71
{
public:

public:
};


// System.Enum
struct  Enum_t23B90B40F60E677A8025267341651C94AE079CDA  : public ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52
{
public:

public:
};

struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_com
{
};

// System.Text.Json.Serialization.JsonAttribute
struct  JsonAttribute_tAFFD32A57EF2BDE3F59649287DCF3A583395800D  : public Attribute_t037CA9D9F3B742C063DB364D2EEBBF9FC5772C71
{
public:

public:
};


// System.ParamArrayAttribute
struct  ParamArrayAttribute_t9DCEB4CDDB8EDDB1124171D4C51FA6069EEA5C5F  : public Attribute_t037CA9D9F3B742C063DB364D2EEBBF9FC5772C71
{
public:

public:
};


// System.Runtime.CompilerServices.RuntimeCompatibilityAttribute
struct  RuntimeCompatibilityAttribute_tFF99AB2963098F9CBCD47A20D9FD3D51C17C1C80  : public Attribute_t037CA9D9F3B742C063DB364D2EEBBF9FC5772C71
{
public:
	// System.Boolean System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::m_wrapNonExceptionThrows
	bool ___m_wrapNonExceptionThrows_0;

public:
	inline static int32_t get_offset_of_m_wrapNonExceptionThrows_0() { return static_cast<int32_t>(offsetof(RuntimeCompatibilityAttribute_tFF99AB2963098F9CBCD47A20D9FD3D51C17C1C80, ___m_wrapNonExceptionThrows_0)); }
	inline bool get_m_wrapNonExceptionThrows_0() const { return ___m_wrapNonExceptionThrows_0; }
	inline bool* get_address_of_m_wrapNonExceptionThrows_0() { return &___m_wrapNonExceptionThrows_0; }
	inline void set_m_wrapNonExceptionThrows_0(bool value)
	{
		___m_wrapNonExceptionThrows_0 = value;
	}
};


// UnityEngine.SerializeField
struct  SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25  : public Attribute_t037CA9D9F3B742C063DB364D2EEBBF9FC5772C71
{
public:

public:
};


// System.Void
struct  Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5__padding[1];
	};

public:
};


// System.Text.Json.Serialization.JsonIncludeAttribute
struct  JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45  : public JsonAttribute_tAFFD32A57EF2BDE3F59649287DCF3A583395800D
{
public:

public:
};


// System.Diagnostics.DebuggableAttribute/DebuggingModes
struct  DebuggingModes_t279D5B9C012ABA935887CB73C5A63A1F46AF08A8 
{
public:
	// System.Int32 System.Diagnostics.DebuggableAttribute/DebuggingModes::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(DebuggingModes_t279D5B9C012ABA935887CB73C5A63A1F46AF08A8, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Diagnostics.DebuggableAttribute
struct  DebuggableAttribute_tA8054EBD0FC7511695D494B690B5771658E3191B  : public Attribute_t037CA9D9F3B742C063DB364D2EEBBF9FC5772C71
{
public:
	// System.Diagnostics.DebuggableAttribute/DebuggingModes System.Diagnostics.DebuggableAttribute::m_debuggingModes
	int32_t ___m_debuggingModes_0;

public:
	inline static int32_t get_offset_of_m_debuggingModes_0() { return static_cast<int32_t>(offsetof(DebuggableAttribute_tA8054EBD0FC7511695D494B690B5771658E3191B, ___m_debuggingModes_0)); }
	inline int32_t get_m_debuggingModes_0() const { return ___m_debuggingModes_0; }
	inline int32_t* get_address_of_m_debuggingModes_0() { return &___m_debuggingModes_0; }
	inline void set_m_debuggingModes_0(int32_t value)
	{
		___m_debuggingModes_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif



// System.Void System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CompilationRelaxationsAttribute__ctor_mAC3079EBC4EEAB474EED8208EF95DB39C922333B (CompilationRelaxationsAttribute_t661FDDC06629BDA607A42BD660944F039FE03AFF * __this, int32_t ___relaxations0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RuntimeCompatibilityAttribute__ctor_m551DDF1438CE97A984571949723F30F44CF7317C (RuntimeCompatibilityAttribute_tFF99AB2963098F9CBCD47A20D9FD3D51C17C1C80 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::set_WrapNonExceptionThrows(System.Boolean)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m8562196F90F3EBCEC23B5708EE0332842883C490_inline (RuntimeCompatibilityAttribute_tFF99AB2963098F9CBCD47A20D9FD3D51C17C1C80 * __this, bool ___value0, const RuntimeMethod* method);
// System.Void System.Diagnostics.DebuggableAttribute::.ctor(System.Diagnostics.DebuggableAttribute/DebuggingModes)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DebuggableAttribute__ctor_m7FF445C8435494A4847123A668D889E692E55550 (DebuggableAttribute_tA8054EBD0FC7511695D494B690B5771658E3191B * __this, int32_t ___modes0, const RuntimeMethod* method);
// System.Void UnityEngine.SerializeField::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3 (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.Serialization.JsonIncludeAttribute::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790 (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * __this, const RuntimeMethod* method);
// System.Void System.ParamArrayAttribute::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ParamArrayAttribute__ctor_mCC72AFF718185BA7B87FD8D9471F1274400C5719 (ParamArrayAttribute_t9DCEB4CDDB8EDDB1124171D4C51FA6069EEA5C5F * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CompilerGeneratedAttribute__ctor_m9DC3E4E2DA76FE93948D44199213E2E924DCBE35 (CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C * __this, const RuntimeMethod* method);
static void AssemblyU2DCSharp_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilationRelaxationsAttribute_t661FDDC06629BDA607A42BD660944F039FE03AFF * tmp = (CompilationRelaxationsAttribute_t661FDDC06629BDA607A42BD660944F039FE03AFF *)cache->attributes[0];
		CompilationRelaxationsAttribute__ctor_mAC3079EBC4EEAB474EED8208EF95DB39C922333B(tmp, 8LL, NULL);
	}
	{
		RuntimeCompatibilityAttribute_tFF99AB2963098F9CBCD47A20D9FD3D51C17C1C80 * tmp = (RuntimeCompatibilityAttribute_tFF99AB2963098F9CBCD47A20D9FD3D51C17C1C80 *)cache->attributes[1];
		RuntimeCompatibilityAttribute__ctor_m551DDF1438CE97A984571949723F30F44CF7317C(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m8562196F90F3EBCEC23B5708EE0332842883C490_inline(tmp, true, NULL);
	}
	{
		DebuggableAttribute_tA8054EBD0FC7511695D494B690B5771658E3191B * tmp = (DebuggableAttribute_tA8054EBD0FC7511695D494B690B5771658E3191B *)cache->attributes[2];
		DebuggableAttribute__ctor_m7FF445C8435494A4847123A668D889E692E55550(tmp, 2LL, NULL);
	}
}
static void ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_allCampaignTypesToLoad(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_language(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_accountId(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_propertyName(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_messageTimeoutInSeconds(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_authID(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void CustomConsentButtonCaller_t8608E29D288D7C85292A6A4132BF9EAFA03506E9_CustomAttributesCacheGenerator_vendors(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void CustomConsentButtonCaller_t8608E29D288D7C85292A6A4132BF9EAFA03506E9_CustomAttributesCacheGenerator_categories(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void CustomConsentButtonCaller_t8608E29D288D7C85292A6A4132BF9EAFA03506E9_CustomAttributesCacheGenerator_legIntCategories(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void PrivacyManagerButtonCaller_tAC898FAD4F866FD3A0E52E87CD238E03A21AAFBF_CustomAttributesCacheGenerator_campaignType(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void PrivacyManagerButtonCaller_tAC898FAD4F866FD3A0E52E87CD238E03A21AAFBF_CustomAttributesCacheGenerator_privacyManagerTab(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void PrivacyManagerButtonCaller_tAC898FAD4F866FD3A0E52E87CD238E03A21AAFBF_CustomAttributesCacheGenerator_pmId(CustomAttributesCache* cache)
{
	{
		SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 * tmp = (SerializeField_t6B23EE6CC99B21C3EBD946352112832A70E67E25 *)cache->attributes[0];
		SerializeField__ctor_mDE6A7673BA2C1FAD03CFEC65C6D473CC37889DD3(tmp, NULL);
	}
}
static void SpConsents_t71C0EB30BF033494458D6DD641E7D506FD33C62C_CustomAttributesCacheGenerator_gdpr(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpConsents_t71C0EB30BF033494458D6DD641E7D506FD33C62C_CustomAttributesCacheGenerator_ccpa(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_addtlConsent(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_childPmId(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_consentedToAll(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_dateCreated(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_hasConsentData(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_rejectedAny(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CcpaConsent_t2A16197813433DAD1962E2360D84DE88C5DDC431_CustomAttributesCacheGenerator_status(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CcpaConsent_t2A16197813433DAD1962E2360D84DE88C5DDC431_CustomAttributesCacheGenerator_uspstring(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CcpaConsent_t2A16197813433DAD1962E2360D84DE88C5DDC431_CustomAttributesCacheGenerator_rejectedVendors(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CcpaConsent_t2A16197813433DAD1962E2360D84DE88C5DDC431_CustomAttributesCacheGenerator_rejectedCategories(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void GdprConsent_t4EB54DEFD75938BDD60ED61D47693D54A9669484_CustomAttributesCacheGenerator_euconsent(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void GdprConsent_t4EB54DEFD75938BDD60ED61D47693D54A9669484_CustomAttributesCacheGenerator_grants(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpCcpaConsent_t3A5B4BC231EFE0F4879D3F27DB63CAAAEE380500_CustomAttributesCacheGenerator_consents(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpGdprConsent_t358E35EF20F13F8BB1D86DABEF8E36B9210A63EE_CustomAttributesCacheGenerator_consents(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpVendorGrant_tD7833EDA2712E03327CD0B68F50993C75CD6BC73_CustomAttributesCacheGenerator_vendorGrant(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpVendorGrant_tD7833EDA2712E03327CD0B68F50993C75CD6BC73_CustomAttributesCacheGenerator_purposeGrants(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void ConsentMessenger_tCA196B8FC2F4918555DEB74A42C641B5205C811B_CustomAttributesCacheGenerator_ConsentMessenger_Broadcast_m6EDEAD2FD50D6FA78CC70A81142819DF98F70E9E____list0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t9DCEB4CDDB8EDDB1124171D4C51FA6069EEA5C5F * tmp = (ParamArrayAttribute_t9DCEB4CDDB8EDDB1124171D4C51FA6069EEA5C5F *)cache->attributes[0];
		ParamArrayAttribute__ctor_mCC72AFF718185BA7B87FD8D9471F1274400C5719(tmp, NULL);
	}
}
static void U3CU3Ec__DisplayClass2_0_1_tF3AE60AF29441F5F372BE3D7AF2BA15B805DD20C_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C * tmp = (CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m9DC3E4E2DA76FE93948D44199213E2E924DCBE35(tmp, NULL);
	}
}
static void U3CU3Ec__2_1_tE372ABAD2E043D4C5E57EC2E6E45BA3D474F72B9_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C * tmp = (CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m9DC3E4E2DA76FE93948D44199213E2E924DCBE35(tmp, NULL);
	}
}
static void U3CU3Ec__DisplayClass1_0_1_t92BCFCB77F82A830B729D8D1D3095BA4A2E7F3B0_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C * tmp = (CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m9DC3E4E2DA76FE93948D44199213E2E924DCBE35(tmp, NULL);
	}
}
static void U3CU3Ec__DisplayClass1_1_1_tEBAED1B7239136E6B15A06171AC2DCD4EC29211E_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C * tmp = (CompilerGeneratedAttribute_t39106AB982658D7A94C27DEF3C48DB2F5F7CD75C *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m9DC3E4E2DA76FE93948D44199213E2E924DCBE35(tmp, NULL);
	}
}
static void SpCustomConsentAndroid_tD733C91708DC4A69F6335575A88E83F4EDE507FA_CustomAttributesCacheGenerator_gdpr(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void GdprConsentWrapper_t88DE19E6ED2071C4AE2234523E4C521788097FBF_CustomAttributesCacheGenerator_euconsent(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void GdprConsentWrapper_t88DE19E6ED2071C4AE2234523E4C521788097FBF_CustomAttributesCacheGenerator_TCData(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void GdprConsentWrapper_t88DE19E6ED2071C4AE2234523E4C521788097FBF_CustomAttributesCacheGenerator_grants(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpVendorGrantWrapper_t66CED5FBA84A53B5A0234D477BBF608D8BA4B433_CustomAttributesCacheGenerator_vendorGrant(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpVendorGrantWrapper_t66CED5FBA84A53B5A0234D477BBF608D8BA4B433_CustomAttributesCacheGenerator_purposeGrants(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpCcpaConsentWrapperAndroid_t6FDDF71EC5FEC1CF7BF41C8BF357C5B7C698D9D4_CustomAttributesCacheGenerator_newUser(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpCcpaConsentWrapperAndroid_t6FDDF71EC5FEC1CF7BF41C8BF357C5B7C698D9D4_CustomAttributesCacheGenerator_rejectedAll(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpCcpaConsentWrapperAndroid_t6FDDF71EC5FEC1CF7BF41C8BF357C5B7C698D9D4_CustomAttributesCacheGenerator_signedLspa(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpCcpaConsentWrapperAndroid_t6FDDF71EC5FEC1CF7BF41C8BF357C5B7C698D9D4_CustomAttributesCacheGenerator_dateCreated(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpConsentsWrapperAndroid_t1BADB60ED2129FA8F9E0FF21C32FDEAE474B8E4B_CustomAttributesCacheGenerator_ccpa(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpConsentsWrapperAndroid_t1BADB60ED2129FA8F9E0FF21C32FDEAE474B8E4B_CustomAttributesCacheGenerator_gdpr(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_consentedToAll(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_addtlConsent(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_dateCreated(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_specialFeatures(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_acceptedVendors(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_legIntCategories(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_acceptedCategories(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CcpaConsentWrapper_t049ED5B366C39F88A3EE701D69457BB4B9BF4183_CustomAttributesCacheGenerator_status(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CcpaConsentWrapper_t049ED5B366C39F88A3EE701D69457BB4B9BF4183_CustomAttributesCacheGenerator_uspstring(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CcpaConsentWrapper_t049ED5B366C39F88A3EE701D69457BB4B9BF4183_CustomAttributesCacheGenerator_rejectedVendors(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void CcpaConsentWrapper_t049ED5B366C39F88A3EE701D69457BB4B9BF4183_CustomAttributesCacheGenerator_rejectedCategories(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpCcpaConsentWrapper_t8B7304873919810918ACB627BBFDE314B5DACF6A_CustomAttributesCacheGenerator_applies(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpCcpaConsentWrapper_t8B7304873919810918ACB627BBFDE314B5DACF6A_CustomAttributesCacheGenerator_consents(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpConsentsWrapper_tE6BFE842A07B9BDD841D245A03DCB398F2902188_CustomAttributesCacheGenerator_ccpa(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpConsentsWrapper_tE6BFE842A07B9BDD841D245A03DCB398F2902188_CustomAttributesCacheGenerator_gdpr(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpGdprConsentWrapper_t62CF85800AFCAD10C6DBBB71A86C3D3C81A9D3CB_CustomAttributesCacheGenerator_applies(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
static void SpGdprConsentWrapper_t62CF85800AFCAD10C6DBBB71A86C3D3C81A9D3CB_CustomAttributesCacheGenerator_consents(CustomAttributesCache* cache)
{
	{
		JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 * tmp = (JsonIncludeAttribute_t42FA83469AFC2D07F39E164E43AA09B20EB83E45 *)cache->attributes[0];
		JsonIncludeAttribute__ctor_m7CF1A7A2FFDAF7DC92F695E725D59C2371E38790(tmp, NULL);
	}
}
IL2CPP_EXTERN_C const CustomAttributesCacheGenerator g_AssemblyU2DCSharp_AttributeGenerators[];
const CustomAttributesCacheGenerator g_AssemblyU2DCSharp_AttributeGenerators[65] = 
{
	U3CU3Ec__DisplayClass2_0_1_tF3AE60AF29441F5F372BE3D7AF2BA15B805DD20C_CustomAttributesCacheGenerator,
	U3CU3Ec__2_1_tE372ABAD2E043D4C5E57EC2E6E45BA3D474F72B9_CustomAttributesCacheGenerator,
	U3CU3Ec__DisplayClass1_0_1_t92BCFCB77F82A830B729D8D1D3095BA4A2E7F3B0_CustomAttributesCacheGenerator,
	U3CU3Ec__DisplayClass1_1_1_tEBAED1B7239136E6B15A06171AC2DCD4EC29211E_CustomAttributesCacheGenerator,
	ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_allCampaignTypesToLoad,
	ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_language,
	ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_accountId,
	ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_propertyName,
	ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_messageTimeoutInSeconds,
	ConsentMessageProvider_t90404B0C67F8B830F921E157813465CB83E04707_CustomAttributesCacheGenerator_authID,
	CustomConsentButtonCaller_t8608E29D288D7C85292A6A4132BF9EAFA03506E9_CustomAttributesCacheGenerator_vendors,
	CustomConsentButtonCaller_t8608E29D288D7C85292A6A4132BF9EAFA03506E9_CustomAttributesCacheGenerator_categories,
	CustomConsentButtonCaller_t8608E29D288D7C85292A6A4132BF9EAFA03506E9_CustomAttributesCacheGenerator_legIntCategories,
	PrivacyManagerButtonCaller_tAC898FAD4F866FD3A0E52E87CD238E03A21AAFBF_CustomAttributesCacheGenerator_campaignType,
	PrivacyManagerButtonCaller_tAC898FAD4F866FD3A0E52E87CD238E03A21AAFBF_CustomAttributesCacheGenerator_privacyManagerTab,
	PrivacyManagerButtonCaller_tAC898FAD4F866FD3A0E52E87CD238E03A21AAFBF_CustomAttributesCacheGenerator_pmId,
	SpConsents_t71C0EB30BF033494458D6DD641E7D506FD33C62C_CustomAttributesCacheGenerator_gdpr,
	SpConsents_t71C0EB30BF033494458D6DD641E7D506FD33C62C_CustomAttributesCacheGenerator_ccpa,
	CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_addtlConsent,
	CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_childPmId,
	CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_consentedToAll,
	CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_dateCreated,
	CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_hasConsentData,
	CustomGdprAndroid_tB5E29DF9EEDB8B62DFA4197755C1866BBA792265_CustomAttributesCacheGenerator_rejectedAny,
	CcpaConsent_t2A16197813433DAD1962E2360D84DE88C5DDC431_CustomAttributesCacheGenerator_status,
	CcpaConsent_t2A16197813433DAD1962E2360D84DE88C5DDC431_CustomAttributesCacheGenerator_uspstring,
	CcpaConsent_t2A16197813433DAD1962E2360D84DE88C5DDC431_CustomAttributesCacheGenerator_rejectedVendors,
	CcpaConsent_t2A16197813433DAD1962E2360D84DE88C5DDC431_CustomAttributesCacheGenerator_rejectedCategories,
	GdprConsent_t4EB54DEFD75938BDD60ED61D47693D54A9669484_CustomAttributesCacheGenerator_euconsent,
	GdprConsent_t4EB54DEFD75938BDD60ED61D47693D54A9669484_CustomAttributesCacheGenerator_grants,
	SpCcpaConsent_t3A5B4BC231EFE0F4879D3F27DB63CAAAEE380500_CustomAttributesCacheGenerator_consents,
	SpGdprConsent_t358E35EF20F13F8BB1D86DABEF8E36B9210A63EE_CustomAttributesCacheGenerator_consents,
	SpVendorGrant_tD7833EDA2712E03327CD0B68F50993C75CD6BC73_CustomAttributesCacheGenerator_vendorGrant,
	SpVendorGrant_tD7833EDA2712E03327CD0B68F50993C75CD6BC73_CustomAttributesCacheGenerator_purposeGrants,
	SpCustomConsentAndroid_tD733C91708DC4A69F6335575A88E83F4EDE507FA_CustomAttributesCacheGenerator_gdpr,
	GdprConsentWrapper_t88DE19E6ED2071C4AE2234523E4C521788097FBF_CustomAttributesCacheGenerator_euconsent,
	GdprConsentWrapper_t88DE19E6ED2071C4AE2234523E4C521788097FBF_CustomAttributesCacheGenerator_TCData,
	GdprConsentWrapper_t88DE19E6ED2071C4AE2234523E4C521788097FBF_CustomAttributesCacheGenerator_grants,
	SpVendorGrantWrapper_t66CED5FBA84A53B5A0234D477BBF608D8BA4B433_CustomAttributesCacheGenerator_vendorGrant,
	SpVendorGrantWrapper_t66CED5FBA84A53B5A0234D477BBF608D8BA4B433_CustomAttributesCacheGenerator_purposeGrants,
	SpCcpaConsentWrapperAndroid_t6FDDF71EC5FEC1CF7BF41C8BF357C5B7C698D9D4_CustomAttributesCacheGenerator_newUser,
	SpCcpaConsentWrapperAndroid_t6FDDF71EC5FEC1CF7BF41C8BF357C5B7C698D9D4_CustomAttributesCacheGenerator_rejectedAll,
	SpCcpaConsentWrapperAndroid_t6FDDF71EC5FEC1CF7BF41C8BF357C5B7C698D9D4_CustomAttributesCacheGenerator_signedLspa,
	SpCcpaConsentWrapperAndroid_t6FDDF71EC5FEC1CF7BF41C8BF357C5B7C698D9D4_CustomAttributesCacheGenerator_dateCreated,
	SpConsentsWrapperAndroid_t1BADB60ED2129FA8F9E0FF21C32FDEAE474B8E4B_CustomAttributesCacheGenerator_ccpa,
	SpConsentsWrapperAndroid_t1BADB60ED2129FA8F9E0FF21C32FDEAE474B8E4B_CustomAttributesCacheGenerator_gdpr,
	SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_consentedToAll,
	SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_addtlConsent,
	SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_dateCreated,
	SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_specialFeatures,
	SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_acceptedVendors,
	SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_legIntCategories,
	SpGdprConsentWrapperAndroid_t2B6409244B5C2FEC49A475956CB985A7BD7C78FB_CustomAttributesCacheGenerator_acceptedCategories,
	CcpaConsentWrapper_t049ED5B366C39F88A3EE701D69457BB4B9BF4183_CustomAttributesCacheGenerator_status,
	CcpaConsentWrapper_t049ED5B366C39F88A3EE701D69457BB4B9BF4183_CustomAttributesCacheGenerator_uspstring,
	CcpaConsentWrapper_t049ED5B366C39F88A3EE701D69457BB4B9BF4183_CustomAttributesCacheGenerator_rejectedVendors,
	CcpaConsentWrapper_t049ED5B366C39F88A3EE701D69457BB4B9BF4183_CustomAttributesCacheGenerator_rejectedCategories,
	SpCcpaConsentWrapper_t8B7304873919810918ACB627BBFDE314B5DACF6A_CustomAttributesCacheGenerator_applies,
	SpCcpaConsentWrapper_t8B7304873919810918ACB627BBFDE314B5DACF6A_CustomAttributesCacheGenerator_consents,
	SpConsentsWrapper_tE6BFE842A07B9BDD841D245A03DCB398F2902188_CustomAttributesCacheGenerator_ccpa,
	SpConsentsWrapper_tE6BFE842A07B9BDD841D245A03DCB398F2902188_CustomAttributesCacheGenerator_gdpr,
	SpGdprConsentWrapper_t62CF85800AFCAD10C6DBBB71A86C3D3C81A9D3CB_CustomAttributesCacheGenerator_applies,
	SpGdprConsentWrapper_t62CF85800AFCAD10C6DBBB71A86C3D3C81A9D3CB_CustomAttributesCacheGenerator_consents,
	ConsentMessenger_tCA196B8FC2F4918555DEB74A42C641B5205C811B_CustomAttributesCacheGenerator_ConsentMessenger_Broadcast_m6EDEAD2FD50D6FA78CC70A81142819DF98F70E9E____list0,
	AssemblyU2DCSharp_CustomAttributesCacheGenerator,
};
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m8562196F90F3EBCEC23B5708EE0332842883C490_inline (RuntimeCompatibilityAttribute_tFF99AB2963098F9CBCD47A20D9FD3D51C17C1C80 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		bool L_0 = ___value0;
		__this->set_m_wrapNonExceptionThrows_0(L_0);
		return;
	}
}
