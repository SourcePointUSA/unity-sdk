﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>
#include <stdint.h>


template <typename R, typename T1>
struct VirtFuncInvoker1
{
	typedef R (*Func)(void*, T1, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename R>
struct VirtFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename T1, typename T2>
struct VirtActionInvoker2
{
	typedef void (*Action)(void*, T1, T2, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, p1, p2, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3, typename T4>
struct VirtFuncInvoker4
{
	typedef R (*Func)(void*, T1, T2, T3, T4, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2, T3 p3, T4 p4)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, p4, invokeData.method);
	}
};
template <typename R>
struct GenericVirtFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (const RuntimeMethod* method, RuntimeObject* obj)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_virtual_invoke_data(method, obj, &invokeData);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename R>
struct InterfaceFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename T1>
struct InterfaceActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename R>
struct GenericInterfaceFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (const RuntimeMethod* method, RuntimeObject* obj)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_interface_invoke_data(method, obj, &invokeData);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};

// System.Action`1<System.Object>
struct Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC;
// System.Buffers.ArrayBufferWriter`1<System.Byte>
struct ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717;
// System.Buffers.ArrayPool`1<System.Byte>
struct ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E;
// System.Collections.Concurrent.ConcurrentDictionary`2<System.Type,System.Text.Json.JsonClassInfo>
struct ConcurrentDictionary_2_t06134CE7BA5058D6E5A23E8C6928111EA6003239;
// System.Collections.Concurrent.ConcurrentDictionary`2<System.Type,System.Text.Json.Serialization.JsonConverter>
struct ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8;
// System.Collections.Generic.Dictionary`2<System.Int32,System.Threading.Tasks.Task>
struct Dictionary_2_tB758E2A2593CD827EFC041BE1F1BB4B68DE1C3E8;
// System.Collections.Generic.Dictionary`2<System.String,System.Text.Json.JsonParameterInfo>
struct Dictionary_2_t88B514DD42AE28E567C3E46EBF620FA30EEA74A1;
// System.Collections.Generic.Dictionary`2<System.String,System.Text.Json.JsonPropertyInfo>
struct Dictionary_2_t249E9FEC7DBA07265D10748B0086D9D57054672A;
// System.Collections.Generic.Dictionary`2<System.Type,System.Text.Json.Serialization.JsonConverter>
struct Dictionary_2_t87370488A06CE643EF15B83A78E0AC9870FEDB15;
// System.Func`1<System.Threading.Tasks.Task/ContingentProperties>
struct Func_1_tBCF42601FA307876E83080BE4204110820F8BF3B;
// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<System.ArraySegment`1<System.Byte>>>
struct Func_2_tB70DBF72BDE13A60F022FF99C0825B7D33B2CD88;
// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<System.Int32>>
struct Func_2_t53CFE8804C8D1C2FE8CC9204CF5DA5B98EC444D0;
// System.Buffers.IBufferWriter`1<System.Byte>
struct IBufferWriter_1_t63F02C77711682A2CEF308B05BA53D9A7AB05ABD;
// System.Collections.Generic.IEnumerator`1<System.Text.Json.JsonElement>
struct IEnumerator_1_tDF9AEBC92D143FDBB6D45BB0E68437CDCE25A31E;
// System.Collections.Generic.IEnumerator`1<System.Text.Json.JsonProperty>
struct IEnumerator_1_tDCF7E2F61DED380BEAA484608CBEFFE5197285B3;
// System.Collections.Generic.IList`1<System.Text.Json.Serialization.JsonConverter>
struct IList_1_t6E5E5B712007D5061BB1DF8DEE9B6530F3634233;
// System.Collections.Generic.List`1<System.Text.Json.ArgumentState>
struct List_1_tC675C6A551AE56FA932D68D31DEC8E811CD23FC7;
// System.Collections.Generic.List`1<System.Text.Json.PropertyRef>
struct List_1_t86B6A92243885E5164DC45FD96099FE62E6A2E6A;
// System.Collections.Generic.List`1<System.Text.Json.ReadStackFrame>
struct List_1_t0E88177B9B829151BC738AFB4713B271CA5BD8CA;
// System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>
struct List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5;
// System.Pinnable`1<System.Byte>
struct Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110;
// System.Pinnable`1<System.Int32>
struct Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D;
// System.Predicate`1<System.Object>
struct Predicate_1_t5C96B81B31A697B11C4C3767E3298773AF25DFEB;
// System.Predicate`1<System.Threading.Tasks.Task>
struct Predicate_1_tC0DBBC8498BD1EE6ABFFAA5628024105FA7D11BD;
// System.Threading.Tasks.TaskFactory`1<System.ArraySegment`1<System.Byte>>
struct TaskFactory_1_tEE49CB5FD4827D7F7DBF62C9200028C41A403EC7;
// System.Threading.Tasks.TaskFactory`1<System.Int32>
struct TaskFactory_1_tCA6286B86C0D5D6C00D5A0DFE56F7E48A482DD5E;
// System.Threading.Tasks.Task`1<System.ArraySegment`1<System.Byte>>
struct Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985;
// System.Threading.Tasks.Task`1<System.Int32>
struct Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725;
// System.Threading.Tasks.Task`1<System.Text.Json.JsonDocument>
struct Task_1_tD781EDEF7BCB3B0E3F7EAD7B32260768B285C6DB;
// System.Threading.Tasks.Task`1<System.Object>
struct Task_1_tC1805497876E88B78A2B0CB81C6409E0B381AC17;
// System.Threading.Tasks.Task`1<System.Threading.Tasks.VoidTaskResult>
struct Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3;
// System.Byte[]
struct ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726;
// System.Char[]
struct CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34;
// System.Delegate[]
struct DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8;
// System.Int32[]
struct Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32;
// System.IntPtr[]
struct IntPtrU5BU5D_t27FC72B0409D75AAF33EC42498E8094E95FEE9A6;
// System.Text.Json.Serialization.JsonConverter[]
struct JsonConverterU5BU5D_t295649D6A60073B0FD8F6F4AEDCDC37CF5421232;
// System.Text.Json.JsonPropertyInfo[]
struct JsonPropertyInfoU5BU5D_t92C433BF3A9CDBC7959A5379838C782A078F0AA1;
// System.Text.Json.ParameterRef[]
struct ParameterRefU5BU5D_t22F33996E671221964593A44EBE1C4460B59F472;
// System.Text.Json.PropertyRef[]
struct PropertyRefU5BU5D_t3F07DF2751485B065F052DDCFA7CB7A0307ABEF0;
// System.Diagnostics.StackTrace[]
struct StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971;
// System.Type[]
struct TypeU5BU5D_t85B10489E46F06CEC7C4B1CCBD0E01FAB6649755;
// System.Text.Json.WriteStackFrame[]
struct WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A;
// System.Action
struct Action_tAF41423D285AE0862865348CF6CE51CD085ABBA6;
// System.Text.Json.ArgumentState
struct ArgumentState_tB59BA647A734F800587B84B8F29F25FC38C93598;
// System.AsyncCallback
struct AsyncCallback_tA7921BEF974919C46FF8F9D9867C567B200BB0EA;
// System.Reflection.Binder
struct Binder_t2BEE27FD84737D1E79BC47FD67F6D3DD2F2DDA30;
// System.Threading.CancellationTokenSource
struct CancellationTokenSource_t78B989179DE23EDD36F870FFEE20A15D6D3C65B3;
// System.Reflection.ConstructorInfo
struct ConstructorInfo_t449AEC508DCA508EE46784C4F2716545488ACD5B;
// System.Threading.ContextCallback
struct ContextCallback_t93707E0430F4FF3E15E1FB5A4844BE89C657AE8B;
// System.Delegate
struct Delegate_t;
// System.DelegateData
struct DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288;
// System.Exception
struct Exception_t;
// System.IAsyncResult
struct IAsyncResult_tC9F97BF36FCF122D29D3101D80642278297BF370;
// System.Runtime.CompilerServices.IAsyncStateMachine
struct IAsyncStateMachine_tAE063F84A60E1058FCA4E3EA9F555D3462641F7D;
// System.Collections.IDictionary
struct IDictionary_t99871C56B8EC2452AC5C4CF3831695E617B89D3A;
// System.Collections.IEnumerator
struct IEnumerator_t5956F3AFB7ECF1117E3BC5890E7FC7B7F7A04105;
// System.Text.Encodings.Web.JavaScriptEncoder
struct JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118;
// System.Text.Json.JsonClassInfo
struct JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18;
// System.Text.Json.Serialization.JsonConverter
struct JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3;
// System.Text.Json.JsonDocument
struct JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1;
// System.Text.Json.JsonElement
struct JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49;
// System.Text.Json.JsonNamingPolicy
struct JsonNamingPolicy_tC50C562D30D5F9EDB5D4F5D68614850A38843BBC;
// System.Text.Json.JsonPropertyInfo
struct JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F;
// System.Text.Json.JsonSerializerOptions
struct JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904;
// System.Text.Json.MemberAccessor
struct MemberAccessor_tCEB2A61BD6975686650BCE8E668E39B9CF74F8F9;
// System.Reflection.MemberFilter
struct MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81;
// System.Reflection.MemberInfo
struct MemberInfo_t;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.Text.Json.Serialization.ReferenceHandler
struct ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F;
// System.Text.Json.Serialization.ReferenceResolver
struct ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87;
// System.Runtime.Serialization.SafeSerializationManager
struct SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F;
// System.Threading.SemaphoreSlim
struct SemaphoreSlim_t3EF85FC980AE57957BEBB6B78E81DE2E3233D385;
// System.SequencePosition
struct SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A;
// System.Threading.Tasks.StackGuard
struct StackGuard_t88E1EE4741AD02CA5FEA04A4EB2CC70F230E0E6D;
// System.IO.Stream
struct Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB;
// System.String
struct String_t;
// System.Text.StringBuilder
struct StringBuilder_t;
// System.StringComparer
struct StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6;
// System.Threading.Tasks.Task
struct Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60;
// System.Threading.Tasks.TaskFactory
struct TaskFactory_t22D999A05A967C31A4B5FFBD08864809BF35EA3B;
// System.Threading.Tasks.TaskScheduler
struct TaskScheduler_t74FBEEEDBDD5E0088FF0EEC18F45CD866B098D5D;
// System.Type
struct Type_t;
// System.Text.Json.Utf8JsonWriter
struct Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C;
// System.Void
struct Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5;
// System.Text.Json.WriteStackFrame
struct WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9;
// System.Text.Json.JsonClassInfo/ConstructorDelegate
struct ConstructorDelegate_t78F14D99A470B7AECB5D508869D8A4D62D40D0C0;
// System.Text.Json.JsonClassInfo/ParameterLookupKey
struct ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9;
// System.Text.Json.JsonClassInfo/ParameterLookupValue
struct ParameterLookupValue_t4CD624C3EDE8825E6865586D118C4B839F1532A9;
// System.Text.Json.Serialization.ReflectionMemberAccessor/<>c__DisplayClass0_0
struct U3CU3Ec__DisplayClass0_0_t22913487C669704BBF5B5C7D3EF3A55C52F8F60F;
// System.IO.Stream/ReadWriteTask
struct ReadWriteTask_t32CD2C230786712954C1DB518DBE420A1F4C7974;
// System.Threading.Tasks.Task/ContingentProperties
struct ContingentProperties_t1E249C737B8B8644ED1D60EEFA101D326B199EA0;

IL2CPP_EXTERN_C RuntimeClass* ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Exception_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IBufferWriter_1_t63F02C77711682A2CEF308B05BA53D9A7AB05ABD_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* RuntimeObject_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* StringBuilder_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Type_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral158765DAD906DF36B8505DD381B603F9A0F345A1;
IL2CPP_EXTERN_C String_t* _stringLiteral9D64FD021538BBCA256D783E52916EC66D2582E4;
IL2CPP_EXTERN_C String_t* _stringLiteral9E6DEA6E609FD74FD29A7E5BB6D900CCBA5F3FBF;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayBufferWriter_1_Advance_m1F8E2CF2769D083066B3C2737AF52719EACD523A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayBufferWriter_1_Clear_m561DC03769B8C169BFFEB40FF3AAD308B4320805_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayBufferWriter_1_get_WrittenCount_m934380C81D0FF8B55609D3E68D229EE5C74E6C53_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayBufferWriter_1_get_WrittenMemory_m52E7F598C012BE7766DE9D809E7F7DAD8DB10F58_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySegment_1__ctor_mAA780E22BB5AE07078510EDCE524DD1EA1E98E0D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySegment_1_get_Count_mC13AC26CCFD0EACBCC08F24F2A7BB22841B44C32_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySegment_1_get_Offset_m13F255A2A7A730982F330A448FCB32239782C505_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C_TisU3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335_m5FCB8074883D5A5D9777C6093EE677835300432F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2_TisU3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B_m179843A0565EF49F48ABDF6635C3E041743C36B9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetException_m8298F499262BDEDE435D3FA226F4267C179B20D0_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetException_m9AEB12146F99A1F4E8F8992A49A6C3BC57AB5EBD_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetResult_m5C03D366FBBD09A38148AF074E67325FCD891702_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetResult_mB6426AE79AFDC2DCFDFD3F2CB765EA12494D7819_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetStateMachine_m57FFFD41160014C16C21B3A3F4B9902B587CAE25_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetStateMachine_m8EA71255760B118307FE9FCE898C563EBE80745E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80_m26462E59FBB44A9CE56618666C19EF4C882860E0_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncValueTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8_m89F9EBB43B233A95E8461140AC187B63D77F2F1F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ConfiguredTaskAwaitable_1_GetAwaiter_m80F1877E5304C1EB51E7F1E92D2C4CA3A9A3AC6D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ConfiguredTaskAwaitable_1_GetAwaiter_m8FA39505FC2099C60148C0F029CB49792690A0D5_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ConfiguredTaskAwaiter_GetResult_m0927E49E03619C51620F396FE1DD5DBD41AC6681_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ConfiguredTaskAwaiter_GetResult_mC723D4CAC0FFD2CB0AF9749A899E22F31CE1B8F6_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ConfiguredTaskAwaiter_get_IsCompleted_m2D230F04D69897DAD535B96F5F4581467DDDE0D8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ConfiguredTaskAwaiter_get_IsCompleted_m4192DC0E89B48FF93421FFF4EB52C21C42687999_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_mF57A675DC30E3A30C75C7B19903BB3AB771AA743_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_mA95BD97532A917EFABAEB51DDE1649AF93AA28DF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_mAF5A5D24EE6E3206F64DF2764D69FE6EEDB40E90_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_set_Item_mAF32960D79EBF6119BA8C7632444CFD38AC1DF75_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryExtensions_AsMemory_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m200D8CCE4E809AF8284BAF03FA13482EE5B0D282_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mD932D4A4EC20A3549450351374B5D165258B0C91_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryExtensions_SequenceEqual_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mA47AE57649F12A2400FE13BDC84254F05A99D1AA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_Cast_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_mC0DBC30388A535C7844D1D37A59E519DA6751DFE_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_Read_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m4C4E201B0499E179319483CA0E299BBC4BFF6688_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_Read_TisUInt32_tE60352A06233E4E69DD198BCC67142159F686B15_m833630665CFD238E8565314AC52CFADD215AB189_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_TryGetArray_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m44A80C61AC6C2697DC2C11372DF211AED4DA945E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_Write_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mBBD4DDE8A6973C64B3C4941610C05FA656A63B48_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* MemoryMarshal_Write_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m53B95538AC301102BF79930E0E45D3300B903BC7_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Memory_1_op_Implicit_mE940358A7E5B8CF728319481BB9080A44E2D914F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Nullable_1_get_HasValue_m92429A0BA8A6F4D11389C83E7568D8A9FFB3410B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Span_1_Clear_mCD3767C2F151B946E3EEB3AD9CCD8EE0794F689C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Span_1_CopyTo_m78B5163997318B736E1238622FCBC09953798836_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Span_1_Slice_mC8E25AC937B49CDD57AA85FF493D7F42595F8EAA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Span_1_ToArray_m0E11A38D8E7A3ECF9716C30900DC2C34BB0CC7E4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Span_1_get_Item_mE8544DBC448A1E9D05A8AC89B0399CB9B0275A2C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Task_1_ConfigureAwait_m0E2430C409BCD2B226EA4AC94C8DA1D8534513C7_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Task_1_ConfigureAwait_m9637E2990F98EDC90D1A03B57A4954CE2171C4E2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CParseAsyncCoreU3Ed__57_MoveNext_mD0675E98AF6165205178B6932DA7B1E452799396_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CReadToEndAsyncU3Ed__65_MoveNext_m6687BB75E19E97F8D89E828FA064629CB2F3390E_RuntimeMethod_var;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;
struct Exception_t_marshaled_com;
struct Exception_t_marshaled_pinvoke;
struct JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49;;
struct JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_com;
struct JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_com;;
struct JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_pinvoke;
struct JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_pinvoke;;
struct SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A;;
struct SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_com;
struct SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_com;;
struct SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_pinvoke;
struct SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_pinvoke;;
struct WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9;;
struct WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_com;
struct WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_com;;
struct WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_pinvoke;
struct WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_pinvoke;;

struct ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726;
struct CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34;
struct DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8;
struct WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object


// System.Buffers.ArrayBufferWriter`1<System.Byte>
struct  ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717  : public RuntimeObject
{
public:
	// T[] System.Buffers.ArrayBufferWriter`1::_buffer
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ____buffer_0;
	// System.Int32 System.Buffers.ArrayBufferWriter`1::_index
	int32_t ____index_1;

public:
	inline static int32_t get_offset_of__buffer_0() { return static_cast<int32_t>(offsetof(ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717, ____buffer_0)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get__buffer_0() const { return ____buffer_0; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of__buffer_0() { return &____buffer_0; }
	inline void set__buffer_0(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		____buffer_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____buffer_0), (void*)value);
	}

	inline static int32_t get_offset_of__index_1() { return static_cast<int32_t>(offsetof(ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717, ____index_1)); }
	inline int32_t get__index_1() const { return ____index_1; }
	inline int32_t* get_address_of__index_1() { return &____index_1; }
	inline void set__index_1(int32_t value)
	{
		____index_1 = value;
	}
};


// System.Buffers.ArrayPool`1<System.Byte>
struct  ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E  : public RuntimeObject
{
public:

public:
};

struct ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E_StaticFields
{
public:
	// System.Buffers.ArrayPool`1<T> System.Buffers.ArrayPool`1::s_sharedInstance
	ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * ___s_sharedInstance_0;

public:
	inline static int32_t get_offset_of_s_sharedInstance_0() { return static_cast<int32_t>(offsetof(ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E_StaticFields, ___s_sharedInstance_0)); }
	inline ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * get_s_sharedInstance_0() const { return ___s_sharedInstance_0; }
	inline ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E ** get_address_of_s_sharedInstance_0() { return &___s_sharedInstance_0; }
	inline void set_s_sharedInstance_0(ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * value)
	{
		___s_sharedInstance_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_sharedInstance_0), (void*)value);
	}
};


// System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>
struct  List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5, ____items_1)); }
	inline WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A* get__items_1() const { return ____items_1; }
	inline WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5_StaticFields, ____emptyArray_5)); }
	inline WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A* get__emptyArray_5() const { return ____emptyArray_5; }
	inline WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Pinnable`1<System.Byte>
struct  Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110  : public RuntimeObject
{
public:
	// T System.Pinnable`1::Data
	uint8_t ___Data_0;

public:
	inline static int32_t get_offset_of_Data_0() { return static_cast<int32_t>(offsetof(Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110, ___Data_0)); }
	inline uint8_t get_Data_0() const { return ___Data_0; }
	inline uint8_t* get_address_of_Data_0() { return &___Data_0; }
	inline void set_Data_0(uint8_t value)
	{
		___Data_0 = value;
	}
};


// System.Pinnable`1<System.Int32>
struct  Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D  : public RuntimeObject
{
public:
	// T System.Pinnable`1::Data
	int32_t ___Data_0;

public:
	inline static int32_t get_offset_of_Data_0() { return static_cast<int32_t>(offsetof(Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D, ___Data_0)); }
	inline int32_t get_Data_0() const { return ___Data_0; }
	inline int32_t* get_address_of_Data_0() { return &___Data_0; }
	inline void set_Data_0(int32_t value)
	{
		___Data_0 = value;
	}
};

struct Il2CppArrayBounds;

// System.Array


// System.Text.Json.Serialization.JsonConverter
struct  JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3  : public RuntimeObject
{
public:
	// System.Boolean System.Text.Json.Serialization.JsonConverter::<CanUseDirectReadOrWrite>k__BackingField
	bool ___U3CCanUseDirectReadOrWriteU3Ek__BackingField_0;
	// System.Boolean System.Text.Json.Serialization.JsonConverter::<CanBePolymorphic>k__BackingField
	bool ___U3CCanBePolymorphicU3Ek__BackingField_1;
	// System.Boolean System.Text.Json.Serialization.JsonConverter::<IsValueType>k__BackingField
	bool ___U3CIsValueTypeU3Ek__BackingField_2;
	// System.Boolean System.Text.Json.Serialization.JsonConverter::<IsInternalConverter>k__BackingField
	bool ___U3CIsInternalConverterU3Ek__BackingField_3;
	// System.Boolean System.Text.Json.Serialization.JsonConverter::IsInternalConverterForNumberType
	bool ___IsInternalConverterForNumberType_4;
	// System.Boolean System.Text.Json.Serialization.JsonConverter::<ConstructorIsParameterized>k__BackingField
	bool ___U3CConstructorIsParameterizedU3Ek__BackingField_5;
	// System.Reflection.ConstructorInfo System.Text.Json.Serialization.JsonConverter::<ConstructorInfo>k__BackingField
	ConstructorInfo_t449AEC508DCA508EE46784C4F2716545488ACD5B * ___U3CConstructorInfoU3Ek__BackingField_6;

public:
	inline static int32_t get_offset_of_U3CCanUseDirectReadOrWriteU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3, ___U3CCanUseDirectReadOrWriteU3Ek__BackingField_0)); }
	inline bool get_U3CCanUseDirectReadOrWriteU3Ek__BackingField_0() const { return ___U3CCanUseDirectReadOrWriteU3Ek__BackingField_0; }
	inline bool* get_address_of_U3CCanUseDirectReadOrWriteU3Ek__BackingField_0() { return &___U3CCanUseDirectReadOrWriteU3Ek__BackingField_0; }
	inline void set_U3CCanUseDirectReadOrWriteU3Ek__BackingField_0(bool value)
	{
		___U3CCanUseDirectReadOrWriteU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_U3CCanBePolymorphicU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3, ___U3CCanBePolymorphicU3Ek__BackingField_1)); }
	inline bool get_U3CCanBePolymorphicU3Ek__BackingField_1() const { return ___U3CCanBePolymorphicU3Ek__BackingField_1; }
	inline bool* get_address_of_U3CCanBePolymorphicU3Ek__BackingField_1() { return &___U3CCanBePolymorphicU3Ek__BackingField_1; }
	inline void set_U3CCanBePolymorphicU3Ek__BackingField_1(bool value)
	{
		___U3CCanBePolymorphicU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CIsValueTypeU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3, ___U3CIsValueTypeU3Ek__BackingField_2)); }
	inline bool get_U3CIsValueTypeU3Ek__BackingField_2() const { return ___U3CIsValueTypeU3Ek__BackingField_2; }
	inline bool* get_address_of_U3CIsValueTypeU3Ek__BackingField_2() { return &___U3CIsValueTypeU3Ek__BackingField_2; }
	inline void set_U3CIsValueTypeU3Ek__BackingField_2(bool value)
	{
		___U3CIsValueTypeU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CIsInternalConverterU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3, ___U3CIsInternalConverterU3Ek__BackingField_3)); }
	inline bool get_U3CIsInternalConverterU3Ek__BackingField_3() const { return ___U3CIsInternalConverterU3Ek__BackingField_3; }
	inline bool* get_address_of_U3CIsInternalConverterU3Ek__BackingField_3() { return &___U3CIsInternalConverterU3Ek__BackingField_3; }
	inline void set_U3CIsInternalConverterU3Ek__BackingField_3(bool value)
	{
		___U3CIsInternalConverterU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_IsInternalConverterForNumberType_4() { return static_cast<int32_t>(offsetof(JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3, ___IsInternalConverterForNumberType_4)); }
	inline bool get_IsInternalConverterForNumberType_4() const { return ___IsInternalConverterForNumberType_4; }
	inline bool* get_address_of_IsInternalConverterForNumberType_4() { return &___IsInternalConverterForNumberType_4; }
	inline void set_IsInternalConverterForNumberType_4(bool value)
	{
		___IsInternalConverterForNumberType_4 = value;
	}

	inline static int32_t get_offset_of_U3CConstructorIsParameterizedU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3, ___U3CConstructorIsParameterizedU3Ek__BackingField_5)); }
	inline bool get_U3CConstructorIsParameterizedU3Ek__BackingField_5() const { return ___U3CConstructorIsParameterizedU3Ek__BackingField_5; }
	inline bool* get_address_of_U3CConstructorIsParameterizedU3Ek__BackingField_5() { return &___U3CConstructorIsParameterizedU3Ek__BackingField_5; }
	inline void set_U3CConstructorIsParameterizedU3Ek__BackingField_5(bool value)
	{
		___U3CConstructorIsParameterizedU3Ek__BackingField_5 = value;
	}

	inline static int32_t get_offset_of_U3CConstructorInfoU3Ek__BackingField_6() { return static_cast<int32_t>(offsetof(JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3, ___U3CConstructorInfoU3Ek__BackingField_6)); }
	inline ConstructorInfo_t449AEC508DCA508EE46784C4F2716545488ACD5B * get_U3CConstructorInfoU3Ek__BackingField_6() const { return ___U3CConstructorInfoU3Ek__BackingField_6; }
	inline ConstructorInfo_t449AEC508DCA508EE46784C4F2716545488ACD5B ** get_address_of_U3CConstructorInfoU3Ek__BackingField_6() { return &___U3CConstructorInfoU3Ek__BackingField_6; }
	inline void set_U3CConstructorInfoU3Ek__BackingField_6(ConstructorInfo_t449AEC508DCA508EE46784C4F2716545488ACD5B * value)
	{
		___U3CConstructorInfoU3Ek__BackingField_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CConstructorInfoU3Ek__BackingField_6), (void*)value);
	}
};


// System.MarshalByRefObject
struct  MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8  : public RuntimeObject
{
public:
	// System.Object System.MarshalByRefObject::_identity
	RuntimeObject * ____identity_0;

public:
	inline static int32_t get_offset_of__identity_0() { return static_cast<int32_t>(offsetof(MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8, ____identity_0)); }
	inline RuntimeObject * get__identity_0() const { return ____identity_0; }
	inline RuntimeObject ** get_address_of__identity_0() { return &____identity_0; }
	inline void set__identity_0(RuntimeObject * value)
	{
		____identity_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____identity_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.MarshalByRefObject
struct MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8_marshaled_pinvoke
{
	Il2CppIUnknown* ____identity_0;
};
// Native definition for COM marshalling of System.MarshalByRefObject
struct MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8_marshaled_com
{
	Il2CppIUnknown* ____identity_0;
};

// System.Reflection.MemberInfo
struct  MemberInfo_t  : public RuntimeObject
{
public:

public:
};


// System.Text.Json.Serialization.ReferenceHandler
struct  ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F  : public RuntimeObject
{
public:

public:
};

struct ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F_StaticFields
{
public:
	// System.Text.Json.Serialization.ReferenceHandler System.Text.Json.Serialization.ReferenceHandler::<Preserve>k__BackingField
	ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * ___U3CPreserveU3Ek__BackingField_0;

public:
	inline static int32_t get_offset_of_U3CPreserveU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F_StaticFields, ___U3CPreserveU3Ek__BackingField_0)); }
	inline ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * get_U3CPreserveU3Ek__BackingField_0() const { return ___U3CPreserveU3Ek__BackingField_0; }
	inline ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F ** get_address_of_U3CPreserveU3Ek__BackingField_0() { return &___U3CPreserveU3Ek__BackingField_0; }
	inline void set_U3CPreserveU3Ek__BackingField_0(ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * value)
	{
		___U3CPreserveU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CPreserveU3Ek__BackingField_0), (void*)value);
	}
};


// System.Text.Json.Serialization.ReferenceResolver
struct  ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87  : public RuntimeObject
{
public:

public:
};


// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::m_stringLength
	int32_t ___m_stringLength_0;
	// System.Char System.String::m_firstChar
	Il2CppChar ___m_firstChar_1;

public:
	inline static int32_t get_offset_of_m_stringLength_0() { return static_cast<int32_t>(offsetof(String_t, ___m_stringLength_0)); }
	inline int32_t get_m_stringLength_0() const { return ___m_stringLength_0; }
	inline int32_t* get_address_of_m_stringLength_0() { return &___m_stringLength_0; }
	inline void set_m_stringLength_0(int32_t value)
	{
		___m_stringLength_0 = value;
	}

	inline static int32_t get_offset_of_m_firstChar_1() { return static_cast<int32_t>(offsetof(String_t, ___m_firstChar_1)); }
	inline Il2CppChar get_m_firstChar_1() const { return ___m_firstChar_1; }
	inline Il2CppChar* get_address_of_m_firstChar_1() { return &___m_firstChar_1; }
	inline void set_m_firstChar_1(Il2CppChar value)
	{
		___m_firstChar_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_5;

public:
	inline static int32_t get_offset_of_Empty_5() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_5)); }
	inline String_t* get_Empty_5() const { return ___Empty_5; }
	inline String_t** get_address_of_Empty_5() { return &___Empty_5; }
	inline void set_Empty_5(String_t* value)
	{
		___Empty_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Empty_5), (void*)value);
	}
};


// System.Text.StringBuilder
struct  StringBuilder_t  : public RuntimeObject
{
public:
	// System.Char[] System.Text.StringBuilder::m_ChunkChars
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___m_ChunkChars_0;
	// System.Text.StringBuilder System.Text.StringBuilder::m_ChunkPrevious
	StringBuilder_t * ___m_ChunkPrevious_1;
	// System.Int32 System.Text.StringBuilder::m_ChunkLength
	int32_t ___m_ChunkLength_2;
	// System.Int32 System.Text.StringBuilder::m_ChunkOffset
	int32_t ___m_ChunkOffset_3;
	// System.Int32 System.Text.StringBuilder::m_MaxCapacity
	int32_t ___m_MaxCapacity_4;

public:
	inline static int32_t get_offset_of_m_ChunkChars_0() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkChars_0)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_m_ChunkChars_0() const { return ___m_ChunkChars_0; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_m_ChunkChars_0() { return &___m_ChunkChars_0; }
	inline void set_m_ChunkChars_0(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___m_ChunkChars_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ChunkChars_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_ChunkPrevious_1() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkPrevious_1)); }
	inline StringBuilder_t * get_m_ChunkPrevious_1() const { return ___m_ChunkPrevious_1; }
	inline StringBuilder_t ** get_address_of_m_ChunkPrevious_1() { return &___m_ChunkPrevious_1; }
	inline void set_m_ChunkPrevious_1(StringBuilder_t * value)
	{
		___m_ChunkPrevious_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ChunkPrevious_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_ChunkLength_2() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkLength_2)); }
	inline int32_t get_m_ChunkLength_2() const { return ___m_ChunkLength_2; }
	inline int32_t* get_address_of_m_ChunkLength_2() { return &___m_ChunkLength_2; }
	inline void set_m_ChunkLength_2(int32_t value)
	{
		___m_ChunkLength_2 = value;
	}

	inline static int32_t get_offset_of_m_ChunkOffset_3() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkOffset_3)); }
	inline int32_t get_m_ChunkOffset_3() const { return ___m_ChunkOffset_3; }
	inline int32_t* get_address_of_m_ChunkOffset_3() { return &___m_ChunkOffset_3; }
	inline void set_m_ChunkOffset_3(int32_t value)
	{
		___m_ChunkOffset_3 = value;
	}

	inline static int32_t get_offset_of_m_MaxCapacity_4() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_MaxCapacity_4)); }
	inline int32_t get_m_MaxCapacity_4() const { return ___m_MaxCapacity_4; }
	inline int32_t* get_address_of_m_MaxCapacity_4() { return &___m_MaxCapacity_4; }
	inline void set_m_MaxCapacity_4(int32_t value)
	{
		___m_MaxCapacity_4 = value;
	}
};


// System.StringComparer
struct  StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6  : public RuntimeObject
{
public:

public:
};

struct StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_StaticFields
{
public:
	// System.StringComparer System.StringComparer::_invariantCulture
	StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * ____invariantCulture_0;
	// System.StringComparer System.StringComparer::_invariantCultureIgnoreCase
	StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * ____invariantCultureIgnoreCase_1;
	// System.StringComparer System.StringComparer::_ordinal
	StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * ____ordinal_2;
	// System.StringComparer System.StringComparer::_ordinalIgnoreCase
	StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * ____ordinalIgnoreCase_3;

public:
	inline static int32_t get_offset_of__invariantCulture_0() { return static_cast<int32_t>(offsetof(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_StaticFields, ____invariantCulture_0)); }
	inline StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * get__invariantCulture_0() const { return ____invariantCulture_0; }
	inline StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 ** get_address_of__invariantCulture_0() { return &____invariantCulture_0; }
	inline void set__invariantCulture_0(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * value)
	{
		____invariantCulture_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____invariantCulture_0), (void*)value);
	}

	inline static int32_t get_offset_of__invariantCultureIgnoreCase_1() { return static_cast<int32_t>(offsetof(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_StaticFields, ____invariantCultureIgnoreCase_1)); }
	inline StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * get__invariantCultureIgnoreCase_1() const { return ____invariantCultureIgnoreCase_1; }
	inline StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 ** get_address_of__invariantCultureIgnoreCase_1() { return &____invariantCultureIgnoreCase_1; }
	inline void set__invariantCultureIgnoreCase_1(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * value)
	{
		____invariantCultureIgnoreCase_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____invariantCultureIgnoreCase_1), (void*)value);
	}

	inline static int32_t get_offset_of__ordinal_2() { return static_cast<int32_t>(offsetof(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_StaticFields, ____ordinal_2)); }
	inline StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * get__ordinal_2() const { return ____ordinal_2; }
	inline StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 ** get_address_of__ordinal_2() { return &____ordinal_2; }
	inline void set__ordinal_2(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * value)
	{
		____ordinal_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____ordinal_2), (void*)value);
	}

	inline static int32_t get_offset_of__ordinalIgnoreCase_3() { return static_cast<int32_t>(offsetof(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_StaticFields, ____ordinalIgnoreCase_3)); }
	inline StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * get__ordinalIgnoreCase_3() const { return ____ordinalIgnoreCase_3; }
	inline StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 ** get_address_of__ordinalIgnoreCase_3() { return &____ordinalIgnoreCase_3; }
	inline void set__ordinalIgnoreCase_3(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * value)
	{
		____ordinalIgnoreCase_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____ordinalIgnoreCase_3), (void*)value);
	}
};


// System.ValueType
struct  ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52_marshaled_com
{
};

// System.Text.Json.JsonClassInfo/ParameterLookupKey
struct  ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9  : public RuntimeObject
{
public:
	// System.String System.Text.Json.JsonClassInfo/ParameterLookupKey::<Name>k__BackingField
	String_t* ___U3CNameU3Ek__BackingField_0;
	// System.Type System.Text.Json.JsonClassInfo/ParameterLookupKey::<Type>k__BackingField
	Type_t * ___U3CTypeU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CNameU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9, ___U3CNameU3Ek__BackingField_0)); }
	inline String_t* get_U3CNameU3Ek__BackingField_0() const { return ___U3CNameU3Ek__BackingField_0; }
	inline String_t** get_address_of_U3CNameU3Ek__BackingField_0() { return &___U3CNameU3Ek__BackingField_0; }
	inline void set_U3CNameU3Ek__BackingField_0(String_t* value)
	{
		___U3CNameU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CNameU3Ek__BackingField_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CTypeU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9, ___U3CTypeU3Ek__BackingField_1)); }
	inline Type_t * get_U3CTypeU3Ek__BackingField_1() const { return ___U3CTypeU3Ek__BackingField_1; }
	inline Type_t ** get_address_of_U3CTypeU3Ek__BackingField_1() { return &___U3CTypeU3Ek__BackingField_1; }
	inline void set_U3CTypeU3Ek__BackingField_1(Type_t * value)
	{
		___U3CTypeU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CTypeU3Ek__BackingField_1), (void*)value);
	}
};


// System.Text.Json.JsonClassInfo/ParameterLookupValue
struct  ParameterLookupValue_t4CD624C3EDE8825E6865586D118C4B839F1532A9  : public RuntimeObject
{
public:
	// System.String System.Text.Json.JsonClassInfo/ParameterLookupValue::<DuplicateName>k__BackingField
	String_t* ___U3CDuplicateNameU3Ek__BackingField_0;
	// System.Text.Json.JsonPropertyInfo System.Text.Json.JsonClassInfo/ParameterLookupValue::<JsonPropertyInfo>k__BackingField
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___U3CJsonPropertyInfoU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CDuplicateNameU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(ParameterLookupValue_t4CD624C3EDE8825E6865586D118C4B839F1532A9, ___U3CDuplicateNameU3Ek__BackingField_0)); }
	inline String_t* get_U3CDuplicateNameU3Ek__BackingField_0() const { return ___U3CDuplicateNameU3Ek__BackingField_0; }
	inline String_t** get_address_of_U3CDuplicateNameU3Ek__BackingField_0() { return &___U3CDuplicateNameU3Ek__BackingField_0; }
	inline void set_U3CDuplicateNameU3Ek__BackingField_0(String_t* value)
	{
		___U3CDuplicateNameU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CDuplicateNameU3Ek__BackingField_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CJsonPropertyInfoU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(ParameterLookupValue_t4CD624C3EDE8825E6865586D118C4B839F1532A9, ___U3CJsonPropertyInfoU3Ek__BackingField_1)); }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * get_U3CJsonPropertyInfoU3Ek__BackingField_1() const { return ___U3CJsonPropertyInfoU3Ek__BackingField_1; }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F ** get_address_of_U3CJsonPropertyInfoU3Ek__BackingField_1() { return &___U3CJsonPropertyInfoU3Ek__BackingField_1; }
	inline void set_U3CJsonPropertyInfoU3Ek__BackingField_1(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * value)
	{
		___U3CJsonPropertyInfoU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CJsonPropertyInfoU3Ek__BackingField_1), (void*)value);
	}
};


// System.Text.Json.Serialization.ReflectionMemberAccessor/<>c__DisplayClass0_0
struct  U3CU3Ec__DisplayClass0_0_t22913487C669704BBF5B5C7D3EF3A55C52F8F60F  : public RuntimeObject
{
public:
	// System.Type System.Text.Json.Serialization.ReflectionMemberAccessor/<>c__DisplayClass0_0::type
	Type_t * ___type_0;

public:
	inline static int32_t get_offset_of_type_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass0_0_t22913487C669704BBF5B5C7D3EF3A55C52F8F60F, ___type_0)); }
	inline Type_t * get_type_0() const { return ___type_0; }
	inline Type_t ** get_address_of_type_0() { return &___type_0; }
	inline void set_type_0(Type_t * value)
	{
		___type_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___type_0), (void*)value);
	}
};


// System.ArraySegment`1<System.Byte>
struct  ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE 
{
public:
	// T[] System.ArraySegment`1::_array
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ____array_0;
	// System.Int32 System.ArraySegment`1::_offset
	int32_t ____offset_1;
	// System.Int32 System.ArraySegment`1::_count
	int32_t ____count_2;

public:
	inline static int32_t get_offset_of__array_0() { return static_cast<int32_t>(offsetof(ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE, ____array_0)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get__array_0() const { return ____array_0; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of__array_0() { return &____array_0; }
	inline void set__array_0(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		____array_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____array_0), (void*)value);
	}

	inline static int32_t get_offset_of__offset_1() { return static_cast<int32_t>(offsetof(ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE, ____offset_1)); }
	inline int32_t get__offset_1() const { return ____offset_1; }
	inline int32_t* get_address_of__offset_1() { return &____offset_1; }
	inline void set__offset_1(int32_t value)
	{
		____offset_1 = value;
	}

	inline static int32_t get_offset_of__count_2() { return static_cast<int32_t>(offsetof(ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE, ____count_2)); }
	inline int32_t get__count_2() const { return ____count_2; }
	inline int32_t* get_address_of__count_2() { return &____count_2; }
	inline void set__count_2(int32_t value)
	{
		____count_2 = value;
	}
};


// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.ArraySegment`1<System.Byte>>
struct  ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C 
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter::m_task
	Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * ___m_task_0;
	// System.Boolean System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter::m_continueOnCapturedContext
	bool ___m_continueOnCapturedContext_1;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C, ___m_task_0)); }
	inline Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * get_m_task_0() const { return ___m_task_0; }
	inline Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_continueOnCapturedContext_1() { return static_cast<int32_t>(offsetof(ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C, ___m_continueOnCapturedContext_1)); }
	inline bool get_m_continueOnCapturedContext_1() const { return ___m_continueOnCapturedContext_1; }
	inline bool* get_address_of_m_continueOnCapturedContext_1() { return &___m_continueOnCapturedContext_1; }
	inline void set_m_continueOnCapturedContext_1(bool value)
	{
		___m_continueOnCapturedContext_1 = value;
	}
};


// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.Int32>
struct  ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter::m_task
	Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 * ___m_task_0;
	// System.Boolean System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter::m_continueOnCapturedContext
	bool ___m_continueOnCapturedContext_1;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2, ___m_task_0)); }
	inline Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 * get_m_task_0() const { return ___m_task_0; }
	inline Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_continueOnCapturedContext_1() { return static_cast<int32_t>(offsetof(ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2, ___m_continueOnCapturedContext_1)); }
	inline bool get_m_continueOnCapturedContext_1() const { return ___m_continueOnCapturedContext_1; }
	inline bool* get_address_of_m_continueOnCapturedContext_1() { return &___m_continueOnCapturedContext_1; }
	inline void set_m_continueOnCapturedContext_1(bool value)
	{
		___m_continueOnCapturedContext_1 = value;
	}
};


// System.Memory`1<System.Byte>
struct  Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9 
{
public:
	// System.Object System.Memory`1::_object
	RuntimeObject * ____object_0;
	// System.Int32 System.Memory`1::_index
	int32_t ____index_1;
	// System.Int32 System.Memory`1::_length
	int32_t ____length_2;

public:
	inline static int32_t get_offset_of__object_0() { return static_cast<int32_t>(offsetof(Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9, ____object_0)); }
	inline RuntimeObject * get__object_0() const { return ____object_0; }
	inline RuntimeObject ** get_address_of__object_0() { return &____object_0; }
	inline void set__object_0(RuntimeObject * value)
	{
		____object_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____object_0), (void*)value);
	}

	inline static int32_t get_offset_of__index_1() { return static_cast<int32_t>(offsetof(Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9, ____index_1)); }
	inline int32_t get__index_1() const { return ____index_1; }
	inline int32_t* get_address_of__index_1() { return &____index_1; }
	inline void set__index_1(int32_t value)
	{
		____index_1 = value;
	}

	inline static int32_t get_offset_of__length_2() { return static_cast<int32_t>(offsetof(Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9, ____length_2)); }
	inline int32_t get__length_2() const { return ____length_2; }
	inline int32_t* get_address_of__length_2() { return &____length_2; }
	inline void set__length_2(int32_t value)
	{
		____length_2 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Memory`1
#ifndef Memory_1_t9C3725E34DF7985E9AF7E72EB2926CD75E709E7A_marshaled_pinvoke_define
#define Memory_1_t9C3725E34DF7985E9AF7E72EB2926CD75E709E7A_marshaled_pinvoke_define
struct Memory_1_t9C3725E34DF7985E9AF7E72EB2926CD75E709E7A_marshaled_pinvoke
{
	Il2CppIUnknown* ____object_0;
	int32_t ____index_1;
	int32_t ____length_2;
};
#endif
// Native definition for COM marshalling of System.Memory`1
#ifndef Memory_1_t9C3725E34DF7985E9AF7E72EB2926CD75E709E7A_marshaled_com_define
#define Memory_1_t9C3725E34DF7985E9AF7E72EB2926CD75E709E7A_marshaled_com_define
struct Memory_1_t9C3725E34DF7985E9AF7E72EB2926CD75E709E7A_marshaled_com
{
	Il2CppIUnknown* ____object_0;
	int32_t ____index_1;
	int32_t ____length_2;
};
#endif

// System.ReadOnlyMemory`1<System.Byte>
struct  ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133 
{
public:
	// System.Object System.ReadOnlyMemory`1::_object
	RuntimeObject * ____object_0;
	// System.Int32 System.ReadOnlyMemory`1::_index
	int32_t ____index_1;
	// System.Int32 System.ReadOnlyMemory`1::_length
	int32_t ____length_2;

public:
	inline static int32_t get_offset_of__object_0() { return static_cast<int32_t>(offsetof(ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133, ____object_0)); }
	inline RuntimeObject * get__object_0() const { return ____object_0; }
	inline RuntimeObject ** get_address_of__object_0() { return &____object_0; }
	inline void set__object_0(RuntimeObject * value)
	{
		____object_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____object_0), (void*)value);
	}

	inline static int32_t get_offset_of__index_1() { return static_cast<int32_t>(offsetof(ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133, ____index_1)); }
	inline int32_t get__index_1() const { return ____index_1; }
	inline int32_t* get_address_of__index_1() { return &____index_1; }
	inline void set__index_1(int32_t value)
	{
		____index_1 = value;
	}

	inline static int32_t get_offset_of__length_2() { return static_cast<int32_t>(offsetof(ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133, ____length_2)); }
	inline int32_t get__length_2() const { return ____length_2; }
	inline int32_t* get_address_of__length_2() { return &____length_2; }
	inline void set__length_2(int32_t value)
	{
		____length_2 = value;
	}
};

// Native definition for P/Invoke marshalling of System.ReadOnlyMemory`1
#ifndef ReadOnlyMemory_1_tAAA9CB78753D364C1C68F98E1112328AEB5C264A_marshaled_pinvoke_define
#define ReadOnlyMemory_1_tAAA9CB78753D364C1C68F98E1112328AEB5C264A_marshaled_pinvoke_define
struct ReadOnlyMemory_1_tAAA9CB78753D364C1C68F98E1112328AEB5C264A_marshaled_pinvoke
{
	Il2CppIUnknown* ____object_0;
	int32_t ____index_1;
	int32_t ____length_2;
};
#endif
// Native definition for COM marshalling of System.ReadOnlyMemory`1
#ifndef ReadOnlyMemory_1_tAAA9CB78753D364C1C68F98E1112328AEB5C264A_marshaled_com_define
#define ReadOnlyMemory_1_tAAA9CB78753D364C1C68F98E1112328AEB5C264A_marshaled_com_define
struct ReadOnlyMemory_1_tAAA9CB78753D364C1C68F98E1112328AEB5C264A_marshaled_com
{
	Il2CppIUnknown* ____object_0;
	int32_t ____index_1;
	int32_t ____length_2;
};
#endif

// System.ValueTuple`2<System.Int32,System.String>
struct  ValueTuple_2_t1C65704531D1BF77739714AEC12FE375712C593F 
{
public:
	// T1 System.ValueTuple`2::Item1
	int32_t ___Item1_0;
	// T2 System.ValueTuple`2::Item2
	String_t* ___Item2_1;

public:
	inline static int32_t get_offset_of_Item1_0() { return static_cast<int32_t>(offsetof(ValueTuple_2_t1C65704531D1BF77739714AEC12FE375712C593F, ___Item1_0)); }
	inline int32_t get_Item1_0() const { return ___Item1_0; }
	inline int32_t* get_address_of_Item1_0() { return &___Item1_0; }
	inline void set_Item1_0(int32_t value)
	{
		___Item1_0 = value;
	}

	inline static int32_t get_offset_of_Item2_1() { return static_cast<int32_t>(offsetof(ValueTuple_2_t1C65704531D1BF77739714AEC12FE375712C593F, ___Item2_1)); }
	inline String_t* get_Item2_1() const { return ___Item2_1; }
	inline String_t** get_address_of_Item2_1() { return &___Item2_1; }
	inline void set_Item2_1(String_t* value)
	{
		___Item2_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Item2_1), (void*)value);
	}
};


// System.Runtime.CompilerServices.AsyncMethodBuilderCore
struct  AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34 
{
public:
	// System.Runtime.CompilerServices.IAsyncStateMachine System.Runtime.CompilerServices.AsyncMethodBuilderCore::m_stateMachine
	RuntimeObject* ___m_stateMachine_0;
	// System.Action System.Runtime.CompilerServices.AsyncMethodBuilderCore::m_defaultContextAction
	Action_tAF41423D285AE0862865348CF6CE51CD085ABBA6 * ___m_defaultContextAction_1;

public:
	inline static int32_t get_offset_of_m_stateMachine_0() { return static_cast<int32_t>(offsetof(AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34, ___m_stateMachine_0)); }
	inline RuntimeObject* get_m_stateMachine_0() const { return ___m_stateMachine_0; }
	inline RuntimeObject** get_address_of_m_stateMachine_0() { return &___m_stateMachine_0; }
	inline void set_m_stateMachine_0(RuntimeObject* value)
	{
		___m_stateMachine_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_stateMachine_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_defaultContextAction_1() { return static_cast<int32_t>(offsetof(AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34, ___m_defaultContextAction_1)); }
	inline Action_tAF41423D285AE0862865348CF6CE51CD085ABBA6 * get_m_defaultContextAction_1() const { return ___m_defaultContextAction_1; }
	inline Action_tAF41423D285AE0862865348CF6CE51CD085ABBA6 ** get_address_of_m_defaultContextAction_1() { return &___m_defaultContextAction_1; }
	inline void set_m_defaultContextAction_1(Action_tAF41423D285AE0862865348CF6CE51CD085ABBA6 * value)
	{
		___m_defaultContextAction_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_defaultContextAction_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Runtime.CompilerServices.AsyncMethodBuilderCore
struct AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34_marshaled_pinvoke
{
	RuntimeObject* ___m_stateMachine_0;
	Il2CppMethodPointer ___m_defaultContextAction_1;
};
// Native definition for COM marshalling of System.Runtime.CompilerServices.AsyncMethodBuilderCore
struct AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34_marshaled_com
{
	RuntimeObject* ___m_stateMachine_0;
	Il2CppMethodPointer ___m_defaultContextAction_1;
};

// System.Text.Json.BitStack
struct  BitStack_t05309790B90A50AE2163A8B3A4125905372F37D7 
{
public:
	// System.Int32[] System.Text.Json.BitStack::_array
	Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* ____array_2;
	// System.UInt64 System.Text.Json.BitStack::_allocationFreeContainer
	uint64_t ____allocationFreeContainer_3;
	// System.Int32 System.Text.Json.BitStack::_currentDepth
	int32_t ____currentDepth_4;

public:
	inline static int32_t get_offset_of__array_2() { return static_cast<int32_t>(offsetof(BitStack_t05309790B90A50AE2163A8B3A4125905372F37D7, ____array_2)); }
	inline Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* get__array_2() const { return ____array_2; }
	inline Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32** get_address_of__array_2() { return &____array_2; }
	inline void set__array_2(Int32U5BU5D_t70F1BDC14B1786481B176D6139A5E3B87DC54C32* value)
	{
		____array_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____array_2), (void*)value);
	}

	inline static int32_t get_offset_of__allocationFreeContainer_3() { return static_cast<int32_t>(offsetof(BitStack_t05309790B90A50AE2163A8B3A4125905372F37D7, ____allocationFreeContainer_3)); }
	inline uint64_t get__allocationFreeContainer_3() const { return ____allocationFreeContainer_3; }
	inline uint64_t* get_address_of__allocationFreeContainer_3() { return &____allocationFreeContainer_3; }
	inline void set__allocationFreeContainer_3(uint64_t value)
	{
		____allocationFreeContainer_3 = value;
	}

	inline static int32_t get_offset_of__currentDepth_4() { return static_cast<int32_t>(offsetof(BitStack_t05309790B90A50AE2163A8B3A4125905372F37D7, ____currentDepth_4)); }
	inline int32_t get__currentDepth_4() const { return ____currentDepth_4; }
	inline int32_t* get_address_of__currentDepth_4() { return &____currentDepth_4; }
	inline void set__currentDepth_4(int32_t value)
	{
		____currentDepth_4 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.BitStack
struct BitStack_t05309790B90A50AE2163A8B3A4125905372F37D7_marshaled_pinvoke
{
	Il2CppSafeArray/*NONE*/* ____array_2;
	uint64_t ____allocationFreeContainer_3;
	int32_t ____currentDepth_4;
};
// Native definition for COM marshalling of System.Text.Json.BitStack
struct BitStack_t05309790B90A50AE2163A8B3A4125905372F37D7_marshaled_com
{
	Il2CppSafeArray/*NONE*/* ____array_2;
	uint64_t ____allocationFreeContainer_3;
	int32_t ____currentDepth_4;
};

// System.Boolean
struct  Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_t07D1E3F34E4813023D64F584DFF7B34C9D922F37_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Byte
struct  Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056 
{
public:
	// System.Byte System.Byte::m_value
	uint8_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056, ___m_value_0)); }
	inline uint8_t get_m_value_0() const { return ___m_value_0; }
	inline uint8_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint8_t value)
	{
		___m_value_0 = value;
	}
};


// System.Threading.CancellationToken
struct  CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD 
{
public:
	// System.Threading.CancellationTokenSource System.Threading.CancellationToken::m_source
	CancellationTokenSource_t78B989179DE23EDD36F870FFEE20A15D6D3C65B3 * ___m_source_0;

public:
	inline static int32_t get_offset_of_m_source_0() { return static_cast<int32_t>(offsetof(CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD, ___m_source_0)); }
	inline CancellationTokenSource_t78B989179DE23EDD36F870FFEE20A15D6D3C65B3 * get_m_source_0() const { return ___m_source_0; }
	inline CancellationTokenSource_t78B989179DE23EDD36F870FFEE20A15D6D3C65B3 ** get_address_of_m_source_0() { return &___m_source_0; }
	inline void set_m_source_0(CancellationTokenSource_t78B989179DE23EDD36F870FFEE20A15D6D3C65B3 * value)
	{
		___m_source_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_source_0), (void*)value);
	}
};

struct CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD_StaticFields
{
public:
	// System.Action`1<System.Object> System.Threading.CancellationToken::s_ActionToActionObjShunt
	Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * ___s_ActionToActionObjShunt_1;

public:
	inline static int32_t get_offset_of_s_ActionToActionObjShunt_1() { return static_cast<int32_t>(offsetof(CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD_StaticFields, ___s_ActionToActionObjShunt_1)); }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * get_s_ActionToActionObjShunt_1() const { return ___s_ActionToActionObjShunt_1; }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC ** get_address_of_s_ActionToActionObjShunt_1() { return &___s_ActionToActionObjShunt_1; }
	inline void set_s_ActionToActionObjShunt_1(Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * value)
	{
		___s_ActionToActionObjShunt_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_ActionToActionObjShunt_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Threading.CancellationToken
struct CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD_marshaled_pinvoke
{
	CancellationTokenSource_t78B989179DE23EDD36F870FFEE20A15D6D3C65B3 * ___m_source_0;
};
// Native definition for COM marshalling of System.Threading.CancellationToken
struct CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD_marshaled_com
{
	CancellationTokenSource_t78B989179DE23EDD36F870FFEE20A15D6D3C65B3 * ___m_source_0;
};

// System.Char
struct  Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14 
{
public:
	// System.Char System.Char::m_value
	Il2CppChar ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14, ___m_value_0)); }
	inline Il2CppChar get_m_value_0() const { return ___m_value_0; }
	inline Il2CppChar* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(Il2CppChar value)
	{
		___m_value_0 = value;
	}
};

struct Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14_StaticFields
{
public:
	// System.Byte[] System.Char::categoryForLatin1
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___categoryForLatin1_3;

public:
	inline static int32_t get_offset_of_categoryForLatin1_3() { return static_cast<int32_t>(offsetof(Char_tFF60D8E7E89A20BE2294A003734341BD1DF43E14_StaticFields, ___categoryForLatin1_3)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_categoryForLatin1_3() const { return ___categoryForLatin1_3; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_categoryForLatin1_3() { return &___categoryForLatin1_3; }
	inline void set_categoryForLatin1_3(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___categoryForLatin1_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___categoryForLatin1_3), (void*)value);
	}
};


// System.Enum
struct  Enum_t23B90B40F60E677A8025267341651C94AE079CDA  : public ValueType_tDBF999C1B75C48C68621878250DBF6CDBCF51E52
{
public:

public:
};

struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t23B90B40F60E677A8025267341651C94AE079CDA_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t23B90B40F60E677A8025267341651C94AE079CDA_marshaled_com
{
};

// System.Int32
struct  Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.Int64
struct  Int64_t378EE0D608BD3107E77238E85F30D2BBD46981F3 
{
public:
	// System.Int64 System.Int64::m_value
	int64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int64_t378EE0D608BD3107E77238E85F30D2BBD46981F3, ___m_value_0)); }
	inline int64_t get_m_value_0() const { return ___m_value_0; }
	inline int64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int64_t value)
	{
		___m_value_0 = value;
	}
};


// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// System.Text.Json.JsonElement
struct  JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 
{
public:
	// System.Text.Json.JsonDocument System.Text.Json.JsonElement::_parent
	JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * ____parent_0;
	// System.Int32 System.Text.Json.JsonElement::_idx
	int32_t ____idx_1;

public:
	inline static int32_t get_offset_of__parent_0() { return static_cast<int32_t>(offsetof(JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49, ____parent_0)); }
	inline JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * get__parent_0() const { return ____parent_0; }
	inline JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 ** get_address_of__parent_0() { return &____parent_0; }
	inline void set__parent_0(JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * value)
	{
		____parent_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____parent_0), (void*)value);
	}

	inline static int32_t get_offset_of__idx_1() { return static_cast<int32_t>(offsetof(JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49, ____idx_1)); }
	inline int32_t get__idx_1() const { return ____idx_1; }
	inline int32_t* get_address_of__idx_1() { return &____idx_1; }
	inline void set__idx_1(int32_t value)
	{
		____idx_1 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.JsonElement
struct JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_pinvoke
{
	JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * ____parent_0;
	int32_t ____idx_1;
};
// Native definition for COM marshalling of System.Text.Json.JsonElement
struct JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_com
{
	JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * ____parent_0;
	int32_t ____idx_1;
};

// System.Text.Json.JsonWriterOptions
struct  JsonWriterOptions_tDF037E30F6E08170C5D33C09632D79BC06A4A67C 
{
public:
	// System.Int32 System.Text.Json.JsonWriterOptions::_optionsMask
	int32_t ____optionsMask_0;
	// System.Text.Encodings.Web.JavaScriptEncoder System.Text.Json.JsonWriterOptions::<Encoder>k__BackingField
	JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118 * ___U3CEncoderU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of__optionsMask_0() { return static_cast<int32_t>(offsetof(JsonWriterOptions_tDF037E30F6E08170C5D33C09632D79BC06A4A67C, ____optionsMask_0)); }
	inline int32_t get__optionsMask_0() const { return ____optionsMask_0; }
	inline int32_t* get_address_of__optionsMask_0() { return &____optionsMask_0; }
	inline void set__optionsMask_0(int32_t value)
	{
		____optionsMask_0 = value;
	}

	inline static int32_t get_offset_of_U3CEncoderU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(JsonWriterOptions_tDF037E30F6E08170C5D33C09632D79BC06A4A67C, ___U3CEncoderU3Ek__BackingField_1)); }
	inline JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118 * get_U3CEncoderU3Ek__BackingField_1() const { return ___U3CEncoderU3Ek__BackingField_1; }
	inline JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118 ** get_address_of_U3CEncoderU3Ek__BackingField_1() { return &___U3CEncoderU3Ek__BackingField_1; }
	inline void set_U3CEncoderU3Ek__BackingField_1(JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118 * value)
	{
		___U3CEncoderU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CEncoderU3Ek__BackingField_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.JsonWriterOptions
struct JsonWriterOptions_tDF037E30F6E08170C5D33C09632D79BC06A4A67C_marshaled_pinvoke
{
	int32_t ____optionsMask_0;
	JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118 * ___U3CEncoderU3Ek__BackingField_1;
};
// Native definition for COM marshalling of System.Text.Json.JsonWriterOptions
struct JsonWriterOptions_tDF037E30F6E08170C5D33C09632D79BC06A4A67C_marshaled_com
{
	int32_t ____optionsMask_0;
	JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118 * ___U3CEncoderU3Ek__BackingField_1;
};

// System.NUInt
struct  NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5 
{
public:
	// System.Void* System.NUInt::_value
	void* ____value_0;

public:
	inline static int32_t get_offset_of__value_0() { return static_cast<int32_t>(offsetof(NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5, ____value_0)); }
	inline void* get__value_0() const { return ____value_0; }
	inline void** get_address_of__value_0() { return &____value_0; }
	inline void set__value_0(void* value)
	{
		____value_0 = value;
	}
};


// System.SequencePosition
struct  SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A 
{
public:
	// System.Object System.SequencePosition::_object
	RuntimeObject * ____object_0;
	// System.Int32 System.SequencePosition::_integer
	int32_t ____integer_1;

public:
	inline static int32_t get_offset_of__object_0() { return static_cast<int32_t>(offsetof(SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A, ____object_0)); }
	inline RuntimeObject * get__object_0() const { return ____object_0; }
	inline RuntimeObject ** get_address_of__object_0() { return &____object_0; }
	inline void set__object_0(RuntimeObject * value)
	{
		____object_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____object_0), (void*)value);
	}

	inline static int32_t get_offset_of__integer_1() { return static_cast<int32_t>(offsetof(SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A, ____integer_1)); }
	inline int32_t get__integer_1() const { return ____integer_1; }
	inline int32_t* get_address_of__integer_1() { return &____integer_1; }
	inline void set__integer_1(int32_t value)
	{
		____integer_1 = value;
	}
};

// Native definition for P/Invoke marshalling of System.SequencePosition
struct SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_pinvoke
{
	Il2CppIUnknown* ____object_0;
	int32_t ____integer_1;
};
// Native definition for COM marshalling of System.SequencePosition
struct SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_com
{
	Il2CppIUnknown* ____object_0;
	int32_t ____integer_1;
};

// System.IO.Stream
struct  Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB  : public MarshalByRefObject_tD4DF91B488B284F899417EC468D8E50E933306A8
{
public:
	// System.IO.Stream/ReadWriteTask System.IO.Stream::_activeReadWriteTask
	ReadWriteTask_t32CD2C230786712954C1DB518DBE420A1F4C7974 * ____activeReadWriteTask_2;
	// System.Threading.SemaphoreSlim System.IO.Stream::_asyncActiveSemaphore
	SemaphoreSlim_t3EF85FC980AE57957BEBB6B78E81DE2E3233D385 * ____asyncActiveSemaphore_3;

public:
	inline static int32_t get_offset_of__activeReadWriteTask_2() { return static_cast<int32_t>(offsetof(Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB, ____activeReadWriteTask_2)); }
	inline ReadWriteTask_t32CD2C230786712954C1DB518DBE420A1F4C7974 * get__activeReadWriteTask_2() const { return ____activeReadWriteTask_2; }
	inline ReadWriteTask_t32CD2C230786712954C1DB518DBE420A1F4C7974 ** get_address_of__activeReadWriteTask_2() { return &____activeReadWriteTask_2; }
	inline void set__activeReadWriteTask_2(ReadWriteTask_t32CD2C230786712954C1DB518DBE420A1F4C7974 * value)
	{
		____activeReadWriteTask_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____activeReadWriteTask_2), (void*)value);
	}

	inline static int32_t get_offset_of__asyncActiveSemaphore_3() { return static_cast<int32_t>(offsetof(Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB, ____asyncActiveSemaphore_3)); }
	inline SemaphoreSlim_t3EF85FC980AE57957BEBB6B78E81DE2E3233D385 * get__asyncActiveSemaphore_3() const { return ____asyncActiveSemaphore_3; }
	inline SemaphoreSlim_t3EF85FC980AE57957BEBB6B78E81DE2E3233D385 ** get_address_of__asyncActiveSemaphore_3() { return &____asyncActiveSemaphore_3; }
	inline void set__asyncActiveSemaphore_3(SemaphoreSlim_t3EF85FC980AE57957BEBB6B78E81DE2E3233D385 * value)
	{
		____asyncActiveSemaphore_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____asyncActiveSemaphore_3), (void*)value);
	}
};

struct Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB_StaticFields
{
public:
	// System.IO.Stream System.IO.Stream::Null
	Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * ___Null_1;

public:
	inline static int32_t get_offset_of_Null_1() { return static_cast<int32_t>(offsetof(Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB_StaticFields, ___Null_1)); }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * get_Null_1() const { return ___Null_1; }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB ** get_address_of_Null_1() { return &___Null_1; }
	inline void set_Null_1(Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * value)
	{
		___Null_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Null_1), (void*)value);
	}
};


// System.UInt32
struct  UInt32_tE60352A06233E4E69DD198BCC67142159F686B15 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt32_tE60352A06233E4E69DD198BCC67142159F686B15, ___m_value_0)); }
	inline uint32_t get_m_value_0() const { return ___m_value_0; }
	inline uint32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint32_t value)
	{
		___m_value_0 = value;
	}
};


// System.UInt64
struct  UInt64_tEC57511B3E3CA2DBA1BEBD434C6983E31C943281 
{
public:
	// System.UInt64 System.UInt64::m_value
	uint64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt64_tEC57511B3E3CA2DBA1BEBD434C6983E31C943281, ___m_value_0)); }
	inline uint64_t get_m_value_0() const { return ___m_value_0; }
	inline uint64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint64_t value)
	{
		___m_value_0 = value;
	}
};


// System.Void
struct  Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t700C6383A2A510C2CF4DD86DABD5CA9FF70ADAC5__padding[1];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=256
struct  __StaticArrayInitTypeSizeU3D256_tFE50B5D9BCF7793F3A6994E8A2310F266EA35E39 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D256_tFE50B5D9BCF7793F3A6994E8A2310F266EA35E39__padding[256];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=3
struct  __StaticArrayInitTypeSizeU3D3_tE2F3546C51324DEDF5756FE7D6B41A92AB162B97 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D3_tE2F3546C51324DEDF5756FE7D6B41A92AB162B97__padding[3];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36
struct  __StaticArrayInitTypeSizeU3D36_t2401DAFADAD1FD72EA54B88D4C784E06C0EC680F 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D36_t2401DAFADAD1FD72EA54B88D4C784E06C0EC680F__padding[36];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=5
struct  __StaticArrayInitTypeSizeU3D5_tCB5874111F93F6592EF31CF23A0172F981CF7E7A 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D5_tCB5874111F93F6592EF31CF23A0172F981CF7E7A__padding[5];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52
struct  __StaticArrayInitTypeSizeU3D52_tED697A1527A65AE077E3DA32C3EC1E00B281B181 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D52_tED697A1527A65AE077E3DA32C3EC1E00B281B181__padding[52];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=7
struct  __StaticArrayInitTypeSizeU3D7_tA73F96B5FD22944B87F36B41977FF48D4B2729EA 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D7_tA73F96B5FD22944B87F36B41977FF48D4B2729EA__padding[7];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=9
struct  __StaticArrayInitTypeSizeU3D9_t6310282638B37E736407CCE5BB3638581321288E 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D9_t6310282638B37E736407CCE5BB3638581321288E__padding[9];
	};

public:
};


// System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter
struct  ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C 
{
public:
	// System.Threading.Tasks.Task System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter::m_task
	Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * ___m_task_0;
	// System.Boolean System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter::m_continueOnCapturedContext
	bool ___m_continueOnCapturedContext_1;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C, ___m_task_0)); }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * get_m_task_0() const { return ___m_task_0; }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_continueOnCapturedContext_1() { return static_cast<int32_t>(offsetof(ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C, ___m_continueOnCapturedContext_1)); }
	inline bool get_m_continueOnCapturedContext_1() const { return ___m_continueOnCapturedContext_1; }
	inline bool* get_address_of_m_continueOnCapturedContext_1() { return &___m_continueOnCapturedContext_1; }
	inline void set_m_continueOnCapturedContext_1(bool value)
	{
		___m_continueOnCapturedContext_1 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter
struct ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_marshaled_pinvoke
{
	Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * ___m_task_0;
	int32_t ___m_continueOnCapturedContext_1;
};
// Native definition for COM marshalling of System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter
struct ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_marshaled_com
{
	Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * ___m_task_0;
	int32_t ___m_continueOnCapturedContext_1;
};

// System.Text.Json.JsonDocument/DbRow
struct  DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F 
{
public:
	// System.Int32 System.Text.Json.JsonDocument/DbRow::_location
	int32_t ____location_1;
	// System.Int32 System.Text.Json.JsonDocument/DbRow::_sizeOrLengthUnion
	int32_t ____sizeOrLengthUnion_2;
	// System.Int32 System.Text.Json.JsonDocument/DbRow::_numberOfRowsAndTypeUnion
	int32_t ____numberOfRowsAndTypeUnion_3;

public:
	inline static int32_t get_offset_of__location_1() { return static_cast<int32_t>(offsetof(DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F, ____location_1)); }
	inline int32_t get__location_1() const { return ____location_1; }
	inline int32_t* get_address_of__location_1() { return &____location_1; }
	inline void set__location_1(int32_t value)
	{
		____location_1 = value;
	}

	inline static int32_t get_offset_of__sizeOrLengthUnion_2() { return static_cast<int32_t>(offsetof(DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F, ____sizeOrLengthUnion_2)); }
	inline int32_t get__sizeOrLengthUnion_2() const { return ____sizeOrLengthUnion_2; }
	inline int32_t* get_address_of__sizeOrLengthUnion_2() { return &____sizeOrLengthUnion_2; }
	inline void set__sizeOrLengthUnion_2(int32_t value)
	{
		____sizeOrLengthUnion_2 = value;
	}

	inline static int32_t get_offset_of__numberOfRowsAndTypeUnion_3() { return static_cast<int32_t>(offsetof(DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F, ____numberOfRowsAndTypeUnion_3)); }
	inline int32_t get__numberOfRowsAndTypeUnion_3() const { return ____numberOfRowsAndTypeUnion_3; }
	inline int32_t* get_address_of__numberOfRowsAndTypeUnion_3() { return &____numberOfRowsAndTypeUnion_3; }
	inline void set__numberOfRowsAndTypeUnion_3(int32_t value)
	{
		____numberOfRowsAndTypeUnion_3 = value;
	}
};


// System.Text.Json.JsonDocument/MetadataDb
struct  MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 
{
public:
	// System.Int32 System.Text.Json.JsonDocument/MetadataDb::<Length>k__BackingField
	int32_t ___U3CLengthU3Ek__BackingField_2;
	// System.Byte[] System.Text.Json.JsonDocument/MetadataDb::_data
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ____data_3;

public:
	inline static int32_t get_offset_of_U3CLengthU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26, ___U3CLengthU3Ek__BackingField_2)); }
	inline int32_t get_U3CLengthU3Ek__BackingField_2() const { return ___U3CLengthU3Ek__BackingField_2; }
	inline int32_t* get_address_of_U3CLengthU3Ek__BackingField_2() { return &___U3CLengthU3Ek__BackingField_2; }
	inline void set_U3CLengthU3Ek__BackingField_2(int32_t value)
	{
		___U3CLengthU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of__data_3() { return static_cast<int32_t>(offsetof(MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26, ____data_3)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get__data_3() const { return ____data_3; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of__data_3() { return &____data_3; }
	inline void set__data_3(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		____data_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____data_3), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.JsonDocument/MetadataDb
struct MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshaled_pinvoke
{
	int32_t ___U3CLengthU3Ek__BackingField_2;
	Il2CppSafeArray/*NONE*/* ____data_3;
};
// Native definition for COM marshalling of System.Text.Json.JsonDocument/MetadataDb
struct MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshaled_com
{
	int32_t ___U3CLengthU3Ek__BackingField_2;
	Il2CppSafeArray/*NONE*/* ____data_3;
};

// System.Text.Json.JsonDocument/StackRow
struct  StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA 
{
public:
	// System.Int32 System.Text.Json.JsonDocument/StackRow::SizeOrLength
	int32_t ___SizeOrLength_1;
	// System.Int32 System.Text.Json.JsonDocument/StackRow::NumberOfRows
	int32_t ___NumberOfRows_2;

public:
	inline static int32_t get_offset_of_SizeOrLength_1() { return static_cast<int32_t>(offsetof(StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA, ___SizeOrLength_1)); }
	inline int32_t get_SizeOrLength_1() const { return ___SizeOrLength_1; }
	inline int32_t* get_address_of_SizeOrLength_1() { return &___SizeOrLength_1; }
	inline void set_SizeOrLength_1(int32_t value)
	{
		___SizeOrLength_1 = value;
	}

	inline static int32_t get_offset_of_NumberOfRows_2() { return static_cast<int32_t>(offsetof(StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA, ___NumberOfRows_2)); }
	inline int32_t get_NumberOfRows_2() const { return ___NumberOfRows_2; }
	inline int32_t* get_address_of_NumberOfRows_2() { return &___NumberOfRows_2; }
	inline void set_NumberOfRows_2(int32_t value)
	{
		___NumberOfRows_2 = value;
	}
};


// System.Text.Json.JsonDocument/StackRowStack
struct  StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C 
{
public:
	// System.Byte[] System.Text.Json.JsonDocument/StackRowStack::_rentedBuffer
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ____rentedBuffer_0;
	// System.Int32 System.Text.Json.JsonDocument/StackRowStack::_topOfStack
	int32_t ____topOfStack_1;

public:
	inline static int32_t get_offset_of__rentedBuffer_0() { return static_cast<int32_t>(offsetof(StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C, ____rentedBuffer_0)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get__rentedBuffer_0() const { return ____rentedBuffer_0; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of__rentedBuffer_0() { return &____rentedBuffer_0; }
	inline void set__rentedBuffer_0(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		____rentedBuffer_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____rentedBuffer_0), (void*)value);
	}

	inline static int32_t get_offset_of__topOfStack_1() { return static_cast<int32_t>(offsetof(StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C, ____topOfStack_1)); }
	inline int32_t get__topOfStack_1() const { return ____topOfStack_1; }
	inline int32_t* get_address_of__topOfStack_1() { return &____topOfStack_1; }
	inline void set__topOfStack_1(int32_t value)
	{
		____topOfStack_1 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.JsonDocument/StackRowStack
struct StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshaled_pinvoke
{
	Il2CppSafeArray/*NONE*/* ____rentedBuffer_0;
	int32_t ____topOfStack_1;
};
// Native definition for COM marshalling of System.Text.Json.JsonDocument/StackRowStack
struct StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshaled_com
{
	Il2CppSafeArray/*NONE*/* ____rentedBuffer_0;
	int32_t ____topOfStack_1;
};

// System.Text.Json.JsonHelpers/DateTimeParseData
struct  DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E 
{
public:
	// System.Int32 System.Text.Json.JsonHelpers/DateTimeParseData::Year
	int32_t ___Year_0;
	// System.Int32 System.Text.Json.JsonHelpers/DateTimeParseData::Month
	int32_t ___Month_1;
	// System.Int32 System.Text.Json.JsonHelpers/DateTimeParseData::Day
	int32_t ___Day_2;
	// System.Int32 System.Text.Json.JsonHelpers/DateTimeParseData::Hour
	int32_t ___Hour_3;
	// System.Int32 System.Text.Json.JsonHelpers/DateTimeParseData::Minute
	int32_t ___Minute_4;
	// System.Int32 System.Text.Json.JsonHelpers/DateTimeParseData::Second
	int32_t ___Second_5;
	// System.Int32 System.Text.Json.JsonHelpers/DateTimeParseData::Fraction
	int32_t ___Fraction_6;
	// System.Int32 System.Text.Json.JsonHelpers/DateTimeParseData::OffsetHours
	int32_t ___OffsetHours_7;
	// System.Int32 System.Text.Json.JsonHelpers/DateTimeParseData::OffsetMinutes
	int32_t ___OffsetMinutes_8;
	// System.Byte System.Text.Json.JsonHelpers/DateTimeParseData::OffsetToken
	uint8_t ___OffsetToken_9;

public:
	inline static int32_t get_offset_of_Year_0() { return static_cast<int32_t>(offsetof(DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E, ___Year_0)); }
	inline int32_t get_Year_0() const { return ___Year_0; }
	inline int32_t* get_address_of_Year_0() { return &___Year_0; }
	inline void set_Year_0(int32_t value)
	{
		___Year_0 = value;
	}

	inline static int32_t get_offset_of_Month_1() { return static_cast<int32_t>(offsetof(DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E, ___Month_1)); }
	inline int32_t get_Month_1() const { return ___Month_1; }
	inline int32_t* get_address_of_Month_1() { return &___Month_1; }
	inline void set_Month_1(int32_t value)
	{
		___Month_1 = value;
	}

	inline static int32_t get_offset_of_Day_2() { return static_cast<int32_t>(offsetof(DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E, ___Day_2)); }
	inline int32_t get_Day_2() const { return ___Day_2; }
	inline int32_t* get_address_of_Day_2() { return &___Day_2; }
	inline void set_Day_2(int32_t value)
	{
		___Day_2 = value;
	}

	inline static int32_t get_offset_of_Hour_3() { return static_cast<int32_t>(offsetof(DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E, ___Hour_3)); }
	inline int32_t get_Hour_3() const { return ___Hour_3; }
	inline int32_t* get_address_of_Hour_3() { return &___Hour_3; }
	inline void set_Hour_3(int32_t value)
	{
		___Hour_3 = value;
	}

	inline static int32_t get_offset_of_Minute_4() { return static_cast<int32_t>(offsetof(DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E, ___Minute_4)); }
	inline int32_t get_Minute_4() const { return ___Minute_4; }
	inline int32_t* get_address_of_Minute_4() { return &___Minute_4; }
	inline void set_Minute_4(int32_t value)
	{
		___Minute_4 = value;
	}

	inline static int32_t get_offset_of_Second_5() { return static_cast<int32_t>(offsetof(DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E, ___Second_5)); }
	inline int32_t get_Second_5() const { return ___Second_5; }
	inline int32_t* get_address_of_Second_5() { return &___Second_5; }
	inline void set_Second_5(int32_t value)
	{
		___Second_5 = value;
	}

	inline static int32_t get_offset_of_Fraction_6() { return static_cast<int32_t>(offsetof(DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E, ___Fraction_6)); }
	inline int32_t get_Fraction_6() const { return ___Fraction_6; }
	inline int32_t* get_address_of_Fraction_6() { return &___Fraction_6; }
	inline void set_Fraction_6(int32_t value)
	{
		___Fraction_6 = value;
	}

	inline static int32_t get_offset_of_OffsetHours_7() { return static_cast<int32_t>(offsetof(DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E, ___OffsetHours_7)); }
	inline int32_t get_OffsetHours_7() const { return ___OffsetHours_7; }
	inline int32_t* get_address_of_OffsetHours_7() { return &___OffsetHours_7; }
	inline void set_OffsetHours_7(int32_t value)
	{
		___OffsetHours_7 = value;
	}

	inline static int32_t get_offset_of_OffsetMinutes_8() { return static_cast<int32_t>(offsetof(DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E, ___OffsetMinutes_8)); }
	inline int32_t get_OffsetMinutes_8() const { return ___OffsetMinutes_8; }
	inline int32_t* get_address_of_OffsetMinutes_8() { return &___OffsetMinutes_8; }
	inline void set_OffsetMinutes_8(int32_t value)
	{
		___OffsetMinutes_8 = value;
	}

	inline static int32_t get_offset_of_OffsetToken_9() { return static_cast<int32_t>(offsetof(DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E, ___OffsetToken_9)); }
	inline uint8_t get_OffsetToken_9() const { return ___OffsetToken_9; }
	inline uint8_t* get_address_of_OffsetToken_9() { return &___OffsetToken_9; }
	inline void set_OffsetToken_9(uint8_t value)
	{
		___OffsetToken_9 = value;
	}
};


// System.Text.Json.JsonSerializerOptions/<>c__DisplayClass3_0
struct  U3CU3Ec__DisplayClass3_0_t6D5AA24C4E207C767D92A44E3D5445CDE5E147A7 
{
public:
	// System.Collections.Generic.Dictionary`2<System.Type,System.Text.Json.Serialization.JsonConverter> System.Text.Json.JsonSerializerOptions/<>c__DisplayClass3_0::converters
	Dictionary_2_t87370488A06CE643EF15B83A78E0AC9870FEDB15 * ___converters_0;

public:
	inline static int32_t get_offset_of_converters_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass3_0_t6D5AA24C4E207C767D92A44E3D5445CDE5E147A7, ___converters_0)); }
	inline Dictionary_2_t87370488A06CE643EF15B83A78E0AC9870FEDB15 * get_converters_0() const { return ___converters_0; }
	inline Dictionary_2_t87370488A06CE643EF15B83A78E0AC9870FEDB15 ** get_address_of_converters_0() { return &___converters_0; }
	inline void set_converters_0(Dictionary_2_t87370488A06CE643EF15B83A78E0AC9870FEDB15 * value)
	{
		___converters_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___converters_0), (void*)value);
	}
};


// System.Text.Json.JsonSerializerOptions/<>c__DisplayClass4_0
struct  U3CU3Ec__DisplayClass4_0_t593C74B93352CD492DB9EB3E51E6C6101A0062FD 
{
public:
	// System.Type System.Text.Json.JsonSerializerOptions/<>c__DisplayClass4_0::keyType
	Type_t * ___keyType_0;
	// System.Text.Json.JsonSerializerOptions System.Text.Json.JsonSerializerOptions/<>c__DisplayClass4_0::<>4__this
	JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * ___U3CU3E4__this_1;

public:
	inline static int32_t get_offset_of_keyType_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass4_0_t593C74B93352CD492DB9EB3E51E6C6101A0062FD, ___keyType_0)); }
	inline Type_t * get_keyType_0() const { return ___keyType_0; }
	inline Type_t ** get_address_of_keyType_0() { return &___keyType_0; }
	inline void set_keyType_0(Type_t * value)
	{
		___keyType_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___keyType_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_1() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass4_0_t593C74B93352CD492DB9EB3E51E6C6101A0062FD, ___U3CU3E4__this_1)); }
	inline JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * get_U3CU3E4__this_1() const { return ___U3CU3E4__this_1; }
	inline JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 ** get_address_of_U3CU3E4__this_1() { return &___U3CU3E4__this_1; }
	inline void set_U3CU3E4__this_1(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * value)
	{
		___U3CU3E4__this_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_1), (void*)value);
	}
};


// System.Text.Json.JsonSerializerOptions/<>c__DisplayClass6_0
struct  U3CU3Ec__DisplayClass6_0_t98714B109933020910C32D029B08AD882351011B 
{
public:
	// System.Collections.Concurrent.ConcurrentDictionary`2<System.Type,System.Text.Json.Serialization.JsonConverter> System.Text.Json.JsonSerializerOptions/<>c__DisplayClass6_0::converters
	ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 * ___converters_0;

public:
	inline static int32_t get_offset_of_converters_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass6_0_t98714B109933020910C32D029B08AD882351011B, ___converters_0)); }
	inline ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 * get_converters_0() const { return ___converters_0; }
	inline ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 ** get_address_of_converters_0() { return &___converters_0; }
	inline void set_converters_0(ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 * value)
	{
		___converters_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___converters_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.ArraySegment`1<System.Byte>>
struct  AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 
{
public:
	// System.Runtime.CompilerServices.AsyncMethodBuilderCore System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_coreState
	AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  ___m_coreState_1;
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_task
	Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * ___m_task_2;

public:
	inline static int32_t get_offset_of_m_coreState_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4, ___m_coreState_1)); }
	inline AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  get_m_coreState_1() const { return ___m_coreState_1; }
	inline AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34 * get_address_of_m_coreState_1() { return &___m_coreState_1; }
	inline void set_m_coreState_1(AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  value)
	{
		___m_coreState_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_task_2() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4, ___m_task_2)); }
	inline Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * get_m_task_2() const { return ___m_task_2; }
	inline Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 ** get_address_of_m_task_2() { return &___m_task_2; }
	inline void set_m_task_2(Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * value)
	{
		___m_task_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_2), (void*)value);
	}
};

struct AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::s_defaultResultTask
	Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * ___s_defaultResultTask_0;

public:
	inline static int32_t get_offset_of_s_defaultResultTask_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4_StaticFields, ___s_defaultResultTask_0)); }
	inline Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * get_s_defaultResultTask_0() const { return ___s_defaultResultTask_0; }
	inline Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 ** get_address_of_s_defaultResultTask_0() { return &___s_defaultResultTask_0; }
	inline void set_s_defaultResultTask_0(Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * value)
	{
		___s_defaultResultTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultResultTask_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Text.Json.JsonDocument>
struct  AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 
{
public:
	// System.Runtime.CompilerServices.AsyncMethodBuilderCore System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_coreState
	AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  ___m_coreState_1;
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_task
	Task_1_tD781EDEF7BCB3B0E3F7EAD7B32260768B285C6DB * ___m_task_2;

public:
	inline static int32_t get_offset_of_m_coreState_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445, ___m_coreState_1)); }
	inline AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  get_m_coreState_1() const { return ___m_coreState_1; }
	inline AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34 * get_address_of_m_coreState_1() { return &___m_coreState_1; }
	inline void set_m_coreState_1(AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  value)
	{
		___m_coreState_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_task_2() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445, ___m_task_2)); }
	inline Task_1_tD781EDEF7BCB3B0E3F7EAD7B32260768B285C6DB * get_m_task_2() const { return ___m_task_2; }
	inline Task_1_tD781EDEF7BCB3B0E3F7EAD7B32260768B285C6DB ** get_address_of_m_task_2() { return &___m_task_2; }
	inline void set_m_task_2(Task_1_tD781EDEF7BCB3B0E3F7EAD7B32260768B285C6DB * value)
	{
		___m_task_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_2), (void*)value);
	}
};

struct AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::s_defaultResultTask
	Task_1_tD781EDEF7BCB3B0E3F7EAD7B32260768B285C6DB * ___s_defaultResultTask_0;

public:
	inline static int32_t get_offset_of_s_defaultResultTask_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445_StaticFields, ___s_defaultResultTask_0)); }
	inline Task_1_tD781EDEF7BCB3B0E3F7EAD7B32260768B285C6DB * get_s_defaultResultTask_0() const { return ___s_defaultResultTask_0; }
	inline Task_1_tD781EDEF7BCB3B0E3F7EAD7B32260768B285C6DB ** get_address_of_s_defaultResultTask_0() { return &___s_defaultResultTask_0; }
	inline void set_s_defaultResultTask_0(Task_1_tD781EDEF7BCB3B0E3F7EAD7B32260768B285C6DB * value)
	{
		___s_defaultResultTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultResultTask_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>
struct  AsyncTaskMethodBuilder_1_tDD2A3BA099C327938EA03C35FDB1A7502BA73020 
{
public:
	// System.Runtime.CompilerServices.AsyncMethodBuilderCore System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_coreState
	AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  ___m_coreState_1;
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_task
	Task_1_tC1805497876E88B78A2B0CB81C6409E0B381AC17 * ___m_task_2;

public:
	inline static int32_t get_offset_of_m_coreState_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_tDD2A3BA099C327938EA03C35FDB1A7502BA73020, ___m_coreState_1)); }
	inline AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  get_m_coreState_1() const { return ___m_coreState_1; }
	inline AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34 * get_address_of_m_coreState_1() { return &___m_coreState_1; }
	inline void set_m_coreState_1(AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  value)
	{
		___m_coreState_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_task_2() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_tDD2A3BA099C327938EA03C35FDB1A7502BA73020, ___m_task_2)); }
	inline Task_1_tC1805497876E88B78A2B0CB81C6409E0B381AC17 * get_m_task_2() const { return ___m_task_2; }
	inline Task_1_tC1805497876E88B78A2B0CB81C6409E0B381AC17 ** get_address_of_m_task_2() { return &___m_task_2; }
	inline void set_m_task_2(Task_1_tC1805497876E88B78A2B0CB81C6409E0B381AC17 * value)
	{
		___m_task_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_2), (void*)value);
	}
};

struct AsyncTaskMethodBuilder_1_tDD2A3BA099C327938EA03C35FDB1A7502BA73020_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::s_defaultResultTask
	Task_1_tC1805497876E88B78A2B0CB81C6409E0B381AC17 * ___s_defaultResultTask_0;

public:
	inline static int32_t get_offset_of_s_defaultResultTask_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_tDD2A3BA099C327938EA03C35FDB1A7502BA73020_StaticFields, ___s_defaultResultTask_0)); }
	inline Task_1_tC1805497876E88B78A2B0CB81C6409E0B381AC17 * get_s_defaultResultTask_0() const { return ___s_defaultResultTask_0; }
	inline Task_1_tC1805497876E88B78A2B0CB81C6409E0B381AC17 ** get_address_of_s_defaultResultTask_0() { return &___s_defaultResultTask_0; }
	inline void set_s_defaultResultTask_0(Task_1_tC1805497876E88B78A2B0CB81C6409E0B381AC17 * value)
	{
		___s_defaultResultTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultResultTask_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Threading.Tasks.VoidTaskResult>
struct  AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD 
{
public:
	// System.Runtime.CompilerServices.AsyncMethodBuilderCore System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_coreState
	AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  ___m_coreState_1;
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_task
	Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 * ___m_task_2;

public:
	inline static int32_t get_offset_of_m_coreState_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD, ___m_coreState_1)); }
	inline AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  get_m_coreState_1() const { return ___m_coreState_1; }
	inline AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34 * get_address_of_m_coreState_1() { return &___m_coreState_1; }
	inline void set_m_coreState_1(AsyncMethodBuilderCore_t2C85055E04767C52B9F66144476FCBF500DBFA34  value)
	{
		___m_coreState_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_task_2() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD, ___m_task_2)); }
	inline Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 * get_m_task_2() const { return ___m_task_2; }
	inline Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 ** get_address_of_m_task_2() { return &___m_task_2; }
	inline void set_m_task_2(Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 * value)
	{
		___m_task_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_2), (void*)value);
	}
};

struct AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::s_defaultResultTask
	Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 * ___s_defaultResultTask_0;

public:
	inline static int32_t get_offset_of_s_defaultResultTask_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD_StaticFields, ___s_defaultResultTask_0)); }
	inline Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 * get_s_defaultResultTask_0() const { return ___s_defaultResultTask_0; }
	inline Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 ** get_address_of_s_defaultResultTask_0() { return &___s_defaultResultTask_0; }
	inline void set_s_defaultResultTask_0(Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 * value)
	{
		___s_defaultResultTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultResultTask_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<System.ArraySegment`1<System.Byte>>
struct  ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8 
{
public:
	// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<TResult> System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1::m_configuredTaskAwaiter
	ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  ___m_configuredTaskAwaiter_0;

public:
	inline static int32_t get_offset_of_m_configuredTaskAwaiter_0() { return static_cast<int32_t>(offsetof(ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8, ___m_configuredTaskAwaiter_0)); }
	inline ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  get_m_configuredTaskAwaiter_0() const { return ___m_configuredTaskAwaiter_0; }
	inline ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C * get_address_of_m_configuredTaskAwaiter_0() { return &___m_configuredTaskAwaiter_0; }
	inline void set_m_configuredTaskAwaiter_0(ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  value)
	{
		___m_configuredTaskAwaiter_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_configuredTaskAwaiter_0))->___m_task_0), (void*)NULL);
	}
};


// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<System.Int32>
struct  ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC 
{
public:
	// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<TResult> System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1::m_configuredTaskAwaiter
	ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  ___m_configuredTaskAwaiter_0;

public:
	inline static int32_t get_offset_of_m_configuredTaskAwaiter_0() { return static_cast<int32_t>(offsetof(ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC, ___m_configuredTaskAwaiter_0)); }
	inline ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  get_m_configuredTaskAwaiter_0() const { return ___m_configuredTaskAwaiter_0; }
	inline ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 * get_address_of_m_configuredTaskAwaiter_0() { return &___m_configuredTaskAwaiter_0; }
	inline void set_m_configuredTaskAwaiter_0(ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  value)
	{
		___m_configuredTaskAwaiter_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_configuredTaskAwaiter_0))->___m_task_0), (void*)NULL);
	}
};


// System.SpanHelpers/PerTypeValues`1<System.Byte>
struct  PerTypeValues_1_tB073195618B2A7CB0FE31C31919AF7A3BB10C376  : public RuntimeObject
{
public:

public:
};

struct PerTypeValues_1_tB073195618B2A7CB0FE31C31919AF7A3BB10C376_StaticFields
{
public:
	// System.Boolean System.SpanHelpers/PerTypeValues`1::IsReferenceOrContainsReferences
	bool ___IsReferenceOrContainsReferences_0;
	// T[] System.SpanHelpers/PerTypeValues`1::EmptyArray
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___EmptyArray_1;
	// System.IntPtr System.SpanHelpers/PerTypeValues`1::ArrayAdjustment
	intptr_t ___ArrayAdjustment_2;

public:
	inline static int32_t get_offset_of_IsReferenceOrContainsReferences_0() { return static_cast<int32_t>(offsetof(PerTypeValues_1_tB073195618B2A7CB0FE31C31919AF7A3BB10C376_StaticFields, ___IsReferenceOrContainsReferences_0)); }
	inline bool get_IsReferenceOrContainsReferences_0() const { return ___IsReferenceOrContainsReferences_0; }
	inline bool* get_address_of_IsReferenceOrContainsReferences_0() { return &___IsReferenceOrContainsReferences_0; }
	inline void set_IsReferenceOrContainsReferences_0(bool value)
	{
		___IsReferenceOrContainsReferences_0 = value;
	}

	inline static int32_t get_offset_of_EmptyArray_1() { return static_cast<int32_t>(offsetof(PerTypeValues_1_tB073195618B2A7CB0FE31C31919AF7A3BB10C376_StaticFields, ___EmptyArray_1)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_EmptyArray_1() const { return ___EmptyArray_1; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_EmptyArray_1() { return &___EmptyArray_1; }
	inline void set_EmptyArray_1(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___EmptyArray_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___EmptyArray_1), (void*)value);
	}

	inline static int32_t get_offset_of_ArrayAdjustment_2() { return static_cast<int32_t>(offsetof(PerTypeValues_1_tB073195618B2A7CB0FE31C31919AF7A3BB10C376_StaticFields, ___ArrayAdjustment_2)); }
	inline intptr_t get_ArrayAdjustment_2() const { return ___ArrayAdjustment_2; }
	inline intptr_t* get_address_of_ArrayAdjustment_2() { return &___ArrayAdjustment_2; }
	inline void set_ArrayAdjustment_2(intptr_t value)
	{
		___ArrayAdjustment_2 = value;
	}
};


// System.ReadOnlySpan`1<System.Byte>
struct  ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 
{
public:
	// System.Pinnable`1<T> System.ReadOnlySpan`1::_pinnable
	Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * ____pinnable_0;
	// System.IntPtr System.ReadOnlySpan`1::_byteOffset
	intptr_t ____byteOffset_1;
	// System.Int32 System.ReadOnlySpan`1::_length
	int32_t ____length_2;

public:
	inline static int32_t get_offset_of__pinnable_0() { return static_cast<int32_t>(offsetof(ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726, ____pinnable_0)); }
	inline Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * get__pinnable_0() const { return ____pinnable_0; }
	inline Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 ** get_address_of__pinnable_0() { return &____pinnable_0; }
	inline void set__pinnable_0(Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * value)
	{
		____pinnable_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____pinnable_0), (void*)value);
	}

	inline static int32_t get_offset_of__byteOffset_1() { return static_cast<int32_t>(offsetof(ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726, ____byteOffset_1)); }
	inline intptr_t get__byteOffset_1() const { return ____byteOffset_1; }
	inline intptr_t* get_address_of__byteOffset_1() { return &____byteOffset_1; }
	inline void set__byteOffset_1(intptr_t value)
	{
		____byteOffset_1 = value;
	}

	inline static int32_t get_offset_of__length_2() { return static_cast<int32_t>(offsetof(ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726, ____length_2)); }
	inline int32_t get__length_2() const { return ____length_2; }
	inline int32_t* get_address_of__length_2() { return &____length_2; }
	inline void set__length_2(int32_t value)
	{
		____length_2 = value;
	}
};


// System.Span`1<System.Byte>
struct  Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 
{
public:
	// System.Pinnable`1<T> System.Span`1::_pinnable
	Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * ____pinnable_0;
	// System.IntPtr System.Span`1::_byteOffset
	intptr_t ____byteOffset_1;
	// System.Int32 System.Span`1::_length
	int32_t ____length_2;

public:
	inline static int32_t get_offset_of__pinnable_0() { return static_cast<int32_t>(offsetof(Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83, ____pinnable_0)); }
	inline Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * get__pinnable_0() const { return ____pinnable_0; }
	inline Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 ** get_address_of__pinnable_0() { return &____pinnable_0; }
	inline void set__pinnable_0(Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * value)
	{
		____pinnable_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____pinnable_0), (void*)value);
	}

	inline static int32_t get_offset_of__byteOffset_1() { return static_cast<int32_t>(offsetof(Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83, ____byteOffset_1)); }
	inline intptr_t get__byteOffset_1() const { return ____byteOffset_1; }
	inline intptr_t* get_address_of__byteOffset_1() { return &____byteOffset_1; }
	inline void set__byteOffset_1(intptr_t value)
	{
		____byteOffset_1 = value;
	}

	inline static int32_t get_offset_of__length_2() { return static_cast<int32_t>(offsetof(Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83, ____length_2)); }
	inline int32_t get__length_2() const { return ____length_2; }
	inline int32_t* get_address_of__length_2() { return &____length_2; }
	inline void set__length_2(int32_t value)
	{
		____length_2 = value;
	}
};


// System.Span`1<System.Int32>
struct  Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526 
{
public:
	// System.Pinnable`1<T> System.Span`1::_pinnable
	Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D * ____pinnable_0;
	// System.IntPtr System.Span`1::_byteOffset
	intptr_t ____byteOffset_1;
	// System.Int32 System.Span`1::_length
	int32_t ____length_2;

public:
	inline static int32_t get_offset_of__pinnable_0() { return static_cast<int32_t>(offsetof(Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526, ____pinnable_0)); }
	inline Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D * get__pinnable_0() const { return ____pinnable_0; }
	inline Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D ** get_address_of__pinnable_0() { return &____pinnable_0; }
	inline void set__pinnable_0(Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D * value)
	{
		____pinnable_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____pinnable_0), (void*)value);
	}

	inline static int32_t get_offset_of__byteOffset_1() { return static_cast<int32_t>(offsetof(Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526, ____byteOffset_1)); }
	inline intptr_t get__byteOffset_1() const { return ____byteOffset_1; }
	inline intptr_t* get_address_of__byteOffset_1() { return &____byteOffset_1; }
	inline void set__byteOffset_1(intptr_t value)
	{
		____byteOffset_1 = value;
	}

	inline static int32_t get_offset_of__length_2() { return static_cast<int32_t>(offsetof(Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526, ____length_2)); }
	inline int32_t get__length_2() const { return ____length_2; }
	inline int32_t* get_address_of__length_2() { return &____length_2; }
	inline void set__length_2(int32_t value)
	{
		____length_2 = value;
	}
};


// System.Reflection.BindingFlags
struct  BindingFlags_tAAAB07D9AC588F0D55D844E51D7035E96DF94733 
{
public:
	// System.Int32 System.Reflection.BindingFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(BindingFlags_tAAAB07D9AC588F0D55D844E51D7035E96DF94733, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Text.Json.ClassType
struct  ClassType_t37D744D31C70BC38ADAA19EB062A9D6DD5A736AC 
{
public:
	// System.Byte System.Text.Json.ClassType::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ClassType_t37D744D31C70BC38ADAA19EB062A9D6DD5A736AC, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};


// System.Runtime.CompilerServices.ConfiguredTaskAwaitable
struct  ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E 
{
public:
	// System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter System.Runtime.CompilerServices.ConfiguredTaskAwaitable::m_configuredTaskAwaiter
	ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  ___m_configuredTaskAwaiter_0;

public:
	inline static int32_t get_offset_of_m_configuredTaskAwaiter_0() { return static_cast<int32_t>(offsetof(ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E, ___m_configuredTaskAwaiter_0)); }
	inline ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  get_m_configuredTaskAwaiter_0() const { return ___m_configuredTaskAwaiter_0; }
	inline ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * get_address_of_m_configuredTaskAwaiter_0() { return &___m_configuredTaskAwaiter_0; }
	inline void set_m_configuredTaskAwaiter_0(ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  value)
	{
		___m_configuredTaskAwaiter_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_configuredTaskAwaiter_0))->___m_task_0), (void*)NULL);
	}
};

// Native definition for P/Invoke marshalling of System.Runtime.CompilerServices.ConfiguredTaskAwaitable
struct ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E_marshaled_pinvoke
{
	ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_marshaled_pinvoke ___m_configuredTaskAwaiter_0;
};
// Native definition for COM marshalling of System.Runtime.CompilerServices.ConfiguredTaskAwaitable
struct ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E_marshaled_com
{
	ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_marshaled_com ___m_configuredTaskAwaiter_0;
};

// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_target_2), (void*)value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___method_info_7), (void*)value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___original_method_info_8), (void*)value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * get_data_9() const { return ___data_9; }
	inline DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___data_9), (void*)value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t17DD30660E330C49381DAA99F934BE75CB11F288 * ___data_9;
	int32_t ___method_is_virtual_10;
};

// System.Exception
struct  Exception_t  : public RuntimeObject
{
public:
	// System.String System.Exception::_className
	String_t* ____className_1;
	// System.String System.Exception::_message
	String_t* ____message_2;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_3;
	// System.Exception System.Exception::_innerException
	Exception_t * ____innerException_4;
	// System.String System.Exception::_helpURL
	String_t* ____helpURL_5;
	// System.Object System.Exception::_stackTrace
	RuntimeObject * ____stackTrace_6;
	// System.String System.Exception::_stackTraceString
	String_t* ____stackTraceString_7;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_8;
	// System.Int32 System.Exception::_remoteStackIndex
	int32_t ____remoteStackIndex_9;
	// System.Object System.Exception::_dynamicMethods
	RuntimeObject * ____dynamicMethods_10;
	// System.Int32 System.Exception::_HResult
	int32_t ____HResult_11;
	// System.String System.Exception::_source
	String_t* ____source_12;
	// System.Runtime.Serialization.SafeSerializationManager System.Exception::_safeSerializationManager
	SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F * ____safeSerializationManager_13;
	// System.Diagnostics.StackTrace[] System.Exception::captured_traces
	StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971* ___captured_traces_14;
	// System.IntPtr[] System.Exception::native_trace_ips
	IntPtrU5BU5D_t27FC72B0409D75AAF33EC42498E8094E95FEE9A6* ___native_trace_ips_15;

public:
	inline static int32_t get_offset_of__className_1() { return static_cast<int32_t>(offsetof(Exception_t, ____className_1)); }
	inline String_t* get__className_1() const { return ____className_1; }
	inline String_t** get_address_of__className_1() { return &____className_1; }
	inline void set__className_1(String_t* value)
	{
		____className_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____className_1), (void*)value);
	}

	inline static int32_t get_offset_of__message_2() { return static_cast<int32_t>(offsetof(Exception_t, ____message_2)); }
	inline String_t* get__message_2() const { return ____message_2; }
	inline String_t** get_address_of__message_2() { return &____message_2; }
	inline void set__message_2(String_t* value)
	{
		____message_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____message_2), (void*)value);
	}

	inline static int32_t get_offset_of__data_3() { return static_cast<int32_t>(offsetof(Exception_t, ____data_3)); }
	inline RuntimeObject* get__data_3() const { return ____data_3; }
	inline RuntimeObject** get_address_of__data_3() { return &____data_3; }
	inline void set__data_3(RuntimeObject* value)
	{
		____data_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____data_3), (void*)value);
	}

	inline static int32_t get_offset_of__innerException_4() { return static_cast<int32_t>(offsetof(Exception_t, ____innerException_4)); }
	inline Exception_t * get__innerException_4() const { return ____innerException_4; }
	inline Exception_t ** get_address_of__innerException_4() { return &____innerException_4; }
	inline void set__innerException_4(Exception_t * value)
	{
		____innerException_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____innerException_4), (void*)value);
	}

	inline static int32_t get_offset_of__helpURL_5() { return static_cast<int32_t>(offsetof(Exception_t, ____helpURL_5)); }
	inline String_t* get__helpURL_5() const { return ____helpURL_5; }
	inline String_t** get_address_of__helpURL_5() { return &____helpURL_5; }
	inline void set__helpURL_5(String_t* value)
	{
		____helpURL_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____helpURL_5), (void*)value);
	}

	inline static int32_t get_offset_of__stackTrace_6() { return static_cast<int32_t>(offsetof(Exception_t, ____stackTrace_6)); }
	inline RuntimeObject * get__stackTrace_6() const { return ____stackTrace_6; }
	inline RuntimeObject ** get_address_of__stackTrace_6() { return &____stackTrace_6; }
	inline void set__stackTrace_6(RuntimeObject * value)
	{
		____stackTrace_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____stackTrace_6), (void*)value);
	}

	inline static int32_t get_offset_of__stackTraceString_7() { return static_cast<int32_t>(offsetof(Exception_t, ____stackTraceString_7)); }
	inline String_t* get__stackTraceString_7() const { return ____stackTraceString_7; }
	inline String_t** get_address_of__stackTraceString_7() { return &____stackTraceString_7; }
	inline void set__stackTraceString_7(String_t* value)
	{
		____stackTraceString_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____stackTraceString_7), (void*)value);
	}

	inline static int32_t get_offset_of__remoteStackTraceString_8() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackTraceString_8)); }
	inline String_t* get__remoteStackTraceString_8() const { return ____remoteStackTraceString_8; }
	inline String_t** get_address_of__remoteStackTraceString_8() { return &____remoteStackTraceString_8; }
	inline void set__remoteStackTraceString_8(String_t* value)
	{
		____remoteStackTraceString_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____remoteStackTraceString_8), (void*)value);
	}

	inline static int32_t get_offset_of__remoteStackIndex_9() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackIndex_9)); }
	inline int32_t get__remoteStackIndex_9() const { return ____remoteStackIndex_9; }
	inline int32_t* get_address_of__remoteStackIndex_9() { return &____remoteStackIndex_9; }
	inline void set__remoteStackIndex_9(int32_t value)
	{
		____remoteStackIndex_9 = value;
	}

	inline static int32_t get_offset_of__dynamicMethods_10() { return static_cast<int32_t>(offsetof(Exception_t, ____dynamicMethods_10)); }
	inline RuntimeObject * get__dynamicMethods_10() const { return ____dynamicMethods_10; }
	inline RuntimeObject ** get_address_of__dynamicMethods_10() { return &____dynamicMethods_10; }
	inline void set__dynamicMethods_10(RuntimeObject * value)
	{
		____dynamicMethods_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____dynamicMethods_10), (void*)value);
	}

	inline static int32_t get_offset_of__HResult_11() { return static_cast<int32_t>(offsetof(Exception_t, ____HResult_11)); }
	inline int32_t get__HResult_11() const { return ____HResult_11; }
	inline int32_t* get_address_of__HResult_11() { return &____HResult_11; }
	inline void set__HResult_11(int32_t value)
	{
		____HResult_11 = value;
	}

	inline static int32_t get_offset_of__source_12() { return static_cast<int32_t>(offsetof(Exception_t, ____source_12)); }
	inline String_t* get__source_12() const { return ____source_12; }
	inline String_t** get_address_of__source_12() { return &____source_12; }
	inline void set__source_12(String_t* value)
	{
		____source_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____source_12), (void*)value);
	}

	inline static int32_t get_offset_of__safeSerializationManager_13() { return static_cast<int32_t>(offsetof(Exception_t, ____safeSerializationManager_13)); }
	inline SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F * get__safeSerializationManager_13() const { return ____safeSerializationManager_13; }
	inline SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F ** get_address_of__safeSerializationManager_13() { return &____safeSerializationManager_13; }
	inline void set__safeSerializationManager_13(SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F * value)
	{
		____safeSerializationManager_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____safeSerializationManager_13), (void*)value);
	}

	inline static int32_t get_offset_of_captured_traces_14() { return static_cast<int32_t>(offsetof(Exception_t, ___captured_traces_14)); }
	inline StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971* get_captured_traces_14() const { return ___captured_traces_14; }
	inline StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971** get_address_of_captured_traces_14() { return &___captured_traces_14; }
	inline void set_captured_traces_14(StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971* value)
	{
		___captured_traces_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___captured_traces_14), (void*)value);
	}

	inline static int32_t get_offset_of_native_trace_ips_15() { return static_cast<int32_t>(offsetof(Exception_t, ___native_trace_ips_15)); }
	inline IntPtrU5BU5D_t27FC72B0409D75AAF33EC42498E8094E95FEE9A6* get_native_trace_ips_15() const { return ___native_trace_ips_15; }
	inline IntPtrU5BU5D_t27FC72B0409D75AAF33EC42498E8094E95FEE9A6** get_address_of_native_trace_ips_15() { return &___native_trace_ips_15; }
	inline void set_native_trace_ips_15(IntPtrU5BU5D_t27FC72B0409D75AAF33EC42498E8094E95FEE9A6* value)
	{
		___native_trace_ips_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___native_trace_ips_15), (void*)value);
	}
};

struct Exception_t_StaticFields
{
public:
	// System.Object System.Exception::s_EDILock
	RuntimeObject * ___s_EDILock_0;

public:
	inline static int32_t get_offset_of_s_EDILock_0() { return static_cast<int32_t>(offsetof(Exception_t_StaticFields, ___s_EDILock_0)); }
	inline RuntimeObject * get_s_EDILock_0() const { return ___s_EDILock_0; }
	inline RuntimeObject ** get_address_of_s_EDILock_0() { return &___s_EDILock_0; }
	inline void set_s_EDILock_0(RuntimeObject * value)
	{
		___s_EDILock_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_EDILock_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Exception
struct Exception_t_marshaled_pinvoke
{
	char* ____className_1;
	char* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_pinvoke* ____innerException_4;
	char* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	char* ____stackTraceString_7;
	char* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	char* ____source_12;
	SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F * ____safeSerializationManager_13;
	StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971* ___captured_traces_14;
	Il2CppSafeArray/*NONE*/* ___native_trace_ips_15;
};
// Native definition for COM marshalling of System.Exception
struct Exception_t_marshaled_com
{
	Il2CppChar* ____className_1;
	Il2CppChar* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_com* ____innerException_4;
	Il2CppChar* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	Il2CppChar* ____stackTraceString_7;
	Il2CppChar* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	Il2CppChar* ____source_12;
	SafeSerializationManager_tDE44F029589A028F8A3053C5C06153FAB4AAE29F * ____safeSerializationManager_13;
	StackTraceU5BU5D_t4AD999C288CB6D1F38A299D12B1598D606588971* ___captured_traces_14;
	Il2CppSafeArray/*NONE*/* ___native_trace_ips_15;
};

// System.ExceptionArgument
struct  ExceptionArgument_t11B098DD9AD21AB015871A94DB7DC9A70A10509F 
{
public:
	// System.Int32 System.ExceptionArgument::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ExceptionArgument_t11B098DD9AD21AB015871A94DB7DC9A70A10509F, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Int32Enum
struct  Int32Enum_t9B63F771913F2B6D586F1173B44A41FBE26F6B5C 
{
public:
	// System.Int32 System.Int32Enum::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Int32Enum_t9B63F771913F2B6D586F1173B44A41FBE26F6B5C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Text.Json.JsonCommentHandling
struct  JsonCommentHandling_t8A1AE8276A4F0145E3232EDFBD781CDC33BD4D2C 
{
public:
	// System.Byte System.Text.Json.JsonCommentHandling::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(JsonCommentHandling_t8A1AE8276A4F0145E3232EDFBD781CDC33BD4D2C, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};


// System.Text.Json.JsonDocument
struct  JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1  : public RuntimeObject
{
public:
	// System.ReadOnlyMemory`1<System.Byte> System.Text.Json.JsonDocument::_utf8Json
	ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  ____utf8Json_0;
	// System.Text.Json.JsonDocument/MetadataDb System.Text.Json.JsonDocument::_parsedData
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  ____parsedData_1;
	// System.Byte[] System.Text.Json.JsonDocument::_extraRentedBytes
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ____extraRentedBytes_2;
	// System.ValueTuple`2<System.Int32,System.String> System.Text.Json.JsonDocument::_lastIndexAndString
	ValueTuple_2_t1C65704531D1BF77739714AEC12FE375712C593F  ____lastIndexAndString_3;
	// System.Boolean System.Text.Json.JsonDocument::<IsDisposable>k__BackingField
	bool ___U3CIsDisposableU3Ek__BackingField_4;

public:
	inline static int32_t get_offset_of__utf8Json_0() { return static_cast<int32_t>(offsetof(JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1, ____utf8Json_0)); }
	inline ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  get__utf8Json_0() const { return ____utf8Json_0; }
	inline ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133 * get_address_of__utf8Json_0() { return &____utf8Json_0; }
	inline void set__utf8Json_0(ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  value)
	{
		____utf8Json_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&____utf8Json_0))->____object_0), (void*)NULL);
	}

	inline static int32_t get_offset_of__parsedData_1() { return static_cast<int32_t>(offsetof(JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1, ____parsedData_1)); }
	inline MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  get__parsedData_1() const { return ____parsedData_1; }
	inline MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * get_address_of__parsedData_1() { return &____parsedData_1; }
	inline void set__parsedData_1(MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  value)
	{
		____parsedData_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&____parsedData_1))->____data_3), (void*)NULL);
	}

	inline static int32_t get_offset_of__extraRentedBytes_2() { return static_cast<int32_t>(offsetof(JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1, ____extraRentedBytes_2)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get__extraRentedBytes_2() const { return ____extraRentedBytes_2; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of__extraRentedBytes_2() { return &____extraRentedBytes_2; }
	inline void set__extraRentedBytes_2(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		____extraRentedBytes_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____extraRentedBytes_2), (void*)value);
	}

	inline static int32_t get_offset_of__lastIndexAndString_3() { return static_cast<int32_t>(offsetof(JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1, ____lastIndexAndString_3)); }
	inline ValueTuple_2_t1C65704531D1BF77739714AEC12FE375712C593F  get__lastIndexAndString_3() const { return ____lastIndexAndString_3; }
	inline ValueTuple_2_t1C65704531D1BF77739714AEC12FE375712C593F * get_address_of__lastIndexAndString_3() { return &____lastIndexAndString_3; }
	inline void set__lastIndexAndString_3(ValueTuple_2_t1C65704531D1BF77739714AEC12FE375712C593F  value)
	{
		____lastIndexAndString_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&____lastIndexAndString_3))->___Item2_1), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CIsDisposableU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1, ___U3CIsDisposableU3Ek__BackingField_4)); }
	inline bool get_U3CIsDisposableU3Ek__BackingField_4() const { return ___U3CIsDisposableU3Ek__BackingField_4; }
	inline bool* get_address_of_U3CIsDisposableU3Ek__BackingField_4() { return &___U3CIsDisposableU3Ek__BackingField_4; }
	inline void set_U3CIsDisposableU3Ek__BackingField_4(bool value)
	{
		___U3CIsDisposableU3Ek__BackingField_4 = value;
	}
};


// System.Text.Json.Serialization.JsonIgnoreCondition
struct  JsonIgnoreCondition_t74763EEE42E5339F9D981FC53212C12186B2F09E 
{
public:
	// System.Int32 System.Text.Json.Serialization.JsonIgnoreCondition::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(JsonIgnoreCondition_t74763EEE42E5339F9D981FC53212C12186B2F09E, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Text.Json.Serialization.JsonNumberHandling
struct  JsonNumberHandling_tC60ADBC09774A886DBBAE55E7C4F5E6908477EFA 
{
public:
	// System.Int32 System.Text.Json.Serialization.JsonNumberHandling::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(JsonNumberHandling_tC60ADBC09774A886DBBAE55E7C4F5E6908477EFA, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Text.Json.JsonProperty
struct  JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043 
{
public:
	// System.Text.Json.JsonElement System.Text.Json.JsonProperty::<Value>k__BackingField
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ___U3CValueU3Ek__BackingField_0;
	// System.String System.Text.Json.JsonProperty::<_name>k__BackingField
	String_t* ___U3C_nameU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CValueU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043, ___U3CValueU3Ek__BackingField_0)); }
	inline JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  get_U3CValueU3Ek__BackingField_0() const { return ___U3CValueU3Ek__BackingField_0; }
	inline JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * get_address_of_U3CValueU3Ek__BackingField_0() { return &___U3CValueU3Ek__BackingField_0; }
	inline void set_U3CValueU3Ek__BackingField_0(JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  value)
	{
		___U3CValueU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CValueU3Ek__BackingField_0))->____parent_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3C_nameU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043, ___U3C_nameU3Ek__BackingField_1)); }
	inline String_t* get_U3C_nameU3Ek__BackingField_1() const { return ___U3C_nameU3Ek__BackingField_1; }
	inline String_t** get_address_of_U3C_nameU3Ek__BackingField_1() { return &___U3C_nameU3Ek__BackingField_1; }
	inline void set_U3C_nameU3Ek__BackingField_1(String_t* value)
	{
		___U3C_nameU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3C_nameU3Ek__BackingField_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.JsonProperty
struct JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043_marshaled_pinvoke
{
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_pinvoke ___U3CValueU3Ek__BackingField_0;
	char* ___U3C_nameU3Ek__BackingField_1;
};
// Native definition for COM marshalling of System.Text.Json.JsonProperty
struct JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043_marshaled_com
{
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_com ___U3CValueU3Ek__BackingField_0;
	Il2CppChar* ___U3C_nameU3Ek__BackingField_1;
};

// System.Text.Json.JsonTokenType
struct  JsonTokenType_tE5EB50B74419504F5207294DAE9C18B473A1B95E 
{
public:
	// System.Byte System.Text.Json.JsonTokenType::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(JsonTokenType_tE5EB50B74419504F5207294DAE9C18B473A1B95E, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};


// System.Text.Json.MetadataPropertyName
struct  MetadataPropertyName_tA22B483DF9F32CF58142B4F18ED702D06498BF3E 
{
public:
	// System.Int32 System.Text.Json.MetadataPropertyName::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(MetadataPropertyName_tA22B483DF9F32CF58142B4F18ED702D06498BF3E, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.RuntimeTypeHandle
struct  RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9 
{
public:
	// System.IntPtr System.RuntimeTypeHandle::value
	intptr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9, ___value_0)); }
	inline intptr_t get_value_0() const { return ___value_0; }
	inline intptr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(intptr_t value)
	{
		___value_0 = value;
	}
};


// System.Text.Json.StackFrameObjectState
struct  StackFrameObjectState_t750D4E8532DD74928C3AE3C0E6244B16F3C3A4A6 
{
public:
	// System.Byte System.Text.Json.StackFrameObjectState::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(StackFrameObjectState_t750D4E8532DD74928C3AE3C0E6244B16F3C3A4A6, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};


// System.Text.Json.StackFramePropertyState
struct  StackFramePropertyState_t0F7A94E834F81B0045292EA56E289C9AC66D54CE 
{
public:
	// System.Byte System.Text.Json.StackFramePropertyState::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(StackFramePropertyState_t0F7A94E834F81B0045292EA56E289C9AC66D54CE, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};


// System.StringComparison
struct  StringComparison_tCC9F72B9B1E2C3C6D2566DD0D3A61E1621048998 
{
public:
	// System.Int32 System.StringComparison::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(StringComparison_tCC9F72B9B1E2C3C6D2566DD0D3A61E1621048998, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Threading.Tasks.Task
struct  Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60  : public RuntimeObject
{
public:
	// System.Int32 modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.Tasks.Task::m_taskId
	int32_t ___m_taskId_4;
	// System.Object System.Threading.Tasks.Task::m_action
	RuntimeObject * ___m_action_5;
	// System.Object System.Threading.Tasks.Task::m_stateObject
	RuntimeObject * ___m_stateObject_6;
	// System.Threading.Tasks.TaskScheduler System.Threading.Tasks.Task::m_taskScheduler
	TaskScheduler_t74FBEEEDBDD5E0088FF0EEC18F45CD866B098D5D * ___m_taskScheduler_7;
	// System.Threading.Tasks.Task System.Threading.Tasks.Task::m_parent
	Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * ___m_parent_8;
	// System.Int32 modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.Tasks.Task::m_stateFlags
	int32_t ___m_stateFlags_9;
	// System.Object modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.Tasks.Task::m_continuationObject
	RuntimeObject * ___m_continuationObject_10;
	// System.Threading.Tasks.Task/ContingentProperties modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.Tasks.Task::m_contingentProperties
	ContingentProperties_t1E249C737B8B8644ED1D60EEFA101D326B199EA0 * ___m_contingentProperties_15;

public:
	inline static int32_t get_offset_of_m_taskId_4() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60, ___m_taskId_4)); }
	inline int32_t get_m_taskId_4() const { return ___m_taskId_4; }
	inline int32_t* get_address_of_m_taskId_4() { return &___m_taskId_4; }
	inline void set_m_taskId_4(int32_t value)
	{
		___m_taskId_4 = value;
	}

	inline static int32_t get_offset_of_m_action_5() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60, ___m_action_5)); }
	inline RuntimeObject * get_m_action_5() const { return ___m_action_5; }
	inline RuntimeObject ** get_address_of_m_action_5() { return &___m_action_5; }
	inline void set_m_action_5(RuntimeObject * value)
	{
		___m_action_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_action_5), (void*)value);
	}

	inline static int32_t get_offset_of_m_stateObject_6() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60, ___m_stateObject_6)); }
	inline RuntimeObject * get_m_stateObject_6() const { return ___m_stateObject_6; }
	inline RuntimeObject ** get_address_of_m_stateObject_6() { return &___m_stateObject_6; }
	inline void set_m_stateObject_6(RuntimeObject * value)
	{
		___m_stateObject_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_stateObject_6), (void*)value);
	}

	inline static int32_t get_offset_of_m_taskScheduler_7() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60, ___m_taskScheduler_7)); }
	inline TaskScheduler_t74FBEEEDBDD5E0088FF0EEC18F45CD866B098D5D * get_m_taskScheduler_7() const { return ___m_taskScheduler_7; }
	inline TaskScheduler_t74FBEEEDBDD5E0088FF0EEC18F45CD866B098D5D ** get_address_of_m_taskScheduler_7() { return &___m_taskScheduler_7; }
	inline void set_m_taskScheduler_7(TaskScheduler_t74FBEEEDBDD5E0088FF0EEC18F45CD866B098D5D * value)
	{
		___m_taskScheduler_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_taskScheduler_7), (void*)value);
	}

	inline static int32_t get_offset_of_m_parent_8() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60, ___m_parent_8)); }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * get_m_parent_8() const { return ___m_parent_8; }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 ** get_address_of_m_parent_8() { return &___m_parent_8; }
	inline void set_m_parent_8(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * value)
	{
		___m_parent_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_parent_8), (void*)value);
	}

	inline static int32_t get_offset_of_m_stateFlags_9() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60, ___m_stateFlags_9)); }
	inline int32_t get_m_stateFlags_9() const { return ___m_stateFlags_9; }
	inline int32_t* get_address_of_m_stateFlags_9() { return &___m_stateFlags_9; }
	inline void set_m_stateFlags_9(int32_t value)
	{
		___m_stateFlags_9 = value;
	}

	inline static int32_t get_offset_of_m_continuationObject_10() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60, ___m_continuationObject_10)); }
	inline RuntimeObject * get_m_continuationObject_10() const { return ___m_continuationObject_10; }
	inline RuntimeObject ** get_address_of_m_continuationObject_10() { return &___m_continuationObject_10; }
	inline void set_m_continuationObject_10(RuntimeObject * value)
	{
		___m_continuationObject_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_continuationObject_10), (void*)value);
	}

	inline static int32_t get_offset_of_m_contingentProperties_15() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60, ___m_contingentProperties_15)); }
	inline ContingentProperties_t1E249C737B8B8644ED1D60EEFA101D326B199EA0 * get_m_contingentProperties_15() const { return ___m_contingentProperties_15; }
	inline ContingentProperties_t1E249C737B8B8644ED1D60EEFA101D326B199EA0 ** get_address_of_m_contingentProperties_15() { return &___m_contingentProperties_15; }
	inline void set_m_contingentProperties_15(ContingentProperties_t1E249C737B8B8644ED1D60EEFA101D326B199EA0 * value)
	{
		___m_contingentProperties_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_contingentProperties_15), (void*)value);
	}
};

struct Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields
{
public:
	// System.Int32 System.Threading.Tasks.Task::s_taskIdCounter
	int32_t ___s_taskIdCounter_2;
	// System.Threading.Tasks.TaskFactory System.Threading.Tasks.Task::s_factory
	TaskFactory_t22D999A05A967C31A4B5FFBD08864809BF35EA3B * ___s_factory_3;
	// System.Object System.Threading.Tasks.Task::s_taskCompletionSentinel
	RuntimeObject * ___s_taskCompletionSentinel_11;
	// System.Boolean System.Threading.Tasks.Task::s_asyncDebuggingEnabled
	bool ___s_asyncDebuggingEnabled_12;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Threading.Tasks.Task> System.Threading.Tasks.Task::s_currentActiveTasks
	Dictionary_2_tB758E2A2593CD827EFC041BE1F1BB4B68DE1C3E8 * ___s_currentActiveTasks_13;
	// System.Object System.Threading.Tasks.Task::s_activeTasksLock
	RuntimeObject * ___s_activeTasksLock_14;
	// System.Action`1<System.Object> System.Threading.Tasks.Task::s_taskCancelCallback
	Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * ___s_taskCancelCallback_16;
	// System.Func`1<System.Threading.Tasks.Task/ContingentProperties> System.Threading.Tasks.Task::s_createContingentProperties
	Func_1_tBCF42601FA307876E83080BE4204110820F8BF3B * ___s_createContingentProperties_17;
	// System.Threading.Tasks.Task System.Threading.Tasks.Task::s_completedTask
	Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * ___s_completedTask_18;
	// System.Predicate`1<System.Threading.Tasks.Task> System.Threading.Tasks.Task::s_IsExceptionObservedByParentPredicate
	Predicate_1_tC0DBBC8498BD1EE6ABFFAA5628024105FA7D11BD * ___s_IsExceptionObservedByParentPredicate_19;
	// System.Threading.ContextCallback System.Threading.Tasks.Task::s_ecCallback
	ContextCallback_t93707E0430F4FF3E15E1FB5A4844BE89C657AE8B * ___s_ecCallback_20;
	// System.Predicate`1<System.Object> System.Threading.Tasks.Task::s_IsTaskContinuationNullPredicate
	Predicate_1_t5C96B81B31A697B11C4C3767E3298773AF25DFEB * ___s_IsTaskContinuationNullPredicate_21;

public:
	inline static int32_t get_offset_of_s_taskIdCounter_2() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_taskIdCounter_2)); }
	inline int32_t get_s_taskIdCounter_2() const { return ___s_taskIdCounter_2; }
	inline int32_t* get_address_of_s_taskIdCounter_2() { return &___s_taskIdCounter_2; }
	inline void set_s_taskIdCounter_2(int32_t value)
	{
		___s_taskIdCounter_2 = value;
	}

	inline static int32_t get_offset_of_s_factory_3() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_factory_3)); }
	inline TaskFactory_t22D999A05A967C31A4B5FFBD08864809BF35EA3B * get_s_factory_3() const { return ___s_factory_3; }
	inline TaskFactory_t22D999A05A967C31A4B5FFBD08864809BF35EA3B ** get_address_of_s_factory_3() { return &___s_factory_3; }
	inline void set_s_factory_3(TaskFactory_t22D999A05A967C31A4B5FFBD08864809BF35EA3B * value)
	{
		___s_factory_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_factory_3), (void*)value);
	}

	inline static int32_t get_offset_of_s_taskCompletionSentinel_11() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_taskCompletionSentinel_11)); }
	inline RuntimeObject * get_s_taskCompletionSentinel_11() const { return ___s_taskCompletionSentinel_11; }
	inline RuntimeObject ** get_address_of_s_taskCompletionSentinel_11() { return &___s_taskCompletionSentinel_11; }
	inline void set_s_taskCompletionSentinel_11(RuntimeObject * value)
	{
		___s_taskCompletionSentinel_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_taskCompletionSentinel_11), (void*)value);
	}

	inline static int32_t get_offset_of_s_asyncDebuggingEnabled_12() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_asyncDebuggingEnabled_12)); }
	inline bool get_s_asyncDebuggingEnabled_12() const { return ___s_asyncDebuggingEnabled_12; }
	inline bool* get_address_of_s_asyncDebuggingEnabled_12() { return &___s_asyncDebuggingEnabled_12; }
	inline void set_s_asyncDebuggingEnabled_12(bool value)
	{
		___s_asyncDebuggingEnabled_12 = value;
	}

	inline static int32_t get_offset_of_s_currentActiveTasks_13() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_currentActiveTasks_13)); }
	inline Dictionary_2_tB758E2A2593CD827EFC041BE1F1BB4B68DE1C3E8 * get_s_currentActiveTasks_13() const { return ___s_currentActiveTasks_13; }
	inline Dictionary_2_tB758E2A2593CD827EFC041BE1F1BB4B68DE1C3E8 ** get_address_of_s_currentActiveTasks_13() { return &___s_currentActiveTasks_13; }
	inline void set_s_currentActiveTasks_13(Dictionary_2_tB758E2A2593CD827EFC041BE1F1BB4B68DE1C3E8 * value)
	{
		___s_currentActiveTasks_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_currentActiveTasks_13), (void*)value);
	}

	inline static int32_t get_offset_of_s_activeTasksLock_14() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_activeTasksLock_14)); }
	inline RuntimeObject * get_s_activeTasksLock_14() const { return ___s_activeTasksLock_14; }
	inline RuntimeObject ** get_address_of_s_activeTasksLock_14() { return &___s_activeTasksLock_14; }
	inline void set_s_activeTasksLock_14(RuntimeObject * value)
	{
		___s_activeTasksLock_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_activeTasksLock_14), (void*)value);
	}

	inline static int32_t get_offset_of_s_taskCancelCallback_16() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_taskCancelCallback_16)); }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * get_s_taskCancelCallback_16() const { return ___s_taskCancelCallback_16; }
	inline Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC ** get_address_of_s_taskCancelCallback_16() { return &___s_taskCancelCallback_16; }
	inline void set_s_taskCancelCallback_16(Action_1_tD9663D9715FAA4E62035CFCF1AD4D094EE7872DC * value)
	{
		___s_taskCancelCallback_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_taskCancelCallback_16), (void*)value);
	}

	inline static int32_t get_offset_of_s_createContingentProperties_17() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_createContingentProperties_17)); }
	inline Func_1_tBCF42601FA307876E83080BE4204110820F8BF3B * get_s_createContingentProperties_17() const { return ___s_createContingentProperties_17; }
	inline Func_1_tBCF42601FA307876E83080BE4204110820F8BF3B ** get_address_of_s_createContingentProperties_17() { return &___s_createContingentProperties_17; }
	inline void set_s_createContingentProperties_17(Func_1_tBCF42601FA307876E83080BE4204110820F8BF3B * value)
	{
		___s_createContingentProperties_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_createContingentProperties_17), (void*)value);
	}

	inline static int32_t get_offset_of_s_completedTask_18() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_completedTask_18)); }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * get_s_completedTask_18() const { return ___s_completedTask_18; }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 ** get_address_of_s_completedTask_18() { return &___s_completedTask_18; }
	inline void set_s_completedTask_18(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * value)
	{
		___s_completedTask_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_completedTask_18), (void*)value);
	}

	inline static int32_t get_offset_of_s_IsExceptionObservedByParentPredicate_19() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_IsExceptionObservedByParentPredicate_19)); }
	inline Predicate_1_tC0DBBC8498BD1EE6ABFFAA5628024105FA7D11BD * get_s_IsExceptionObservedByParentPredicate_19() const { return ___s_IsExceptionObservedByParentPredicate_19; }
	inline Predicate_1_tC0DBBC8498BD1EE6ABFFAA5628024105FA7D11BD ** get_address_of_s_IsExceptionObservedByParentPredicate_19() { return &___s_IsExceptionObservedByParentPredicate_19; }
	inline void set_s_IsExceptionObservedByParentPredicate_19(Predicate_1_tC0DBBC8498BD1EE6ABFFAA5628024105FA7D11BD * value)
	{
		___s_IsExceptionObservedByParentPredicate_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_IsExceptionObservedByParentPredicate_19), (void*)value);
	}

	inline static int32_t get_offset_of_s_ecCallback_20() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_ecCallback_20)); }
	inline ContextCallback_t93707E0430F4FF3E15E1FB5A4844BE89C657AE8B * get_s_ecCallback_20() const { return ___s_ecCallback_20; }
	inline ContextCallback_t93707E0430F4FF3E15E1FB5A4844BE89C657AE8B ** get_address_of_s_ecCallback_20() { return &___s_ecCallback_20; }
	inline void set_s_ecCallback_20(ContextCallback_t93707E0430F4FF3E15E1FB5A4844BE89C657AE8B * value)
	{
		___s_ecCallback_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_ecCallback_20), (void*)value);
	}

	inline static int32_t get_offset_of_s_IsTaskContinuationNullPredicate_21() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_StaticFields, ___s_IsTaskContinuationNullPredicate_21)); }
	inline Predicate_1_t5C96B81B31A697B11C4C3767E3298773AF25DFEB * get_s_IsTaskContinuationNullPredicate_21() const { return ___s_IsTaskContinuationNullPredicate_21; }
	inline Predicate_1_t5C96B81B31A697B11C4C3767E3298773AF25DFEB ** get_address_of_s_IsTaskContinuationNullPredicate_21() { return &___s_IsTaskContinuationNullPredicate_21; }
	inline void set_s_IsTaskContinuationNullPredicate_21(Predicate_1_t5C96B81B31A697B11C4C3767E3298773AF25DFEB * value)
	{
		___s_IsTaskContinuationNullPredicate_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_IsTaskContinuationNullPredicate_21), (void*)value);
	}
};

struct Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_ThreadStaticFields
{
public:
	// System.Threading.Tasks.Task System.Threading.Tasks.Task::t_currentTask
	Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * ___t_currentTask_0;
	// System.Threading.Tasks.StackGuard System.Threading.Tasks.Task::t_stackGuard
	StackGuard_t88E1EE4741AD02CA5FEA04A4EB2CC70F230E0E6D * ___t_stackGuard_1;

public:
	inline static int32_t get_offset_of_t_currentTask_0() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_ThreadStaticFields, ___t_currentTask_0)); }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * get_t_currentTask_0() const { return ___t_currentTask_0; }
	inline Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 ** get_address_of_t_currentTask_0() { return &___t_currentTask_0; }
	inline void set_t_currentTask_0(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * value)
	{
		___t_currentTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___t_currentTask_0), (void*)value);
	}

	inline static int32_t get_offset_of_t_stackGuard_1() { return static_cast<int32_t>(offsetof(Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60_ThreadStaticFields, ___t_stackGuard_1)); }
	inline StackGuard_t88E1EE4741AD02CA5FEA04A4EB2CC70F230E0E6D * get_t_stackGuard_1() const { return ___t_stackGuard_1; }
	inline StackGuard_t88E1EE4741AD02CA5FEA04A4EB2CC70F230E0E6D ** get_address_of_t_stackGuard_1() { return &___t_stackGuard_1; }
	inline void set_t_stackGuard_1(StackGuard_t88E1EE4741AD02CA5FEA04A4EB2CC70F230E0E6D * value)
	{
		___t_stackGuard_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___t_stackGuard_1), (void*)value);
	}
};


// System.HexConverter/Casing
struct  Casing_tDDB236894A11074D84673DD4EFE6F05548B5DF9B 
{
public:
	// System.UInt32 System.HexConverter/Casing::value__
	uint32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Casing_tDDB236894A11074D84673DD4EFE6F05548B5DF9B, ___value___2)); }
	inline uint32_t get_value___2() const { return ___value___2; }
	inline uint32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint32_t value)
	{
		___value___2 = value;
	}
};


// System.Text.Json.JsonElement/ArrayEnumerator
struct  ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 
{
public:
	// System.Text.Json.JsonElement System.Text.Json.JsonElement/ArrayEnumerator::_target
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ____target_0;
	// System.Int32 System.Text.Json.JsonElement/ArrayEnumerator::_curIdx
	int32_t ____curIdx_1;
	// System.Int32 System.Text.Json.JsonElement/ArrayEnumerator::_endIdxOrVersion
	int32_t ____endIdxOrVersion_2;

public:
	inline static int32_t get_offset_of__target_0() { return static_cast<int32_t>(offsetof(ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0, ____target_0)); }
	inline JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  get__target_0() const { return ____target_0; }
	inline JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * get_address_of__target_0() { return &____target_0; }
	inline void set__target_0(JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  value)
	{
		____target_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&____target_0))->____parent_0), (void*)NULL);
	}

	inline static int32_t get_offset_of__curIdx_1() { return static_cast<int32_t>(offsetof(ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0, ____curIdx_1)); }
	inline int32_t get__curIdx_1() const { return ____curIdx_1; }
	inline int32_t* get_address_of__curIdx_1() { return &____curIdx_1; }
	inline void set__curIdx_1(int32_t value)
	{
		____curIdx_1 = value;
	}

	inline static int32_t get_offset_of__endIdxOrVersion_2() { return static_cast<int32_t>(offsetof(ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0, ____endIdxOrVersion_2)); }
	inline int32_t get__endIdxOrVersion_2() const { return ____endIdxOrVersion_2; }
	inline int32_t* get_address_of__endIdxOrVersion_2() { return &____endIdxOrVersion_2; }
	inline void set__endIdxOrVersion_2(int32_t value)
	{
		____endIdxOrVersion_2 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.JsonElement/ArrayEnumerator
struct ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshaled_pinvoke
{
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_pinvoke ____target_0;
	int32_t ____curIdx_1;
	int32_t ____endIdxOrVersion_2;
};
// Native definition for COM marshalling of System.Text.Json.JsonElement/ArrayEnumerator
struct ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshaled_com
{
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_com ____target_0;
	int32_t ____curIdx_1;
	int32_t ____endIdxOrVersion_2;
};

// System.Text.Json.JsonElement/ObjectEnumerator
struct  ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 
{
public:
	// System.Text.Json.JsonElement System.Text.Json.JsonElement/ObjectEnumerator::_target
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ____target_0;
	// System.Int32 System.Text.Json.JsonElement/ObjectEnumerator::_curIdx
	int32_t ____curIdx_1;
	// System.Int32 System.Text.Json.JsonElement/ObjectEnumerator::_endIdxOrVersion
	int32_t ____endIdxOrVersion_2;

public:
	inline static int32_t get_offset_of__target_0() { return static_cast<int32_t>(offsetof(ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812, ____target_0)); }
	inline JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  get__target_0() const { return ____target_0; }
	inline JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * get_address_of__target_0() { return &____target_0; }
	inline void set__target_0(JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  value)
	{
		____target_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&____target_0))->____parent_0), (void*)NULL);
	}

	inline static int32_t get_offset_of__curIdx_1() { return static_cast<int32_t>(offsetof(ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812, ____curIdx_1)); }
	inline int32_t get__curIdx_1() const { return ____curIdx_1; }
	inline int32_t* get_address_of__curIdx_1() { return &____curIdx_1; }
	inline void set__curIdx_1(int32_t value)
	{
		____curIdx_1 = value;
	}

	inline static int32_t get_offset_of__endIdxOrVersion_2() { return static_cast<int32_t>(offsetof(ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812, ____endIdxOrVersion_2)); }
	inline int32_t get__endIdxOrVersion_2() const { return ____endIdxOrVersion_2; }
	inline int32_t* get_address_of__endIdxOrVersion_2() { return &____endIdxOrVersion_2; }
	inline void set__endIdxOrVersion_2(int32_t value)
	{
		____endIdxOrVersion_2 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.JsonElement/ObjectEnumerator
struct ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshaled_pinvoke
{
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_pinvoke ____target_0;
	int32_t ____curIdx_1;
	int32_t ____endIdxOrVersion_2;
};
// Native definition for COM marshalling of System.Text.Json.JsonElement/ObjectEnumerator
struct ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshaled_com
{
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_com ____target_0;
	int32_t ____curIdx_1;
	int32_t ____endIdxOrVersion_2;
};

// System.Text.Json.Utf8JsonReader/PartialStateForRollback
struct  PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1 
{
public:
	// System.Int64 System.Text.Json.Utf8JsonReader/PartialStateForRollback::_prevTotalConsumed
	int64_t ____prevTotalConsumed_0;
	// System.Int64 System.Text.Json.Utf8JsonReader/PartialStateForRollback::_prevBytePositionInLine
	int64_t ____prevBytePositionInLine_1;
	// System.Int32 System.Text.Json.Utf8JsonReader/PartialStateForRollback::_prevConsumed
	int32_t ____prevConsumed_2;
	// System.SequencePosition System.Text.Json.Utf8JsonReader/PartialStateForRollback::_prevCurrentPosition
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  ____prevCurrentPosition_3;

public:
	inline static int32_t get_offset_of__prevTotalConsumed_0() { return static_cast<int32_t>(offsetof(PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1, ____prevTotalConsumed_0)); }
	inline int64_t get__prevTotalConsumed_0() const { return ____prevTotalConsumed_0; }
	inline int64_t* get_address_of__prevTotalConsumed_0() { return &____prevTotalConsumed_0; }
	inline void set__prevTotalConsumed_0(int64_t value)
	{
		____prevTotalConsumed_0 = value;
	}

	inline static int32_t get_offset_of__prevBytePositionInLine_1() { return static_cast<int32_t>(offsetof(PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1, ____prevBytePositionInLine_1)); }
	inline int64_t get__prevBytePositionInLine_1() const { return ____prevBytePositionInLine_1; }
	inline int64_t* get_address_of__prevBytePositionInLine_1() { return &____prevBytePositionInLine_1; }
	inline void set__prevBytePositionInLine_1(int64_t value)
	{
		____prevBytePositionInLine_1 = value;
	}

	inline static int32_t get_offset_of__prevConsumed_2() { return static_cast<int32_t>(offsetof(PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1, ____prevConsumed_2)); }
	inline int32_t get__prevConsumed_2() const { return ____prevConsumed_2; }
	inline int32_t* get_address_of__prevConsumed_2() { return &____prevConsumed_2; }
	inline void set__prevConsumed_2(int32_t value)
	{
		____prevConsumed_2 = value;
	}

	inline static int32_t get_offset_of__prevCurrentPosition_3() { return static_cast<int32_t>(offsetof(PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1, ____prevCurrentPosition_3)); }
	inline SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  get__prevCurrentPosition_3() const { return ____prevCurrentPosition_3; }
	inline SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A * get_address_of__prevCurrentPosition_3() { return &____prevCurrentPosition_3; }
	inline void set__prevCurrentPosition_3(SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  value)
	{
		____prevCurrentPosition_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&____prevCurrentPosition_3))->____object_0), (void*)NULL);
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.Utf8JsonReader/PartialStateForRollback
struct PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshaled_pinvoke
{
	int64_t ____prevTotalConsumed_0;
	int64_t ____prevBytePositionInLine_1;
	int32_t ____prevConsumed_2;
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_pinvoke ____prevCurrentPosition_3;
};
// Native definition for COM marshalling of System.Text.Json.Utf8JsonReader/PartialStateForRollback
struct PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshaled_com
{
	int64_t ____prevTotalConsumed_0;
	int64_t ____prevBytePositionInLine_1;
	int32_t ____prevConsumed_2;
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_com ____prevCurrentPosition_3;
};

// System.Nullable`1<System.Int32Enum>
struct  Nullable_1_t64244F99361E39CBE565C5E89436C898F18DF5DC 
{
public:
	// T System.Nullable`1::value
	int32_t ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_t64244F99361E39CBE565C5E89436C898F18DF5DC, ___value_0)); }
	inline int32_t get_value_0() const { return ___value_0; }
	inline int32_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(int32_t value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_t64244F99361E39CBE565C5E89436C898F18DF5DC, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};


// System.Nullable`1<System.Text.Json.Serialization.JsonNumberHandling>
struct  Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58 
{
public:
	// T System.Nullable`1::value
	int32_t ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58, ___value_0)); }
	inline int32_t get_value_0() const { return ___value_0; }
	inline int32_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(int32_t value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};


// System.Threading.Tasks.Task`1<System.ArraySegment`1<System.Byte>>
struct  Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985  : public Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60
{
public:
	// TResult System.Threading.Tasks.Task`1::m_result
	ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  ___m_result_22;

public:
	inline static int32_t get_offset_of_m_result_22() { return static_cast<int32_t>(offsetof(Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985, ___m_result_22)); }
	inline ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  get_m_result_22() const { return ___m_result_22; }
	inline ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * get_address_of_m_result_22() { return &___m_result_22; }
	inline void set_m_result_22(ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  value)
	{
		___m_result_22 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_result_22))->____array_0), (void*)NULL);
	}
};

struct Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985_StaticFields
{
public:
	// System.Threading.Tasks.TaskFactory`1<TResult> System.Threading.Tasks.Task`1::s_Factory
	TaskFactory_1_tEE49CB5FD4827D7F7DBF62C9200028C41A403EC7 * ___s_Factory_23;
	// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<TResult>> System.Threading.Tasks.Task`1::TaskWhenAnyCast
	Func_2_tB70DBF72BDE13A60F022FF99C0825B7D33B2CD88 * ___TaskWhenAnyCast_24;

public:
	inline static int32_t get_offset_of_s_Factory_23() { return static_cast<int32_t>(offsetof(Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985_StaticFields, ___s_Factory_23)); }
	inline TaskFactory_1_tEE49CB5FD4827D7F7DBF62C9200028C41A403EC7 * get_s_Factory_23() const { return ___s_Factory_23; }
	inline TaskFactory_1_tEE49CB5FD4827D7F7DBF62C9200028C41A403EC7 ** get_address_of_s_Factory_23() { return &___s_Factory_23; }
	inline void set_s_Factory_23(TaskFactory_1_tEE49CB5FD4827D7F7DBF62C9200028C41A403EC7 * value)
	{
		___s_Factory_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Factory_23), (void*)value);
	}

	inline static int32_t get_offset_of_TaskWhenAnyCast_24() { return static_cast<int32_t>(offsetof(Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985_StaticFields, ___TaskWhenAnyCast_24)); }
	inline Func_2_tB70DBF72BDE13A60F022FF99C0825B7D33B2CD88 * get_TaskWhenAnyCast_24() const { return ___TaskWhenAnyCast_24; }
	inline Func_2_tB70DBF72BDE13A60F022FF99C0825B7D33B2CD88 ** get_address_of_TaskWhenAnyCast_24() { return &___TaskWhenAnyCast_24; }
	inline void set_TaskWhenAnyCast_24(Func_2_tB70DBF72BDE13A60F022FF99C0825B7D33B2CD88 * value)
	{
		___TaskWhenAnyCast_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TaskWhenAnyCast_24), (void*)value);
	}
};


// System.Threading.Tasks.Task`1<System.Int32>
struct  Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725  : public Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60
{
public:
	// TResult System.Threading.Tasks.Task`1::m_result
	int32_t ___m_result_22;

public:
	inline static int32_t get_offset_of_m_result_22() { return static_cast<int32_t>(offsetof(Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725, ___m_result_22)); }
	inline int32_t get_m_result_22() const { return ___m_result_22; }
	inline int32_t* get_address_of_m_result_22() { return &___m_result_22; }
	inline void set_m_result_22(int32_t value)
	{
		___m_result_22 = value;
	}
};

struct Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725_StaticFields
{
public:
	// System.Threading.Tasks.TaskFactory`1<TResult> System.Threading.Tasks.Task`1::s_Factory
	TaskFactory_1_tCA6286B86C0D5D6C00D5A0DFE56F7E48A482DD5E * ___s_Factory_23;
	// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<TResult>> System.Threading.Tasks.Task`1::TaskWhenAnyCast
	Func_2_t53CFE8804C8D1C2FE8CC9204CF5DA5B98EC444D0 * ___TaskWhenAnyCast_24;

public:
	inline static int32_t get_offset_of_s_Factory_23() { return static_cast<int32_t>(offsetof(Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725_StaticFields, ___s_Factory_23)); }
	inline TaskFactory_1_tCA6286B86C0D5D6C00D5A0DFE56F7E48A482DD5E * get_s_Factory_23() const { return ___s_Factory_23; }
	inline TaskFactory_1_tCA6286B86C0D5D6C00D5A0DFE56F7E48A482DD5E ** get_address_of_s_Factory_23() { return &___s_Factory_23; }
	inline void set_s_Factory_23(TaskFactory_1_tCA6286B86C0D5D6C00D5A0DFE56F7E48A482DD5E * value)
	{
		___s_Factory_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Factory_23), (void*)value);
	}

	inline static int32_t get_offset_of_TaskWhenAnyCast_24() { return static_cast<int32_t>(offsetof(Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725_StaticFields, ___TaskWhenAnyCast_24)); }
	inline Func_2_t53CFE8804C8D1C2FE8CC9204CF5DA5B98EC444D0 * get_TaskWhenAnyCast_24() const { return ___TaskWhenAnyCast_24; }
	inline Func_2_t53CFE8804C8D1C2FE8CC9204CF5DA5B98EC444D0 ** get_address_of_TaskWhenAnyCast_24() { return &___TaskWhenAnyCast_24; }
	inline void set_TaskWhenAnyCast_24(Func_2_t53CFE8804C8D1C2FE8CC9204CF5DA5B98EC444D0 * value)
	{
		___TaskWhenAnyCast_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TaskWhenAnyCast_24), (void*)value);
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder
struct  AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B 
{
public:
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Threading.Tasks.VoidTaskResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder::m_builder
	AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD  ___m_builder_1;

public:
	inline static int32_t get_offset_of_m_builder_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B, ___m_builder_1)); }
	inline AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD  get_m_builder_1() const { return ___m_builder_1; }
	inline AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD * get_address_of_m_builder_1() { return &___m_builder_1; }
	inline void set_m_builder_1(AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD  value)
	{
		___m_builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}
};

struct AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<System.Threading.Tasks.VoidTaskResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder::s_cachedCompleted
	Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 * ___s_cachedCompleted_0;

public:
	inline static int32_t get_offset_of_s_cachedCompleted_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B_StaticFields, ___s_cachedCompleted_0)); }
	inline Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 * get_s_cachedCompleted_0() const { return ___s_cachedCompleted_0; }
	inline Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 ** get_address_of_s_cachedCompleted_0() { return &___s_cachedCompleted_0; }
	inline void set_s_cachedCompleted_0(Task_1_t65FD5EE287B61746F015BBC8E90A97D38D258FB3 * value)
	{
		___s_cachedCompleted_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_cachedCompleted_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Runtime.CompilerServices.AsyncTaskMethodBuilder
struct AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B_marshaled_pinvoke
{
	AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD  ___m_builder_1;
};
// Native definition for COM marshalling of System.Runtime.CompilerServices.AsyncTaskMethodBuilder
struct AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B_marshaled_com
{
	AsyncTaskMethodBuilder_1_t3E10C35B53D8718724E2BF748600FB762F4719AD  ___m_builder_1;
};

// System.Text.Json.JsonClassInfo
struct  JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18  : public RuntimeObject
{
public:
	// System.Text.Json.JsonClassInfo/ConstructorDelegate System.Text.Json.JsonClassInfo::<CreateObject>k__BackingField
	ConstructorDelegate_t78F14D99A470B7AECB5D508869D8A4D62D40D0C0 * ___U3CCreateObjectU3Ek__BackingField_0;
	// System.Object System.Text.Json.JsonClassInfo::<CreateObjectWithArgs>k__BackingField
	RuntimeObject * ___U3CCreateObjectWithArgsU3Ek__BackingField_1;
	// System.Object System.Text.Json.JsonClassInfo::<AddMethodDelegate>k__BackingField
	RuntimeObject * ___U3CAddMethodDelegateU3Ek__BackingField_2;
	// System.Text.Json.ClassType System.Text.Json.JsonClassInfo::<ClassType>k__BackingField
	uint8_t ___U3CClassTypeU3Ek__BackingField_3;
	// System.Text.Json.JsonPropertyInfo System.Text.Json.JsonClassInfo::<DataExtensionProperty>k__BackingField
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___U3CDataExtensionPropertyU3Ek__BackingField_4;
	// System.Text.Json.JsonClassInfo System.Text.Json.JsonClassInfo::_elementClassInfo
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * ____elementClassInfo_5;
	// System.Type System.Text.Json.JsonClassInfo::<ElementType>k__BackingField
	Type_t * ___U3CElementTypeU3Ek__BackingField_6;
	// System.Text.Json.JsonSerializerOptions System.Text.Json.JsonClassInfo::<Options>k__BackingField
	JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * ___U3COptionsU3Ek__BackingField_7;
	// System.Type System.Text.Json.JsonClassInfo::<Type>k__BackingField
	Type_t * ___U3CTypeU3Ek__BackingField_8;
	// System.Text.Json.JsonPropertyInfo System.Text.Json.JsonClassInfo::<PropertyInfoForClassInfo>k__BackingField
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___U3CPropertyInfoForClassInfoU3Ek__BackingField_9;
	// System.Int32 System.Text.Json.JsonClassInfo::<ParameterCount>k__BackingField
	int32_t ___U3CParameterCountU3Ek__BackingField_14;
	// System.Collections.Generic.Dictionary`2<System.String,System.Text.Json.JsonParameterInfo> System.Text.Json.JsonClassInfo::ParameterCache
	Dictionary_2_t88B514DD42AE28E567C3E46EBF620FA30EEA74A1 * ___ParameterCache_15;
	// System.Collections.Generic.Dictionary`2<System.String,System.Text.Json.JsonPropertyInfo> System.Text.Json.JsonClassInfo::PropertyCache
	Dictionary_2_t249E9FEC7DBA07265D10748B0086D9D57054672A * ___PropertyCache_16;
	// System.Text.Json.JsonPropertyInfo[] System.Text.Json.JsonClassInfo::PropertyCacheArray
	JsonPropertyInfoU5BU5D_t92C433BF3A9CDBC7959A5379838C782A078F0AA1* ___PropertyCacheArray_17;
	// System.Text.Json.ParameterRef[] modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Json.JsonClassInfo::_parameterRefsSorted
	ParameterRefU5BU5D_t22F33996E671221964593A44EBE1C4460B59F472* ____parameterRefsSorted_18;
	// System.Text.Json.PropertyRef[] modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Json.JsonClassInfo::_propertyRefsSorted
	PropertyRefU5BU5D_t3F07DF2751485B065F052DDCFA7CB7A0307ABEF0* ____propertyRefsSorted_19;

public:
	inline static int32_t get_offset_of_U3CCreateObjectU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___U3CCreateObjectU3Ek__BackingField_0)); }
	inline ConstructorDelegate_t78F14D99A470B7AECB5D508869D8A4D62D40D0C0 * get_U3CCreateObjectU3Ek__BackingField_0() const { return ___U3CCreateObjectU3Ek__BackingField_0; }
	inline ConstructorDelegate_t78F14D99A470B7AECB5D508869D8A4D62D40D0C0 ** get_address_of_U3CCreateObjectU3Ek__BackingField_0() { return &___U3CCreateObjectU3Ek__BackingField_0; }
	inline void set_U3CCreateObjectU3Ek__BackingField_0(ConstructorDelegate_t78F14D99A470B7AECB5D508869D8A4D62D40D0C0 * value)
	{
		___U3CCreateObjectU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CCreateObjectU3Ek__BackingField_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CCreateObjectWithArgsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___U3CCreateObjectWithArgsU3Ek__BackingField_1)); }
	inline RuntimeObject * get_U3CCreateObjectWithArgsU3Ek__BackingField_1() const { return ___U3CCreateObjectWithArgsU3Ek__BackingField_1; }
	inline RuntimeObject ** get_address_of_U3CCreateObjectWithArgsU3Ek__BackingField_1() { return &___U3CCreateObjectWithArgsU3Ek__BackingField_1; }
	inline void set_U3CCreateObjectWithArgsU3Ek__BackingField_1(RuntimeObject * value)
	{
		___U3CCreateObjectWithArgsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CCreateObjectWithArgsU3Ek__BackingField_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CAddMethodDelegateU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___U3CAddMethodDelegateU3Ek__BackingField_2)); }
	inline RuntimeObject * get_U3CAddMethodDelegateU3Ek__BackingField_2() const { return ___U3CAddMethodDelegateU3Ek__BackingField_2; }
	inline RuntimeObject ** get_address_of_U3CAddMethodDelegateU3Ek__BackingField_2() { return &___U3CAddMethodDelegateU3Ek__BackingField_2; }
	inline void set_U3CAddMethodDelegateU3Ek__BackingField_2(RuntimeObject * value)
	{
		___U3CAddMethodDelegateU3Ek__BackingField_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CAddMethodDelegateU3Ek__BackingField_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CClassTypeU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___U3CClassTypeU3Ek__BackingField_3)); }
	inline uint8_t get_U3CClassTypeU3Ek__BackingField_3() const { return ___U3CClassTypeU3Ek__BackingField_3; }
	inline uint8_t* get_address_of_U3CClassTypeU3Ek__BackingField_3() { return &___U3CClassTypeU3Ek__BackingField_3; }
	inline void set_U3CClassTypeU3Ek__BackingField_3(uint8_t value)
	{
		___U3CClassTypeU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_U3CDataExtensionPropertyU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___U3CDataExtensionPropertyU3Ek__BackingField_4)); }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * get_U3CDataExtensionPropertyU3Ek__BackingField_4() const { return ___U3CDataExtensionPropertyU3Ek__BackingField_4; }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F ** get_address_of_U3CDataExtensionPropertyU3Ek__BackingField_4() { return &___U3CDataExtensionPropertyU3Ek__BackingField_4; }
	inline void set_U3CDataExtensionPropertyU3Ek__BackingField_4(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * value)
	{
		___U3CDataExtensionPropertyU3Ek__BackingField_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CDataExtensionPropertyU3Ek__BackingField_4), (void*)value);
	}

	inline static int32_t get_offset_of__elementClassInfo_5() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ____elementClassInfo_5)); }
	inline JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * get__elementClassInfo_5() const { return ____elementClassInfo_5; }
	inline JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 ** get_address_of__elementClassInfo_5() { return &____elementClassInfo_5; }
	inline void set__elementClassInfo_5(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * value)
	{
		____elementClassInfo_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____elementClassInfo_5), (void*)value);
	}

	inline static int32_t get_offset_of_U3CElementTypeU3Ek__BackingField_6() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___U3CElementTypeU3Ek__BackingField_6)); }
	inline Type_t * get_U3CElementTypeU3Ek__BackingField_6() const { return ___U3CElementTypeU3Ek__BackingField_6; }
	inline Type_t ** get_address_of_U3CElementTypeU3Ek__BackingField_6() { return &___U3CElementTypeU3Ek__BackingField_6; }
	inline void set_U3CElementTypeU3Ek__BackingField_6(Type_t * value)
	{
		___U3CElementTypeU3Ek__BackingField_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CElementTypeU3Ek__BackingField_6), (void*)value);
	}

	inline static int32_t get_offset_of_U3COptionsU3Ek__BackingField_7() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___U3COptionsU3Ek__BackingField_7)); }
	inline JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * get_U3COptionsU3Ek__BackingField_7() const { return ___U3COptionsU3Ek__BackingField_7; }
	inline JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 ** get_address_of_U3COptionsU3Ek__BackingField_7() { return &___U3COptionsU3Ek__BackingField_7; }
	inline void set_U3COptionsU3Ek__BackingField_7(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * value)
	{
		___U3COptionsU3Ek__BackingField_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3COptionsU3Ek__BackingField_7), (void*)value);
	}

	inline static int32_t get_offset_of_U3CTypeU3Ek__BackingField_8() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___U3CTypeU3Ek__BackingField_8)); }
	inline Type_t * get_U3CTypeU3Ek__BackingField_8() const { return ___U3CTypeU3Ek__BackingField_8; }
	inline Type_t ** get_address_of_U3CTypeU3Ek__BackingField_8() { return &___U3CTypeU3Ek__BackingField_8; }
	inline void set_U3CTypeU3Ek__BackingField_8(Type_t * value)
	{
		___U3CTypeU3Ek__BackingField_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CTypeU3Ek__BackingField_8), (void*)value);
	}

	inline static int32_t get_offset_of_U3CPropertyInfoForClassInfoU3Ek__BackingField_9() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___U3CPropertyInfoForClassInfoU3Ek__BackingField_9)); }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * get_U3CPropertyInfoForClassInfoU3Ek__BackingField_9() const { return ___U3CPropertyInfoForClassInfoU3Ek__BackingField_9; }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F ** get_address_of_U3CPropertyInfoForClassInfoU3Ek__BackingField_9() { return &___U3CPropertyInfoForClassInfoU3Ek__BackingField_9; }
	inline void set_U3CPropertyInfoForClassInfoU3Ek__BackingField_9(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * value)
	{
		___U3CPropertyInfoForClassInfoU3Ek__BackingField_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CPropertyInfoForClassInfoU3Ek__BackingField_9), (void*)value);
	}

	inline static int32_t get_offset_of_U3CParameterCountU3Ek__BackingField_14() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___U3CParameterCountU3Ek__BackingField_14)); }
	inline int32_t get_U3CParameterCountU3Ek__BackingField_14() const { return ___U3CParameterCountU3Ek__BackingField_14; }
	inline int32_t* get_address_of_U3CParameterCountU3Ek__BackingField_14() { return &___U3CParameterCountU3Ek__BackingField_14; }
	inline void set_U3CParameterCountU3Ek__BackingField_14(int32_t value)
	{
		___U3CParameterCountU3Ek__BackingField_14 = value;
	}

	inline static int32_t get_offset_of_ParameterCache_15() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___ParameterCache_15)); }
	inline Dictionary_2_t88B514DD42AE28E567C3E46EBF620FA30EEA74A1 * get_ParameterCache_15() const { return ___ParameterCache_15; }
	inline Dictionary_2_t88B514DD42AE28E567C3E46EBF620FA30EEA74A1 ** get_address_of_ParameterCache_15() { return &___ParameterCache_15; }
	inline void set_ParameterCache_15(Dictionary_2_t88B514DD42AE28E567C3E46EBF620FA30EEA74A1 * value)
	{
		___ParameterCache_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ParameterCache_15), (void*)value);
	}

	inline static int32_t get_offset_of_PropertyCache_16() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___PropertyCache_16)); }
	inline Dictionary_2_t249E9FEC7DBA07265D10748B0086D9D57054672A * get_PropertyCache_16() const { return ___PropertyCache_16; }
	inline Dictionary_2_t249E9FEC7DBA07265D10748B0086D9D57054672A ** get_address_of_PropertyCache_16() { return &___PropertyCache_16; }
	inline void set_PropertyCache_16(Dictionary_2_t249E9FEC7DBA07265D10748B0086D9D57054672A * value)
	{
		___PropertyCache_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PropertyCache_16), (void*)value);
	}

	inline static int32_t get_offset_of_PropertyCacheArray_17() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ___PropertyCacheArray_17)); }
	inline JsonPropertyInfoU5BU5D_t92C433BF3A9CDBC7959A5379838C782A078F0AA1* get_PropertyCacheArray_17() const { return ___PropertyCacheArray_17; }
	inline JsonPropertyInfoU5BU5D_t92C433BF3A9CDBC7959A5379838C782A078F0AA1** get_address_of_PropertyCacheArray_17() { return &___PropertyCacheArray_17; }
	inline void set_PropertyCacheArray_17(JsonPropertyInfoU5BU5D_t92C433BF3A9CDBC7959A5379838C782A078F0AA1* value)
	{
		___PropertyCacheArray_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PropertyCacheArray_17), (void*)value);
	}

	inline static int32_t get_offset_of__parameterRefsSorted_18() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ____parameterRefsSorted_18)); }
	inline ParameterRefU5BU5D_t22F33996E671221964593A44EBE1C4460B59F472* get__parameterRefsSorted_18() const { return ____parameterRefsSorted_18; }
	inline ParameterRefU5BU5D_t22F33996E671221964593A44EBE1C4460B59F472** get_address_of__parameterRefsSorted_18() { return &____parameterRefsSorted_18; }
	inline void set__parameterRefsSorted_18(ParameterRefU5BU5D_t22F33996E671221964593A44EBE1C4460B59F472* value)
	{
		____parameterRefsSorted_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____parameterRefsSorted_18), (void*)value);
	}

	inline static int32_t get_offset_of__propertyRefsSorted_19() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18, ____propertyRefsSorted_19)); }
	inline PropertyRefU5BU5D_t3F07DF2751485B065F052DDCFA7CB7A0307ABEF0* get__propertyRefsSorted_19() const { return ____propertyRefsSorted_19; }
	inline PropertyRefU5BU5D_t3F07DF2751485B065F052DDCFA7CB7A0307ABEF0** get_address_of__propertyRefsSorted_19() { return &____propertyRefsSorted_19; }
	inline void set__propertyRefsSorted_19(PropertyRefU5BU5D_t3F07DF2751485B065F052DDCFA7CB7A0307ABEF0* value)
	{
		____propertyRefsSorted_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____propertyRefsSorted_19), (void*)value);
	}
};

struct JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18_StaticFields
{
public:
	// System.Type System.Text.Json.JsonClassInfo::ObjectType
	Type_t * ___ObjectType_10;

public:
	inline static int32_t get_offset_of_ObjectType_10() { return static_cast<int32_t>(offsetof(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18_StaticFields, ___ObjectType_10)); }
	inline Type_t * get_ObjectType_10() const { return ___ObjectType_10; }
	inline Type_t ** get_address_of_ObjectType_10() { return &___ObjectType_10; }
	inline void set_ObjectType_10(Type_t * value)
	{
		___ObjectType_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ObjectType_10), (void*)value);
	}
};


// System.Text.Json.JsonDocumentOptions
struct  JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675 
{
public:
	// System.Int32 System.Text.Json.JsonDocumentOptions::_maxDepth
	int32_t ____maxDepth_1;
	// System.Text.Json.JsonCommentHandling System.Text.Json.JsonDocumentOptions::_commentHandling
	uint8_t ____commentHandling_2;
	// System.Boolean System.Text.Json.JsonDocumentOptions::<AllowTrailingCommas>k__BackingField
	bool ___U3CAllowTrailingCommasU3Ek__BackingField_3;

public:
	inline static int32_t get_offset_of__maxDepth_1() { return static_cast<int32_t>(offsetof(JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675, ____maxDepth_1)); }
	inline int32_t get__maxDepth_1() const { return ____maxDepth_1; }
	inline int32_t* get_address_of__maxDepth_1() { return &____maxDepth_1; }
	inline void set__maxDepth_1(int32_t value)
	{
		____maxDepth_1 = value;
	}

	inline static int32_t get_offset_of__commentHandling_2() { return static_cast<int32_t>(offsetof(JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675, ____commentHandling_2)); }
	inline uint8_t get__commentHandling_2() const { return ____commentHandling_2; }
	inline uint8_t* get_address_of__commentHandling_2() { return &____commentHandling_2; }
	inline void set__commentHandling_2(uint8_t value)
	{
		____commentHandling_2 = value;
	}

	inline static int32_t get_offset_of_U3CAllowTrailingCommasU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675, ___U3CAllowTrailingCommasU3Ek__BackingField_3)); }
	inline bool get_U3CAllowTrailingCommasU3Ek__BackingField_3() const { return ___U3CAllowTrailingCommasU3Ek__BackingField_3; }
	inline bool* get_address_of_U3CAllowTrailingCommasU3Ek__BackingField_3() { return &___U3CAllowTrailingCommasU3Ek__BackingField_3; }
	inline void set_U3CAllowTrailingCommasU3Ek__BackingField_3(bool value)
	{
		___U3CAllowTrailingCommasU3Ek__BackingField_3 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.JsonDocumentOptions
struct JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675_marshaled_pinvoke
{
	int32_t ____maxDepth_1;
	uint8_t ____commentHandling_2;
	int32_t ___U3CAllowTrailingCommasU3Ek__BackingField_3;
};
// Native definition for COM marshalling of System.Text.Json.JsonDocumentOptions
struct JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675_marshaled_com
{
	int32_t ____maxDepth_1;
	uint8_t ____commentHandling_2;
	int32_t ___U3CAllowTrailingCommasU3Ek__BackingField_3;
};

// System.Text.Json.JsonReaderOptions
struct  JsonReaderOptions_tD7C9A60EFCE572E4EA0AC3B1B0731900248253D3 
{
public:
	// System.Int32 System.Text.Json.JsonReaderOptions::_maxDepth
	int32_t ____maxDepth_1;
	// System.Text.Json.JsonCommentHandling System.Text.Json.JsonReaderOptions::_commentHandling
	uint8_t ____commentHandling_2;
	// System.Boolean System.Text.Json.JsonReaderOptions::<AllowTrailingCommas>k__BackingField
	bool ___U3CAllowTrailingCommasU3Ek__BackingField_3;

public:
	inline static int32_t get_offset_of__maxDepth_1() { return static_cast<int32_t>(offsetof(JsonReaderOptions_tD7C9A60EFCE572E4EA0AC3B1B0731900248253D3, ____maxDepth_1)); }
	inline int32_t get__maxDepth_1() const { return ____maxDepth_1; }
	inline int32_t* get_address_of__maxDepth_1() { return &____maxDepth_1; }
	inline void set__maxDepth_1(int32_t value)
	{
		____maxDepth_1 = value;
	}

	inline static int32_t get_offset_of__commentHandling_2() { return static_cast<int32_t>(offsetof(JsonReaderOptions_tD7C9A60EFCE572E4EA0AC3B1B0731900248253D3, ____commentHandling_2)); }
	inline uint8_t get__commentHandling_2() const { return ____commentHandling_2; }
	inline uint8_t* get_address_of__commentHandling_2() { return &____commentHandling_2; }
	inline void set__commentHandling_2(uint8_t value)
	{
		____commentHandling_2 = value;
	}

	inline static int32_t get_offset_of_U3CAllowTrailingCommasU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(JsonReaderOptions_tD7C9A60EFCE572E4EA0AC3B1B0731900248253D3, ___U3CAllowTrailingCommasU3Ek__BackingField_3)); }
	inline bool get_U3CAllowTrailingCommasU3Ek__BackingField_3() const { return ___U3CAllowTrailingCommasU3Ek__BackingField_3; }
	inline bool* get_address_of_U3CAllowTrailingCommasU3Ek__BackingField_3() { return &___U3CAllowTrailingCommasU3Ek__BackingField_3; }
	inline void set_U3CAllowTrailingCommasU3Ek__BackingField_3(bool value)
	{
		___U3CAllowTrailingCommasU3Ek__BackingField_3 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.JsonReaderOptions
struct JsonReaderOptions_tD7C9A60EFCE572E4EA0AC3B1B0731900248253D3_marshaled_pinvoke
{
	int32_t ____maxDepth_1;
	uint8_t ____commentHandling_2;
	int32_t ___U3CAllowTrailingCommasU3Ek__BackingField_3;
};
// Native definition for COM marshalling of System.Text.Json.JsonReaderOptions
struct JsonReaderOptions_tD7C9A60EFCE572E4EA0AC3B1B0731900248253D3_marshaled_com
{
	int32_t ____maxDepth_1;
	uint8_t ____commentHandling_2;
	int32_t ___U3CAllowTrailingCommasU3Ek__BackingField_3;
};

// System.Text.Json.JsonSerializerOptions
struct  JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904  : public RuntimeObject
{
public:
	// System.Collections.Concurrent.ConcurrentDictionary`2<System.Type,System.Text.Json.Serialization.JsonConverter> System.Text.Json.JsonSerializerOptions::_converters
	ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 * ____converters_2;
	// System.Collections.Concurrent.ConcurrentDictionary`2<System.Type,System.Text.Json.Serialization.JsonConverter> System.Text.Json.JsonSerializerOptions::_dictionaryKeyConverters
	ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 * ____dictionaryKeyConverters_3;
	// System.Collections.Generic.IList`1<System.Text.Json.Serialization.JsonConverter> System.Text.Json.JsonSerializerOptions::<Converters>k__BackingField
	RuntimeObject* ___U3CConvertersU3Ek__BackingField_4;
	// System.Collections.Concurrent.ConcurrentDictionary`2<System.Type,System.Text.Json.JsonClassInfo> System.Text.Json.JsonSerializerOptions::_classes
	ConcurrentDictionary_2_t06134CE7BA5058D6E5A23E8C6928111EA6003239 * ____classes_7;
	// System.Text.Json.JsonClassInfo System.Text.Json.JsonSerializerOptions::<_lastClass>k__BackingField
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * ___U3C_lastClassU3Ek__BackingField_8;
	// System.Text.Json.MemberAccessor System.Text.Json.JsonSerializerOptions::_memberAccessorStrategy
	MemberAccessor_tCEB2A61BD6975686650BCE8E668E39B9CF74F8F9 * ____memberAccessorStrategy_9;
	// System.Text.Json.JsonNamingPolicy System.Text.Json.JsonSerializerOptions::_dictionaryKeyPolicy
	JsonNamingPolicy_tC50C562D30D5F9EDB5D4F5D68614850A38843BBC * ____dictionaryKeyPolicy_10;
	// System.Text.Json.JsonNamingPolicy System.Text.Json.JsonSerializerOptions::_jsonPropertyNamingPolicy
	JsonNamingPolicy_tC50C562D30D5F9EDB5D4F5D68614850A38843BBC * ____jsonPropertyNamingPolicy_11;
	// System.Text.Json.JsonCommentHandling System.Text.Json.JsonSerializerOptions::_readCommentHandling
	uint8_t ____readCommentHandling_12;
	// System.Text.Json.Serialization.ReferenceHandler System.Text.Json.JsonSerializerOptions::_referenceHandler
	ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * ____referenceHandler_13;
	// System.Text.Encodings.Web.JavaScriptEncoder System.Text.Json.JsonSerializerOptions::_encoder
	JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118 * ____encoder_14;
	// System.Text.Json.Serialization.JsonIgnoreCondition System.Text.Json.JsonSerializerOptions::_defaultIgnoreCondition
	int32_t ____defaultIgnoreCondition_15;
	// System.Text.Json.Serialization.JsonNumberHandling System.Text.Json.JsonSerializerOptions::_numberHandling
	int32_t ____numberHandling_16;
	// System.Int32 System.Text.Json.JsonSerializerOptions::_defaultBufferSize
	int32_t ____defaultBufferSize_17;
	// System.Int32 System.Text.Json.JsonSerializerOptions::_maxDepth
	int32_t ____maxDepth_18;
	// System.Boolean System.Text.Json.JsonSerializerOptions::_allowTrailingCommas
	bool ____allowTrailingCommas_19;
	// System.Boolean System.Text.Json.JsonSerializerOptions::_haveTypesBeenCreated
	bool ____haveTypesBeenCreated_20;
	// System.Boolean System.Text.Json.JsonSerializerOptions::_ignoreNullValues
	bool ____ignoreNullValues_21;
	// System.Boolean System.Text.Json.JsonSerializerOptions::_ignoreReadOnlyProperties
	bool ____ignoreReadOnlyProperties_22;
	// System.Boolean System.Text.Json.JsonSerializerOptions::_ignoreReadonlyFields
	bool ____ignoreReadonlyFields_23;
	// System.Boolean System.Text.Json.JsonSerializerOptions::_includeFields
	bool ____includeFields_24;
	// System.Boolean System.Text.Json.JsonSerializerOptions::_propertyNameCaseInsensitive
	bool ____propertyNameCaseInsensitive_25;
	// System.Boolean System.Text.Json.JsonSerializerOptions::_writeIndented
	bool ____writeIndented_26;
	// System.Int32 System.Text.Json.JsonSerializerOptions::<EffectiveMaxDepth>k__BackingField
	int32_t ___U3CEffectiveMaxDepthU3Ek__BackingField_27;

public:
	inline static int32_t get_offset_of__converters_2() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____converters_2)); }
	inline ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 * get__converters_2() const { return ____converters_2; }
	inline ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 ** get_address_of__converters_2() { return &____converters_2; }
	inline void set__converters_2(ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 * value)
	{
		____converters_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____converters_2), (void*)value);
	}

	inline static int32_t get_offset_of__dictionaryKeyConverters_3() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____dictionaryKeyConverters_3)); }
	inline ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 * get__dictionaryKeyConverters_3() const { return ____dictionaryKeyConverters_3; }
	inline ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 ** get_address_of__dictionaryKeyConverters_3() { return &____dictionaryKeyConverters_3; }
	inline void set__dictionaryKeyConverters_3(ConcurrentDictionary_2_tF1BF2537296337F220D8F97940DA14112C5E03A8 * value)
	{
		____dictionaryKeyConverters_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____dictionaryKeyConverters_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3CConvertersU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ___U3CConvertersU3Ek__BackingField_4)); }
	inline RuntimeObject* get_U3CConvertersU3Ek__BackingField_4() const { return ___U3CConvertersU3Ek__BackingField_4; }
	inline RuntimeObject** get_address_of_U3CConvertersU3Ek__BackingField_4() { return &___U3CConvertersU3Ek__BackingField_4; }
	inline void set_U3CConvertersU3Ek__BackingField_4(RuntimeObject* value)
	{
		___U3CConvertersU3Ek__BackingField_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CConvertersU3Ek__BackingField_4), (void*)value);
	}

	inline static int32_t get_offset_of__classes_7() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____classes_7)); }
	inline ConcurrentDictionary_2_t06134CE7BA5058D6E5A23E8C6928111EA6003239 * get__classes_7() const { return ____classes_7; }
	inline ConcurrentDictionary_2_t06134CE7BA5058D6E5A23E8C6928111EA6003239 ** get_address_of__classes_7() { return &____classes_7; }
	inline void set__classes_7(ConcurrentDictionary_2_t06134CE7BA5058D6E5A23E8C6928111EA6003239 * value)
	{
		____classes_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____classes_7), (void*)value);
	}

	inline static int32_t get_offset_of_U3C_lastClassU3Ek__BackingField_8() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ___U3C_lastClassU3Ek__BackingField_8)); }
	inline JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * get_U3C_lastClassU3Ek__BackingField_8() const { return ___U3C_lastClassU3Ek__BackingField_8; }
	inline JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 ** get_address_of_U3C_lastClassU3Ek__BackingField_8() { return &___U3C_lastClassU3Ek__BackingField_8; }
	inline void set_U3C_lastClassU3Ek__BackingField_8(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * value)
	{
		___U3C_lastClassU3Ek__BackingField_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3C_lastClassU3Ek__BackingField_8), (void*)value);
	}

	inline static int32_t get_offset_of__memberAccessorStrategy_9() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____memberAccessorStrategy_9)); }
	inline MemberAccessor_tCEB2A61BD6975686650BCE8E668E39B9CF74F8F9 * get__memberAccessorStrategy_9() const { return ____memberAccessorStrategy_9; }
	inline MemberAccessor_tCEB2A61BD6975686650BCE8E668E39B9CF74F8F9 ** get_address_of__memberAccessorStrategy_9() { return &____memberAccessorStrategy_9; }
	inline void set__memberAccessorStrategy_9(MemberAccessor_tCEB2A61BD6975686650BCE8E668E39B9CF74F8F9 * value)
	{
		____memberAccessorStrategy_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____memberAccessorStrategy_9), (void*)value);
	}

	inline static int32_t get_offset_of__dictionaryKeyPolicy_10() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____dictionaryKeyPolicy_10)); }
	inline JsonNamingPolicy_tC50C562D30D5F9EDB5D4F5D68614850A38843BBC * get__dictionaryKeyPolicy_10() const { return ____dictionaryKeyPolicy_10; }
	inline JsonNamingPolicy_tC50C562D30D5F9EDB5D4F5D68614850A38843BBC ** get_address_of__dictionaryKeyPolicy_10() { return &____dictionaryKeyPolicy_10; }
	inline void set__dictionaryKeyPolicy_10(JsonNamingPolicy_tC50C562D30D5F9EDB5D4F5D68614850A38843BBC * value)
	{
		____dictionaryKeyPolicy_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____dictionaryKeyPolicy_10), (void*)value);
	}

	inline static int32_t get_offset_of__jsonPropertyNamingPolicy_11() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____jsonPropertyNamingPolicy_11)); }
	inline JsonNamingPolicy_tC50C562D30D5F9EDB5D4F5D68614850A38843BBC * get__jsonPropertyNamingPolicy_11() const { return ____jsonPropertyNamingPolicy_11; }
	inline JsonNamingPolicy_tC50C562D30D5F9EDB5D4F5D68614850A38843BBC ** get_address_of__jsonPropertyNamingPolicy_11() { return &____jsonPropertyNamingPolicy_11; }
	inline void set__jsonPropertyNamingPolicy_11(JsonNamingPolicy_tC50C562D30D5F9EDB5D4F5D68614850A38843BBC * value)
	{
		____jsonPropertyNamingPolicy_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____jsonPropertyNamingPolicy_11), (void*)value);
	}

	inline static int32_t get_offset_of__readCommentHandling_12() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____readCommentHandling_12)); }
	inline uint8_t get__readCommentHandling_12() const { return ____readCommentHandling_12; }
	inline uint8_t* get_address_of__readCommentHandling_12() { return &____readCommentHandling_12; }
	inline void set__readCommentHandling_12(uint8_t value)
	{
		____readCommentHandling_12 = value;
	}

	inline static int32_t get_offset_of__referenceHandler_13() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____referenceHandler_13)); }
	inline ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * get__referenceHandler_13() const { return ____referenceHandler_13; }
	inline ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F ** get_address_of__referenceHandler_13() { return &____referenceHandler_13; }
	inline void set__referenceHandler_13(ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * value)
	{
		____referenceHandler_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____referenceHandler_13), (void*)value);
	}

	inline static int32_t get_offset_of__encoder_14() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____encoder_14)); }
	inline JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118 * get__encoder_14() const { return ____encoder_14; }
	inline JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118 ** get_address_of__encoder_14() { return &____encoder_14; }
	inline void set__encoder_14(JavaScriptEncoder_tEE2A7276ABD8379AD6317965D32A05CF2AD7B118 * value)
	{
		____encoder_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____encoder_14), (void*)value);
	}

	inline static int32_t get_offset_of__defaultIgnoreCondition_15() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____defaultIgnoreCondition_15)); }
	inline int32_t get__defaultIgnoreCondition_15() const { return ____defaultIgnoreCondition_15; }
	inline int32_t* get_address_of__defaultIgnoreCondition_15() { return &____defaultIgnoreCondition_15; }
	inline void set__defaultIgnoreCondition_15(int32_t value)
	{
		____defaultIgnoreCondition_15 = value;
	}

	inline static int32_t get_offset_of__numberHandling_16() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____numberHandling_16)); }
	inline int32_t get__numberHandling_16() const { return ____numberHandling_16; }
	inline int32_t* get_address_of__numberHandling_16() { return &____numberHandling_16; }
	inline void set__numberHandling_16(int32_t value)
	{
		____numberHandling_16 = value;
	}

	inline static int32_t get_offset_of__defaultBufferSize_17() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____defaultBufferSize_17)); }
	inline int32_t get__defaultBufferSize_17() const { return ____defaultBufferSize_17; }
	inline int32_t* get_address_of__defaultBufferSize_17() { return &____defaultBufferSize_17; }
	inline void set__defaultBufferSize_17(int32_t value)
	{
		____defaultBufferSize_17 = value;
	}

	inline static int32_t get_offset_of__maxDepth_18() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____maxDepth_18)); }
	inline int32_t get__maxDepth_18() const { return ____maxDepth_18; }
	inline int32_t* get_address_of__maxDepth_18() { return &____maxDepth_18; }
	inline void set__maxDepth_18(int32_t value)
	{
		____maxDepth_18 = value;
	}

	inline static int32_t get_offset_of__allowTrailingCommas_19() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____allowTrailingCommas_19)); }
	inline bool get__allowTrailingCommas_19() const { return ____allowTrailingCommas_19; }
	inline bool* get_address_of__allowTrailingCommas_19() { return &____allowTrailingCommas_19; }
	inline void set__allowTrailingCommas_19(bool value)
	{
		____allowTrailingCommas_19 = value;
	}

	inline static int32_t get_offset_of__haveTypesBeenCreated_20() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____haveTypesBeenCreated_20)); }
	inline bool get__haveTypesBeenCreated_20() const { return ____haveTypesBeenCreated_20; }
	inline bool* get_address_of__haveTypesBeenCreated_20() { return &____haveTypesBeenCreated_20; }
	inline void set__haveTypesBeenCreated_20(bool value)
	{
		____haveTypesBeenCreated_20 = value;
	}

	inline static int32_t get_offset_of__ignoreNullValues_21() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____ignoreNullValues_21)); }
	inline bool get__ignoreNullValues_21() const { return ____ignoreNullValues_21; }
	inline bool* get_address_of__ignoreNullValues_21() { return &____ignoreNullValues_21; }
	inline void set__ignoreNullValues_21(bool value)
	{
		____ignoreNullValues_21 = value;
	}

	inline static int32_t get_offset_of__ignoreReadOnlyProperties_22() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____ignoreReadOnlyProperties_22)); }
	inline bool get__ignoreReadOnlyProperties_22() const { return ____ignoreReadOnlyProperties_22; }
	inline bool* get_address_of__ignoreReadOnlyProperties_22() { return &____ignoreReadOnlyProperties_22; }
	inline void set__ignoreReadOnlyProperties_22(bool value)
	{
		____ignoreReadOnlyProperties_22 = value;
	}

	inline static int32_t get_offset_of__ignoreReadonlyFields_23() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____ignoreReadonlyFields_23)); }
	inline bool get__ignoreReadonlyFields_23() const { return ____ignoreReadonlyFields_23; }
	inline bool* get_address_of__ignoreReadonlyFields_23() { return &____ignoreReadonlyFields_23; }
	inline void set__ignoreReadonlyFields_23(bool value)
	{
		____ignoreReadonlyFields_23 = value;
	}

	inline static int32_t get_offset_of__includeFields_24() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____includeFields_24)); }
	inline bool get__includeFields_24() const { return ____includeFields_24; }
	inline bool* get_address_of__includeFields_24() { return &____includeFields_24; }
	inline void set__includeFields_24(bool value)
	{
		____includeFields_24 = value;
	}

	inline static int32_t get_offset_of__propertyNameCaseInsensitive_25() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____propertyNameCaseInsensitive_25)); }
	inline bool get__propertyNameCaseInsensitive_25() const { return ____propertyNameCaseInsensitive_25; }
	inline bool* get_address_of__propertyNameCaseInsensitive_25() { return &____propertyNameCaseInsensitive_25; }
	inline void set__propertyNameCaseInsensitive_25(bool value)
	{
		____propertyNameCaseInsensitive_25 = value;
	}

	inline static int32_t get_offset_of__writeIndented_26() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ____writeIndented_26)); }
	inline bool get__writeIndented_26() const { return ____writeIndented_26; }
	inline bool* get_address_of__writeIndented_26() { return &____writeIndented_26; }
	inline void set__writeIndented_26(bool value)
	{
		____writeIndented_26 = value;
	}

	inline static int32_t get_offset_of_U3CEffectiveMaxDepthU3Ek__BackingField_27() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904, ___U3CEffectiveMaxDepthU3Ek__BackingField_27)); }
	inline int32_t get_U3CEffectiveMaxDepthU3Ek__BackingField_27() const { return ___U3CEffectiveMaxDepthU3Ek__BackingField_27; }
	inline int32_t* get_address_of_U3CEffectiveMaxDepthU3Ek__BackingField_27() { return &___U3CEffectiveMaxDepthU3Ek__BackingField_27; }
	inline void set_U3CEffectiveMaxDepthU3Ek__BackingField_27(int32_t value)
	{
		___U3CEffectiveMaxDepthU3Ek__BackingField_27 = value;
	}
};

struct JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.Type,System.Text.Json.Serialization.JsonConverter> System.Text.Json.JsonSerializerOptions::s_defaultSimpleConverters
	Dictionary_2_t87370488A06CE643EF15B83A78E0AC9870FEDB15 * ___s_defaultSimpleConverters_0;
	// System.Text.Json.Serialization.JsonConverter[] System.Text.Json.JsonSerializerOptions::s_defaultFactoryConverters
	JsonConverterU5BU5D_t295649D6A60073B0FD8F6F4AEDCDC37CF5421232* ___s_defaultFactoryConverters_1;
	// System.Text.Json.JsonSerializerOptions System.Text.Json.JsonSerializerOptions::s_defaultOptions
	JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * ___s_defaultOptions_6;

public:
	inline static int32_t get_offset_of_s_defaultSimpleConverters_0() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904_StaticFields, ___s_defaultSimpleConverters_0)); }
	inline Dictionary_2_t87370488A06CE643EF15B83A78E0AC9870FEDB15 * get_s_defaultSimpleConverters_0() const { return ___s_defaultSimpleConverters_0; }
	inline Dictionary_2_t87370488A06CE643EF15B83A78E0AC9870FEDB15 ** get_address_of_s_defaultSimpleConverters_0() { return &___s_defaultSimpleConverters_0; }
	inline void set_s_defaultSimpleConverters_0(Dictionary_2_t87370488A06CE643EF15B83A78E0AC9870FEDB15 * value)
	{
		___s_defaultSimpleConverters_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultSimpleConverters_0), (void*)value);
	}

	inline static int32_t get_offset_of_s_defaultFactoryConverters_1() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904_StaticFields, ___s_defaultFactoryConverters_1)); }
	inline JsonConverterU5BU5D_t295649D6A60073B0FD8F6F4AEDCDC37CF5421232* get_s_defaultFactoryConverters_1() const { return ___s_defaultFactoryConverters_1; }
	inline JsonConverterU5BU5D_t295649D6A60073B0FD8F6F4AEDCDC37CF5421232** get_address_of_s_defaultFactoryConverters_1() { return &___s_defaultFactoryConverters_1; }
	inline void set_s_defaultFactoryConverters_1(JsonConverterU5BU5D_t295649D6A60073B0FD8F6F4AEDCDC37CF5421232* value)
	{
		___s_defaultFactoryConverters_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultFactoryConverters_1), (void*)value);
	}

	inline static int32_t get_offset_of_s_defaultOptions_6() { return static_cast<int32_t>(offsetof(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904_StaticFields, ___s_defaultOptions_6)); }
	inline JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * get_s_defaultOptions_6() const { return ___s_defaultOptions_6; }
	inline JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 ** get_address_of_s_defaultOptions_6() { return &___s_defaultOptions_6; }
	inline void set_s_defaultOptions_6(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * value)
	{
		___s_defaultOptions_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultOptions_6), (void*)value);
	}
};


// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___delegates_11), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};

// System.Type
struct  Type_t  : public MemberInfo_t
{
public:
	// System.RuntimeTypeHandle System.Type::_impl
	RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  ____impl_9;

public:
	inline static int32_t get_offset_of__impl_9() { return static_cast<int32_t>(offsetof(Type_t, ____impl_9)); }
	inline RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  get__impl_9() const { return ____impl_9; }
	inline RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9 * get_address_of__impl_9() { return &____impl_9; }
	inline void set__impl_9(RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  value)
	{
		____impl_9 = value;
	}
};

struct Type_t_StaticFields
{
public:
	// System.Reflection.MemberFilter System.Type::FilterAttribute
	MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 * ___FilterAttribute_0;
	// System.Reflection.MemberFilter System.Type::FilterName
	MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 * ___FilterName_1;
	// System.Reflection.MemberFilter System.Type::FilterNameIgnoreCase
	MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 * ___FilterNameIgnoreCase_2;
	// System.Object System.Type::Missing
	RuntimeObject * ___Missing_3;
	// System.Char System.Type::Delimiter
	Il2CppChar ___Delimiter_4;
	// System.Type[] System.Type::EmptyTypes
	TypeU5BU5D_t85B10489E46F06CEC7C4B1CCBD0E01FAB6649755* ___EmptyTypes_5;
	// System.Reflection.Binder System.Type::defaultBinder
	Binder_t2BEE27FD84737D1E79BC47FD67F6D3DD2F2DDA30 * ___defaultBinder_6;

public:
	inline static int32_t get_offset_of_FilterAttribute_0() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterAttribute_0)); }
	inline MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 * get_FilterAttribute_0() const { return ___FilterAttribute_0; }
	inline MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 ** get_address_of_FilterAttribute_0() { return &___FilterAttribute_0; }
	inline void set_FilterAttribute_0(MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 * value)
	{
		___FilterAttribute_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FilterAttribute_0), (void*)value);
	}

	inline static int32_t get_offset_of_FilterName_1() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterName_1)); }
	inline MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 * get_FilterName_1() const { return ___FilterName_1; }
	inline MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 ** get_address_of_FilterName_1() { return &___FilterName_1; }
	inline void set_FilterName_1(MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 * value)
	{
		___FilterName_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FilterName_1), (void*)value);
	}

	inline static int32_t get_offset_of_FilterNameIgnoreCase_2() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterNameIgnoreCase_2)); }
	inline MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 * get_FilterNameIgnoreCase_2() const { return ___FilterNameIgnoreCase_2; }
	inline MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 ** get_address_of_FilterNameIgnoreCase_2() { return &___FilterNameIgnoreCase_2; }
	inline void set_FilterNameIgnoreCase_2(MemberFilter_t48D0AA10105D186AF42428FA532D4B4332CF8B81 * value)
	{
		___FilterNameIgnoreCase_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FilterNameIgnoreCase_2), (void*)value);
	}

	inline static int32_t get_offset_of_Missing_3() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___Missing_3)); }
	inline RuntimeObject * get_Missing_3() const { return ___Missing_3; }
	inline RuntimeObject ** get_address_of_Missing_3() { return &___Missing_3; }
	inline void set_Missing_3(RuntimeObject * value)
	{
		___Missing_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Missing_3), (void*)value);
	}

	inline static int32_t get_offset_of_Delimiter_4() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___Delimiter_4)); }
	inline Il2CppChar get_Delimiter_4() const { return ___Delimiter_4; }
	inline Il2CppChar* get_address_of_Delimiter_4() { return &___Delimiter_4; }
	inline void set_Delimiter_4(Il2CppChar value)
	{
		___Delimiter_4 = value;
	}

	inline static int32_t get_offset_of_EmptyTypes_5() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___EmptyTypes_5)); }
	inline TypeU5BU5D_t85B10489E46F06CEC7C4B1CCBD0E01FAB6649755* get_EmptyTypes_5() const { return ___EmptyTypes_5; }
	inline TypeU5BU5D_t85B10489E46F06CEC7C4B1CCBD0E01FAB6649755** get_address_of_EmptyTypes_5() { return &___EmptyTypes_5; }
	inline void set_EmptyTypes_5(TypeU5BU5D_t85B10489E46F06CEC7C4B1CCBD0E01FAB6649755* value)
	{
		___EmptyTypes_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___EmptyTypes_5), (void*)value);
	}

	inline static int32_t get_offset_of_defaultBinder_6() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___defaultBinder_6)); }
	inline Binder_t2BEE27FD84737D1E79BC47FD67F6D3DD2F2DDA30 * get_defaultBinder_6() const { return ___defaultBinder_6; }
	inline Binder_t2BEE27FD84737D1E79BC47FD67F6D3DD2F2DDA30 ** get_address_of_defaultBinder_6() { return &___defaultBinder_6; }
	inline void set_defaultBinder_6(Binder_t2BEE27FD84737D1E79BC47FD67F6D3DD2F2DDA30 * value)
	{
		___defaultBinder_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___defaultBinder_6), (void*)value);
	}
};


// System.Text.Json.Utf8JsonWriter
struct  Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C  : public RuntimeObject
{
public:
	// System.Buffers.IBufferWriter`1<System.Byte> System.Text.Json.Utf8JsonWriter::_output
	RuntimeObject* ____output_3;
	// System.IO.Stream System.Text.Json.Utf8JsonWriter::_stream
	Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * ____stream_4;
	// System.Buffers.ArrayBufferWriter`1<System.Byte> System.Text.Json.Utf8JsonWriter::_arrayBufferWriter
	ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * ____arrayBufferWriter_5;
	// System.Memory`1<System.Byte> System.Text.Json.Utf8JsonWriter::_memory
	Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9  ____memory_6;
	// System.Boolean System.Text.Json.Utf8JsonWriter::_inObject
	bool ____inObject_7;
	// System.Text.Json.JsonTokenType System.Text.Json.Utf8JsonWriter::_tokenType
	uint8_t ____tokenType_8;
	// System.Text.Json.BitStack System.Text.Json.Utf8JsonWriter::_bitStack
	BitStack_t05309790B90A50AE2163A8B3A4125905372F37D7  ____bitStack_9;
	// System.Int32 System.Text.Json.Utf8JsonWriter::_currentDepth
	int32_t ____currentDepth_10;
	// System.Text.Json.JsonWriterOptions System.Text.Json.Utf8JsonWriter::_options
	JsonWriterOptions_tDF037E30F6E08170C5D33C09632D79BC06A4A67C  ____options_11;
	// System.Int32 System.Text.Json.Utf8JsonWriter::<BytesPending>k__BackingField
	int32_t ___U3CBytesPendingU3Ek__BackingField_12;
	// System.Int64 System.Text.Json.Utf8JsonWriter::<BytesCommitted>k__BackingField
	int64_t ___U3CBytesCommittedU3Ek__BackingField_13;

public:
	inline static int32_t get_offset_of__output_3() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ____output_3)); }
	inline RuntimeObject* get__output_3() const { return ____output_3; }
	inline RuntimeObject** get_address_of__output_3() { return &____output_3; }
	inline void set__output_3(RuntimeObject* value)
	{
		____output_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____output_3), (void*)value);
	}

	inline static int32_t get_offset_of__stream_4() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ____stream_4)); }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * get__stream_4() const { return ____stream_4; }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB ** get_address_of__stream_4() { return &____stream_4; }
	inline void set__stream_4(Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * value)
	{
		____stream_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____stream_4), (void*)value);
	}

	inline static int32_t get_offset_of__arrayBufferWriter_5() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ____arrayBufferWriter_5)); }
	inline ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * get__arrayBufferWriter_5() const { return ____arrayBufferWriter_5; }
	inline ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 ** get_address_of__arrayBufferWriter_5() { return &____arrayBufferWriter_5; }
	inline void set__arrayBufferWriter_5(ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * value)
	{
		____arrayBufferWriter_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____arrayBufferWriter_5), (void*)value);
	}

	inline static int32_t get_offset_of__memory_6() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ____memory_6)); }
	inline Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9  get__memory_6() const { return ____memory_6; }
	inline Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9 * get_address_of__memory_6() { return &____memory_6; }
	inline void set__memory_6(Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9  value)
	{
		____memory_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&____memory_6))->____object_0), (void*)NULL);
	}

	inline static int32_t get_offset_of__inObject_7() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ____inObject_7)); }
	inline bool get__inObject_7() const { return ____inObject_7; }
	inline bool* get_address_of__inObject_7() { return &____inObject_7; }
	inline void set__inObject_7(bool value)
	{
		____inObject_7 = value;
	}

	inline static int32_t get_offset_of__tokenType_8() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ____tokenType_8)); }
	inline uint8_t get__tokenType_8() const { return ____tokenType_8; }
	inline uint8_t* get_address_of__tokenType_8() { return &____tokenType_8; }
	inline void set__tokenType_8(uint8_t value)
	{
		____tokenType_8 = value;
	}

	inline static int32_t get_offset_of__bitStack_9() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ____bitStack_9)); }
	inline BitStack_t05309790B90A50AE2163A8B3A4125905372F37D7  get__bitStack_9() const { return ____bitStack_9; }
	inline BitStack_t05309790B90A50AE2163A8B3A4125905372F37D7 * get_address_of__bitStack_9() { return &____bitStack_9; }
	inline void set__bitStack_9(BitStack_t05309790B90A50AE2163A8B3A4125905372F37D7  value)
	{
		____bitStack_9 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&____bitStack_9))->____array_2), (void*)NULL);
	}

	inline static int32_t get_offset_of__currentDepth_10() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ____currentDepth_10)); }
	inline int32_t get__currentDepth_10() const { return ____currentDepth_10; }
	inline int32_t* get_address_of__currentDepth_10() { return &____currentDepth_10; }
	inline void set__currentDepth_10(int32_t value)
	{
		____currentDepth_10 = value;
	}

	inline static int32_t get_offset_of__options_11() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ____options_11)); }
	inline JsonWriterOptions_tDF037E30F6E08170C5D33C09632D79BC06A4A67C  get__options_11() const { return ____options_11; }
	inline JsonWriterOptions_tDF037E30F6E08170C5D33C09632D79BC06A4A67C * get_address_of__options_11() { return &____options_11; }
	inline void set__options_11(JsonWriterOptions_tDF037E30F6E08170C5D33C09632D79BC06A4A67C  value)
	{
		____options_11 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&____options_11))->___U3CEncoderU3Ek__BackingField_1), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CBytesPendingU3Ek__BackingField_12() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ___U3CBytesPendingU3Ek__BackingField_12)); }
	inline int32_t get_U3CBytesPendingU3Ek__BackingField_12() const { return ___U3CBytesPendingU3Ek__BackingField_12; }
	inline int32_t* get_address_of_U3CBytesPendingU3Ek__BackingField_12() { return &___U3CBytesPendingU3Ek__BackingField_12; }
	inline void set_U3CBytesPendingU3Ek__BackingField_12(int32_t value)
	{
		___U3CBytesPendingU3Ek__BackingField_12 = value;
	}

	inline static int32_t get_offset_of_U3CBytesCommittedU3Ek__BackingField_13() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C, ___U3CBytesCommittedU3Ek__BackingField_13)); }
	inline int64_t get_U3CBytesCommittedU3Ek__BackingField_13() const { return ___U3CBytesCommittedU3Ek__BackingField_13; }
	inline int64_t* get_address_of_U3CBytesCommittedU3Ek__BackingField_13() { return &___U3CBytesCommittedU3Ek__BackingField_13; }
	inline void set_U3CBytesCommittedU3Ek__BackingField_13(int64_t value)
	{
		___U3CBytesCommittedU3Ek__BackingField_13 = value;
	}
};

struct Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C_StaticFields
{
public:
	// System.Int32 System.Text.Json.Utf8JsonWriter::s_newLineLength
	int32_t ___s_newLineLength_0;
	// System.Char[] System.Text.Json.Utf8JsonWriter::s_singleLineCommentDelimiter
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___s_singleLineCommentDelimiter_14;

public:
	inline static int32_t get_offset_of_s_newLineLength_0() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C_StaticFields, ___s_newLineLength_0)); }
	inline int32_t get_s_newLineLength_0() const { return ___s_newLineLength_0; }
	inline int32_t* get_address_of_s_newLineLength_0() { return &___s_newLineLength_0; }
	inline void set_s_newLineLength_0(int32_t value)
	{
		___s_newLineLength_0 = value;
	}

	inline static int32_t get_offset_of_s_singleLineCommentDelimiter_14() { return static_cast<int32_t>(offsetof(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C_StaticFields, ___s_singleLineCommentDelimiter_14)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_s_singleLineCommentDelimiter_14() const { return ___s_singleLineCommentDelimiter_14; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_s_singleLineCommentDelimiter_14() { return &___s_singleLineCommentDelimiter_14; }
	inline void set_s_singleLineCommentDelimiter_14(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___s_singleLineCommentDelimiter_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_singleLineCommentDelimiter_14), (void*)value);
	}
};


// System.Text.Json.JsonDocument/<ReadToEndAsync>d__65
struct  U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B 
{
public:
	// System.Int32 System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.ArraySegment`1<System.Byte>> System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::<>t__builder
	AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4  ___U3CU3Et__builder_1;
	// System.IO.Stream System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::stream
	Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * ___stream_2;
	// System.Threading.CancellationToken System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::cancellationToken
	CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  ___cancellationToken_3;
	// System.Int32 System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::<written>5__2
	int32_t ___U3CwrittenU3E5__2_4;
	// System.Byte[] System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::<rented>5__3
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___U3CrentedU3E5__3_5;
	// System.Int32 System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::<utf8BomLength>5__4
	int32_t ___U3Cutf8BomLengthU3E5__4_6;
	// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.Int32> System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::<>u__1
	ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  ___U3CU3Eu__1_7;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Et__builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_stream_2() { return static_cast<int32_t>(offsetof(U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B, ___stream_2)); }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * get_stream_2() const { return ___stream_2; }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB ** get_address_of_stream_2() { return &___stream_2; }
	inline void set_stream_2(Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * value)
	{
		___stream_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___stream_2), (void*)value);
	}

	inline static int32_t get_offset_of_cancellationToken_3() { return static_cast<int32_t>(offsetof(U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B, ___cancellationToken_3)); }
	inline CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  get_cancellationToken_3() const { return ___cancellationToken_3; }
	inline CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD * get_address_of_cancellationToken_3() { return &___cancellationToken_3; }
	inline void set_cancellationToken_3(CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  value)
	{
		___cancellationToken_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___cancellationToken_3))->___m_source_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CwrittenU3E5__2_4() { return static_cast<int32_t>(offsetof(U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B, ___U3CwrittenU3E5__2_4)); }
	inline int32_t get_U3CwrittenU3E5__2_4() const { return ___U3CwrittenU3E5__2_4; }
	inline int32_t* get_address_of_U3CwrittenU3E5__2_4() { return &___U3CwrittenU3E5__2_4; }
	inline void set_U3CwrittenU3E5__2_4(int32_t value)
	{
		___U3CwrittenU3E5__2_4 = value;
	}

	inline static int32_t get_offset_of_U3CrentedU3E5__3_5() { return static_cast<int32_t>(offsetof(U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B, ___U3CrentedU3E5__3_5)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_U3CrentedU3E5__3_5() const { return ___U3CrentedU3E5__3_5; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_U3CrentedU3E5__3_5() { return &___U3CrentedU3E5__3_5; }
	inline void set_U3CrentedU3E5__3_5(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___U3CrentedU3E5__3_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CrentedU3E5__3_5), (void*)value);
	}

	inline static int32_t get_offset_of_U3Cutf8BomLengthU3E5__4_6() { return static_cast<int32_t>(offsetof(U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B, ___U3Cutf8BomLengthU3E5__4_6)); }
	inline int32_t get_U3Cutf8BomLengthU3E5__4_6() const { return ___U3Cutf8BomLengthU3E5__4_6; }
	inline int32_t* get_address_of_U3Cutf8BomLengthU3E5__4_6() { return &___U3Cutf8BomLengthU3E5__4_6; }
	inline void set_U3Cutf8BomLengthU3E5__4_6(int32_t value)
	{
		___U3Cutf8BomLengthU3E5__4_6 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_7() { return static_cast<int32_t>(offsetof(U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B, ___U3CU3Eu__1_7)); }
	inline ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  get_U3CU3Eu__1_7() const { return ___U3CU3Eu__1_7; }
	inline ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 * get_address_of_U3CU3Eu__1_7() { return &___U3CU3Eu__1_7; }
	inline void set_U3CU3Eu__1_7(ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  value)
	{
		___U3CU3Eu__1_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_7))->___m_task_0), (void*)NULL);
	}
};


// System.AsyncCallback
struct  AsyncCallback_tA7921BEF974919C46FF8F9D9867C567B200BB0EA  : public MulticastDelegate_t
{
public:

public:
};


// System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder
struct  AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 
{
public:
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::_methodBuilder
	AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B  ____methodBuilder_0;
	// System.Boolean System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::_haveResult
	bool ____haveResult_1;
	// System.Boolean System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::_useBuilder
	bool ____useBuilder_2;

public:
	inline static int32_t get_offset_of__methodBuilder_0() { return static_cast<int32_t>(offsetof(AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8, ____methodBuilder_0)); }
	inline AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B  get__methodBuilder_0() const { return ____methodBuilder_0; }
	inline AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * get_address_of__methodBuilder_0() { return &____methodBuilder_0; }
	inline void set__methodBuilder_0(AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B  value)
	{
		____methodBuilder_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&____methodBuilder_0))->___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&____methodBuilder_0))->___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&____methodBuilder_0))->___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of__haveResult_1() { return static_cast<int32_t>(offsetof(AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8, ____haveResult_1)); }
	inline bool get__haveResult_1() const { return ____haveResult_1; }
	inline bool* get_address_of__haveResult_1() { return &____haveResult_1; }
	inline void set__haveResult_1(bool value)
	{
		____haveResult_1 = value;
	}

	inline static int32_t get_offset_of__useBuilder_2() { return static_cast<int32_t>(offsetof(AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8, ____useBuilder_2)); }
	inline bool get__useBuilder_2() const { return ____useBuilder_2; }
	inline bool* get_address_of__useBuilder_2() { return &____useBuilder_2; }
	inline void set__useBuilder_2(bool value)
	{
		____useBuilder_2 = value;
	}
};


// System.Text.Json.JsonPropertyInfo
struct  JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F  : public RuntimeObject
{
public:
	// System.Text.Json.JsonClassInfo System.Text.Json.JsonPropertyInfo::_runtimeClassInfo
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * ____runtimeClassInfo_1;
	// System.Text.Json.ClassType System.Text.Json.JsonPropertyInfo::ClassType
	uint8_t ___ClassType_2;
	// System.Type System.Text.Json.JsonPropertyInfo::<DeclaredPropertyType>k__BackingField
	Type_t * ___U3CDeclaredPropertyTypeU3Ek__BackingField_3;
	// System.Boolean System.Text.Json.JsonPropertyInfo::<HasGetter>k__BackingField
	bool ___U3CHasGetterU3Ek__BackingField_4;
	// System.Boolean System.Text.Json.JsonPropertyInfo::<HasSetter>k__BackingField
	bool ___U3CHasSetterU3Ek__BackingField_5;
	// System.Boolean System.Text.Json.JsonPropertyInfo::<IgnoreDefaultValuesOnRead>k__BackingField
	bool ___U3CIgnoreDefaultValuesOnReadU3Ek__BackingField_6;
	// System.Boolean System.Text.Json.JsonPropertyInfo::<IgnoreDefaultValuesOnWrite>k__BackingField
	bool ___U3CIgnoreDefaultValuesOnWriteU3Ek__BackingField_7;
	// System.Boolean System.Text.Json.JsonPropertyInfo::<IsForClassInfo>k__BackingField
	bool ___U3CIsForClassInfoU3Ek__BackingField_8;
	// System.String System.Text.Json.JsonPropertyInfo::<NameAsString>k__BackingField
	String_t* ___U3CNameAsStringU3Ek__BackingField_9;
	// System.Byte[] System.Text.Json.JsonPropertyInfo::NameAsUtf8Bytes
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___NameAsUtf8Bytes_10;
	// System.Byte[] System.Text.Json.JsonPropertyInfo::EscapedNameSection
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___EscapedNameSection_11;
	// System.Text.Json.JsonSerializerOptions System.Text.Json.JsonPropertyInfo::<Options>k__BackingField
	JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * ___U3COptionsU3Ek__BackingField_12;
	// System.Type System.Text.Json.JsonPropertyInfo::<ParentClassType>k__BackingField
	Type_t * ___U3CParentClassTypeU3Ek__BackingField_13;
	// System.Reflection.MemberInfo System.Text.Json.JsonPropertyInfo::<MemberInfo>k__BackingField
	MemberInfo_t * ___U3CMemberInfoU3Ek__BackingField_14;
	// System.Type System.Text.Json.JsonPropertyInfo::<RuntimePropertyType>k__BackingField
	Type_t * ___U3CRuntimePropertyTypeU3Ek__BackingField_15;
	// System.Boolean System.Text.Json.JsonPropertyInfo::<ShouldSerialize>k__BackingField
	bool ___U3CShouldSerializeU3Ek__BackingField_16;
	// System.Boolean System.Text.Json.JsonPropertyInfo::<ShouldDeserialize>k__BackingField
	bool ___U3CShouldDeserializeU3Ek__BackingField_17;
	// System.Boolean System.Text.Json.JsonPropertyInfo::<IsIgnored>k__BackingField
	bool ___U3CIsIgnoredU3Ek__BackingField_18;
	// System.Nullable`1<System.Text.Json.Serialization.JsonNumberHandling> System.Text.Json.JsonPropertyInfo::<NumberHandling>k__BackingField
	Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  ___U3CNumberHandlingU3Ek__BackingField_19;
	// System.Boolean System.Text.Json.JsonPropertyInfo::<PropertyTypeCanBeNull>k__BackingField
	bool ___U3CPropertyTypeCanBeNullU3Ek__BackingField_20;

public:
	inline static int32_t get_offset_of__runtimeClassInfo_1() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ____runtimeClassInfo_1)); }
	inline JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * get__runtimeClassInfo_1() const { return ____runtimeClassInfo_1; }
	inline JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 ** get_address_of__runtimeClassInfo_1() { return &____runtimeClassInfo_1; }
	inline void set__runtimeClassInfo_1(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * value)
	{
		____runtimeClassInfo_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____runtimeClassInfo_1), (void*)value);
	}

	inline static int32_t get_offset_of_ClassType_2() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___ClassType_2)); }
	inline uint8_t get_ClassType_2() const { return ___ClassType_2; }
	inline uint8_t* get_address_of_ClassType_2() { return &___ClassType_2; }
	inline void set_ClassType_2(uint8_t value)
	{
		___ClassType_2 = value;
	}

	inline static int32_t get_offset_of_U3CDeclaredPropertyTypeU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CDeclaredPropertyTypeU3Ek__BackingField_3)); }
	inline Type_t * get_U3CDeclaredPropertyTypeU3Ek__BackingField_3() const { return ___U3CDeclaredPropertyTypeU3Ek__BackingField_3; }
	inline Type_t ** get_address_of_U3CDeclaredPropertyTypeU3Ek__BackingField_3() { return &___U3CDeclaredPropertyTypeU3Ek__BackingField_3; }
	inline void set_U3CDeclaredPropertyTypeU3Ek__BackingField_3(Type_t * value)
	{
		___U3CDeclaredPropertyTypeU3Ek__BackingField_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CDeclaredPropertyTypeU3Ek__BackingField_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3CHasGetterU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CHasGetterU3Ek__BackingField_4)); }
	inline bool get_U3CHasGetterU3Ek__BackingField_4() const { return ___U3CHasGetterU3Ek__BackingField_4; }
	inline bool* get_address_of_U3CHasGetterU3Ek__BackingField_4() { return &___U3CHasGetterU3Ek__BackingField_4; }
	inline void set_U3CHasGetterU3Ek__BackingField_4(bool value)
	{
		___U3CHasGetterU3Ek__BackingField_4 = value;
	}

	inline static int32_t get_offset_of_U3CHasSetterU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CHasSetterU3Ek__BackingField_5)); }
	inline bool get_U3CHasSetterU3Ek__BackingField_5() const { return ___U3CHasSetterU3Ek__BackingField_5; }
	inline bool* get_address_of_U3CHasSetterU3Ek__BackingField_5() { return &___U3CHasSetterU3Ek__BackingField_5; }
	inline void set_U3CHasSetterU3Ek__BackingField_5(bool value)
	{
		___U3CHasSetterU3Ek__BackingField_5 = value;
	}

	inline static int32_t get_offset_of_U3CIgnoreDefaultValuesOnReadU3Ek__BackingField_6() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CIgnoreDefaultValuesOnReadU3Ek__BackingField_6)); }
	inline bool get_U3CIgnoreDefaultValuesOnReadU3Ek__BackingField_6() const { return ___U3CIgnoreDefaultValuesOnReadU3Ek__BackingField_6; }
	inline bool* get_address_of_U3CIgnoreDefaultValuesOnReadU3Ek__BackingField_6() { return &___U3CIgnoreDefaultValuesOnReadU3Ek__BackingField_6; }
	inline void set_U3CIgnoreDefaultValuesOnReadU3Ek__BackingField_6(bool value)
	{
		___U3CIgnoreDefaultValuesOnReadU3Ek__BackingField_6 = value;
	}

	inline static int32_t get_offset_of_U3CIgnoreDefaultValuesOnWriteU3Ek__BackingField_7() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CIgnoreDefaultValuesOnWriteU3Ek__BackingField_7)); }
	inline bool get_U3CIgnoreDefaultValuesOnWriteU3Ek__BackingField_7() const { return ___U3CIgnoreDefaultValuesOnWriteU3Ek__BackingField_7; }
	inline bool* get_address_of_U3CIgnoreDefaultValuesOnWriteU3Ek__BackingField_7() { return &___U3CIgnoreDefaultValuesOnWriteU3Ek__BackingField_7; }
	inline void set_U3CIgnoreDefaultValuesOnWriteU3Ek__BackingField_7(bool value)
	{
		___U3CIgnoreDefaultValuesOnWriteU3Ek__BackingField_7 = value;
	}

	inline static int32_t get_offset_of_U3CIsForClassInfoU3Ek__BackingField_8() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CIsForClassInfoU3Ek__BackingField_8)); }
	inline bool get_U3CIsForClassInfoU3Ek__BackingField_8() const { return ___U3CIsForClassInfoU3Ek__BackingField_8; }
	inline bool* get_address_of_U3CIsForClassInfoU3Ek__BackingField_8() { return &___U3CIsForClassInfoU3Ek__BackingField_8; }
	inline void set_U3CIsForClassInfoU3Ek__BackingField_8(bool value)
	{
		___U3CIsForClassInfoU3Ek__BackingField_8 = value;
	}

	inline static int32_t get_offset_of_U3CNameAsStringU3Ek__BackingField_9() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CNameAsStringU3Ek__BackingField_9)); }
	inline String_t* get_U3CNameAsStringU3Ek__BackingField_9() const { return ___U3CNameAsStringU3Ek__BackingField_9; }
	inline String_t** get_address_of_U3CNameAsStringU3Ek__BackingField_9() { return &___U3CNameAsStringU3Ek__BackingField_9; }
	inline void set_U3CNameAsStringU3Ek__BackingField_9(String_t* value)
	{
		___U3CNameAsStringU3Ek__BackingField_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CNameAsStringU3Ek__BackingField_9), (void*)value);
	}

	inline static int32_t get_offset_of_NameAsUtf8Bytes_10() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___NameAsUtf8Bytes_10)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_NameAsUtf8Bytes_10() const { return ___NameAsUtf8Bytes_10; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_NameAsUtf8Bytes_10() { return &___NameAsUtf8Bytes_10; }
	inline void set_NameAsUtf8Bytes_10(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___NameAsUtf8Bytes_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___NameAsUtf8Bytes_10), (void*)value);
	}

	inline static int32_t get_offset_of_EscapedNameSection_11() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___EscapedNameSection_11)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_EscapedNameSection_11() const { return ___EscapedNameSection_11; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_EscapedNameSection_11() { return &___EscapedNameSection_11; }
	inline void set_EscapedNameSection_11(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___EscapedNameSection_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___EscapedNameSection_11), (void*)value);
	}

	inline static int32_t get_offset_of_U3COptionsU3Ek__BackingField_12() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3COptionsU3Ek__BackingField_12)); }
	inline JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * get_U3COptionsU3Ek__BackingField_12() const { return ___U3COptionsU3Ek__BackingField_12; }
	inline JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 ** get_address_of_U3COptionsU3Ek__BackingField_12() { return &___U3COptionsU3Ek__BackingField_12; }
	inline void set_U3COptionsU3Ek__BackingField_12(JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * value)
	{
		___U3COptionsU3Ek__BackingField_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3COptionsU3Ek__BackingField_12), (void*)value);
	}

	inline static int32_t get_offset_of_U3CParentClassTypeU3Ek__BackingField_13() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CParentClassTypeU3Ek__BackingField_13)); }
	inline Type_t * get_U3CParentClassTypeU3Ek__BackingField_13() const { return ___U3CParentClassTypeU3Ek__BackingField_13; }
	inline Type_t ** get_address_of_U3CParentClassTypeU3Ek__BackingField_13() { return &___U3CParentClassTypeU3Ek__BackingField_13; }
	inline void set_U3CParentClassTypeU3Ek__BackingField_13(Type_t * value)
	{
		___U3CParentClassTypeU3Ek__BackingField_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CParentClassTypeU3Ek__BackingField_13), (void*)value);
	}

	inline static int32_t get_offset_of_U3CMemberInfoU3Ek__BackingField_14() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CMemberInfoU3Ek__BackingField_14)); }
	inline MemberInfo_t * get_U3CMemberInfoU3Ek__BackingField_14() const { return ___U3CMemberInfoU3Ek__BackingField_14; }
	inline MemberInfo_t ** get_address_of_U3CMemberInfoU3Ek__BackingField_14() { return &___U3CMemberInfoU3Ek__BackingField_14; }
	inline void set_U3CMemberInfoU3Ek__BackingField_14(MemberInfo_t * value)
	{
		___U3CMemberInfoU3Ek__BackingField_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CMemberInfoU3Ek__BackingField_14), (void*)value);
	}

	inline static int32_t get_offset_of_U3CRuntimePropertyTypeU3Ek__BackingField_15() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CRuntimePropertyTypeU3Ek__BackingField_15)); }
	inline Type_t * get_U3CRuntimePropertyTypeU3Ek__BackingField_15() const { return ___U3CRuntimePropertyTypeU3Ek__BackingField_15; }
	inline Type_t ** get_address_of_U3CRuntimePropertyTypeU3Ek__BackingField_15() { return &___U3CRuntimePropertyTypeU3Ek__BackingField_15; }
	inline void set_U3CRuntimePropertyTypeU3Ek__BackingField_15(Type_t * value)
	{
		___U3CRuntimePropertyTypeU3Ek__BackingField_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CRuntimePropertyTypeU3Ek__BackingField_15), (void*)value);
	}

	inline static int32_t get_offset_of_U3CShouldSerializeU3Ek__BackingField_16() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CShouldSerializeU3Ek__BackingField_16)); }
	inline bool get_U3CShouldSerializeU3Ek__BackingField_16() const { return ___U3CShouldSerializeU3Ek__BackingField_16; }
	inline bool* get_address_of_U3CShouldSerializeU3Ek__BackingField_16() { return &___U3CShouldSerializeU3Ek__BackingField_16; }
	inline void set_U3CShouldSerializeU3Ek__BackingField_16(bool value)
	{
		___U3CShouldSerializeU3Ek__BackingField_16 = value;
	}

	inline static int32_t get_offset_of_U3CShouldDeserializeU3Ek__BackingField_17() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CShouldDeserializeU3Ek__BackingField_17)); }
	inline bool get_U3CShouldDeserializeU3Ek__BackingField_17() const { return ___U3CShouldDeserializeU3Ek__BackingField_17; }
	inline bool* get_address_of_U3CShouldDeserializeU3Ek__BackingField_17() { return &___U3CShouldDeserializeU3Ek__BackingField_17; }
	inline void set_U3CShouldDeserializeU3Ek__BackingField_17(bool value)
	{
		___U3CShouldDeserializeU3Ek__BackingField_17 = value;
	}

	inline static int32_t get_offset_of_U3CIsIgnoredU3Ek__BackingField_18() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CIsIgnoredU3Ek__BackingField_18)); }
	inline bool get_U3CIsIgnoredU3Ek__BackingField_18() const { return ___U3CIsIgnoredU3Ek__BackingField_18; }
	inline bool* get_address_of_U3CIsIgnoredU3Ek__BackingField_18() { return &___U3CIsIgnoredU3Ek__BackingField_18; }
	inline void set_U3CIsIgnoredU3Ek__BackingField_18(bool value)
	{
		___U3CIsIgnoredU3Ek__BackingField_18 = value;
	}

	inline static int32_t get_offset_of_U3CNumberHandlingU3Ek__BackingField_19() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CNumberHandlingU3Ek__BackingField_19)); }
	inline Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  get_U3CNumberHandlingU3Ek__BackingField_19() const { return ___U3CNumberHandlingU3Ek__BackingField_19; }
	inline Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58 * get_address_of_U3CNumberHandlingU3Ek__BackingField_19() { return &___U3CNumberHandlingU3Ek__BackingField_19; }
	inline void set_U3CNumberHandlingU3Ek__BackingField_19(Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  value)
	{
		___U3CNumberHandlingU3Ek__BackingField_19 = value;
	}

	inline static int32_t get_offset_of_U3CPropertyTypeCanBeNullU3Ek__BackingField_20() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F, ___U3CPropertyTypeCanBeNullU3Ek__BackingField_20)); }
	inline bool get_U3CPropertyTypeCanBeNullU3Ek__BackingField_20() const { return ___U3CPropertyTypeCanBeNullU3Ek__BackingField_20; }
	inline bool* get_address_of_U3CPropertyTypeCanBeNullU3Ek__BackingField_20() { return &___U3CPropertyTypeCanBeNullU3Ek__BackingField_20; }
	inline void set_U3CPropertyTypeCanBeNullU3Ek__BackingField_20(bool value)
	{
		___U3CPropertyTypeCanBeNullU3Ek__BackingField_20 = value;
	}
};

struct JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F_StaticFields
{
public:
	// System.Text.Json.JsonPropertyInfo System.Text.Json.JsonPropertyInfo::s_missingProperty
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___s_missingProperty_0;

public:
	inline static int32_t get_offset_of_s_missingProperty_0() { return static_cast<int32_t>(offsetof(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F_StaticFields, ___s_missingProperty_0)); }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * get_s_missingProperty_0() const { return ___s_missingProperty_0; }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F ** get_address_of_s_missingProperty_0() { return &___s_missingProperty_0; }
	inline void set_s_missingProperty_0(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * value)
	{
		___s_missingProperty_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_missingProperty_0), (void*)value);
	}
};


// System.Text.Json.ReadStackFrame
struct  ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756 
{
public:
	// System.Text.Json.JsonPropertyInfo System.Text.Json.ReadStackFrame::JsonPropertyInfo
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___JsonPropertyInfo_0;
	// System.Text.Json.StackFramePropertyState System.Text.Json.ReadStackFrame::PropertyState
	uint8_t ___PropertyState_1;
	// System.Boolean System.Text.Json.ReadStackFrame::UseExtensionProperty
	bool ___UseExtensionProperty_2;
	// System.Byte[] System.Text.Json.ReadStackFrame::JsonPropertyName
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___JsonPropertyName_3;
	// System.String System.Text.Json.ReadStackFrame::JsonPropertyNameAsString
	String_t* ___JsonPropertyNameAsString_4;
	// System.Object System.Text.Json.ReadStackFrame::DictionaryKey
	RuntimeObject * ___DictionaryKey_5;
	// System.Int32 System.Text.Json.ReadStackFrame::OriginalDepth
	int32_t ___OriginalDepth_6;
	// System.Text.Json.JsonTokenType System.Text.Json.ReadStackFrame::OriginalTokenType
	uint8_t ___OriginalTokenType_7;
	// System.Object System.Text.Json.ReadStackFrame::ReturnValue
	RuntimeObject * ___ReturnValue_8;
	// System.Text.Json.JsonClassInfo System.Text.Json.ReadStackFrame::JsonClassInfo
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * ___JsonClassInfo_9;
	// System.Text.Json.StackFrameObjectState System.Text.Json.ReadStackFrame::ObjectState
	uint8_t ___ObjectState_10;
	// System.Boolean System.Text.Json.ReadStackFrame::ValidateEndTokenOnArray
	bool ___ValidateEndTokenOnArray_11;
	// System.Int32 System.Text.Json.ReadStackFrame::PropertyIndex
	int32_t ___PropertyIndex_12;
	// System.Collections.Generic.List`1<System.Text.Json.PropertyRef> System.Text.Json.ReadStackFrame::PropertyRefCache
	List_1_t86B6A92243885E5164DC45FD96099FE62E6A2E6A * ___PropertyRefCache_13;
	// System.Int32 System.Text.Json.ReadStackFrame::CtorArgumentStateIndex
	int32_t ___CtorArgumentStateIndex_14;
	// System.Text.Json.ArgumentState System.Text.Json.ReadStackFrame::CtorArgumentState
	ArgumentState_tB59BA647A734F800587B84B8F29F25FC38C93598 * ___CtorArgumentState_15;
	// System.Nullable`1<System.Text.Json.Serialization.JsonNumberHandling> System.Text.Json.ReadStackFrame::NumberHandling
	Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  ___NumberHandling_16;

public:
	inline static int32_t get_offset_of_JsonPropertyInfo_0() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___JsonPropertyInfo_0)); }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * get_JsonPropertyInfo_0() const { return ___JsonPropertyInfo_0; }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F ** get_address_of_JsonPropertyInfo_0() { return &___JsonPropertyInfo_0; }
	inline void set_JsonPropertyInfo_0(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * value)
	{
		___JsonPropertyInfo_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___JsonPropertyInfo_0), (void*)value);
	}

	inline static int32_t get_offset_of_PropertyState_1() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___PropertyState_1)); }
	inline uint8_t get_PropertyState_1() const { return ___PropertyState_1; }
	inline uint8_t* get_address_of_PropertyState_1() { return &___PropertyState_1; }
	inline void set_PropertyState_1(uint8_t value)
	{
		___PropertyState_1 = value;
	}

	inline static int32_t get_offset_of_UseExtensionProperty_2() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___UseExtensionProperty_2)); }
	inline bool get_UseExtensionProperty_2() const { return ___UseExtensionProperty_2; }
	inline bool* get_address_of_UseExtensionProperty_2() { return &___UseExtensionProperty_2; }
	inline void set_UseExtensionProperty_2(bool value)
	{
		___UseExtensionProperty_2 = value;
	}

	inline static int32_t get_offset_of_JsonPropertyName_3() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___JsonPropertyName_3)); }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* get_JsonPropertyName_3() const { return ___JsonPropertyName_3; }
	inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** get_address_of_JsonPropertyName_3() { return &___JsonPropertyName_3; }
	inline void set_JsonPropertyName_3(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* value)
	{
		___JsonPropertyName_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___JsonPropertyName_3), (void*)value);
	}

	inline static int32_t get_offset_of_JsonPropertyNameAsString_4() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___JsonPropertyNameAsString_4)); }
	inline String_t* get_JsonPropertyNameAsString_4() const { return ___JsonPropertyNameAsString_4; }
	inline String_t** get_address_of_JsonPropertyNameAsString_4() { return &___JsonPropertyNameAsString_4; }
	inline void set_JsonPropertyNameAsString_4(String_t* value)
	{
		___JsonPropertyNameAsString_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___JsonPropertyNameAsString_4), (void*)value);
	}

	inline static int32_t get_offset_of_DictionaryKey_5() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___DictionaryKey_5)); }
	inline RuntimeObject * get_DictionaryKey_5() const { return ___DictionaryKey_5; }
	inline RuntimeObject ** get_address_of_DictionaryKey_5() { return &___DictionaryKey_5; }
	inline void set_DictionaryKey_5(RuntimeObject * value)
	{
		___DictionaryKey_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___DictionaryKey_5), (void*)value);
	}

	inline static int32_t get_offset_of_OriginalDepth_6() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___OriginalDepth_6)); }
	inline int32_t get_OriginalDepth_6() const { return ___OriginalDepth_6; }
	inline int32_t* get_address_of_OriginalDepth_6() { return &___OriginalDepth_6; }
	inline void set_OriginalDepth_6(int32_t value)
	{
		___OriginalDepth_6 = value;
	}

	inline static int32_t get_offset_of_OriginalTokenType_7() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___OriginalTokenType_7)); }
	inline uint8_t get_OriginalTokenType_7() const { return ___OriginalTokenType_7; }
	inline uint8_t* get_address_of_OriginalTokenType_7() { return &___OriginalTokenType_7; }
	inline void set_OriginalTokenType_7(uint8_t value)
	{
		___OriginalTokenType_7 = value;
	}

	inline static int32_t get_offset_of_ReturnValue_8() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___ReturnValue_8)); }
	inline RuntimeObject * get_ReturnValue_8() const { return ___ReturnValue_8; }
	inline RuntimeObject ** get_address_of_ReturnValue_8() { return &___ReturnValue_8; }
	inline void set_ReturnValue_8(RuntimeObject * value)
	{
		___ReturnValue_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ReturnValue_8), (void*)value);
	}

	inline static int32_t get_offset_of_JsonClassInfo_9() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___JsonClassInfo_9)); }
	inline JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * get_JsonClassInfo_9() const { return ___JsonClassInfo_9; }
	inline JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 ** get_address_of_JsonClassInfo_9() { return &___JsonClassInfo_9; }
	inline void set_JsonClassInfo_9(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * value)
	{
		___JsonClassInfo_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___JsonClassInfo_9), (void*)value);
	}

	inline static int32_t get_offset_of_ObjectState_10() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___ObjectState_10)); }
	inline uint8_t get_ObjectState_10() const { return ___ObjectState_10; }
	inline uint8_t* get_address_of_ObjectState_10() { return &___ObjectState_10; }
	inline void set_ObjectState_10(uint8_t value)
	{
		___ObjectState_10 = value;
	}

	inline static int32_t get_offset_of_ValidateEndTokenOnArray_11() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___ValidateEndTokenOnArray_11)); }
	inline bool get_ValidateEndTokenOnArray_11() const { return ___ValidateEndTokenOnArray_11; }
	inline bool* get_address_of_ValidateEndTokenOnArray_11() { return &___ValidateEndTokenOnArray_11; }
	inline void set_ValidateEndTokenOnArray_11(bool value)
	{
		___ValidateEndTokenOnArray_11 = value;
	}

	inline static int32_t get_offset_of_PropertyIndex_12() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___PropertyIndex_12)); }
	inline int32_t get_PropertyIndex_12() const { return ___PropertyIndex_12; }
	inline int32_t* get_address_of_PropertyIndex_12() { return &___PropertyIndex_12; }
	inline void set_PropertyIndex_12(int32_t value)
	{
		___PropertyIndex_12 = value;
	}

	inline static int32_t get_offset_of_PropertyRefCache_13() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___PropertyRefCache_13)); }
	inline List_1_t86B6A92243885E5164DC45FD96099FE62E6A2E6A * get_PropertyRefCache_13() const { return ___PropertyRefCache_13; }
	inline List_1_t86B6A92243885E5164DC45FD96099FE62E6A2E6A ** get_address_of_PropertyRefCache_13() { return &___PropertyRefCache_13; }
	inline void set_PropertyRefCache_13(List_1_t86B6A92243885E5164DC45FD96099FE62E6A2E6A * value)
	{
		___PropertyRefCache_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PropertyRefCache_13), (void*)value);
	}

	inline static int32_t get_offset_of_CtorArgumentStateIndex_14() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___CtorArgumentStateIndex_14)); }
	inline int32_t get_CtorArgumentStateIndex_14() const { return ___CtorArgumentStateIndex_14; }
	inline int32_t* get_address_of_CtorArgumentStateIndex_14() { return &___CtorArgumentStateIndex_14; }
	inline void set_CtorArgumentStateIndex_14(int32_t value)
	{
		___CtorArgumentStateIndex_14 = value;
	}

	inline static int32_t get_offset_of_CtorArgumentState_15() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___CtorArgumentState_15)); }
	inline ArgumentState_tB59BA647A734F800587B84B8F29F25FC38C93598 * get_CtorArgumentState_15() const { return ___CtorArgumentState_15; }
	inline ArgumentState_tB59BA647A734F800587B84B8F29F25FC38C93598 ** get_address_of_CtorArgumentState_15() { return &___CtorArgumentState_15; }
	inline void set_CtorArgumentState_15(ArgumentState_tB59BA647A734F800587B84B8F29F25FC38C93598 * value)
	{
		___CtorArgumentState_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___CtorArgumentState_15), (void*)value);
	}

	inline static int32_t get_offset_of_NumberHandling_16() { return static_cast<int32_t>(offsetof(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756, ___NumberHandling_16)); }
	inline Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  get_NumberHandling_16() const { return ___NumberHandling_16; }
	inline Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58 * get_address_of_NumberHandling_16() { return &___NumberHandling_16; }
	inline void set_NumberHandling_16(Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  value)
	{
		___NumberHandling_16 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.ReadStackFrame
struct ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756_marshaled_pinvoke
{
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___JsonPropertyInfo_0;
	uint8_t ___PropertyState_1;
	int32_t ___UseExtensionProperty_2;
	Il2CppSafeArray/*NONE*/* ___JsonPropertyName_3;
	char* ___JsonPropertyNameAsString_4;
	Il2CppIUnknown* ___DictionaryKey_5;
	int32_t ___OriginalDepth_6;
	uint8_t ___OriginalTokenType_7;
	Il2CppIUnknown* ___ReturnValue_8;
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * ___JsonClassInfo_9;
	uint8_t ___ObjectState_10;
	int32_t ___ValidateEndTokenOnArray_11;
	int32_t ___PropertyIndex_12;
	List_1_t86B6A92243885E5164DC45FD96099FE62E6A2E6A * ___PropertyRefCache_13;
	int32_t ___CtorArgumentStateIndex_14;
	ArgumentState_tB59BA647A734F800587B84B8F29F25FC38C93598 * ___CtorArgumentState_15;
	Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  ___NumberHandling_16;
};
// Native definition for COM marshalling of System.Text.Json.ReadStackFrame
struct ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756_marshaled_com
{
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___JsonPropertyInfo_0;
	uint8_t ___PropertyState_1;
	int32_t ___UseExtensionProperty_2;
	Il2CppSafeArray/*NONE*/* ___JsonPropertyName_3;
	Il2CppChar* ___JsonPropertyNameAsString_4;
	Il2CppIUnknown* ___DictionaryKey_5;
	int32_t ___OriginalDepth_6;
	uint8_t ___OriginalTokenType_7;
	Il2CppIUnknown* ___ReturnValue_8;
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * ___JsonClassInfo_9;
	uint8_t ___ObjectState_10;
	int32_t ___ValidateEndTokenOnArray_11;
	int32_t ___PropertyIndex_12;
	List_1_t86B6A92243885E5164DC45FD96099FE62E6A2E6A * ___PropertyRefCache_13;
	int32_t ___CtorArgumentStateIndex_14;
	ArgumentState_tB59BA647A734F800587B84B8F29F25FC38C93598 * ___CtorArgumentState_15;
	Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  ___NumberHandling_16;
};

// System.Text.Json.WriteStackFrame
struct  WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 
{
public:
	// System.Collections.IEnumerator System.Text.Json.WriteStackFrame::CollectionEnumerator
	RuntimeObject* ___CollectionEnumerator_0;
	// System.Text.Json.JsonPropertyInfo System.Text.Json.WriteStackFrame::DeclaredJsonPropertyInfo
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___DeclaredJsonPropertyInfo_1;
	// System.Boolean System.Text.Json.WriteStackFrame::IgnoreDictionaryKeyPolicy
	bool ___IgnoreDictionaryKeyPolicy_2;
	// System.Text.Json.JsonClassInfo System.Text.Json.WriteStackFrame::JsonClassInfo
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * ___JsonClassInfo_3;
	// System.Int32 System.Text.Json.WriteStackFrame::OriginalDepth
	int32_t ___OriginalDepth_4;
	// System.Boolean System.Text.Json.WriteStackFrame::ProcessedStartToken
	bool ___ProcessedStartToken_5;
	// System.Boolean System.Text.Json.WriteStackFrame::ProcessedEndToken
	bool ___ProcessedEndToken_6;
	// System.Text.Json.StackFramePropertyState System.Text.Json.WriteStackFrame::PropertyState
	uint8_t ___PropertyState_7;
	// System.Int32 System.Text.Json.WriteStackFrame::EnumeratorIndex
	int32_t ___EnumeratorIndex_8;
	// System.String System.Text.Json.WriteStackFrame::JsonPropertyNameAsString
	String_t* ___JsonPropertyNameAsString_9;
	// System.Text.Json.MetadataPropertyName System.Text.Json.WriteStackFrame::MetadataPropertyName
	int32_t ___MetadataPropertyName_10;
	// System.Text.Json.JsonPropertyInfo System.Text.Json.WriteStackFrame::PolymorphicJsonPropertyInfo
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___PolymorphicJsonPropertyInfo_11;
	// System.Nullable`1<System.Text.Json.Serialization.JsonNumberHandling> System.Text.Json.WriteStackFrame::NumberHandling
	Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  ___NumberHandling_12;

public:
	inline static int32_t get_offset_of_CollectionEnumerator_0() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___CollectionEnumerator_0)); }
	inline RuntimeObject* get_CollectionEnumerator_0() const { return ___CollectionEnumerator_0; }
	inline RuntimeObject** get_address_of_CollectionEnumerator_0() { return &___CollectionEnumerator_0; }
	inline void set_CollectionEnumerator_0(RuntimeObject* value)
	{
		___CollectionEnumerator_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___CollectionEnumerator_0), (void*)value);
	}

	inline static int32_t get_offset_of_DeclaredJsonPropertyInfo_1() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___DeclaredJsonPropertyInfo_1)); }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * get_DeclaredJsonPropertyInfo_1() const { return ___DeclaredJsonPropertyInfo_1; }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F ** get_address_of_DeclaredJsonPropertyInfo_1() { return &___DeclaredJsonPropertyInfo_1; }
	inline void set_DeclaredJsonPropertyInfo_1(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * value)
	{
		___DeclaredJsonPropertyInfo_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___DeclaredJsonPropertyInfo_1), (void*)value);
	}

	inline static int32_t get_offset_of_IgnoreDictionaryKeyPolicy_2() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___IgnoreDictionaryKeyPolicy_2)); }
	inline bool get_IgnoreDictionaryKeyPolicy_2() const { return ___IgnoreDictionaryKeyPolicy_2; }
	inline bool* get_address_of_IgnoreDictionaryKeyPolicy_2() { return &___IgnoreDictionaryKeyPolicy_2; }
	inline void set_IgnoreDictionaryKeyPolicy_2(bool value)
	{
		___IgnoreDictionaryKeyPolicy_2 = value;
	}

	inline static int32_t get_offset_of_JsonClassInfo_3() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___JsonClassInfo_3)); }
	inline JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * get_JsonClassInfo_3() const { return ___JsonClassInfo_3; }
	inline JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 ** get_address_of_JsonClassInfo_3() { return &___JsonClassInfo_3; }
	inline void set_JsonClassInfo_3(JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * value)
	{
		___JsonClassInfo_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___JsonClassInfo_3), (void*)value);
	}

	inline static int32_t get_offset_of_OriginalDepth_4() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___OriginalDepth_4)); }
	inline int32_t get_OriginalDepth_4() const { return ___OriginalDepth_4; }
	inline int32_t* get_address_of_OriginalDepth_4() { return &___OriginalDepth_4; }
	inline void set_OriginalDepth_4(int32_t value)
	{
		___OriginalDepth_4 = value;
	}

	inline static int32_t get_offset_of_ProcessedStartToken_5() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___ProcessedStartToken_5)); }
	inline bool get_ProcessedStartToken_5() const { return ___ProcessedStartToken_5; }
	inline bool* get_address_of_ProcessedStartToken_5() { return &___ProcessedStartToken_5; }
	inline void set_ProcessedStartToken_5(bool value)
	{
		___ProcessedStartToken_5 = value;
	}

	inline static int32_t get_offset_of_ProcessedEndToken_6() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___ProcessedEndToken_6)); }
	inline bool get_ProcessedEndToken_6() const { return ___ProcessedEndToken_6; }
	inline bool* get_address_of_ProcessedEndToken_6() { return &___ProcessedEndToken_6; }
	inline void set_ProcessedEndToken_6(bool value)
	{
		___ProcessedEndToken_6 = value;
	}

	inline static int32_t get_offset_of_PropertyState_7() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___PropertyState_7)); }
	inline uint8_t get_PropertyState_7() const { return ___PropertyState_7; }
	inline uint8_t* get_address_of_PropertyState_7() { return &___PropertyState_7; }
	inline void set_PropertyState_7(uint8_t value)
	{
		___PropertyState_7 = value;
	}

	inline static int32_t get_offset_of_EnumeratorIndex_8() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___EnumeratorIndex_8)); }
	inline int32_t get_EnumeratorIndex_8() const { return ___EnumeratorIndex_8; }
	inline int32_t* get_address_of_EnumeratorIndex_8() { return &___EnumeratorIndex_8; }
	inline void set_EnumeratorIndex_8(int32_t value)
	{
		___EnumeratorIndex_8 = value;
	}

	inline static int32_t get_offset_of_JsonPropertyNameAsString_9() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___JsonPropertyNameAsString_9)); }
	inline String_t* get_JsonPropertyNameAsString_9() const { return ___JsonPropertyNameAsString_9; }
	inline String_t** get_address_of_JsonPropertyNameAsString_9() { return &___JsonPropertyNameAsString_9; }
	inline void set_JsonPropertyNameAsString_9(String_t* value)
	{
		___JsonPropertyNameAsString_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___JsonPropertyNameAsString_9), (void*)value);
	}

	inline static int32_t get_offset_of_MetadataPropertyName_10() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___MetadataPropertyName_10)); }
	inline int32_t get_MetadataPropertyName_10() const { return ___MetadataPropertyName_10; }
	inline int32_t* get_address_of_MetadataPropertyName_10() { return &___MetadataPropertyName_10; }
	inline void set_MetadataPropertyName_10(int32_t value)
	{
		___MetadataPropertyName_10 = value;
	}

	inline static int32_t get_offset_of_PolymorphicJsonPropertyInfo_11() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___PolymorphicJsonPropertyInfo_11)); }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * get_PolymorphicJsonPropertyInfo_11() const { return ___PolymorphicJsonPropertyInfo_11; }
	inline JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F ** get_address_of_PolymorphicJsonPropertyInfo_11() { return &___PolymorphicJsonPropertyInfo_11; }
	inline void set_PolymorphicJsonPropertyInfo_11(JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * value)
	{
		___PolymorphicJsonPropertyInfo_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PolymorphicJsonPropertyInfo_11), (void*)value);
	}

	inline static int32_t get_offset_of_NumberHandling_12() { return static_cast<int32_t>(offsetof(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9, ___NumberHandling_12)); }
	inline Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  get_NumberHandling_12() const { return ___NumberHandling_12; }
	inline Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58 * get_address_of_NumberHandling_12() { return &___NumberHandling_12; }
	inline void set_NumberHandling_12(Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  value)
	{
		___NumberHandling_12 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.WriteStackFrame
struct WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_pinvoke
{
	RuntimeObject* ___CollectionEnumerator_0;
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___DeclaredJsonPropertyInfo_1;
	int32_t ___IgnoreDictionaryKeyPolicy_2;
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * ___JsonClassInfo_3;
	int32_t ___OriginalDepth_4;
	int32_t ___ProcessedStartToken_5;
	int32_t ___ProcessedEndToken_6;
	uint8_t ___PropertyState_7;
	int32_t ___EnumeratorIndex_8;
	char* ___JsonPropertyNameAsString_9;
	int32_t ___MetadataPropertyName_10;
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___PolymorphicJsonPropertyInfo_11;
	Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  ___NumberHandling_12;
};
// Native definition for COM marshalling of System.Text.Json.WriteStackFrame
struct WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_com
{
	RuntimeObject* ___CollectionEnumerator_0;
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___DeclaredJsonPropertyInfo_1;
	int32_t ___IgnoreDictionaryKeyPolicy_2;
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * ___JsonClassInfo_3;
	int32_t ___OriginalDepth_4;
	int32_t ___ProcessedStartToken_5;
	int32_t ___ProcessedEndToken_6;
	uint8_t ___PropertyState_7;
	int32_t ___EnumeratorIndex_8;
	Il2CppChar* ___JsonPropertyNameAsString_9;
	int32_t ___MetadataPropertyName_10;
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___PolymorphicJsonPropertyInfo_11;
	Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  ___NumberHandling_12;
};

// System.Text.Json.JsonClassInfo/ConstructorDelegate
struct  ConstructorDelegate_t78F14D99A470B7AECB5D508869D8A4D62D40D0C0  : public MulticastDelegate_t
{
public:

public:
};


// System.Text.Json.JsonDocument/<ParseAsyncCore>d__57
struct  U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 
{
public:
	// System.Int32 System.Text.Json.JsonDocument/<ParseAsyncCore>d__57::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Text.Json.JsonDocument> System.Text.Json.JsonDocument/<ParseAsyncCore>d__57::<>t__builder
	AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445  ___U3CU3Et__builder_1;
	// System.IO.Stream System.Text.Json.JsonDocument/<ParseAsyncCore>d__57::utf8Json
	Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * ___utf8Json_2;
	// System.Threading.CancellationToken System.Text.Json.JsonDocument/<ParseAsyncCore>d__57::cancellationToken
	CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  ___cancellationToken_3;
	// System.Text.Json.JsonDocumentOptions System.Text.Json.JsonDocument/<ParseAsyncCore>d__57::options
	JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675  ___options_4;
	// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.ArraySegment`1<System.Byte>> System.Text.Json.JsonDocument/<ParseAsyncCore>d__57::<>u__1
	ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  ___U3CU3Eu__1_5;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Et__builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_utf8Json_2() { return static_cast<int32_t>(offsetof(U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335, ___utf8Json_2)); }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * get_utf8Json_2() const { return ___utf8Json_2; }
	inline Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB ** get_address_of_utf8Json_2() { return &___utf8Json_2; }
	inline void set_utf8Json_2(Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * value)
	{
		___utf8Json_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___utf8Json_2), (void*)value);
	}

	inline static int32_t get_offset_of_cancellationToken_3() { return static_cast<int32_t>(offsetof(U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335, ___cancellationToken_3)); }
	inline CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  get_cancellationToken_3() const { return ___cancellationToken_3; }
	inline CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD * get_address_of_cancellationToken_3() { return &___cancellationToken_3; }
	inline void set_cancellationToken_3(CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  value)
	{
		___cancellationToken_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___cancellationToken_3))->___m_source_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_options_4() { return static_cast<int32_t>(offsetof(U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335, ___options_4)); }
	inline JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675  get_options_4() const { return ___options_4; }
	inline JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675 * get_address_of_options_4() { return &___options_4; }
	inline void set_options_4(JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675  value)
	{
		___options_4 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_5() { return static_cast<int32_t>(offsetof(U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335, ___U3CU3Eu__1_5)); }
	inline ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  get_U3CU3Eu__1_5() const { return ___U3CU3Eu__1_5; }
	inline ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C * get_address_of_U3CU3Eu__1_5() { return &___U3CU3Eu__1_5; }
	inline void set_U3CU3Eu__1_5(ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  value)
	{
		___U3CU3Eu__1_5 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_5))->___m_task_0), (void*)NULL);
	}
};


// System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36
struct  U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 
{
public:
	// System.Int32 System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36::<>t__builder
	AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B  ___U3CU3Et__builder_1;
	// System.Text.Json.Utf8JsonWriter System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36::<>4__this
	Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * ___U3CU3E4__this_2;
	// System.Threading.CancellationToken System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36::cancellationToken
	CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  ___cancellationToken_3;
	// System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36::<>u__1
	ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  ___U3CU3Eu__1_4;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80, ___U3CU3E4__this_2)); }
	inline Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_cancellationToken_3() { return static_cast<int32_t>(offsetof(U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80, ___cancellationToken_3)); }
	inline CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  get_cancellationToken_3() const { return ___cancellationToken_3; }
	inline CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD * get_address_of_cancellationToken_3() { return &___cancellationToken_3; }
	inline void set_cancellationToken_3(CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  value)
	{
		___cancellationToken_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___cancellationToken_3))->___m_source_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_4() { return static_cast<int32_t>(offsetof(U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80, ___U3CU3Eu__1_4)); }
	inline ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  get_U3CU3Eu__1_4() const { return ___U3CU3Eu__1_4; }
	inline ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * get_address_of_U3CU3Eu__1_4() { return &___U3CU3Eu__1_4; }
	inline void set_U3CU3Eu__1_4(ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  value)
	{
		___U3CU3Eu__1_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_4))->___m_task_0), (void*)NULL);
	}
};


// System.Text.Json.ReadStack
struct  ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E 
{
public:
	// System.Int32 System.Text.Json.ReadStack::_continuationCount
	int32_t ____continuationCount_1;
	// System.Int32 System.Text.Json.ReadStack::_count
	int32_t ____count_2;
	// System.Collections.Generic.List`1<System.Text.Json.ReadStackFrame> System.Text.Json.ReadStack::_previous
	List_1_t0E88177B9B829151BC738AFB4713B271CA5BD8CA * ____previous_3;
	// System.Collections.Generic.List`1<System.Text.Json.ArgumentState> System.Text.Json.ReadStack::_ctorArgStateCache
	List_1_tC675C6A551AE56FA932D68D31DEC8E811CD23FC7 * ____ctorArgStateCache_4;
	// System.Int64 System.Text.Json.ReadStack::BytesConsumed
	int64_t ___BytesConsumed_5;
	// System.Text.Json.ReadStackFrame System.Text.Json.ReadStack::Current
	ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756  ___Current_6;
	// System.Boolean System.Text.Json.ReadStack::ReadAhead
	bool ___ReadAhead_7;
	// System.Text.Json.Serialization.ReferenceResolver System.Text.Json.ReadStack::ReferenceResolver
	ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * ___ReferenceResolver_8;
	// System.Boolean System.Text.Json.ReadStack::SupportContinuation
	bool ___SupportContinuation_9;
	// System.Boolean System.Text.Json.ReadStack::UseFastPath
	bool ___UseFastPath_10;

public:
	inline static int32_t get_offset_of__continuationCount_1() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E, ____continuationCount_1)); }
	inline int32_t get__continuationCount_1() const { return ____continuationCount_1; }
	inline int32_t* get_address_of__continuationCount_1() { return &____continuationCount_1; }
	inline void set__continuationCount_1(int32_t value)
	{
		____continuationCount_1 = value;
	}

	inline static int32_t get_offset_of__count_2() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E, ____count_2)); }
	inline int32_t get__count_2() const { return ____count_2; }
	inline int32_t* get_address_of__count_2() { return &____count_2; }
	inline void set__count_2(int32_t value)
	{
		____count_2 = value;
	}

	inline static int32_t get_offset_of__previous_3() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E, ____previous_3)); }
	inline List_1_t0E88177B9B829151BC738AFB4713B271CA5BD8CA * get__previous_3() const { return ____previous_3; }
	inline List_1_t0E88177B9B829151BC738AFB4713B271CA5BD8CA ** get_address_of__previous_3() { return &____previous_3; }
	inline void set__previous_3(List_1_t0E88177B9B829151BC738AFB4713B271CA5BD8CA * value)
	{
		____previous_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____previous_3), (void*)value);
	}

	inline static int32_t get_offset_of__ctorArgStateCache_4() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E, ____ctorArgStateCache_4)); }
	inline List_1_tC675C6A551AE56FA932D68D31DEC8E811CD23FC7 * get__ctorArgStateCache_4() const { return ____ctorArgStateCache_4; }
	inline List_1_tC675C6A551AE56FA932D68D31DEC8E811CD23FC7 ** get_address_of__ctorArgStateCache_4() { return &____ctorArgStateCache_4; }
	inline void set__ctorArgStateCache_4(List_1_tC675C6A551AE56FA932D68D31DEC8E811CD23FC7 * value)
	{
		____ctorArgStateCache_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____ctorArgStateCache_4), (void*)value);
	}

	inline static int32_t get_offset_of_BytesConsumed_5() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E, ___BytesConsumed_5)); }
	inline int64_t get_BytesConsumed_5() const { return ___BytesConsumed_5; }
	inline int64_t* get_address_of_BytesConsumed_5() { return &___BytesConsumed_5; }
	inline void set_BytesConsumed_5(int64_t value)
	{
		___BytesConsumed_5 = value;
	}

	inline static int32_t get_offset_of_Current_6() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E, ___Current_6)); }
	inline ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756  get_Current_6() const { return ___Current_6; }
	inline ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756 * get_address_of_Current_6() { return &___Current_6; }
	inline void set_Current_6(ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756  value)
	{
		___Current_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_6))->___JsonPropertyInfo_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_6))->___JsonPropertyName_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_6))->___JsonPropertyNameAsString_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_6))->___DictionaryKey_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_6))->___ReturnValue_8), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_6))->___JsonClassInfo_9), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_6))->___PropertyRefCache_13), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_6))->___CtorArgumentState_15), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_ReadAhead_7() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E, ___ReadAhead_7)); }
	inline bool get_ReadAhead_7() const { return ___ReadAhead_7; }
	inline bool* get_address_of_ReadAhead_7() { return &___ReadAhead_7; }
	inline void set_ReadAhead_7(bool value)
	{
		___ReadAhead_7 = value;
	}

	inline static int32_t get_offset_of_ReferenceResolver_8() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E, ___ReferenceResolver_8)); }
	inline ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * get_ReferenceResolver_8() const { return ___ReferenceResolver_8; }
	inline ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 ** get_address_of_ReferenceResolver_8() { return &___ReferenceResolver_8; }
	inline void set_ReferenceResolver_8(ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * value)
	{
		___ReferenceResolver_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ReferenceResolver_8), (void*)value);
	}

	inline static int32_t get_offset_of_SupportContinuation_9() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E, ___SupportContinuation_9)); }
	inline bool get_SupportContinuation_9() const { return ___SupportContinuation_9; }
	inline bool* get_address_of_SupportContinuation_9() { return &___SupportContinuation_9; }
	inline void set_SupportContinuation_9(bool value)
	{
		___SupportContinuation_9 = value;
	}

	inline static int32_t get_offset_of_UseFastPath_10() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E, ___UseFastPath_10)); }
	inline bool get_UseFastPath_10() const { return ___UseFastPath_10; }
	inline bool* get_address_of_UseFastPath_10() { return &___UseFastPath_10; }
	inline void set_UseFastPath_10(bool value)
	{
		___UseFastPath_10 = value;
	}
};

struct ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E_StaticFields
{
public:
	// System.Char[] System.Text.Json.ReadStack::SpecialCharacters
	CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___SpecialCharacters_0;

public:
	inline static int32_t get_offset_of_SpecialCharacters_0() { return static_cast<int32_t>(offsetof(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E_StaticFields, ___SpecialCharacters_0)); }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* get_SpecialCharacters_0() const { return ___SpecialCharacters_0; }
	inline CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34** get_address_of_SpecialCharacters_0() { return &___SpecialCharacters_0; }
	inline void set_SpecialCharacters_0(CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* value)
	{
		___SpecialCharacters_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___SpecialCharacters_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.ReadStack
struct ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E_marshaled_pinvoke
{
	int32_t ____continuationCount_1;
	int32_t ____count_2;
	List_1_t0E88177B9B829151BC738AFB4713B271CA5BD8CA * ____previous_3;
	List_1_tC675C6A551AE56FA932D68D31DEC8E811CD23FC7 * ____ctorArgStateCache_4;
	int64_t ___BytesConsumed_5;
	ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756_marshaled_pinvoke ___Current_6;
	int32_t ___ReadAhead_7;
	ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * ___ReferenceResolver_8;
	int32_t ___SupportContinuation_9;
	int32_t ___UseFastPath_10;
};
// Native definition for COM marshalling of System.Text.Json.ReadStack
struct ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E_marshaled_com
{
	int32_t ____continuationCount_1;
	int32_t ____count_2;
	List_1_t0E88177B9B829151BC738AFB4713B271CA5BD8CA * ____previous_3;
	List_1_tC675C6A551AE56FA932D68D31DEC8E811CD23FC7 * ____ctorArgStateCache_4;
	int64_t ___BytesConsumed_5;
	ReadStackFrame_t35BBF02D5EACDF26EE823E40A647ED5DBE8B1756_marshaled_com ___Current_6;
	int32_t ___ReadAhead_7;
	ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * ___ReferenceResolver_8;
	int32_t ___SupportContinuation_9;
	int32_t ___UseFastPath_10;
};

// System.Text.Json.WriteStack
struct  WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 
{
public:
	// System.Int32 System.Text.Json.WriteStack::_continuationCount
	int32_t ____continuationCount_0;
	// System.Int32 System.Text.Json.WriteStack::_count
	int32_t ____count_1;
	// System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame> System.Text.Json.WriteStack::_previous
	List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * ____previous_2;
	// System.Text.Json.WriteStackFrame System.Text.Json.WriteStack::Current
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  ___Current_3;
	// System.Int32 System.Text.Json.WriteStack::FlushThreshold
	int32_t ___FlushThreshold_4;
	// System.Text.Json.Serialization.ReferenceResolver System.Text.Json.WriteStack::ReferenceResolver
	ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * ___ReferenceResolver_5;
	// System.Boolean System.Text.Json.WriteStack::SupportContinuation
	bool ___SupportContinuation_6;

public:
	inline static int32_t get_offset_of__continuationCount_0() { return static_cast<int32_t>(offsetof(WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30, ____continuationCount_0)); }
	inline int32_t get__continuationCount_0() const { return ____continuationCount_0; }
	inline int32_t* get_address_of__continuationCount_0() { return &____continuationCount_0; }
	inline void set__continuationCount_0(int32_t value)
	{
		____continuationCount_0 = value;
	}

	inline static int32_t get_offset_of__count_1() { return static_cast<int32_t>(offsetof(WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30, ____count_1)); }
	inline int32_t get__count_1() const { return ____count_1; }
	inline int32_t* get_address_of__count_1() { return &____count_1; }
	inline void set__count_1(int32_t value)
	{
		____count_1 = value;
	}

	inline static int32_t get_offset_of__previous_2() { return static_cast<int32_t>(offsetof(WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30, ____previous_2)); }
	inline List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * get__previous_2() const { return ____previous_2; }
	inline List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 ** get_address_of__previous_2() { return &____previous_2; }
	inline void set__previous_2(List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * value)
	{
		____previous_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____previous_2), (void*)value);
	}

	inline static int32_t get_offset_of_Current_3() { return static_cast<int32_t>(offsetof(WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30, ___Current_3)); }
	inline WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  get_Current_3() const { return ___Current_3; }
	inline WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * get_address_of_Current_3() { return &___Current_3; }
	inline void set_Current_3(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  value)
	{
		___Current_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_3))->___CollectionEnumerator_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_3))->___DeclaredJsonPropertyInfo_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_3))->___JsonClassInfo_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_3))->___JsonPropertyNameAsString_9), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___Current_3))->___PolymorphicJsonPropertyInfo_11), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_FlushThreshold_4() { return static_cast<int32_t>(offsetof(WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30, ___FlushThreshold_4)); }
	inline int32_t get_FlushThreshold_4() const { return ___FlushThreshold_4; }
	inline int32_t* get_address_of_FlushThreshold_4() { return &___FlushThreshold_4; }
	inline void set_FlushThreshold_4(int32_t value)
	{
		___FlushThreshold_4 = value;
	}

	inline static int32_t get_offset_of_ReferenceResolver_5() { return static_cast<int32_t>(offsetof(WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30, ___ReferenceResolver_5)); }
	inline ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * get_ReferenceResolver_5() const { return ___ReferenceResolver_5; }
	inline ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 ** get_address_of_ReferenceResolver_5() { return &___ReferenceResolver_5; }
	inline void set_ReferenceResolver_5(ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * value)
	{
		___ReferenceResolver_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ReferenceResolver_5), (void*)value);
	}

	inline static int32_t get_offset_of_SupportContinuation_6() { return static_cast<int32_t>(offsetof(WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30, ___SupportContinuation_6)); }
	inline bool get_SupportContinuation_6() const { return ___SupportContinuation_6; }
	inline bool* get_address_of_SupportContinuation_6() { return &___SupportContinuation_6; }
	inline void set_SupportContinuation_6(bool value)
	{
		___SupportContinuation_6 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Text.Json.WriteStack
struct WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshaled_pinvoke
{
	int32_t ____continuationCount_0;
	int32_t ____count_1;
	List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * ____previous_2;
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_pinvoke ___Current_3;
	int32_t ___FlushThreshold_4;
	ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * ___ReferenceResolver_5;
	int32_t ___SupportContinuation_6;
};
// Native definition for COM marshalling of System.Text.Json.WriteStack
struct WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshaled_com
{
	int32_t ____continuationCount_0;
	int32_t ____count_1;
	List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * ____previous_2;
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_com ___Current_3;
	int32_t ___FlushThreshold_4;
	ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * ___ReferenceResolver_5;
	int32_t ___SupportContinuation_6;
};

// System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35
struct  U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 
{
public:
	// System.Int32 System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35::<>t__builder
	AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8  ___U3CU3Et__builder_1;
	// System.Text.Json.Utf8JsonWriter System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35::<>4__this
	Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * ___U3CU3E4__this_2;
	// System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35::<>u__1
	ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  ___U3CU3Eu__1_3;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8, ___U3CU3Et__builder_1)); }
	inline AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&((&(((&___U3CU3Et__builder_1))->____methodBuilder_0))->___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&((&(((&___U3CU3Et__builder_1))->____methodBuilder_0))->___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->____methodBuilder_0))->___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8, ___U3CU3E4__this_2)); }
	inline Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_3() { return static_cast<int32_t>(offsetof(U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8, ___U3CU3Eu__1_3)); }
	inline ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  get_U3CU3Eu__1_3() const { return ___U3CU3Eu__1_3; }
	inline ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * get_address_of_U3CU3Eu__1_3() { return &___U3CU3Eu__1_3; }
	inline void set_U3CU3Eu__1_3(ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  value)
	{
		___U3CU3Eu__1_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_3))->___m_task_0), (void*)NULL);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// System.Char[]
struct CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Il2CppChar m_Items[1];

public:
	inline Il2CppChar GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Il2CppChar* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Il2CppChar value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline Il2CppChar GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Il2CppChar* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Il2CppChar value)
	{
		m_Items[index] = value;
	}
};
// System.Delegate[]
struct DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Delegate_t * m_Items[1];

public:
	inline Delegate_t * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Delegate_t ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Delegate_t * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Delegate_t * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Delegate_t ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Delegate_t * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// System.Byte[]
struct ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) uint8_t m_Items[1];

public:
	inline uint8_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline uint8_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, uint8_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline uint8_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline uint8_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, uint8_t value)
	{
		m_Items[index] = value;
	}
};
// System.Text.Json.WriteStackFrame[]
struct WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  m_Items[1];

public:
	inline WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___CollectionEnumerator_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___DeclaredJsonPropertyInfo_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___JsonClassInfo_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___JsonPropertyNameAsString_9), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___PolymorphicJsonPropertyInfo_11), (void*)NULL);
		#endif
	}
	inline WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___CollectionEnumerator_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___DeclaredJsonPropertyInfo_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___JsonClassInfo_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___JsonPropertyNameAsString_9), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___PolymorphicJsonPropertyInfo_11), (void*)NULL);
		#endif
	}
};

IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_pinvoke(const WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9& unmarshaled, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_pinvoke_back(const WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_pinvoke& marshaled, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9& unmarshaled);
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_pinvoke_cleanup(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_com(const WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9& unmarshaled, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_com& marshaled);
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_com_back(const WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_com& marshaled, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9& unmarshaled);
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_com_cleanup(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_com& marshaled);
IL2CPP_EXTERN_C void JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshal_pinvoke(const JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49& unmarshaled, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshal_pinvoke_back(const JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_pinvoke& marshaled, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49& unmarshaled);
IL2CPP_EXTERN_C void JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshal_pinvoke_cleanup(JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshal_com(const JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49& unmarshaled, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_com& marshaled);
IL2CPP_EXTERN_C void JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshal_com_back(const JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_com& marshaled, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49& unmarshaled);
IL2CPP_EXTERN_C void JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshal_com_cleanup(JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_marshaled_com& marshaled);
IL2CPP_EXTERN_C void SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_pinvoke(const SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A& unmarshaled, SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_pinvoke_back(const SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_pinvoke& marshaled, SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A& unmarshaled);
IL2CPP_EXTERN_C void SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_pinvoke_cleanup(SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_pinvoke& marshaled);
IL2CPP_EXTERN_C void SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_com(const SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A& unmarshaled, SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_com& marshaled);
IL2CPP_EXTERN_C void SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_com_back(const SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_com& marshaled, SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A& unmarshaled);
IL2CPP_EXTERN_C void SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_com_cleanup(SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshaled_com& marshaled);

// System.Void System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_mA95BD97532A917EFABAEB51DDE1649AF93AA28DF_gshared (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>::get_Count()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_mAF5A5D24EE6E3206F64DF2764D69FE6EEDB40E90_gshared_inline (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>::Add(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_Add_mF57A675DC30E3A30C75C7B19903BB3AB771AA743_gshared (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  ___item0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>::set_Item(System.Int32,!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_set_Item_mAF32960D79EBF6119BA8C7632444CFD38AC1DF75_gshared (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, int32_t ___index0, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  ___value1, const RuntimeMethod* method);
// System.Boolean System.Nullable`1<System.Int32Enum>::get_HasValue()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Nullable_1_get_HasValue_m4C033F49F5318E94BC8CBA9CE5175EFDBFADEF9C_gshared_inline (Nullable_1_t64244F99361E39CBE565C5E89436C898F18DF5DC * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>::get_Item(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_gshared_inline (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, int32_t ___index0, const RuntimeMethod* method);
// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<!0> System.Threading.Tasks.Task`1<System.ArraySegment`1<System.Byte>>::ConfigureAwait(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8  Task_1_ConfigureAwait_m0E2430C409BCD2B226EA4AC94C8DA1D8534513C7_gshared (Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * __this, bool ___continueOnCapturedContext0, const RuntimeMethod* method);
// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<!0> System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<System.ArraySegment`1<System.Byte>>::GetAwaiter()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  ConfiguredTaskAwaitable_1_GetAwaiter_m80F1877E5304C1EB51E7F1E92D2C4CA3A9A3AC6D_gshared_inline (ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8 * __this, const RuntimeMethod* method);
// System.Boolean System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.ArraySegment`1<System.Byte>>::get_IsCompleted()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ConfiguredTaskAwaiter_get_IsCompleted_m2D230F04D69897DAD535B96F5F4581467DDDE0D8_gshared (ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.ArraySegment`1<System.Byte>>,System.Text.Json.JsonDocument/<ParseAsyncCore>d__57>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C_TisU3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335_mE9AAF8AA713F4CB5F6237BFB678C7F848F01B188_gshared (AsyncTaskMethodBuilder_1_tDD2A3BA099C327938EA03C35FDB1A7502BA73020 * __this, ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C * ___awaiter0, U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 * ___stateMachine1, const RuntimeMethod* method);
// !0 System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.ArraySegment`1<System.Byte>>::GetResult()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  ConfiguredTaskAwaiter_GetResult_mC723D4CAC0FFD2CB0AF9749A899E22F31CE1B8F6_gshared (ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C * __this, const RuntimeMethod* method);
// System.Memory`1<!!0> System.MemoryExtensions::AsMemory<System.Byte>(System.ArraySegment`1<!!0>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9  MemoryExtensions_AsMemory_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m200D8CCE4E809AF8284BAF03FA13482EE5B0D282_gshared (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  ___segment0, const RuntimeMethod* method);
// System.ReadOnlyMemory`1<!0> System.Memory`1<System.Byte>::op_Implicit(System.Memory`1<!0>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  Memory_1_op_Implicit_mE940358A7E5B8CF728319481BB9080A44E2D914F_gshared (Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9  ___memory0, const RuntimeMethod* method);
// !0[] System.ArraySegment`1<System.Byte>::get_Array()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_gshared_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, const RuntimeMethod* method);
// System.Span`1<!!0> System.MemoryExtensions::AsSpan<System.Byte>(System.ArraySegment`1<!!0>)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mD932D4A4EC20A3549450351374B5D165258B0C91_gshared_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  ___segment0, const RuntimeMethod* method);
// System.Void System.Span`1<System.Byte>::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Span_1_Clear_mCD3767C2F151B946E3EEB3AD9CCD8EE0794F689C_gshared (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, const RuntimeMethod* method);
// System.Buffers.ArrayPool`1<!0> System.Buffers.ArrayPool`1<System.Byte>::get_Shared()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_gshared_inline (const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::SetException(System.Exception)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetException_m29521EB618E38AF72FF0C4094070C1489F4129B3_gshared (AsyncTaskMethodBuilder_1_tDD2A3BA099C327938EA03C35FDB1A7502BA73020 * __this, Exception_t * ___exception0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::SetResult(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetResult_m3E4AB12877D4FE377F26708CF6899C49360007FA_gshared (AsyncTaskMethodBuilder_1_tDD2A3BA099C327938EA03C35FDB1A7502BA73020 * __this, RuntimeObject * ___result0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetStateMachine_m736C84D61B4AB2FCD150BD3945C6874471A9224D_gshared (AsyncTaskMethodBuilder_1_tDD2A3BA099C327938EA03C35FDB1A7502BA73020 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Int32 System.ReadOnlySpan`1<System.Byte>::get_Length()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 * __this, const RuntimeMethod* method);
// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<!0> System.Threading.Tasks.Task`1<System.Int32>::ConfigureAwait(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC  Task_1_ConfigureAwait_m9637E2990F98EDC90D1A03B57A4954CE2171C4E2_gshared (Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 * __this, bool ___continueOnCapturedContext0, const RuntimeMethod* method);
// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<!0> System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<System.Int32>::GetAwaiter()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  ConfiguredTaskAwaitable_1_GetAwaiter_m8FA39505FC2099C60148C0F029CB49792690A0D5_gshared_inline (ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC * __this, const RuntimeMethod* method);
// System.Boolean System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.Int32>::get_IsCompleted()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ConfiguredTaskAwaiter_get_IsCompleted_m4192DC0E89B48FF93421FFF4EB52C21C42687999_gshared (ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.ArraySegment`1<System.Byte>>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.Int32>,System.Text.Json.JsonDocument/<ReadToEndAsync>d__65>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2_TisU3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B_m179843A0565EF49F48ABDF6635C3E041743C36B9_gshared (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * __this, ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 * ___awaiter0, U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B * ___stateMachine1, const RuntimeMethod* method);
// !0 System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.Int32>::GetResult()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ConfiguredTaskAwaiter_GetResult_m0927E49E03619C51620F396FE1DD5DBD41AC6681_gshared (ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 * __this, const RuntimeMethod* method);
// System.Span`1<!!0> System.MemoryExtensions::AsSpan<System.Byte>(!!0[],System.Int32,System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_gshared_inline (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, int32_t ___start1, int32_t ___length2, const RuntimeMethod* method);
// System.ReadOnlySpan`1<!0> System.Span`1<System.Byte>::op_Implicit(System.Span`1<!0>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_gshared (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___span0, const RuntimeMethod* method);
// System.Boolean System.MemoryExtensions::SequenceEqual<System.Byte>(System.ReadOnlySpan`1<!!0>,System.ReadOnlySpan`1<!!0>)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool MemoryExtensions_SequenceEqual_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mA47AE57649F12A2400FE13BDC84254F05A99D1AA_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___span0, ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___other1, const RuntimeMethod* method);
// System.Void System.ArraySegment`1<System.Byte>::.ctor(!0[],System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArraySegment_1__ctor_mAA780E22BB5AE07078510EDCE524DD1EA1E98E0D_gshared (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, int32_t ___offset1, int32_t ___count2, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.ArraySegment`1<System.Byte>>::SetException(System.Exception)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetException_m9AEB12146F99A1F4E8F8992A49A6C3BC57AB5EBD_gshared (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * __this, Exception_t * ___exception0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.ArraySegment`1<System.Byte>>::SetResult(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetResult_mB6426AE79AFDC2DCFDFD3F2CB765EA12494D7819_gshared (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * __this, ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  ___result0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.ArraySegment`1<System.Byte>>::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetStateMachine_m57FFFD41160014C16C21B3A3F4B9902B587CAE25_gshared (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Span`1<!0> System.Span`1<System.Byte>::op_Implicit(!0[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4_gshared (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, const RuntimeMethod* method);
// System.Void System.Span`1<System.Byte>::CopyTo(System.Span`1<!0>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Span_1_CopyTo_m78B5163997318B736E1238622FCBC09953798836_gshared (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, const RuntimeMethod* method);
// !0[] System.Span`1<System.Byte>::ToArray()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* Span_1_ToArray_m0E11A38D8E7A3ECF9716C30900DC2C34BB0CC7E4_gshared (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, const RuntimeMethod* method);
// System.Span`1<!!0> System.MemoryExtensions::AsSpan<System.Byte>(!!0[],System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_gshared (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, int32_t ___start1, const RuntimeMethod* method);
// System.Void System.Runtime.InteropServices.MemoryMarshal::Write<System.Text.Json.JsonDocument/DbRow>(System.Span`1<System.Byte>,!!0&)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void MemoryMarshal_Write_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mBBD4DDE8A6973C64B3C4941610C05FA656A63B48_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * ___value1, const RuntimeMethod* method);
// System.Void System.Runtime.InteropServices.MemoryMarshal::Write<System.Int32>(System.Span`1<System.Byte>,!!0&)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, int32_t* ___value1, const RuntimeMethod* method);
// !!0 System.Runtime.InteropServices.MemoryMarshal::Read<System.Int32>(System.ReadOnlySpan`1<System.Byte>)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method);
// System.Span`1<!0> System.Span`1<System.Byte>::Slice(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  Span_1_Slice_mC8E25AC937B49CDD57AA85FF493D7F42595F8EAA_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, int32_t ___start0, const RuntimeMethod* method);
// !!0 System.Runtime.InteropServices.MemoryMarshal::Read<System.Text.Json.JsonDocument/DbRow>(System.ReadOnlySpan`1<System.Byte>)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method);
// !!0 System.Runtime.InteropServices.MemoryMarshal::Read<System.UInt32>(System.ReadOnlySpan`1<System.Byte>)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t MemoryMarshal_Read_TisUInt32_tE60352A06233E4E69DD198BCC67142159F686B15_m833630665CFD238E8565314AC52CFADD215AB189_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method);
// System.Span`1<!!1> System.Runtime.InteropServices.MemoryMarshal::Cast<System.Byte,System.Int32>(System.Span`1<!!0>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526  MemoryMarshal_Cast_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_mC0DBC30388A535C7844D1D37A59E519DA6751DFE_gshared (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___span0, const RuntimeMethod* method);
// !0& System.Span`1<System.Int32>::get_Item(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t* Span_1_get_Item_mE8544DBC448A1E9D05A8AC89B0399CB9B0275A2C_gshared_inline (Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526 * __this, int32_t ___index0, const RuntimeMethod* method);
// System.Void System.Runtime.InteropServices.MemoryMarshal::Write<System.Text.Json.JsonDocument/StackRow>(System.Span`1<System.Byte>,!!0&)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void MemoryMarshal_Write_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m53B95538AC301102BF79930E0E45D3300B903BC7_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA * ___value1, const RuntimeMethod* method);
// !!0 System.Runtime.InteropServices.MemoryMarshal::Read<System.Text.Json.JsonDocument/StackRow>(System.ReadOnlySpan`1<System.Byte>)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  MemoryMarshal_Read_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m4C4E201B0499E179319483CA0E299BBC4BFF6688_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter,System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncValueTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8_m89F9EBB43B233A95E8461140AC187B63D77F2F1F_gshared (AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 * __this, ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * ___awaiter0, U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Buffers.ArrayBufferWriter`1<System.Byte>::Advance(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayBufferWriter_1_Advance_m1F8E2CF2769D083066B3C2737AF52719EACD523A_gshared (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * __this, int32_t ___count0, const RuntimeMethod* method);
// System.ReadOnlyMemory`1<T> System.Buffers.ArrayBufferWriter`1<System.Byte>::get_WrittenMemory()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  ArrayBufferWriter_1_get_WrittenMemory_m52E7F598C012BE7766DE9D809E7F7DAD8DB10F58_gshared (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * __this, const RuntimeMethod* method);
// System.Boolean System.Runtime.InteropServices.MemoryMarshal::TryGetArray<System.Byte>(System.ReadOnlyMemory`1<!!0>,System.ArraySegment`1<!!0>&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool MemoryMarshal_TryGetArray_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m44A80C61AC6C2697DC2C11372DF211AED4DA945E_gshared (ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  ___memory0, ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * ___segment1, const RuntimeMethod* method);
// System.Int32 System.ArraySegment`1<System.Byte>::get_Offset()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ArraySegment_1_get_Offset_m13F255A2A7A730982F330A448FCB32239782C505_gshared_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, const RuntimeMethod* method);
// System.Int32 System.ArraySegment`1<System.Byte>::get_Count()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ArraySegment_1_get_Count_mC13AC26CCFD0EACBCC08F24F2A7BB22841B44C32_gshared_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter,System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80_m26462E59FBB44A9CE56618666C19EF4C882860E0_gshared (AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * __this, ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * ___awaiter0, U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 * ___stateMachine1, const RuntimeMethod* method);
// System.Int32 System.Buffers.ArrayBufferWriter`1<System.Byte>::get_WrittenCount()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ArrayBufferWriter_1_get_WrittenCount_m934380C81D0FF8B55609D3E68D229EE5C74E6C53_gshared_inline (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * __this, const RuntimeMethod* method);
// System.Void System.Buffers.ArrayBufferWriter`1<System.Byte>::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayBufferWriter_1_Clear_m561DC03769B8C169BFFEB40FF3AAD308B4320805_gshared (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * __this, const RuntimeMethod* method);
// System.Void System.Span`1<System.Byte>::.ctor(T[],System.Int32,System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Span_1__ctor_m9DE8211969D97AFD415F2998D3789BA642B8A85D_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, int32_t ___start1, int32_t ___length2, const RuntimeMethod* method);
// System.Int32 System.Span`1<System.Byte>::get_Length()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, const RuntimeMethod* method);
// T& System.Runtime.InteropServices.MemoryMarshal::GetReference<System.Byte>(System.Span`1<T>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t* MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226_gshared (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___span0, const RuntimeMethod* method);
// T& System.Runtime.InteropServices.MemoryMarshal::GetReference<System.Byte>(System.ReadOnlySpan`1<T>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t* MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_gshared (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___span0, const RuntimeMethod* method);
// System.Void System.Span`1<System.Byte>::.ctor(System.Pinnable`1<T>,System.IntPtr,System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Span_1__ctor_mFF8F544A7E3798F8239A0FEB4D32301758CBFCCA_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * ___pinnable0, intptr_t ___byteOffset1, int32_t ___length2, const RuntimeMethod* method);

// System.Boolean System.Text.Json.WriteStack::get_IsContinuation()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WriteStack_get_IsContinuation_m88FEB1F19992286B54F88DE66079DAA6CB1BF319 (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>::.ctor()
inline void List_1__ctor_mA95BD97532A917EFABAEB51DDE1649AF93AA28DF (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 *, const RuntimeMethod*))List_1__ctor_mA95BD97532A917EFABAEB51DDE1649AF93AA28DF_gshared)(__this, method);
}
// System.Int32 System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>::get_Count()
inline int32_t List_1_get_Count_mAF5A5D24EE6E3206F64DF2764D69FE6EEDB40E90_inline (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 *, const RuntimeMethod*))List_1_get_Count_mAF5A5D24EE6E3206F64DF2764D69FE6EEDB40E90_gshared_inline)(__this, method);
}
// System.Void System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>::Add(!0)
inline void List_1_Add_mF57A675DC30E3A30C75C7B19903BB3AB771AA743 (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  ___item0, const RuntimeMethod* method)
{
	((  void (*) (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 *, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 , const RuntimeMethod*))List_1_Add_mF57A675DC30E3A30C75C7B19903BB3AB771AA743_gshared)(__this, ___item0, method);
}
// System.Void System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>::set_Item(System.Int32,!0)
inline void List_1_set_Item_mAF32960D79EBF6119BA8C7632444CFD38AC1DF75 (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, int32_t ___index0, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  ___value1, const RuntimeMethod* method)
{
	((  void (*) (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 *, int32_t, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 , const RuntimeMethod*))List_1_set_Item_mAF32960D79EBF6119BA8C7632444CFD38AC1DF75_gshared)(__this, ___index0, ___value1, method);
}
// System.Void System.Text.Json.WriteStack::AddCurrent()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStack_AddCurrent_m47F360C33799C68FED06B57AA0321371A5A4CF68 (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, const RuntimeMethod* method);
// System.Text.Json.JsonClassInfo System.Text.Json.JsonSerializerOptions::GetOrAddClassForRootType(System.Type)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * JsonSerializerOptions_GetOrAddClassForRootType_mD9ECD25EC6AA5ECFD8AB35CA89BA487C6AE2EC8A (JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * __this, Type_t * ___type0, const RuntimeMethod* method);
// System.Text.Json.JsonPropertyInfo System.Text.Json.JsonClassInfo::get_PropertyInfoForClassInfo()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * JsonClassInfo_get_PropertyInfoForClassInfo_m43DD25A15635FAD68648F55AD79A8B6FB15433FC_inline (JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * __this, const RuntimeMethod* method);
// System.Nullable`1<System.Text.Json.Serialization.JsonNumberHandling> System.Text.Json.JsonPropertyInfo::get_NumberHandling()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  JsonPropertyInfo_get_NumberHandling_m3F57EC55C9CC7CE9C1017CBF1B737759673F3947_inline (JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * __this, const RuntimeMethod* method);
// System.Text.Json.Serialization.ReferenceHandler System.Text.Json.JsonSerializerOptions::get_ReferenceHandler()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * JsonSerializerOptions_get_ReferenceHandler_m0617CB46B783371338540A3A470133DE6CB5CD9A_inline (JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * __this, const RuntimeMethod* method);
// System.Text.Json.Serialization.JsonConverter System.Text.Json.WriteStack::Initialize(System.Type,System.Text.Json.JsonSerializerOptions,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * WriteStack_Initialize_m1BA93CE9F8C4B1A365B61E8AF2A3B0D1FBCF7F3F (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, Type_t * ___type0, JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * ___options1, bool ___supportContinuation2, const RuntimeMethod* method);
// System.Text.Json.JsonPropertyInfo System.Text.Json.WriteStackFrame::GetPolymorphicJsonPropertyInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * WriteStackFrame_GetPolymorphicJsonPropertyInfo_mC6241293FD5975BCF17AE77AAD2A1735932D473C (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * __this, const RuntimeMethod* method);
// System.Text.Json.JsonClassInfo System.Text.Json.JsonPropertyInfo::get_RuntimeClassInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * JsonPropertyInfo_get_RuntimeClassInfo_m8CF6F07A07ED366B98034C37161FF6A37C5FEC96 (JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.WriteStackFrame::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStackFrame_Reset_m919F66E6B37A5AABD075DF89DC00723E2FE74485 (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * __this, const RuntimeMethod* method);
// System.Boolean System.Nullable`1<System.Text.Json.Serialization.JsonNumberHandling>::get_HasValue()
inline bool Nullable_1_get_HasValue_m92429A0BA8A6F4D11389C83E7568D8A9FFB3410B_inline (Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58 *, const RuntimeMethod*))Nullable_1_get_HasValue_m4C033F49F5318E94BC8CBA9CE5175EFDBFADEF9C_gshared_inline)(__this, method);
}
// !0 System.Collections.Generic.List`1<System.Text.Json.WriteStackFrame>::get_Item(System.Int32)
inline WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_inline (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	return ((  WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  (*) (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 *, int32_t, const RuntimeMethod*))List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_gshared_inline)(__this, ___index0, method);
}
// System.Void System.Text.Json.WriteStack::Push()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStack_Push_mEFB808A906431C95FBFE4A654F9FEFB8C962F048 (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.WriteStack::Pop(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStack_Pop_mA03ABCC412B4F0C5720FB1774D6A61F716450B48 (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, bool ___success0, const RuntimeMethod* method);
// System.Void System.Text.StringBuilder::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StringBuilder__ctor_m9305A36F9CF53EDD80D132428999934C68904C77 (StringBuilder_t * __this, String_t* ___value0, const RuntimeMethod* method);
// System.Int32 System.Math::Max(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Math_Max_mD8AA27386BF012C65303FCDEA041B0CC65056E7B (int32_t ___val10, int32_t ___val21, const RuntimeMethod* method);
// System.Void System.Text.Json.WriteStack::<PropertyPath>g__AppendStackFrame|13_0(System.Text.StringBuilder,System.Text.Json.WriteStackFrame&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStack_U3CPropertyPathU3Eg__AppendStackFrameU7C13_0_mFA8217E89FE0DFE851708748202127A07F74AEBA (StringBuilder_t * ___sb0, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * ___frame1, const RuntimeMethod* method);
// System.String System.Text.Json.WriteStack::PropertyPath()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* WriteStack_PropertyPath_m2B7C7609CF52ABC0DCCB60162CB58BFEA3EE4969 (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, const RuntimeMethod* method);
// System.Reflection.MemberInfo System.Text.Json.JsonPropertyInfo::get_MemberInfo()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR MemberInfo_t * JsonPropertyInfo_get_MemberInfo_mDB50F867A36435920C12ED71CA72580FF7EB3A8E_inline (JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.WriteStack::<PropertyPath>g__AppendPropertyName|13_1(System.Text.StringBuilder,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStack_U3CPropertyPathU3Eg__AppendPropertyNameU7C13_1_m5A499E425FD4D40245FC2BDDF6CB558870F6A287 (StringBuilder_t * ___sb0, String_t* ___propertyName1, const RuntimeMethod* method);
// System.Int32 System.String::IndexOfAny(System.Char[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t String_IndexOfAny_m7E9204CF616E533528CC448D05BC8AF97A7D8038 (String_t* __this, CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* ___anyOf0, const RuntimeMethod* method);
// System.Text.StringBuilder System.Text.StringBuilder::Append(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR StringBuilder_t * StringBuilder_Append_mD02AB0C74C6F55E3E330818C77EC147E22096FB1 (StringBuilder_t * __this, String_t* ___value0, const RuntimeMethod* method);
// System.Text.StringBuilder System.Text.StringBuilder::Append(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR StringBuilder_t * StringBuilder_Append_m1ADA3C16E40BF253BCDB5F9579B4DBA9C3E5B22E (StringBuilder_t * __this, Il2CppChar ___value0, const RuntimeMethod* method);
// System.Void System.Text.Json.WriteStackFrame::EndDictionaryElement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStackFrame_EndDictionaryElement_mF8B3A60F6AAB6D4EF329FC9EC0026B1BF43A184B (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.WriteStackFrame::EndProperty()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStackFrame_EndProperty_mFD22836ABA865D92442FBBC0E612A51A74F0F503 (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * __this, const RuntimeMethod* method);
// System.Text.Json.JsonClassInfo System.Text.Json.JsonSerializerOptions::GetOrAddClass(System.Type)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * JsonSerializerOptions_GetOrAddClass_mC4C69C74911631072200AD6AB5A4343176D95D07 (JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * __this, Type_t * ___type0, const RuntimeMethod* method);
// System.Text.Json.Serialization.JsonConverter System.Text.Json.WriteStackFrame::InitializeReEntry(System.Type,System.Text.Json.JsonSerializerOptions,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * WriteStackFrame_InitializeReEntry_m6F30B6BDCE7931B9867F8DE7CE69299CA0C5330B (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * __this, Type_t * ___type0, JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * ___options1, String_t* ___propertyName2, const RuntimeMethod* method);
// System.Void System.Object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405 (RuntimeObject * __this, const RuntimeMethod* method);
// System.StringComparer System.StringComparer::get_OrdinalIgnoreCase()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * StringComparer_get_OrdinalIgnoreCase_m8FD38206B6FFE866E97CE4DF84B037F0DF175288_inline (const RuntimeMethod* method);
// System.String System.Text.Json.JsonClassInfo/ParameterLookupKey::get_Name()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* ParameterLookupKey_get_Name_m048FB355797E2E00063B62A5FDB6A30CE1C543CC_inline (ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * __this, const RuntimeMethod* method);
// System.Type System.Text.Json.JsonClassInfo/ParameterLookupKey::get_Type()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Type_t * ParameterLookupKey_get_Type_m66F89A37473AEEDE2674D17D6FD97C773D54B23A_inline (ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * __this, const RuntimeMethod* method);
// System.Boolean System.Type::op_Equality(System.Type,System.Type)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Type_op_Equality_mA438719A1FDF103C7BBBB08AEF564E7FAEEA0046 (Type_t * ___left0, Type_t * ___right1, const RuntimeMethod* method);
// System.Boolean System.String::Equals(System.String,System.String,System.StringComparison)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_Equals_mD65682B0BB7933CC7A8561AE34DED02E4F3BBBE5 (String_t* ___a0, String_t* ___b1, int32_t ___comparisonType2, const RuntimeMethod* method);
// System.Threading.Tasks.Task`1<System.ArraySegment`1<System.Byte>> System.Text.Json.JsonDocument::ReadToEndAsync(System.IO.Stream,System.Threading.CancellationToken)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * JsonDocument_ReadToEndAsync_m13C80CFB1B36CE78A59A2F124018A078113338E4 (Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * ___stream0, CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  ___cancellationToken1, const RuntimeMethod* method);
// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<!0> System.Threading.Tasks.Task`1<System.ArraySegment`1<System.Byte>>::ConfigureAwait(System.Boolean)
inline ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8  Task_1_ConfigureAwait_m0E2430C409BCD2B226EA4AC94C8DA1D8534513C7 (Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * __this, bool ___continueOnCapturedContext0, const RuntimeMethod* method)
{
	return ((  ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8  (*) (Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 *, bool, const RuntimeMethod*))Task_1_ConfigureAwait_m0E2430C409BCD2B226EA4AC94C8DA1D8534513C7_gshared)(__this, ___continueOnCapturedContext0, method);
}
// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<!0> System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<System.ArraySegment`1<System.Byte>>::GetAwaiter()
inline ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  ConfiguredTaskAwaitable_1_GetAwaiter_m80F1877E5304C1EB51E7F1E92D2C4CA3A9A3AC6D_inline (ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8 * __this, const RuntimeMethod* method)
{
	return ((  ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  (*) (ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8 *, const RuntimeMethod*))ConfiguredTaskAwaitable_1_GetAwaiter_m80F1877E5304C1EB51E7F1E92D2C4CA3A9A3AC6D_gshared_inline)(__this, method);
}
// System.Boolean System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.ArraySegment`1<System.Byte>>::get_IsCompleted()
inline bool ConfiguredTaskAwaiter_get_IsCompleted_m2D230F04D69897DAD535B96F5F4581467DDDE0D8 (ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C *, const RuntimeMethod*))ConfiguredTaskAwaiter_get_IsCompleted_m2D230F04D69897DAD535B96F5F4581467DDDE0D8_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Text.Json.JsonDocument>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.ArraySegment`1<System.Byte>>,System.Text.Json.JsonDocument/<ParseAsyncCore>d__57>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C_TisU3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335_m5FCB8074883D5A5D9777C6093EE677835300432F (AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 * __this, ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C * ___awaiter0, U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 *, ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C *, U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C_TisU3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335_mE9AAF8AA713F4CB5F6237BFB678C7F848F01B188_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// !0 System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.ArraySegment`1<System.Byte>>::GetResult()
inline ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  ConfiguredTaskAwaiter_GetResult_mC723D4CAC0FFD2CB0AF9749A899E22F31CE1B8F6 (ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C * __this, const RuntimeMethod* method)
{
	return ((  ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  (*) (ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C *, const RuntimeMethod*))ConfiguredTaskAwaiter_GetResult_mC723D4CAC0FFD2CB0AF9749A899E22F31CE1B8F6_gshared)(__this, method);
}
// System.Memory`1<!!0> System.MemoryExtensions::AsMemory<System.Byte>(System.ArraySegment`1<!!0>)
inline Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9  MemoryExtensions_AsMemory_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m200D8CCE4E809AF8284BAF03FA13482EE5B0D282 (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  ___segment0, const RuntimeMethod* method)
{
	return ((  Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9  (*) (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE , const RuntimeMethod*))MemoryExtensions_AsMemory_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m200D8CCE4E809AF8284BAF03FA13482EE5B0D282_gshared)(___segment0, method);
}
// System.ReadOnlyMemory`1<!0> System.Memory`1<System.Byte>::op_Implicit(System.Memory`1<!0>)
inline ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  Memory_1_op_Implicit_mE940358A7E5B8CF728319481BB9080A44E2D914F (Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9  ___memory0, const RuntimeMethod* method)
{
	return ((  ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  (*) (Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9 , const RuntimeMethod*))Memory_1_op_Implicit_mE940358A7E5B8CF728319481BB9080A44E2D914F_gshared)(___memory0, method);
}
// System.Text.Json.JsonReaderOptions System.Text.Json.JsonDocumentOptions::GetReaderOptions()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonReaderOptions_tD7C9A60EFCE572E4EA0AC3B1B0731900248253D3  JsonDocumentOptions_GetReaderOptions_mB45CDABD01DCD171F5576B841FD948C183A3F4BC (JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675 * __this, const RuntimeMethod* method);
// !0[] System.ArraySegment`1<System.Byte>::get_Array()
inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, const RuntimeMethod* method)
{
	return ((  ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* (*) (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *, const RuntimeMethod*))ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_gshared_inline)(__this, method);
}
// System.Text.Json.JsonDocument System.Text.Json.JsonDocument::Parse(System.ReadOnlyMemory`1<System.Byte>,System.Text.Json.JsonReaderOptions,System.Byte[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * JsonDocument_Parse_mDCD23B7F0D42C0481828DAA5ACCDEF6DFC858BE1 (ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  ___utf8Json0, JsonReaderOptions_tD7C9A60EFCE572E4EA0AC3B1B0731900248253D3  ___readerOptions1, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___extraRentedBytes2, const RuntimeMethod* method);
// System.Span`1<!!0> System.MemoryExtensions::AsSpan<System.Byte>(System.ArraySegment`1<!!0>)
inline Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mD932D4A4EC20A3549450351374B5D165258B0C91_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  ___segment0, const RuntimeMethod* method)
{
	return ((  Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  (*) (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE , const RuntimeMethod*))MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mD932D4A4EC20A3549450351374B5D165258B0C91_gshared_inline)(___segment0, method);
}
// System.Void System.Span`1<System.Byte>::Clear()
inline void Span_1_Clear_mCD3767C2F151B946E3EEB3AD9CCD8EE0794F689C (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, const RuntimeMethod* method)
{
	((  void (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *, const RuntimeMethod*))Span_1_Clear_mCD3767C2F151B946E3EEB3AD9CCD8EE0794F689C_gshared)(__this, method);
}
// System.Buffers.ArrayPool`1<!0> System.Buffers.ArrayPool`1<System.Byte>::get_Shared()
inline ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline (const RuntimeMethod* method)
{
	return ((  ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * (*) (const RuntimeMethod*))ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_gshared_inline)(method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Text.Json.JsonDocument>::SetException(System.Exception)
inline void AsyncTaskMethodBuilder_1_SetException_m8298F499262BDEDE435D3FA226F4267C179B20D0 (AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 * __this, Exception_t * ___exception0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 *, Exception_t *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetException_m29521EB618E38AF72FF0C4094070C1489F4129B3_gshared)(__this, ___exception0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Text.Json.JsonDocument>::SetResult(!0)
inline void AsyncTaskMethodBuilder_1_SetResult_m5C03D366FBBD09A38148AF074E67325FCD891702 (AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 * __this, JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * ___result0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 *, JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetResult_m3E4AB12877D4FE377F26708CF6899C49360007FA_gshared)(__this, ___result0, method);
}
// System.Void System.Text.Json.JsonDocument/<ParseAsyncCore>d__57::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CParseAsyncCoreU3Ed__57_MoveNext_mD0675E98AF6165205178B6932DA7B1E452799396 (U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Text.Json.JsonDocument>::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
inline void AsyncTaskMethodBuilder_1_SetStateMachine_m8EA71255760B118307FE9FCE898C563EBE80745E (AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 *, RuntimeObject*, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetStateMachine_m736C84D61B4AB2FCD150BD3945C6874471A9224D_gshared)(__this, ___stateMachine0, method);
}
// System.Void System.Text.Json.JsonDocument/<ParseAsyncCore>d__57::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CParseAsyncCoreU3Ed__57_SetStateMachine_m5691C5FAE97992748A81440A273C884169FF58FF (U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.ReadOnlySpan`1<System.Byte> System.Text.Json.JsonConstants::get_Utf8Bom()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  JsonConstants_get_Utf8Bom_m3DC03C02C3987D2937211BF777AA50B8933BC778 (const RuntimeMethod* method);
// System.Int32 System.ReadOnlySpan`1<System.Byte>::get_Length()
inline int32_t ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *, const RuntimeMethod*))ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_gshared_inline)(__this, method);
}
// System.Int64 System.Math::Max(System.Int64,System.Int64)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int64_t Math_Max_m9CDC0B9CEA956A30F9B6BDA815DA307169C6E1C8 (int64_t ___val10, int64_t ___val21, const RuntimeMethod* method);
// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<!0> System.Threading.Tasks.Task`1<System.Int32>::ConfigureAwait(System.Boolean)
inline ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC  Task_1_ConfigureAwait_m9637E2990F98EDC90D1A03B57A4954CE2171C4E2 (Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 * __this, bool ___continueOnCapturedContext0, const RuntimeMethod* method)
{
	return ((  ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC  (*) (Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 *, bool, const RuntimeMethod*))Task_1_ConfigureAwait_m9637E2990F98EDC90D1A03B57A4954CE2171C4E2_gshared)(__this, ___continueOnCapturedContext0, method);
}
// System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<!0> System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1<System.Int32>::GetAwaiter()
inline ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  ConfiguredTaskAwaitable_1_GetAwaiter_m8FA39505FC2099C60148C0F029CB49792690A0D5_inline (ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC * __this, const RuntimeMethod* method)
{
	return ((  ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  (*) (ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC *, const RuntimeMethod*))ConfiguredTaskAwaitable_1_GetAwaiter_m8FA39505FC2099C60148C0F029CB49792690A0D5_gshared_inline)(__this, method);
}
// System.Boolean System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.Int32>::get_IsCompleted()
inline bool ConfiguredTaskAwaiter_get_IsCompleted_m4192DC0E89B48FF93421FFF4EB52C21C42687999 (ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 *, const RuntimeMethod*))ConfiguredTaskAwaiter_get_IsCompleted_m4192DC0E89B48FF93421FFF4EB52C21C42687999_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.ArraySegment`1<System.Byte>>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.Int32>,System.Text.Json.JsonDocument/<ReadToEndAsync>d__65>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2_TisU3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B_m179843A0565EF49F48ABDF6635C3E041743C36B9 (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * __this, ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 * ___awaiter0, U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 *, ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 *, U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2_TisU3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B_m179843A0565EF49F48ABDF6635C3E041743C36B9_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// !0 System.Runtime.CompilerServices.ConfiguredTaskAwaitable`1/ConfiguredTaskAwaiter<System.Int32>::GetResult()
inline int32_t ConfiguredTaskAwaiter_GetResult_m0927E49E03619C51620F396FE1DD5DBD41AC6681 (ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 *, const RuntimeMethod*))ConfiguredTaskAwaiter_GetResult_m0927E49E03619C51620F396FE1DD5DBD41AC6681_gshared)(__this, method);
}
// System.Span`1<!!0> System.MemoryExtensions::AsSpan<System.Byte>(!!0[],System.Int32,System.Int32)
inline Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_inline (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, int32_t ___start1, int32_t ___length2, const RuntimeMethod* method)
{
	return ((  Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  (*) (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t, int32_t, const RuntimeMethod*))MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_gshared_inline)(___array0, ___start1, ___length2, method);
}
// System.ReadOnlySpan`1<!0> System.Span`1<System.Byte>::op_Implicit(System.Span`1<!0>)
inline ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5 (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___span0, const RuntimeMethod* method)
{
	return ((  ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 , const RuntimeMethod*))Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_gshared)(___span0, method);
}
// System.Boolean System.MemoryExtensions::SequenceEqual<System.Byte>(System.ReadOnlySpan`1<!!0>,System.ReadOnlySpan`1<!!0>)
inline bool MemoryExtensions_SequenceEqual_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mA47AE57649F12A2400FE13BDC84254F05A99D1AA_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___span0, ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___other1, const RuntimeMethod* method)
{
	return ((  bool (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , const RuntimeMethod*))MemoryExtensions_SequenceEqual_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mA47AE57649F12A2400FE13BDC84254F05A99D1AA_gshared_inline)(___span0, ___other1, method);
}
// System.Void System.Buffer::BlockCopy(System.Array,System.Int32,System.Array,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Buffer_BlockCopy_mD01FC13D87078586714AA235261A9E786C351725 (RuntimeArray * ___src0, int32_t ___srcOffset1, RuntimeArray * ___dst2, int32_t ___dstOffset3, int32_t ___count4, const RuntimeMethod* method);
// System.Void System.ArraySegment`1<System.Byte>::.ctor(!0[],System.Int32,System.Int32)
inline void ArraySegment_1__ctor_mAA780E22BB5AE07078510EDCE524DD1EA1E98E0D (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, int32_t ___offset1, int32_t ___count2, const RuntimeMethod* method)
{
	((  void (*) (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t, int32_t, const RuntimeMethod*))ArraySegment_1__ctor_mAA780E22BB5AE07078510EDCE524DD1EA1E98E0D_gshared)(__this, ___array0, ___offset1, ___count2, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.ArraySegment`1<System.Byte>>::SetException(System.Exception)
inline void AsyncTaskMethodBuilder_1_SetException_m9AEB12146F99A1F4E8F8992A49A6C3BC57AB5EBD (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * __this, Exception_t * ___exception0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 *, Exception_t *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetException_m9AEB12146F99A1F4E8F8992A49A6C3BC57AB5EBD_gshared)(__this, ___exception0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.ArraySegment`1<System.Byte>>::SetResult(!0)
inline void AsyncTaskMethodBuilder_1_SetResult_mB6426AE79AFDC2DCFDFD3F2CB765EA12494D7819 (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * __this, ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  ___result0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 *, ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE , const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetResult_mB6426AE79AFDC2DCFDFD3F2CB765EA12494D7819_gshared)(__this, ___result0, method);
}
// System.Void System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReadToEndAsyncU3Ed__65_MoveNext_m6687BB75E19E97F8D89E828FA064629CB2F3390E (U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.ArraySegment`1<System.Byte>>::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
inline void AsyncTaskMethodBuilder_1_SetStateMachine_m57FFFD41160014C16C21B3A3F4B9902B587CAE25 (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 *, RuntimeObject*, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetStateMachine_m57FFFD41160014C16C21B3A3F4B9902B587CAE25_gshared)(__this, ___stateMachine0, method);
}
// System.Void System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReadToEndAsyncU3Ed__65_SetStateMachine_m7B7DC4541C9CE1E4B20C91F17064C80477738C27 (U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Int32 System.Text.Json.JsonDocument/DbRow::get_Location()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t DbRow_get_Location_m64A1FE8677C03A2ED3384727229059262AD3F149_inline (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method);
// System.Int32 System.Text.Json.JsonDocument/DbRow::get_SizeOrLength()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t DbRow_get_SizeOrLength_mD035DFC369AC701D3930C33A159A067B00913772 (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method);
// System.Boolean System.Text.Json.JsonDocument/DbRow::get_IsUnknownSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DbRow_get_IsUnknownSize_mAB1898B5C44A75E8F3F5737B39E22A9829052B9E (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method);
// System.Boolean System.Text.Json.JsonDocument/DbRow::get_HasComplexChildren()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DbRow_get_HasComplexChildren_m7FB54FB106AA84F5168A030E00E21B2687C58D09 (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method);
// System.Int32 System.Text.Json.JsonDocument/DbRow::get_NumberOfRows()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t DbRow_get_NumberOfRows_mB356515E008E677E4E79834F315165BD49A825DF (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method);
// System.Text.Json.JsonTokenType System.Text.Json.JsonDocument/DbRow::get_TokenType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t DbRow_get_TokenType_m25D3999BC52C9991FC22A97FEC677997068D1E7B (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/DbRow::.ctor(System.Text.Json.JsonTokenType,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DbRow__ctor_m83855B245AEDA3542D69D4181E26D625780729FF (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, uint8_t ___jsonTokenType0, int32_t ___location1, int32_t ___sizeOrLength2, const RuntimeMethod* method);
// System.Boolean System.Text.Json.JsonDocument/DbRow::get_IsSimpleValue()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DbRow_get_IsSimpleValue_mF9C4D4A9AA674E10C15D23BFDCEE3B7A9CE78638 (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method);
// System.Int32 System.Text.Json.JsonDocument/MetadataDb::get_Length()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/MetadataDb::set_Length(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void MetadataDb_set_Length_mDEED679131C22B2B98BD28E71CABB539B01E79C7_inline (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/MetadataDb::.ctor(System.Byte[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb__ctor_mF5690ADF4EA9661465EF315D0505E445C6E222FB (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___completeDb0, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/MetadataDb::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb__ctor_mADDFB275C40C9946CEFB568AE37356AEB5FBE14D (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___payloadLength0, const RuntimeMethod* method);
// System.Span`1<!0> System.Span`1<System.Byte>::op_Implicit(!0[])
inline Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4 (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, const RuntimeMethod* method)
{
	return ((  Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  (*) (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, const RuntimeMethod*))Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4_gshared)(___array0, method);
}
// System.Void System.Span`1<System.Byte>::CopyTo(System.Span`1<!0>)
inline void Span_1_CopyTo_m78B5163997318B736E1238622FCBC09953798836 (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, const RuntimeMethod* method)
{
	((  void (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *, Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 , const RuntimeMethod*))Span_1_CopyTo_m78B5163997318B736E1238622FCBC09953798836_gshared)(__this, ___destination0, method);
}
// !0[] System.Span`1<System.Byte>::ToArray()
inline ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* Span_1_ToArray_m0E11A38D8E7A3ECF9716C30900DC2C34BB0CC7E4 (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, const RuntimeMethod* method)
{
	return ((  ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *, const RuntimeMethod*))Span_1_ToArray_m0E11A38D8E7A3ECF9716C30900DC2C34BB0CC7E4_gshared)(__this, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::.ctor(System.Text.Json.JsonDocument/MetadataDb,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb__ctor_mDFB25B7D23103882D8C1A5E006A56041CA1E783B (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  ___source0, bool ___useArrayPools1, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/MetadataDb::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_Dispose_m65983FCE3C671C0E078BA5B7192D66EA6224D218 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/MetadataDb::TrimExcess()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_TrimExcess_m4BAD9F80840A78E601E56F2EAE6822A02267A1CD (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/MetadataDb::Enlarge()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_Enlarge_m1D564D4B6A73CB588BBACAD06E20CAC2CC87BE91 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, const RuntimeMethod* method);
// System.Span`1<!!0> System.MemoryExtensions::AsSpan<System.Byte>(!!0[],System.Int32)
inline Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, int32_t ___start1, const RuntimeMethod* method)
{
	return ((  Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  (*) (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t, const RuntimeMethod*))MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_gshared)(___array0, ___start1, method);
}
// System.Void System.Runtime.InteropServices.MemoryMarshal::Write<System.Text.Json.JsonDocument/DbRow>(System.Span`1<System.Byte>,!!0&)
inline void MemoryMarshal_Write_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mBBD4DDE8A6973C64B3C4941610C05FA656A63B48_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * ___value1, const RuntimeMethod* method)
{
	((  void (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 , DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *, const RuntimeMethod*))MemoryMarshal_Write_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mBBD4DDE8A6973C64B3C4941610C05FA656A63B48_gshared_inline)(___destination0, ___value1, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::Append(System.Text.Json.JsonTokenType,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_Append_m70BEF3B5C094C35F03E20E23CABEF3905616B61A (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, uint8_t ___tokenType0, int32_t ___startLocation1, int32_t ___length2, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/MetadataDb::AssertValidIndex(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_AssertValidIndex_m1F59B45473AF571F819E12A4D7D9BC7749846CF7 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, const RuntimeMethod* method);
// System.Void System.Runtime.InteropServices.MemoryMarshal::Write<System.Int32>(System.Span`1<System.Byte>,!!0&)
inline void MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, int32_t* ___value1, const RuntimeMethod* method)
{
	((  void (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 , int32_t*, const RuntimeMethod*))MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_gshared_inline)(___destination0, ___value1, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::SetLength(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_SetLength_mF874FB9D92FF15E65645B752D2F16693FD85EA53 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, int32_t ___length1, const RuntimeMethod* method);
// !!0 System.Runtime.InteropServices.MemoryMarshal::Read<System.Int32>(System.ReadOnlySpan`1<System.Byte>)
inline int32_t MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , const RuntimeMethod*))MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_gshared_inline)(___source0, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::SetNumberOfRows(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_SetNumberOfRows_mE9A9288F6CFE360E85CC8E0A50AE964D43C470E2 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, int32_t ___numberOfRows1, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/MetadataDb::SetHasComplexChildren(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_SetHasComplexChildren_m23B89D6C169828F97B1138999C88AD2C334E46D9 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, const RuntimeMethod* method);
// System.Int32 System.Text.Json.JsonDocument/MetadataDb::FindOpenElement(System.Text.Json.JsonTokenType)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t MetadataDb_FindOpenElement_m764A0CA02C9B76F9FB4501BEC77D157A87ADCC8C (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, uint8_t ___lookupType0, const RuntimeMethod* method);
// System.Int32 System.Text.Json.JsonDocument/MetadataDb::FindIndexOfFirstUnsetSizeOrLength(System.Text.Json.JsonTokenType)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t MetadataDb_FindIndexOfFirstUnsetSizeOrLength_m93260D165FFDE321BC10AEB51ADA16EA571BDA92 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, uint8_t ___lookupType0, const RuntimeMethod* method);
// System.Span`1<!0> System.Span`1<System.Byte>::Slice(System.Int32)
inline Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  Span_1_Slice_mC8E25AC937B49CDD57AA85FF493D7F42595F8EAA_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, int32_t ___start0, const RuntimeMethod* method)
{
	return ((  Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *, int32_t, const RuntimeMethod*))Span_1_Slice_mC8E25AC937B49CDD57AA85FF493D7F42595F8EAA_gshared_inline)(__this, ___start0, method);
}
// !!0 System.Runtime.InteropServices.MemoryMarshal::Read<System.Text.Json.JsonDocument/DbRow>(System.ReadOnlySpan`1<System.Byte>)
inline DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method)
{
	return ((  DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , const RuntimeMethod*))MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_gshared_inline)(___source0, method);
}
// System.Text.Json.JsonDocument/DbRow System.Text.Json.JsonDocument/MetadataDb::Get(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  MetadataDb_Get_m54EC69D0C0A5AFA94790823E043C9C5AF611E879 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, const RuntimeMethod* method);
// !!0 System.Runtime.InteropServices.MemoryMarshal::Read<System.UInt32>(System.ReadOnlySpan`1<System.Byte>)
inline uint32_t MemoryMarshal_Read_TisUInt32_tE60352A06233E4E69DD198BCC67142159F686B15_m833630665CFD238E8565314AC52CFADD215AB189_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method)
{
	return ((  uint32_t (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , const RuntimeMethod*))MemoryMarshal_Read_TisUInt32_tE60352A06233E4E69DD198BCC67142159F686B15_m833630665CFD238E8565314AC52CFADD215AB189_gshared_inline)(___source0, method);
}
// System.Text.Json.JsonTokenType System.Text.Json.JsonDocument/MetadataDb::GetJsonTokenType(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t MetadataDb_GetJsonTokenType_mFE77CF70D471447224C7088BF78347AD9922BDD8 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, const RuntimeMethod* method);
// System.Span`1<!!1> System.Runtime.InteropServices.MemoryMarshal::Cast<System.Byte,System.Int32>(System.Span`1<!!0>)
inline Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526  MemoryMarshal_Cast_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_mC0DBC30388A535C7844D1D37A59E519DA6751DFE (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___span0, const RuntimeMethod* method)
{
	return ((  Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526  (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 , const RuntimeMethod*))MemoryMarshal_Cast_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_mC0DBC30388A535C7844D1D37A59E519DA6751DFE_gshared)(___span0, method);
}
// !0& System.Span`1<System.Int32>::get_Item(System.Int32)
inline int32_t* Span_1_get_Item_mE8544DBC448A1E9D05A8AC89B0399CB9B0275A2C_inline (Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	return ((  int32_t* (*) (Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526 *, int32_t, const RuntimeMethod*))Span_1_get_Item_mE8544DBC448A1E9D05A8AC89B0399CB9B0275A2C_gshared_inline)(__this, ___index0, method);
}
// System.Text.Json.JsonDocument/MetadataDb System.Text.Json.JsonDocument/MetadataDb::CopySegment(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  MetadataDb_CopySegment_mE2A805BC0A4A35436649F6DFF69A286C416A056C (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___startIndex0, int32_t ___endIndex1, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/StackRow::.ctor(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StackRow__ctor_mE83A64F557423B2C1417CF2CAA47FCB6DAE79597 (StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA * __this, int32_t ___sizeOrLength0, int32_t ___numberOfRows1, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/StackRowStack::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StackRowStack__ctor_mC2D0A937968645C04762AE37C6F9196811FC60AD (StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * __this, int32_t ___initialSize0, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/StackRowStack::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StackRowStack_Dispose_mE69DCE4BA09A561767066C061517880FC9FD240E (StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonDocument/StackRowStack::Enlarge()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StackRowStack_Enlarge_m9CAB452BCBA0F7795608ED801F3741F645037CF0 (StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * __this, const RuntimeMethod* method);
// System.Void System.Runtime.InteropServices.MemoryMarshal::Write<System.Text.Json.JsonDocument/StackRow>(System.Span`1<System.Byte>,!!0&)
inline void MemoryMarshal_Write_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m53B95538AC301102BF79930E0E45D3300B903BC7_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA * ___value1, const RuntimeMethod* method)
{
	((  void (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 , StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA *, const RuntimeMethod*))MemoryMarshal_Write_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m53B95538AC301102BF79930E0E45D3300B903BC7_gshared_inline)(___destination0, ___value1, method);
}
// System.Void System.Text.Json.JsonDocument/StackRowStack::Push(System.Text.Json.JsonDocument/StackRow)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StackRowStack_Push_m2EB6DF0A8051783F40F7911AC981072DB6DF3AA0 (StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * __this, StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  ___row0, const RuntimeMethod* method);
// !!0 System.Runtime.InteropServices.MemoryMarshal::Read<System.Text.Json.JsonDocument/StackRow>(System.ReadOnlySpan`1<System.Byte>)
inline StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  MemoryMarshal_Read_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m4C4E201B0499E179319483CA0E299BBC4BFF6688_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method)
{
	return ((  StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , const RuntimeMethod*))MemoryMarshal_Read_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m4C4E201B0499E179319483CA0E299BBC4BFF6688_gshared_inline)(___source0, method);
}
// System.Text.Json.JsonDocument/StackRow System.Text.Json.JsonDocument/StackRowStack::Pop()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  StackRowStack_Pop_mB7727C6BB4EF6384ADB6A055F63AE463231B3731 (StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * __this, const RuntimeMethod* method);
// System.Int32 System.Text.Json.JsonDocument::GetEndIndex(System.Int32,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t JsonDocument_GetEndIndex_mCB49D234EB50A854CC608B35B030D317C6478A47 (JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * __this, int32_t ___index0, bool ___includeEndElement1, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonElement/ArrayEnumerator::.ctor(System.Text.Json.JsonElement)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayEnumerator__ctor_mE63EDB3BC6E93B2C7E2A40C824553B06F853E68C (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ___target0, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonElement::.ctor(System.Text.Json.JsonDocument,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void JsonElement__ctor_m08BBC84BCD6BF2156EEA51E7E367E772C44E8C9C (JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * __this, JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * ___parent0, int32_t ___idx1, const RuntimeMethod* method);
// System.Text.Json.JsonElement System.Text.Json.JsonElement/ArrayEnumerator::get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ArrayEnumerator_get_Current_mF52CB9638D47BF1F300A8D90DE72F16FE7760A50 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method);
// System.Text.Json.JsonElement/ArrayEnumerator System.Text.Json.JsonElement/ArrayEnumerator::GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  ArrayEnumerator_GetEnumerator_m84826411DC72414B035DD2383B98995030DC1D64 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method);
// System.Collections.IEnumerator System.Text.Json.JsonElement/ArrayEnumerator::System.Collections.IEnumerable.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* ArrayEnumerator_System_Collections_IEnumerable_GetEnumerator_mFA06CBD3D1326936DCA477D78774A7D5244051B2 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerator`1<System.Text.Json.JsonElement> System.Text.Json.JsonElement/ArrayEnumerator::System.Collections.Generic.IEnumerable<System.Text.Json.JsonElement>.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* ArrayEnumerator_System_Collections_Generic_IEnumerableU3CSystem_Text_Json_JsonElementU3E_GetEnumerator_m7E27A28429F4B25E812197A40277394C3898FBF4 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonElement/ArrayEnumerator::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayEnumerator_Dispose_m013242AA10DC5F3B889EF39004D9E62C88484F36 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonElement/ArrayEnumerator::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayEnumerator_Reset_m4E108783AA0C9538A0723F914B99F999D0907825 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method);
// System.Object System.Text.Json.JsonElement/ArrayEnumerator::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * ArrayEnumerator_System_Collections_IEnumerator_get_Current_m0625474B01CE733D09EC696C2D3943FEBDA9D8B9 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method);
// System.Boolean System.Text.Json.JsonElement/ArrayEnumerator::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ArrayEnumerator_MoveNext_m4A4255B7F6ADA0D569E1644355F8542007BC99E8 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonElement/ObjectEnumerator::.ctor(System.Text.Json.JsonElement)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ObjectEnumerator__ctor_mE6CFBEE462A2DAD097E3CF38C5E1F93B3A72575A (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ___target0, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonProperty::.ctor(System.Text.Json.JsonElement,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void JsonProperty__ctor_m0C3653F7D2BC6F745C523466CA7294E355FABB13 (JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043 * __this, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ___value0, String_t* ___name1, const RuntimeMethod* method);
// System.Text.Json.JsonProperty System.Text.Json.JsonElement/ObjectEnumerator::get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043  ObjectEnumerator_get_Current_mEBA991658CFB79D8EC48C940587E8F56E5FCF6A6 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method);
// System.Text.Json.JsonElement/ObjectEnumerator System.Text.Json.JsonElement/ObjectEnumerator::GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  ObjectEnumerator_GetEnumerator_m6431E7E6BAF73BDCC9B211871E2046D8C5557C9F (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method);
// System.Collections.IEnumerator System.Text.Json.JsonElement/ObjectEnumerator::System.Collections.IEnumerable.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* ObjectEnumerator_System_Collections_IEnumerable_GetEnumerator_mFABC61E9837E42D4B98EDD2EB829169691151DA4 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerator`1<System.Text.Json.JsonProperty> System.Text.Json.JsonElement/ObjectEnumerator::System.Collections.Generic.IEnumerable<System.Text.Json.JsonProperty>.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* ObjectEnumerator_System_Collections_Generic_IEnumerableU3CSystem_Text_Json_JsonPropertyU3E_GetEnumerator_m152A46470709CCB7745C15E69C8B5E3CC379F292 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonElement/ObjectEnumerator::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ObjectEnumerator_Dispose_m05CE64A63964F3D868775EC395EF5AFCBFD0C772 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.JsonElement/ObjectEnumerator::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ObjectEnumerator_Reset_m2375949AFCB32D333217A2F8674E48BF3A948DC7 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method);
// System.Object System.Text.Json.JsonElement/ObjectEnumerator::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * ObjectEnumerator_System_Collections_IEnumerator_get_Current_m819E29B32A75D77D74B6CA9F65F28BDFF7C7E6BC (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method);
// System.Boolean System.Text.Json.JsonElement/ObjectEnumerator::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ObjectEnumerator_MoveNext_m9EF4007222C1BFD3D5BEF8CC03A76CE222F4D859 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method);
// System.Boolean System.Text.Json.JsonHelpers/DateTimeParseData::get_OffsetNegative()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DateTimeParseData_get_OffsetNegative_m0D054B07A34B50D970C5751B503F342C14F5F3E9 (DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E * __this, const RuntimeMethod* method);
// System.Object System.Activator::CreateInstance(System.Type,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_NO_INLINE IL2CPP_METHOD_ATTR RuntimeObject * Activator_CreateInstance_m35ED39C8B9201D90292C1803022AEE106B69A295 (Type_t * ___type0, bool ___nonPublic1, const RuntimeMethod* method);
// System.Void System.Text.Json.Utf8JsonReader/PartialStateForRollback::.ctor(System.Int64,System.Int64,System.Int32,System.SequencePosition)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PartialStateForRollback__ctor_m0A2CA55E0DA1307DCE07752039D69E1E171C6178 (PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1 * __this, int64_t ___totalConsumed0, int64_t ___bytePositionInLine1, int32_t ___consumed2, SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  ___currentPosition3, const RuntimeMethod* method);
// System.Object System.SequencePosition::GetObject()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject * SequencePosition_GetObject_m33D4D02B2042DFCCC2549006639381910F1F3525_inline (SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A * __this, const RuntimeMethod* method);
// System.Int32 System.SequencePosition::GetInteger()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SequencePosition_GetInteger_mE4D2683EB441F31A3C1474845ABBD0FA78C130DE_inline (SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A * __this, const RuntimeMethod* method);
// System.Void System.SequencePosition::.ctor(System.Object,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SequencePosition__ctor_m881E247213B0B28B3903475A1FC0237C56B5F0B0 (SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A * __this, RuntimeObject * ___object0, int32_t ___integer1, const RuntimeMethod* method);
// System.SequencePosition System.Text.Json.Utf8JsonReader/PartialStateForRollback::GetStartPosition(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  PartialStateForRollback_GetStartPosition_mD8F495352B433FEE2C9D27A58FDBAC331C418D63 (PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1 * __this, int32_t ___offset0, const RuntimeMethod* method);
// System.Threading.Tasks.Task System.Text.Json.Utf8JsonWriter::FlushAsync(System.Threading.CancellationToken)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * Utf8JsonWriter_FlushAsync_m9A2787600340AB5AE4C3FE80C58FA4BC65677B68 (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  ___cancellationToken0, const RuntimeMethod* method);
// System.Runtime.CompilerServices.ConfiguredTaskAwaitable System.Threading.Tasks.Task::ConfigureAwait(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E  Task_ConfigureAwait_m0477031D48C23B8368049C62C53C33D32322EDCE (Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * __this, bool ___continueOnCapturedContext0, const RuntimeMethod* method);
// System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter System.Runtime.CompilerServices.ConfiguredTaskAwaitable::GetAwaiter()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  ConfiguredTaskAwaitable_GetAwaiter_m9F912D7DF74F087AFAF1F478CE59152DF22395A2_inline (ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E * __this, const RuntimeMethod* method);
// System.Boolean System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter::get_IsCompleted()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ConfiguredTaskAwaiter_get_IsCompleted_m98056416CC6E5741A2201994591D27D127A17730 (ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter,System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35>(!!0&,!!1&)
inline void AsyncValueTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8_m89F9EBB43B233A95E8461140AC187B63D77F2F1F (AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 * __this, ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * ___awaiter0, U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 *, ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *, U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 *, const RuntimeMethod*))AsyncValueTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8_m89F9EBB43B233A95E8461140AC187B63D77F2F1F_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter::GetResult()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ConfiguredTaskAwaiter_GetResult_m29A9880E9FCC4B8E9928B60E137FB53D0C8F0CE6 (ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.Utf8JsonWriter::ResetHelper()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Utf8JsonWriter_ResetHelper_m106A696B3EBF0175EF391F2DAEC5FA2F3DD5129A (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::SetException(System.Exception)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncValueTaskMethodBuilder_SetException_m9B47529F90B538885E5FE9B831021AB356858933 (AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 * __this, Exception_t * ___exception0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::SetResult()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncValueTaskMethodBuilder_SetResult_m965DBAD8BBA26DB5B979D5CE7A8D30B2ED6D4AA1 (AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CDisposeAsyncU3Ed__35_MoveNext_mFE5C0EA2A27B3FC766BF6EBE70C6B330ADCA7E74 (U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncValueTaskMethodBuilder::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncValueTaskMethodBuilder_SetStateMachine_m3188B03A10264F946C66E4219B762F5E8DA834DF (AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CDisposeAsyncU3Ed__35_SetStateMachine_mBF71AD303A810C158035E8C0C2A0658EA152E188 (U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Text.Json.Utf8JsonWriter::CheckNotDisposed()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Utf8JsonWriter_CheckNotDisposed_m83F234E5126E68BAD92D6145BF87189C78E8FF33 (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, const RuntimeMethod* method);
// System.Int32 System.Text.Json.Utf8JsonWriter::get_BytesPending()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Utf8JsonWriter_get_BytesPending_m3972ECDA5A4E7DBC6A17F7AA0610CB20AB58EF2C_inline (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, const RuntimeMethod* method);
// System.Void System.Buffers.ArrayBufferWriter`1<System.Byte>::Advance(System.Int32)
inline void ArrayBufferWriter_1_Advance_m1F8E2CF2769D083066B3C2737AF52719EACD523A (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * __this, int32_t ___count0, const RuntimeMethod* method)
{
	((  void (*) (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 *, int32_t, const RuntimeMethod*))ArrayBufferWriter_1_Advance_m1F8E2CF2769D083066B3C2737AF52719EACD523A_gshared)(__this, ___count0, method);
}
// System.Void System.Text.Json.Utf8JsonWriter::set_BytesPending(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Utf8JsonWriter_set_BytesPending_m21E09C8027465D1AD0C46E31DD91C8C83524DB10_inline (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, int32_t ___value0, const RuntimeMethod* method);
// System.ReadOnlyMemory`1<T> System.Buffers.ArrayBufferWriter`1<System.Byte>::get_WrittenMemory()
inline ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  ArrayBufferWriter_1_get_WrittenMemory_m52E7F598C012BE7766DE9D809E7F7DAD8DB10F58 (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * __this, const RuntimeMethod* method)
{
	return ((  ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  (*) (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 *, const RuntimeMethod*))ArrayBufferWriter_1_get_WrittenMemory_m52E7F598C012BE7766DE9D809E7F7DAD8DB10F58_gshared)(__this, method);
}
// System.Boolean System.Runtime.InteropServices.MemoryMarshal::TryGetArray<System.Byte>(System.ReadOnlyMemory`1<!!0>,System.ArraySegment`1<!!0>&)
inline bool MemoryMarshal_TryGetArray_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m44A80C61AC6C2697DC2C11372DF211AED4DA945E (ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  ___memory0, ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * ___segment1, const RuntimeMethod* method)
{
	return ((  bool (*) (ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133 , ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *, const RuntimeMethod*))MemoryMarshal_TryGetArray_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m44A80C61AC6C2697DC2C11372DF211AED4DA945E_gshared)(___memory0, ___segment1, method);
}
// System.Int32 System.ArraySegment`1<System.Byte>::get_Offset()
inline int32_t ArraySegment_1_get_Offset_m13F255A2A7A730982F330A448FCB32239782C505_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *, const RuntimeMethod*))ArraySegment_1_get_Offset_m13F255A2A7A730982F330A448FCB32239782C505_gshared_inline)(__this, method);
}
// System.Int32 System.ArraySegment`1<System.Byte>::get_Count()
inline int32_t ArraySegment_1_get_Count_mC13AC26CCFD0EACBCC08F24F2A7BB22841B44C32_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *, const RuntimeMethod*))ArraySegment_1_get_Count_mC13AC26CCFD0EACBCC08F24F2A7BB22841B44C32_gshared_inline)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.ConfiguredTaskAwaitable/ConfiguredTaskAwaiter,System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80_m26462E59FBB44A9CE56618666C19EF4C882860E0 (AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * __this, ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * ___awaiter0, U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B *, ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *, U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80_m26462E59FBB44A9CE56618666C19EF4C882860E0_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Int64 System.Text.Json.Utf8JsonWriter::get_BytesCommitted()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int64_t Utf8JsonWriter_get_BytesCommitted_m4647460AF1A97E6805CF12393C978FE240CCB076_inline (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, const RuntimeMethod* method);
// System.Int32 System.Buffers.ArrayBufferWriter`1<System.Byte>::get_WrittenCount()
inline int32_t ArrayBufferWriter_1_get_WrittenCount_m934380C81D0FF8B55609D3E68D229EE5C74E6C53_inline (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 *, const RuntimeMethod*))ArrayBufferWriter_1_get_WrittenCount_m934380C81D0FF8B55609D3E68D229EE5C74E6C53_gshared_inline)(__this, method);
}
// System.Void System.Text.Json.Utf8JsonWriter::set_BytesCommitted(System.Int64)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Utf8JsonWriter_set_BytesCommitted_m05CFA019A22B21A6E59B688CCD22B1C76C42E9B3_inline (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, int64_t ___value0, const RuntimeMethod* method);
// System.Void System.Buffers.ArrayBufferWriter`1<System.Byte>::Clear()
inline void ArrayBufferWriter_1_Clear_m561DC03769B8C169BFFEB40FF3AAD308B4320805 (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * __this, const RuntimeMethod* method)
{
	((  void (*) (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 *, const RuntimeMethod*))ArrayBufferWriter_1_Clear_m561DC03769B8C169BFFEB40FF3AAD308B4320805_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::SetException(System.Exception)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_SetException_m54A9FC97C33C9AC4E514923F7C58D76B94D344C4 (AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * __this, Exception_t * ___exception0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::SetResult()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_SetResult_m89AF7435D1B349EE8A377B5DFFC082999D9F8CD9 (AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * __this, const RuntimeMethod* method);
// System.Void System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CFlushAsyncU3Ed__36_MoveNext_m8912AC13068F93D8A40A2321928DB63BC7D32790 (U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_SetStateMachine_m68788E9C6C30BBAA030DEC1963E8A6C6B2C8A3E6 (AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CFlushAsyncU3Ed__36_SetStateMachine_m18624CF1FEFE83DD9B7E9250A954B72BE3C094A2 (U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.ThrowHelper::ThrowArgumentOutOfRangeException()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ThrowHelper_ThrowArgumentOutOfRangeException_m4841366ABC2B2AFA37C10900551D7E07522C0929 (const RuntimeMethod* method);
// System.Void System.Span`1<System.Byte>::.ctor(T[],System.Int32,System.Int32)
inline void Span_1__ctor_m9DE8211969D97AFD415F2998D3789BA642B8A85D_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, int32_t ___start1, int32_t ___length2, const RuntimeMethod* method)
{
	((  void (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t, int32_t, const RuntimeMethod*))Span_1__ctor_m9DE8211969D97AFD415F2998D3789BA642B8A85D_gshared_inline)(__this, ___array0, ___start1, ___length2, method);
}
// System.NUInt System.NUInt::op_Explicit(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  NUInt_op_Explicit_m680513883587956D1452B1EB6D321D4C3A0C8366 (int32_t ___value0, const RuntimeMethod* method);
// System.NUInt System.NUInt::op_Multiply(System.NUInt,System.NUInt)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  NUInt_op_Multiply_mABFB3E10A51F74FDC0CD9B799B7BF35C2C5D8D85_inline (NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  ___left0, NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  ___right1, const RuntimeMethod* method);
// System.Boolean System.SpanHelpers::SequenceEqual(System.Byte&,System.Byte&,System.NUInt)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool SpanHelpers_SequenceEqual_mDEB0F358BB173EA24BEEB0609454A997E9273A89 (uint8_t* ___first0, uint8_t* ___second1, NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  ___length2, const RuntimeMethod* method);
// System.Type System.Type::GetTypeFromHandle(System.RuntimeTypeHandle)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Type_t * Type_GetTypeFromHandle_m8BB57524FF7F9DB1803BC561D2B3A4DBACEB385E (RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  ___handle0, const RuntimeMethod* method);
// System.Void System.ThrowHelper::ThrowArgumentException_InvalidTypeWithPointersNotSupported(System.Type)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ThrowHelper_ThrowArgumentException_InvalidTypeWithPointersNotSupported_m4A71872D4B069AF36758A61E4CA3FB663B4E8EC4 (Type_t * ___type0, const RuntimeMethod* method);
// System.Int32 System.Span`1<System.Byte>::get_Length()
inline int32_t Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *, const RuntimeMethod*))Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_gshared_inline)(__this, method);
}
// System.Void System.ThrowHelper::ThrowArgumentOutOfRangeException(System.ExceptionArgument)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5 (int32_t ___argument0, const RuntimeMethod* method);
// T& System.Runtime.InteropServices.MemoryMarshal::GetReference<System.Byte>(System.Span`1<T>)
inline uint8_t* MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226 (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___span0, const RuntimeMethod* method)
{
	return ((  uint8_t* (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 , const RuntimeMethod*))MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226_gshared)(___span0, method);
}
// T& System.Runtime.InteropServices.MemoryMarshal::GetReference<System.Byte>(System.ReadOnlySpan`1<T>)
inline uint8_t* MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824 (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___span0, const RuntimeMethod* method)
{
	return ((  uint8_t* (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , const RuntimeMethod*))MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_gshared)(___span0, method);
}
// System.Void System.Span`1<System.Byte>::.ctor(System.Pinnable`1<T>,System.IntPtr,System.Int32)
inline void Span_1__ctor_mFF8F544A7E3798F8239A0FEB4D32301758CBFCCA_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * ___pinnable0, intptr_t ___byteOffset1, int32_t ___length2, const RuntimeMethod* method)
{
	((  void (*) (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *, Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 *, intptr_t, int32_t, const RuntimeMethod*))Span_1__ctor_mFF8F544A7E3798F8239A0FEB4D32301758CBFCCA_gshared_inline)(__this, ___pinnable0, ___byteOffset1, ___length2, method);
}
// System.Void System.ThrowHelper::ThrowIndexOutOfRangeException()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ThrowHelper_ThrowIndexOutOfRangeException_m4D1EB8558F17DFE372ECF87D9BCAD112A7F5E6BC (const RuntimeMethod* method);
// System.Void* System.IntPtr::ToPointer()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void* IntPtr_ToPointer_m5C7CE32B14B6E30467B378052FEA25300833C61F_inline (intptr_t* __this, const RuntimeMethod* method);
// System.Void System.NUInt::.ctor(System.UInt64)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NUInt__ctor_mBD99E19E274774DF07488C672C5DFC90F4B21973 (NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5 * __this, uint64_t ___value0, const RuntimeMethod* method);
// System.Void System.NUInt::.ctor(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NUInt__ctor_m34A1178C5D59B395E905B670FCF390D1AA5DC85E (NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5 * __this, uint32_t ___value0, const RuntimeMethod* method);
// System.Type System.Object::GetType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Type_t * Object_GetType_m571FE8360C10B98C23AAF1F066D92C08CC94F45B (RuntimeObject * __this, const RuntimeMethod* method);
// System.Boolean System.Type::op_Inequality(System.Type,System.Type)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Type_op_Inequality_m6DDC5E923203A79BF505F9275B694AD3FAA36DB0 (Type_t * ___left0, Type_t * ___right1, const RuntimeMethod* method);
// System.Void System.ThrowHelper::ThrowArrayTypeMismatchException()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ThrowHelper_ThrowArrayTypeMismatchException_mFC0D7756FD2EA1A7E41D8426D819369FDBD728FC (const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif


// Conversion methods for marshalling of: System.Text.Json.WriteStack
IL2CPP_EXTERN_C void WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshal_pinvoke(const WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30& unmarshaled, WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshaled_pinvoke& marshaled)
{
	Exception_t* ____previous_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_previous' of type 'WriteStack'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____previous_2Exception, NULL);
}
IL2CPP_EXTERN_C void WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshal_pinvoke_back(const WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshaled_pinvoke& marshaled, WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30& unmarshaled)
{
	Exception_t* ____previous_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_previous' of type 'WriteStack'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____previous_2Exception, NULL);
}
// Conversion method for clean up from marshalling of: System.Text.Json.WriteStack
IL2CPP_EXTERN_C void WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshal_pinvoke_cleanup(WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshaled_pinvoke& marshaled)
{
}


// Conversion methods for marshalling of: System.Text.Json.WriteStack
IL2CPP_EXTERN_C void WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshal_com(const WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30& unmarshaled, WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshaled_com& marshaled)
{
	Exception_t* ____previous_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_previous' of type 'WriteStack'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____previous_2Exception, NULL);
}
IL2CPP_EXTERN_C void WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshal_com_back(const WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshaled_com& marshaled, WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30& unmarshaled)
{
	Exception_t* ____previous_2Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_previous' of type 'WriteStack'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____previous_2Exception, NULL);
}
// Conversion method for clean up from marshalling of: System.Text.Json.WriteStack
IL2CPP_EXTERN_C void WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshal_com_cleanup(WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30_marshaled_com& marshaled)
{
}
// System.Boolean System.Text.Json.WriteStack::get_IsContinuation()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool WriteStack_get_IsContinuation_m88FEB1F19992286B54F88DE66079DAA6CB1BF319 (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__continuationCount_0();
		return (bool)((!(((uint32_t)L_0) <= ((uint32_t)0)))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool WriteStack_get_IsContinuation_m88FEB1F19992286B54F88DE66079DAA6CB1BF319_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * _thisAdjusted = reinterpret_cast<WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 *>(__this + _offset);
	bool _returnValue;
	_returnValue = WriteStack_get_IsContinuation_m88FEB1F19992286B54F88DE66079DAA6CB1BF319(_thisAdjusted, method);
	return _returnValue;
}
// System.Void System.Text.Json.WriteStack::AddCurrent()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStack_AddCurrent_m47F360C33799C68FED06B57AA0321371A5A4CF68 (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_mF57A675DC30E3A30C75C7B19903BB3AB771AA743_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_mA95BD97532A917EFABAEB51DDE1649AF93AA28DF_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_mAF5A5D24EE6E3206F64DF2764D69FE6EEDB40E90_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_set_Item_mAF32960D79EBF6119BA8C7632444CFD38AC1DF75_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * L_0 = __this->get__previous_2();
		if (L_0)
		{
			goto IL_0013;
		}
	}
	{
		List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * L_1 = (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 *)il2cpp_codegen_object_new(List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5_il2cpp_TypeInfo_var);
		List_1__ctor_mA95BD97532A917EFABAEB51DDE1649AF93AA28DF(L_1, /*hidden argument*/List_1__ctor_mA95BD97532A917EFABAEB51DDE1649AF93AA28DF_RuntimeMethod_var);
		__this->set__previous_2(L_1);
	}

IL_0013:
	{
		int32_t L_2 = __this->get__count_1();
		List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * L_3 = __this->get__previous_2();
		NullCheck(L_3);
		int32_t L_4;
		L_4 = List_1_get_Count_mAF5A5D24EE6E3206F64DF2764D69FE6EEDB40E90_inline(L_3, /*hidden argument*/List_1_get_Count_mAF5A5D24EE6E3206F64DF2764D69FE6EEDB40E90_RuntimeMethod_var);
		if ((((int32_t)L_2) <= ((int32_t)L_4)))
		{
			goto IL_0039;
		}
	}
	{
		List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * L_5 = __this->get__previous_2();
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  L_6 = __this->get_Current_3();
		NullCheck(L_5);
		List_1_Add_mF57A675DC30E3A30C75C7B19903BB3AB771AA743(L_5, L_6, /*hidden argument*/List_1_Add_mF57A675DC30E3A30C75C7B19903BB3AB771AA743_RuntimeMethod_var);
		goto IL_0052;
	}

IL_0039:
	{
		List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * L_7 = __this->get__previous_2();
		int32_t L_8 = __this->get__count_1();
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  L_9 = __this->get_Current_3();
		NullCheck(L_7);
		List_1_set_Item_mAF32960D79EBF6119BA8C7632444CFD38AC1DF75(L_7, ((int32_t)il2cpp_codegen_subtract((int32_t)L_8, (int32_t)1)), L_9, /*hidden argument*/List_1_set_Item_mAF32960D79EBF6119BA8C7632444CFD38AC1DF75_RuntimeMethod_var);
	}

IL_0052:
	{
		int32_t L_10 = __this->get__count_1();
		__this->set__count_1(((int32_t)il2cpp_codegen_add((int32_t)L_10, (int32_t)1)));
		return;
	}
}
IL2CPP_EXTERN_C  void WriteStack_AddCurrent_m47F360C33799C68FED06B57AA0321371A5A4CF68_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * _thisAdjusted = reinterpret_cast<WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 *>(__this + _offset);
	WriteStack_AddCurrent_m47F360C33799C68FED06B57AA0321371A5A4CF68(_thisAdjusted, method);
}
// System.Text.Json.Serialization.JsonConverter System.Text.Json.WriteStack::Initialize(System.Type,System.Text.Json.JsonSerializerOptions,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * WriteStack_Initialize_m1BA93CE9F8C4B1A365B61E8AF2A3B0D1FBCF7F3F (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, Type_t * ___type0, JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * ___options1, bool ___supportContinuation2, const RuntimeMethod* method)
{
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * V_0 = NULL;
	{
		JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * L_0 = ___options1;
		Type_t * L_1 = ___type0;
		NullCheck(L_0);
		JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * L_2;
		L_2 = JsonSerializerOptions_GetOrAddClassForRootType_mD9ECD25EC6AA5ECFD8AB35CA89BA487C6AE2EC8A(L_0, L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_3 = __this->get_address_of_Current_3();
		JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * L_4 = V_0;
		L_3->set_JsonClassInfo_3(L_4);
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_5 = __this->get_address_of_Current_3();
		JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * L_6 = V_0;
		NullCheck(L_6);
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_7;
		L_7 = JsonClassInfo_get_PropertyInfoForClassInfo_m43DD25A15635FAD68648F55AD79A8B6FB15433FC_inline(L_6, /*hidden argument*/NULL);
		L_5->set_DeclaredJsonPropertyInfo_1(L_7);
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_8 = __this->get_address_of_Current_3();
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_9 = __this->get_address_of_Current_3();
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_10 = L_9->get_DeclaredJsonPropertyInfo_1();
		NullCheck(L_10);
		Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  L_11;
		L_11 = JsonPropertyInfo_get_NumberHandling_m3F57EC55C9CC7CE9C1017CBF1B737759673F3947_inline(L_10, /*hidden argument*/NULL);
		L_8->set_NumberHandling_12(L_11);
		JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * L_12 = ___options1;
		NullCheck(L_12);
		ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * L_13;
		L_13 = JsonSerializerOptions_get_ReferenceHandler_m0617CB46B783371338540A3A470133DE6CB5CD9A_inline(L_12, /*hidden argument*/NULL);
		if (!L_13)
		{
			goto IL_005a;
		}
	}
	{
		JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * L_14 = ___options1;
		NullCheck(L_14);
		ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * L_15;
		L_15 = JsonSerializerOptions_get_ReferenceHandler_m0617CB46B783371338540A3A470133DE6CB5CD9A_inline(L_14, /*hidden argument*/NULL);
		NullCheck(L_15);
		ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 * L_16;
		L_16 = VirtFuncInvoker1< ReferenceResolver_t087C19EF63D0709C29E27E16D0BF0DA510BEBE87 *, bool >::Invoke(5 /* System.Text.Json.Serialization.ReferenceResolver System.Text.Json.Serialization.ReferenceHandler::CreateResolver(System.Boolean) */, L_15, (bool)1);
		__this->set_ReferenceResolver_5(L_16);
	}

IL_005a:
	{
		bool L_17 = ___supportContinuation2;
		__this->set_SupportContinuation_6(L_17);
		JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * L_18 = V_0;
		NullCheck(L_18);
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_19;
		L_19 = JsonClassInfo_get_PropertyInfoForClassInfo_m43DD25A15635FAD68648F55AD79A8B6FB15433FC_inline(L_18, /*hidden argument*/NULL);
		NullCheck(L_19);
		JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * L_20;
		L_20 = VirtFuncInvoker0< JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * >::Invoke(4 /* System.Text.Json.Serialization.JsonConverter System.Text.Json.JsonPropertyInfo::get_ConverterBase() */, L_19);
		return L_20;
	}
}
IL2CPP_EXTERN_C  JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * WriteStack_Initialize_m1BA93CE9F8C4B1A365B61E8AF2A3B0D1FBCF7F3F_AdjustorThunk (RuntimeObject * __this, Type_t * ___type0, JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * ___options1, bool ___supportContinuation2, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * _thisAdjusted = reinterpret_cast<WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 *>(__this + _offset);
	JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * _returnValue;
	_returnValue = WriteStack_Initialize_m1BA93CE9F8C4B1A365B61E8AF2A3B0D1FBCF7F3F(_thisAdjusted, ___type0, ___options1, ___supportContinuation2, method);
	return _returnValue;
}
// System.Void System.Text.Json.WriteStack::Push()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStack_Push_mEFB808A906431C95FBFE4A654F9FEFB8C962F048 (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Nullable_1_get_HasValue_m92429A0BA8A6F4D11389C83E7568D8A9FFB3410B_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * V_0 = NULL;
	Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  V_1;
	memset((&V_1), 0, sizeof(V_1));
	Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  V_2;
	memset((&V_2), 0, sizeof(V_2));
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * G_B5_0 = NULL;
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * G_B4_0 = NULL;
	Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  G_B6_0;
	memset((&G_B6_0), 0, sizeof(G_B6_0));
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * G_B6_1 = NULL;
	{
		int32_t L_0 = __this->get__continuationCount_0();
		if (L_0)
		{
			goto IL_0090;
		}
	}
	{
		int32_t L_1 = __this->get__count_1();
		if (L_1)
		{
			goto IL_001b;
		}
	}
	{
		__this->set__count_1(1);
		return;
	}

IL_001b:
	{
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_2 = __this->get_address_of_Current_3();
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_3;
		L_3 = WriteStackFrame_GetPolymorphicJsonPropertyInfo_mC6241293FD5975BCF17AE77AAD2A1735932D473C((WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 *)L_2, /*hidden argument*/NULL);
		NullCheck(L_3);
		JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * L_4;
		L_4 = JsonPropertyInfo_get_RuntimeClassInfo_m8CF6F07A07ED366B98034C37161FF6A37C5FEC96(L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_5 = __this->get_address_of_Current_3();
		Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  L_6 = L_5->get_NumberHandling_12();
		V_1 = L_6;
		WriteStack_AddCurrent_m47F360C33799C68FED06B57AA0321371A5A4CF68((WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 *)__this, /*hidden argument*/NULL);
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_7 = __this->get_address_of_Current_3();
		WriteStackFrame_Reset_m919F66E6B37A5AABD075DF89DC00723E2FE74485((WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 *)L_7, /*hidden argument*/NULL);
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_8 = __this->get_address_of_Current_3();
		JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * L_9 = V_0;
		L_8->set_JsonClassInfo_3(L_9);
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_10 = __this->get_address_of_Current_3();
		JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * L_11 = V_0;
		NullCheck(L_11);
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_12;
		L_12 = JsonClassInfo_get_PropertyInfoForClassInfo_m43DD25A15635FAD68648F55AD79A8B6FB15433FC_inline(L_11, /*hidden argument*/NULL);
		L_10->set_DeclaredJsonPropertyInfo_1(L_12);
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_13 = __this->get_address_of_Current_3();
		Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  L_14 = V_1;
		V_2 = L_14;
		bool L_15;
		L_15 = Nullable_1_get_HasValue_m92429A0BA8A6F4D11389C83E7568D8A9FFB3410B_inline((Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58 *)(&V_2), /*hidden argument*/Nullable_1_get_HasValue_m92429A0BA8A6F4D11389C83E7568D8A9FFB3410B_RuntimeMethod_var);
		G_B4_0 = L_13;
		if (L_15)
		{
			G_B5_0 = L_13;
			goto IL_0089;
		}
	}
	{
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_16 = __this->get_address_of_Current_3();
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_17 = L_16->get_DeclaredJsonPropertyInfo_1();
		NullCheck(L_17);
		Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  L_18;
		L_18 = JsonPropertyInfo_get_NumberHandling_m3F57EC55C9CC7CE9C1017CBF1B737759673F3947_inline(L_17, /*hidden argument*/NULL);
		G_B6_0 = L_18;
		G_B6_1 = G_B4_0;
		goto IL_008a;
	}

IL_0089:
	{
		Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  L_19 = V_2;
		G_B6_0 = L_19;
		G_B6_1 = G_B5_0;
	}

IL_008a:
	{
		G_B6_1->set_NumberHandling_12(G_B6_0);
		return;
	}

IL_0090:
	{
		int32_t L_20 = __this->get__continuationCount_0();
		if ((!(((uint32_t)L_20) == ((uint32_t)1))))
		{
			goto IL_00a1;
		}
	}
	{
		__this->set__continuationCount_0(0);
		return;
	}

IL_00a1:
	{
		List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * L_21 = __this->get__previous_2();
		int32_t L_22 = __this->get__count_1();
		NullCheck(L_21);
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  L_23;
		L_23 = List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_inline(L_21, ((int32_t)il2cpp_codegen_subtract((int32_t)L_22, (int32_t)1)), /*hidden argument*/List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_RuntimeMethod_var);
		__this->set_Current_3(L_23);
		int32_t L_24 = __this->get__count_1();
		int32_t L_25 = __this->get__continuationCount_0();
		if ((!(((uint32_t)L_24) == ((uint32_t)L_25))))
		{
			goto IL_00d0;
		}
	}
	{
		__this->set__continuationCount_0(0);
		return;
	}

IL_00d0:
	{
		int32_t L_26 = __this->get__count_1();
		__this->set__count_1(((int32_t)il2cpp_codegen_add((int32_t)L_26, (int32_t)1)));
		return;
	}
}
IL2CPP_EXTERN_C  void WriteStack_Push_mEFB808A906431C95FBFE4A654F9FEFB8C962F048_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * _thisAdjusted = reinterpret_cast<WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 *>(__this + _offset);
	WriteStack_Push_mEFB808A906431C95FBFE4A654F9FEFB8C962F048(_thisAdjusted, method);
}
// System.Void System.Text.Json.WriteStack::Pop(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStack_Pop_mA03ABCC412B4F0C5720FB1774D6A61F716450B48 (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, bool ___success0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_set_Item_mAF32960D79EBF6119BA8C7632444CFD38AC1DF75_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		bool L_0 = ___success0;
		if (L_0)
		{
			goto IL_0091;
		}
	}
	{
		int32_t L_1 = __this->get__continuationCount_0();
		if (L_1)
		{
			goto IL_006e;
		}
	}
	{
		int32_t L_2 = __this->get__count_1();
		if ((!(((uint32_t)L_2) == ((uint32_t)1))))
		{
			goto IL_0026;
		}
	}
	{
		__this->set__continuationCount_0(1);
		__this->set__count_1(1);
		return;
	}

IL_0026:
	{
		WriteStack_AddCurrent_m47F360C33799C68FED06B57AA0321371A5A4CF68((WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 *)__this, /*hidden argument*/NULL);
		int32_t L_3 = __this->get__count_1();
		__this->set__count_1(((int32_t)il2cpp_codegen_subtract((int32_t)L_3, (int32_t)1)));
		int32_t L_4 = __this->get__count_1();
		__this->set__continuationCount_0(L_4);
		int32_t L_5 = __this->get__count_1();
		__this->set__count_1(((int32_t)il2cpp_codegen_subtract((int32_t)L_5, (int32_t)1)));
		List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * L_6 = __this->get__previous_2();
		int32_t L_7 = __this->get__count_1();
		NullCheck(L_6);
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  L_8;
		L_8 = List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_inline(L_6, ((int32_t)il2cpp_codegen_subtract((int32_t)L_7, (int32_t)1)), /*hidden argument*/List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_RuntimeMethod_var);
		__this->set_Current_3(L_8);
		return;
	}

IL_006e:
	{
		int32_t L_9 = __this->get__continuationCount_0();
		if ((!(((uint32_t)L_9) == ((uint32_t)1))))
		{
			goto IL_0078;
		}
	}
	{
		return;
	}

IL_0078:
	{
		List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * L_10 = __this->get__previous_2();
		int32_t L_11 = __this->get__count_1();
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  L_12 = __this->get_Current_3();
		NullCheck(L_10);
		List_1_set_Item_mAF32960D79EBF6119BA8C7632444CFD38AC1DF75(L_10, ((int32_t)il2cpp_codegen_subtract((int32_t)L_11, (int32_t)1)), L_12, /*hidden argument*/List_1_set_Item_mAF32960D79EBF6119BA8C7632444CFD38AC1DF75_RuntimeMethod_var);
	}

IL_0091:
	{
		int32_t L_13 = __this->get__count_1();
		if ((((int32_t)L_13) <= ((int32_t)1)))
		{
			goto IL_00be;
		}
	}
	{
		List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * L_14 = __this->get__previous_2();
		int32_t L_15 = __this->get__count_1();
		V_0 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_15, (int32_t)1));
		int32_t L_16 = V_0;
		__this->set__count_1(L_16);
		int32_t L_17 = V_0;
		NullCheck(L_14);
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  L_18;
		L_18 = List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_inline(L_14, ((int32_t)il2cpp_codegen_subtract((int32_t)L_17, (int32_t)1)), /*hidden argument*/List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_RuntimeMethod_var);
		__this->set_Current_3(L_18);
	}

IL_00be:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void WriteStack_Pop_mA03ABCC412B4F0C5720FB1774D6A61F716450B48_AdjustorThunk (RuntimeObject * __this, bool ___success0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * _thisAdjusted = reinterpret_cast<WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 *>(__this + _offset);
	WriteStack_Pop_mA03ABCC412B4F0C5720FB1774D6A61F716450B48(_thisAdjusted, ___success0, method);
}
// System.String System.Text.Json.WriteStack::PropertyPath()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* WriteStack_PropertyPath_m2B7C7609CF52ABC0DCCB60162CB58BFEA3EE4969 (WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StringBuilder_t_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral9E6DEA6E609FD74FD29A7E5BB6D900CCBA5F3FBF);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t * V_0 = NULL;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  V_3;
	memset((&V_3), 0, sizeof(V_3));
	{
		StringBuilder_t * L_0 = (StringBuilder_t *)il2cpp_codegen_object_new(StringBuilder_t_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m9305A36F9CF53EDD80D132428999934C68904C77(L_0, _stringLiteral9E6DEA6E609FD74FD29A7E5BB6D900CCBA5F3FBF, /*hidden argument*/NULL);
		V_0 = L_0;
		int32_t L_1 = __this->get__count_1();
		int32_t L_2 = __this->get__continuationCount_0();
		IL2CPP_RUNTIME_CLASS_INIT(Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		int32_t L_3;
		L_3 = Math_Max_mD8AA27386BF012C65303FCDEA041B0CC65056E7B(L_1, L_2, /*hidden argument*/NULL);
		V_1 = L_3;
		V_2 = 0;
		goto IL_003a;
	}

IL_0021:
	{
		StringBuilder_t * L_4 = V_0;
		List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * L_5 = __this->get__previous_2();
		int32_t L_6 = V_2;
		NullCheck(L_5);
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  L_7;
		L_7 = List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_inline(L_5, L_6, /*hidden argument*/List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_RuntimeMethod_var);
		V_3 = L_7;
		WriteStack_U3CPropertyPathU3Eg__AppendStackFrameU7C13_0_mFA8217E89FE0DFE851708748202127A07F74AEBA(L_4, (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 *)(&V_3), /*hidden argument*/NULL);
		int32_t L_8 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add((int32_t)L_8, (int32_t)1));
	}

IL_003a:
	{
		int32_t L_9 = V_2;
		int32_t L_10 = V_1;
		if ((((int32_t)L_9) < ((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_10, (int32_t)1)))))
		{
			goto IL_0021;
		}
	}
	{
		int32_t L_11 = __this->get__continuationCount_0();
		if (L_11)
		{
			goto IL_0054;
		}
	}
	{
		StringBuilder_t * L_12 = V_0;
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_13 = __this->get_address_of_Current_3();
		WriteStack_U3CPropertyPathU3Eg__AppendStackFrameU7C13_0_mFA8217E89FE0DFE851708748202127A07F74AEBA(L_12, (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 *)L_13, /*hidden argument*/NULL);
	}

IL_0054:
	{
		StringBuilder_t * L_14 = V_0;
		NullCheck(L_14);
		String_t* L_15;
		L_15 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_14);
		return L_15;
	}
}
IL2CPP_EXTERN_C  String_t* WriteStack_PropertyPath_m2B7C7609CF52ABC0DCCB60162CB58BFEA3EE4969_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 * _thisAdjusted = reinterpret_cast<WriteStack_t624F9C4FD4312A83B1BB9AFDC475267AC88CAE30 *>(__this + _offset);
	String_t* _returnValue;
	_returnValue = WriteStack_PropertyPath_m2B7C7609CF52ABC0DCCB60162CB58BFEA3EE4969(_thisAdjusted, method);
	return _returnValue;
}
// System.Void System.Text.Json.WriteStack::<PropertyPath>g__AppendStackFrame|13_0(System.Text.StringBuilder,System.Text.Json.WriteStackFrame&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStack_U3CPropertyPathU3Eg__AppendStackFrameU7C13_0_mFA8217E89FE0DFE851708748202127A07F74AEBA (StringBuilder_t * ___sb0, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * ___frame1, const RuntimeMethod* method)
{
	String_t* V_0 = NULL;
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * G_B2_0 = NULL;
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * G_B1_0 = NULL;
	String_t* G_B5_0 = NULL;
	MemberInfo_t * G_B4_0 = NULL;
	MemberInfo_t * G_B3_0 = NULL;
	{
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_0 = ___frame1;
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_1 = L_0->get_DeclaredJsonPropertyInfo_1();
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_2 = L_1;
		G_B1_0 = L_2;
		if (L_2)
		{
			G_B2_0 = L_2;
			goto IL_000d;
		}
	}
	{
		G_B5_0 = ((String_t*)(NULL));
		goto IL_001e;
	}

IL_000d:
	{
		NullCheck(G_B2_0);
		MemberInfo_t * L_3;
		L_3 = JsonPropertyInfo_get_MemberInfo_mDB50F867A36435920C12ED71CA72580FF7EB3A8E_inline(G_B2_0, /*hidden argument*/NULL);
		MemberInfo_t * L_4 = L_3;
		G_B3_0 = L_4;
		if (L_4)
		{
			G_B4_0 = L_4;
			goto IL_0019;
		}
	}
	{
		G_B5_0 = ((String_t*)(NULL));
		goto IL_001e;
	}

IL_0019:
	{
		NullCheck(G_B4_0);
		String_t* L_5;
		L_5 = VirtFuncInvoker0< String_t* >::Invoke(7 /* System.String System.Reflection.MemberInfo::get_Name() */, G_B4_0);
		G_B5_0 = L_5;
	}

IL_001e:
	{
		V_0 = G_B5_0;
		String_t* L_6 = V_0;
		if (L_6)
		{
			goto IL_0029;
		}
	}
	{
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * L_7 = ___frame1;
		String_t* L_8 = L_7->get_JsonPropertyNameAsString_9();
		V_0 = L_8;
	}

IL_0029:
	{
		StringBuilder_t * L_9 = ___sb0;
		String_t* L_10 = V_0;
		WriteStack_U3CPropertyPathU3Eg__AppendPropertyNameU7C13_1_m5A499E425FD4D40245FC2BDDF6CB558870F6A287(L_9, L_10, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Text.Json.WriteStack::<PropertyPath>g__AppendPropertyName|13_1(System.Text.StringBuilder,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStack_U3CPropertyPathU3Eg__AppendPropertyNameU7C13_1_m5A499E425FD4D40245FC2BDDF6CB558870F6A287 (StringBuilder_t * ___sb0, String_t* ___propertyName1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral158765DAD906DF36B8505DD381B603F9A0F345A1);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral9D64FD021538BBCA256D783E52916EC66D2582E4);
		s_Il2CppMethodInitialized = true;
	}
	{
		String_t* L_0 = ___propertyName1;
		if (!L_0)
		{
			goto IL_0043;
		}
	}
	{
		String_t* L_1 = ___propertyName1;
		IL2CPP_RUNTIME_CLASS_INIT(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E_il2cpp_TypeInfo_var);
		CharU5BU5D_t7B7FC5BC8091AA3B9CB0B29CDD80B5EE9254AA34* L_2 = ((ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E_StaticFields*)il2cpp_codegen_static_fields_for(ReadStack_t14CBAF200D5EA9722FC42A7DBFA991438573447E_il2cpp_TypeInfo_var))->get_SpecialCharacters_0();
		NullCheck(L_1);
		int32_t L_3;
		L_3 = String_IndexOfAny_m7E9204CF616E533528CC448D05BC8AF97A7D8038(L_1, L_2, /*hidden argument*/NULL);
		if ((((int32_t)L_3) == ((int32_t)(-1))))
		{
			goto IL_0032;
		}
	}
	{
		StringBuilder_t * L_4 = ___sb0;
		NullCheck(L_4);
		StringBuilder_t * L_5;
		L_5 = StringBuilder_Append_mD02AB0C74C6F55E3E330818C77EC147E22096FB1(L_4, _stringLiteral9D64FD021538BBCA256D783E52916EC66D2582E4, /*hidden argument*/NULL);
		StringBuilder_t * L_6 = ___sb0;
		String_t* L_7 = ___propertyName1;
		NullCheck(L_6);
		StringBuilder_t * L_8;
		L_8 = StringBuilder_Append_mD02AB0C74C6F55E3E330818C77EC147E22096FB1(L_6, L_7, /*hidden argument*/NULL);
		StringBuilder_t * L_9 = ___sb0;
		NullCheck(L_9);
		StringBuilder_t * L_10;
		L_10 = StringBuilder_Append_mD02AB0C74C6F55E3E330818C77EC147E22096FB1(L_9, _stringLiteral158765DAD906DF36B8505DD381B603F9A0F345A1, /*hidden argument*/NULL);
		return;
	}

IL_0032:
	{
		StringBuilder_t * L_11 = ___sb0;
		NullCheck(L_11);
		StringBuilder_t * L_12;
		L_12 = StringBuilder_Append_m1ADA3C16E40BF253BCDB5F9579B4DBA9C3E5B22E(L_11, ((int32_t)46), /*hidden argument*/NULL);
		StringBuilder_t * L_13 = ___sb0;
		String_t* L_14 = ___propertyName1;
		NullCheck(L_13);
		StringBuilder_t * L_15;
		L_15 = StringBuilder_Append_mD02AB0C74C6F55E3E330818C77EC147E22096FB1(L_13, L_14, /*hidden argument*/NULL);
	}

IL_0043:
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: System.Text.Json.WriteStackFrame
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_pinvoke(const WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9& unmarshaled, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_pinvoke& marshaled)
{
	Exception_t* ___CollectionEnumerator_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'CollectionEnumerator' of type 'WriteStackFrame': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___CollectionEnumerator_0Exception, NULL);
}
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_pinvoke_back(const WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_pinvoke& marshaled, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9& unmarshaled)
{
	Exception_t* ___CollectionEnumerator_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'CollectionEnumerator' of type 'WriteStackFrame': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___CollectionEnumerator_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: System.Text.Json.WriteStackFrame
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_pinvoke_cleanup(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: System.Text.Json.WriteStackFrame
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_com(const WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9& unmarshaled, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_com& marshaled)
{
	Exception_t* ___CollectionEnumerator_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'CollectionEnumerator' of type 'WriteStackFrame': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___CollectionEnumerator_0Exception, NULL);
}
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_com_back(const WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_com& marshaled, WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9& unmarshaled)
{
	Exception_t* ___CollectionEnumerator_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'CollectionEnumerator' of type 'WriteStackFrame': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___CollectionEnumerator_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: System.Text.Json.WriteStackFrame
IL2CPP_EXTERN_C void WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshal_com_cleanup(WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9_marshaled_com& marshaled)
{
}
// System.Void System.Text.Json.WriteStackFrame::EndDictionaryElement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStackFrame_EndDictionaryElement_mF8B3A60F6AAB6D4EF329FC9EC0026B1BF43A184B (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * __this, const RuntimeMethod* method)
{
	{
		__this->set_PropertyState_7(0);
		return;
	}
}
IL2CPP_EXTERN_C  void WriteStackFrame_EndDictionaryElement_mF8B3A60F6AAB6D4EF329FC9EC0026B1BF43A184B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * _thisAdjusted = reinterpret_cast<WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 *>(__this + _offset);
	WriteStackFrame_EndDictionaryElement_mF8B3A60F6AAB6D4EF329FC9EC0026B1BF43A184B(_thisAdjusted, method);
}
// System.Void System.Text.Json.WriteStackFrame::EndProperty()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStackFrame_EndProperty_mFD22836ABA865D92442FBBC0E612A51A74F0F503 (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * __this, const RuntimeMethod* method)
{
	{
		__this->set_DeclaredJsonPropertyInfo_1((JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F *)NULL);
		__this->set_JsonPropertyNameAsString_9((String_t*)NULL);
		__this->set_PolymorphicJsonPropertyInfo_11((JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F *)NULL);
		__this->set_PropertyState_7(0);
		return;
	}
}
IL2CPP_EXTERN_C  void WriteStackFrame_EndProperty_mFD22836ABA865D92442FBBC0E612A51A74F0F503_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * _thisAdjusted = reinterpret_cast<WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 *>(__this + _offset);
	WriteStackFrame_EndProperty_mFD22836ABA865D92442FBBC0E612A51A74F0F503(_thisAdjusted, method);
}
// System.Text.Json.JsonPropertyInfo System.Text.Json.WriteStackFrame::GetPolymorphicJsonPropertyInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * WriteStackFrame_GetPolymorphicJsonPropertyInfo_mC6241293FD5975BCF17AE77AAD2A1735932D473C (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * __this, const RuntimeMethod* method)
{
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * G_B2_0 = NULL;
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * G_B1_0 = NULL;
	{
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_0 = __this->get_PolymorphicJsonPropertyInfo_11();
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_1 = L_0;
		G_B1_0 = L_1;
		if (L_1)
		{
			G_B2_0 = L_1;
			goto IL_0010;
		}
	}
	{
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_2 = __this->get_DeclaredJsonPropertyInfo_1();
		G_B2_0 = L_2;
	}

IL_0010:
	{
		return G_B2_0;
	}
}
IL2CPP_EXTERN_C  JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * WriteStackFrame_GetPolymorphicJsonPropertyInfo_mC6241293FD5975BCF17AE77AAD2A1735932D473C_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * _thisAdjusted = reinterpret_cast<WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 *>(__this + _offset);
	JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * _returnValue;
	_returnValue = WriteStackFrame_GetPolymorphicJsonPropertyInfo_mC6241293FD5975BCF17AE77AAD2A1735932D473C(_thisAdjusted, method);
	return _returnValue;
}
// System.Text.Json.Serialization.JsonConverter System.Text.Json.WriteStackFrame::InitializeReEntry(System.Type,System.Text.Json.JsonSerializerOptions,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * WriteStackFrame_InitializeReEntry_m6F30B6BDCE7931B9867F8DE7CE69299CA0C5330B (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * __this, Type_t * ___type0, JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * ___options1, String_t* ___propertyName2, const RuntimeMethod* method)
{
	JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * V_0 = NULL;
	{
		JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * L_0 = ___options1;
		Type_t * L_1 = ___type0;
		NullCheck(L_0);
		JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * L_2;
		L_2 = JsonSerializerOptions_GetOrAddClass_mC4C69C74911631072200AD6AB5A4343176D95D07(L_0, L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		String_t* L_3 = ___propertyName2;
		__this->set_JsonPropertyNameAsString_9(L_3);
		JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * L_4 = V_0;
		NullCheck(L_4);
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_5;
		L_5 = JsonClassInfo_get_PropertyInfoForClassInfo_m43DD25A15635FAD68648F55AD79A8B6FB15433FC_inline(L_4, /*hidden argument*/NULL);
		__this->set_PolymorphicJsonPropertyInfo_11(L_5);
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_6 = __this->get_PolymorphicJsonPropertyInfo_11();
		NullCheck(L_6);
		JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * L_7;
		L_7 = VirtFuncInvoker0< JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * >::Invoke(4 /* System.Text.Json.Serialization.JsonConverter System.Text.Json.JsonPropertyInfo::get_ConverterBase() */, L_6);
		return L_7;
	}
}
IL2CPP_EXTERN_C  JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * WriteStackFrame_InitializeReEntry_m6F30B6BDCE7931B9867F8DE7CE69299CA0C5330B_AdjustorThunk (RuntimeObject * __this, Type_t * ___type0, JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * ___options1, String_t* ___propertyName2, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * _thisAdjusted = reinterpret_cast<WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 *>(__this + _offset);
	JsonConverter_t251202A0A1DDA5AC5C3F7316E5532F3EA725CDB3 * _returnValue;
	_returnValue = WriteStackFrame_InitializeReEntry_m6F30B6BDCE7931B9867F8DE7CE69299CA0C5330B(_thisAdjusted, ___type0, ___options1, ___propertyName2, method);
	return _returnValue;
}
// System.Void System.Text.Json.WriteStackFrame::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WriteStackFrame_Reset_m919F66E6B37A5AABD075DF89DC00723E2FE74485 (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * __this, const RuntimeMethod* method)
{
	{
		__this->set_CollectionEnumerator_0((RuntimeObject*)NULL);
		__this->set_EnumeratorIndex_8(0);
		__this->set_IgnoreDictionaryKeyPolicy_2((bool)0);
		__this->set_JsonClassInfo_3((JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 *)NULL);
		__this->set_OriginalDepth_4(0);
		__this->set_ProcessedStartToken_5((bool)0);
		__this->set_ProcessedEndToken_6((bool)0);
		WriteStackFrame_EndProperty_mFD22836ABA865D92442FBBC0E612A51A74F0F503((WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 *)__this, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void WriteStackFrame_Reset_m919F66E6B37A5AABD075DF89DC00723E2FE74485_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 * _thisAdjusted = reinterpret_cast<WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 *>(__this + _offset);
	WriteStackFrame_Reset_m919F66E6B37A5AABD075DF89DC00723E2FE74485(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Text.Json.JsonClassInfo/ConstructorDelegate::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ConstructorDelegate__ctor_m8BF4F0FB25B31B565C9970B41F618B3E5FB0CFFA (ConstructorDelegate_t78F14D99A470B7AECB5D508869D8A4D62D40D0C0 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method)
{
	__this->set_method_ptr_0(il2cpp_codegen_get_method_pointer((RuntimeMethod*)___method1));
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Object System.Text.Json.JsonClassInfo/ConstructorDelegate::Invoke()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * ConstructorDelegate_Invoke_m9B0B0DE22F6407E28E7A905F4B2FD373B2176511 (ConstructorDelegate_t78F14D99A470B7AECB5D508869D8A4D62D40D0C0 * __this, const RuntimeMethod* method)
{
	RuntimeObject * result = NULL;
	DelegateU5BU5D_t677D8FE08A5F99E8EE49150B73966CD6E9BF7DB8* delegateArrayToInvoke = __this->get_delegates_11();
	Delegate_t** delegatesToInvoke;
	il2cpp_array_size_t length;
	if (delegateArrayToInvoke != NULL)
	{
		length = delegateArrayToInvoke->max_length;
		delegatesToInvoke = reinterpret_cast<Delegate_t**>(delegateArrayToInvoke->GetAddressAtUnchecked(0));
	}
	else
	{
		length = 1;
		delegatesToInvoke = reinterpret_cast<Delegate_t**>(&__this);
	}

	for (il2cpp_array_size_t i = 0; i < length; i++)
	{
		Delegate_t* currentDelegate = delegatesToInvoke[i];
		Il2CppMethodPointer targetMethodPointer = currentDelegate->get_method_ptr_0();
		RuntimeObject* targetThis = currentDelegate->get_m_target_2();
		RuntimeMethod* targetMethod = (RuntimeMethod*)(currentDelegate->get_method_3());
		if (!il2cpp_codegen_method_is_virtual(targetMethod))
		{
			il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found(targetMethod);
		}
		bool ___methodIsStatic = MethodIsStatic(targetMethod);
		int ___parameterCount = il2cpp_codegen_method_parameter_count(targetMethod);
		if (___methodIsStatic)
		{
			if (___parameterCount == 0)
			{
				// open
				typedef RuntimeObject * (*FunctionPointerType) (const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(targetMethod);
			}
			else
			{
				// closed
				typedef RuntimeObject * (*FunctionPointerType) (void*, const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(targetThis, targetMethod);
			}
		}
		else
		{
			// closed
			if (targetThis != NULL && il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_generic_instance(targetMethod))
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						result = GenericInterfaceFuncInvoker0< RuntimeObject * >::Invoke(targetMethod, targetThis);
					else
						result = GenericVirtFuncInvoker0< RuntimeObject * >::Invoke(targetMethod, targetThis);
				}
				else
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						result = InterfaceFuncInvoker0< RuntimeObject * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), targetThis);
					else
						result = VirtFuncInvoker0< RuntimeObject * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), targetThis);
				}
			}
			else
			{
				typedef RuntimeObject * (*FunctionPointerType) (void*, const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(targetThis, targetMethod);
			}
		}
	}
	return result;
}
// System.IAsyncResult System.Text.Json.JsonClassInfo/ConstructorDelegate::BeginInvoke(System.AsyncCallback,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* ConstructorDelegate_BeginInvoke_mF6CFC34D80BDB6C948FB6C79B6FBCAB3A70E4C08 (ConstructorDelegate_t78F14D99A470B7AECB5D508869D8A4D62D40D0C0 * __this, AsyncCallback_tA7921BEF974919C46FF8F9D9867C567B200BB0EA * ___callback0, RuntimeObject * ___object1, const RuntimeMethod* method)
{
	void *__d_args[1] = {0};
	return (RuntimeObject*)il2cpp_codegen_delegate_begin_invoke((RuntimeDelegate*)__this, __d_args, (RuntimeDelegate*)___callback0, (RuntimeObject*)___object1);;
}
// System.Object System.Text.Json.JsonClassInfo/ConstructorDelegate::EndInvoke(System.IAsyncResult)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * ConstructorDelegate_EndInvoke_mEC242178ABA2867DCF1A3C13E6F75AB2CF233216 (ConstructorDelegate_t78F14D99A470B7AECB5D508869D8A4D62D40D0C0 * __this, RuntimeObject* ___result0, const RuntimeMethod* method)
{
	RuntimeObject *__result = il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
	return (RuntimeObject *)__result;;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Text.Json.JsonClassInfo/ParameterLookupKey::.ctor(System.String,System.Type)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ParameterLookupKey__ctor_mE556DF61D1FA243C6204BA09DB581C64A01469D8 (ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * __this, String_t* ___name0, Type_t * ___type1, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___name0;
		__this->set_U3CNameU3Ek__BackingField_0(L_0);
		Type_t * L_1 = ___type1;
		__this->set_U3CTypeU3Ek__BackingField_1(L_1);
		return;
	}
}
// System.String System.Text.Json.JsonClassInfo/ParameterLookupKey::get_Name()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* ParameterLookupKey_get_Name_m048FB355797E2E00063B62A5FDB6A30CE1C543CC (ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_U3CNameU3Ek__BackingField_0();
		return L_0;
	}
}
// System.Type System.Text.Json.JsonClassInfo/ParameterLookupKey::get_Type()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Type_t * ParameterLookupKey_get_Type_m66F89A37473AEEDE2674D17D6FD97C773D54B23A (ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * __this, const RuntimeMethod* method)
{
	{
		Type_t * L_0 = __this->get_U3CTypeU3Ek__BackingField_1();
		return L_0;
	}
}
// System.Int32 System.Text.Json.JsonClassInfo/ParameterLookupKey::GetHashCode()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ParameterLookupKey_GetHashCode_m270F39E11121C94B24B3471AEA06E1396A8A962C (ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_il2cpp_TypeInfo_var);
		StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * L_0;
		L_0 = StringComparer_get_OrdinalIgnoreCase_m8FD38206B6FFE866E97CE4DF84B037F0DF175288_inline(/*hidden argument*/NULL);
		String_t* L_1;
		L_1 = ParameterLookupKey_get_Name_m048FB355797E2E00063B62A5FDB6A30CE1C543CC_inline(__this, /*hidden argument*/NULL);
		NullCheck(L_0);
		int32_t L_2;
		L_2 = VirtFuncInvoker1< int32_t, String_t* >::Invoke(12 /* System.Int32 System.StringComparer::GetHashCode(System.String) */, L_0, L_1);
		return L_2;
	}
}
// System.Boolean System.Text.Json.JsonClassInfo/ParameterLookupKey::Equals(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ParameterLookupKey_Equals_m763548E25FABB3FFC76054F10098EFB1D95E4F57 (ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Type_t_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * V_0 = NULL;
	{
		RuntimeObject * L_0 = ___obj0;
		V_0 = ((ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 *)CastclassSealed((RuntimeObject*)L_0, ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9_il2cpp_TypeInfo_var));
		Type_t * L_1;
		L_1 = ParameterLookupKey_get_Type_m66F89A37473AEEDE2674D17D6FD97C773D54B23A_inline(__this, /*hidden argument*/NULL);
		ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * L_2 = V_0;
		NullCheck(L_2);
		Type_t * L_3;
		L_3 = ParameterLookupKey_get_Type_m66F89A37473AEEDE2674D17D6FD97C773D54B23A_inline(L_2, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		bool L_4;
		L_4 = Type_op_Equality_mA438719A1FDF103C7BBBB08AEF564E7FAEEA0046(L_1, L_3, /*hidden argument*/NULL);
		if (!L_4)
		{
			goto IL_002d;
		}
	}
	{
		String_t* L_5;
		L_5 = ParameterLookupKey_get_Name_m048FB355797E2E00063B62A5FDB6A30CE1C543CC_inline(__this, /*hidden argument*/NULL);
		ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * L_6 = V_0;
		NullCheck(L_6);
		String_t* L_7;
		L_7 = ParameterLookupKey_get_Name_m048FB355797E2E00063B62A5FDB6A30CE1C543CC_inline(L_6, /*hidden argument*/NULL);
		bool L_8;
		L_8 = String_Equals_mD65682B0BB7933CC7A8561AE34DED02E4F3BBBE5(L_5, L_7, 5, /*hidden argument*/NULL);
		return L_8;
	}

IL_002d:
	{
		return (bool)0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Text.Json.JsonClassInfo/ParameterLookupValue::.ctor(System.Text.Json.JsonPropertyInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ParameterLookupValue__ctor_mD1613835BCF09DB67A265CB62B529F079E261816 (ParameterLookupValue_t4CD624C3EDE8825E6865586D118C4B839F1532A9 * __this, JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ___jsonPropertyInfo0, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_0 = ___jsonPropertyInfo0;
		__this->set_U3CJsonPropertyInfoU3Ek__BackingField_1(L_0);
		return;
	}
}
// System.String System.Text.Json.JsonClassInfo/ParameterLookupValue::get_DuplicateName()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* ParameterLookupValue_get_DuplicateName_m2846FDEB4E05B3167D754D5F2774A3F8FFDD3B50 (ParameterLookupValue_t4CD624C3EDE8825E6865586D118C4B839F1532A9 * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_U3CDuplicateNameU3Ek__BackingField_0();
		return L_0;
	}
}
// System.Void System.Text.Json.JsonClassInfo/ParameterLookupValue::set_DuplicateName(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ParameterLookupValue_set_DuplicateName_mE89B81F211FE3342D05118E95ACF64341027BB43 (ParameterLookupValue_t4CD624C3EDE8825E6865586D118C4B839F1532A9 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		String_t* L_0 = ___value0;
		__this->set_U3CDuplicateNameU3Ek__BackingField_0(L_0);
		return;
	}
}
// System.Text.Json.JsonPropertyInfo System.Text.Json.JsonClassInfo/ParameterLookupValue::get_JsonPropertyInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * ParameterLookupValue_get_JsonPropertyInfo_m8570A2FA9EDD6BFA2A1C5DE2B8AF26287C402CFA (ParameterLookupValue_t4CD624C3EDE8825E6865586D118C4B839F1532A9 * __this, const RuntimeMethod* method)
{
	{
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_0 = __this->get_U3CJsonPropertyInfoU3Ek__BackingField_1();
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Text.Json.JsonDocument/<ParseAsyncCore>d__57::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CParseAsyncCoreU3Ed__57_MoveNext_mD0675E98AF6165205178B6932DA7B1E452799396 (U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C_TisU3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335_m5FCB8074883D5A5D9777C6093EE677835300432F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&AsyncTaskMethodBuilder_1_SetResult_m5C03D366FBBD09A38148AF074E67325FCD891702_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ConfiguredTaskAwaitable_1_GetAwaiter_m80F1877E5304C1EB51E7F1E92D2C4CA3A9A3AC6D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ConfiguredTaskAwaiter_GetResult_mC723D4CAC0FFD2CB0AF9749A899E22F31CE1B8F6_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ConfiguredTaskAwaiter_get_IsCompleted_m2D230F04D69897DAD535B96F5F4581467DDDE0D8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsMemory_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m200D8CCE4E809AF8284BAF03FA13482EE5B0D282_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Memory_1_op_Implicit_mE940358A7E5B8CF728319481BB9080A44E2D914F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Task_1_ConfigureAwait_m0E2430C409BCD2B226EA4AC94C8DA1D8534513C7_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * V_1 = NULL;
	ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  V_2;
	memset((&V_2), 0, sizeof(V_2));
	ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  V_3;
	memset((&V_3), 0, sizeof(V_3));
	ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  V_4;
	memset((&V_4), 0, sizeof(V_4));
	ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8  V_5;
	memset((&V_5), 0, sizeof(V_5));
	Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  V_6;
	memset((&V_6), 0, sizeof(V_6));
	Exception_t * V_7 = NULL;
	il2cpp::utils::ExceptionSupportStack<RuntimeObject*, 2> __active_exceptions;
	il2cpp::utils::ExceptionSupportStack<int32_t, 3> __leave_targets;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
	}

IL_0007:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_1 = V_0;
			if (!L_1)
			{
				goto IL_0059;
			}
		}

IL_000a:
		{
			Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * L_2 = __this->get_utf8Json_2();
			CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  L_3 = __this->get_cancellationToken_3();
			Task_1_tCBE5A2ABED266F89E7F1CAC31F882816D804B985 * L_4;
			L_4 = JsonDocument_ReadToEndAsync_m13C80CFB1B36CE78A59A2F124018A078113338E4(L_2, L_3, /*hidden argument*/NULL);
			NullCheck(L_4);
			ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8  L_5;
			L_5 = Task_1_ConfigureAwait_m0E2430C409BCD2B226EA4AC94C8DA1D8534513C7(L_4, (bool)0, /*hidden argument*/Task_1_ConfigureAwait_m0E2430C409BCD2B226EA4AC94C8DA1D8534513C7_RuntimeMethod_var);
			V_5 = L_5;
			ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  L_6;
			L_6 = ConfiguredTaskAwaitable_1_GetAwaiter_m80F1877E5304C1EB51E7F1E92D2C4CA3A9A3AC6D_inline((ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8 *)(&V_5), /*hidden argument*/ConfiguredTaskAwaitable_1_GetAwaiter_m80F1877E5304C1EB51E7F1E92D2C4CA3A9A3AC6D_RuntimeMethod_var);
			V_4 = L_6;
			bool L_7;
			L_7 = ConfiguredTaskAwaiter_get_IsCompleted_m2D230F04D69897DAD535B96F5F4581467DDDE0D8((ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C *)(&V_4), /*hidden argument*/ConfiguredTaskAwaiter_get_IsCompleted_m2D230F04D69897DAD535B96F5F4581467DDDE0D8_RuntimeMethod_var);
			if (L_7)
			{
				goto IL_0076;
			}
		}

IL_0035:
		{
			int32_t L_8 = 0;
			V_0 = L_8;
			__this->set_U3CU3E1__state_0(L_8);
			ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  L_9 = V_4;
			__this->set_U3CU3Eu__1_5(L_9);
			AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 * L_10 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C_TisU3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335_m5FCB8074883D5A5D9777C6093EE677835300432F((AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 *)L_10, (ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C *)(&V_4), (U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C_TisU3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335_m5FCB8074883D5A5D9777C6093EE677835300432F_RuntimeMethod_var);
			goto IL_00f6;
		}

IL_0059:
		{
			ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  L_11 = __this->get_U3CU3Eu__1_5();
			V_4 = L_11;
			ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C * L_12 = __this->get_address_of_U3CU3Eu__1_5();
			il2cpp_codegen_initobj(L_12, sizeof(ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C ));
			int32_t L_13 = (-1);
			V_0 = L_13;
			__this->set_U3CU3E1__state_0(L_13);
		}

IL_0076:
		{
			ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  L_14;
			L_14 = ConfiguredTaskAwaiter_GetResult_mC723D4CAC0FFD2CB0AF9749A899E22F31CE1B8F6((ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C *)(&V_4), /*hidden argument*/ConfiguredTaskAwaiter_GetResult_mC723D4CAC0FFD2CB0AF9749A899E22F31CE1B8F6_RuntimeMethod_var);
			V_3 = L_14;
			ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  L_15 = V_3;
			V_2 = L_15;
		}

IL_0080:
		try
		{ // begin try (depth: 2)
			ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  L_16 = V_2;
			IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
			Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9  L_17;
			L_17 = MemoryExtensions_AsMemory_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m200D8CCE4E809AF8284BAF03FA13482EE5B0D282(L_16, /*hidden argument*/MemoryExtensions_AsMemory_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m200D8CCE4E809AF8284BAF03FA13482EE5B0D282_RuntimeMethod_var);
			ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  L_18;
			L_18 = Memory_1_op_Implicit_mE940358A7E5B8CF728319481BB9080A44E2D914F(L_17, /*hidden argument*/Memory_1_op_Implicit_mE940358A7E5B8CF728319481BB9080A44E2D914F_RuntimeMethod_var);
			JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675 * L_19 = __this->get_address_of_options_4();
			JsonReaderOptions_tD7C9A60EFCE572E4EA0AC3B1B0731900248253D3  L_20;
			L_20 = JsonDocumentOptions_GetReaderOptions_mB45CDABD01DCD171F5576B841FD948C183A3F4BC((JsonDocumentOptions_t418891DA23BEAC275F96171708DAA6C84110F675 *)L_19, /*hidden argument*/NULL);
			ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_21;
			L_21 = ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_inline((ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(&V_2), /*hidden argument*/ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_RuntimeMethod_var);
			JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * L_22;
			L_22 = JsonDocument_Parse_mDCD23B7F0D42C0481828DAA5ACCDEF6DFC858BE1(L_18, L_20, L_21, /*hidden argument*/NULL);
			V_1 = L_22;
			goto IL_00e2;
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			if(il2cpp_codegen_class_is_assignable_from (((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&RuntimeObject_il2cpp_TypeInfo_var)), il2cpp_codegen_object_class(e.ex)))
			{
				IL2CPP_PUSH_ACTIVE_EXCEPTION(e.ex);
				goto CATCH_00a5;
			}
			throw e;
		}

CATCH_00a5:
		{ // begin catch(System.Object)
			ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  L_23 = V_2;
			IL2CPP_RUNTIME_CLASS_INIT(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var)));
			Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_24;
			L_24 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mD932D4A4EC20A3549450351374B5D165258B0C91_inline(L_23, /*hidden argument*/((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mD932D4A4EC20A3549450351374B5D165258B0C91_RuntimeMethod_var)));
			V_6 = L_24;
			Span_1_Clear_mCD3767C2F151B946E3EEB3AD9CCD8EE0794F689C((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(&V_6), /*hidden argument*/((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Span_1_Clear_mCD3767C2F151B946E3EEB3AD9CCD8EE0794F689C_RuntimeMethod_var)));
			ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_25;
			L_25 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var)));
			ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_26;
			L_26 = ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_inline((ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(&V_2), /*hidden argument*/((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_RuntimeMethod_var)));
			NullCheck(L_25);
			VirtActionInvoker2< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, bool >::Invoke(5 /* System.Void System.Buffers.ArrayPool`1<System.Byte>::Return(!0[],System.Boolean) */, L_25, L_26, (bool)0);
			IL2CPP_RAISE_MANAGED_EXCEPTION(IL2CPP_GET_ACTIVE_EXCEPTION(Exception_t *), ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&U3CParseAsyncCoreU3Ed__57_MoveNext_mD0675E98AF6165205178B6932DA7B1E452799396_RuntimeMethod_var)));
		} // end catch (depth: 2)
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		if(il2cpp_codegen_class_is_assignable_from (((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Exception_t_il2cpp_TypeInfo_var)), il2cpp_codegen_object_class(e.ex)))
		{
			IL2CPP_PUSH_ACTIVE_EXCEPTION(e.ex);
			goto CATCH_00c9;
		}
		throw e;
	}

CATCH_00c9:
	{ // begin catch(System.Exception)
		V_7 = ((Exception_t *)IL2CPP_GET_ACTIVE_EXCEPTION(Exception_t *));
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 * L_27 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_28 = V_7;
		AsyncTaskMethodBuilder_1_SetException_m8298F499262BDEDE435D3FA226F4267C179B20D0((AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 *)L_27, L_28, /*hidden argument*/((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&AsyncTaskMethodBuilder_1_SetException_m8298F499262BDEDE435D3FA226F4267C179B20D0_RuntimeMethod_var)));
		IL2CPP_POP_ACTIVE_EXCEPTION();
		goto IL_00f6;
	} // end catch (depth: 1)

IL_00e2:
	{
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 * L_29 = __this->get_address_of_U3CU3Et__builder_1();
		JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * L_30 = V_1;
		AsyncTaskMethodBuilder_1_SetResult_m5C03D366FBBD09A38148AF074E67325FCD891702((AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 *)L_29, L_30, /*hidden argument*/AsyncTaskMethodBuilder_1_SetResult_m5C03D366FBBD09A38148AF074E67325FCD891702_RuntimeMethod_var);
	}

IL_00f6:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CParseAsyncCoreU3Ed__57_MoveNext_mD0675E98AF6165205178B6932DA7B1E452799396_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 * _thisAdjusted = reinterpret_cast<U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 *>(__this + _offset);
	U3CParseAsyncCoreU3Ed__57_MoveNext_mD0675E98AF6165205178B6932DA7B1E452799396(_thisAdjusted, method);
}
// System.Void System.Text.Json.JsonDocument/<ParseAsyncCore>d__57::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CParseAsyncCoreU3Ed__57_SetStateMachine_m5691C5FAE97992748A81440A273C884169FF58FF (U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&AsyncTaskMethodBuilder_1_SetStateMachine_m8EA71255760B118307FE9FCE898C563EBE80745E_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_1_SetStateMachine_m8EA71255760B118307FE9FCE898C563EBE80745E((AsyncTaskMethodBuilder_1_t0A471A82580AD870AC9A47AB73B836B6A9D82445 *)L_0, L_1, /*hidden argument*/AsyncTaskMethodBuilder_1_SetStateMachine_m8EA71255760B118307FE9FCE898C563EBE80745E_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CParseAsyncCoreU3Ed__57_SetStateMachine_m5691C5FAE97992748A81440A273C884169FF58FF_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 * _thisAdjusted = reinterpret_cast<U3CParseAsyncCoreU3Ed__57_tF9086E4726FEDB66FD7F41A973BEC27D97691335 *>(__this + _offset);
	U3CParseAsyncCoreU3Ed__57_SetStateMachine_m5691C5FAE97992748A81440A273C884169FF58FF(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReadToEndAsyncU3Ed__65_MoveNext_m6687BB75E19E97F8D89E828FA064629CB2F3390E (U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySegment_1__ctor_mAA780E22BB5AE07078510EDCE524DD1EA1E98E0D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2_TisU3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B_m179843A0565EF49F48ABDF6635C3E041743C36B9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&AsyncTaskMethodBuilder_1_SetResult_mB6426AE79AFDC2DCFDFD3F2CB765EA12494D7819_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ConfiguredTaskAwaitable_1_GetAwaiter_m8FA39505FC2099C60148C0F029CB49792690A0D5_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ConfiguredTaskAwaiter_GetResult_m0927E49E03619C51620F396FE1DD5DBD41AC6681_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ConfiguredTaskAwaiter_get_IsCompleted_m4192DC0E89B48FF93421FFF4EB52C21C42687999_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_SequenceEqual_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mA47AE57649F12A2400FE13BDC84254F05A99D1AA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Task_1_ConfigureAwait_m9637E2990F98EDC90D1A03B57A4954CE2171C4E2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CReadToEndAsyncU3Ed__65_MoveNext_m6687BB75E19E97F8D89E828FA064629CB2F3390E_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  V_1;
	memset((&V_1), 0, sizeof(V_1));
	int32_t V_2 = 0;
	ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  V_3;
	memset((&V_3), 0, sizeof(V_3));
	int64_t V_4 = 0;
	int32_t V_5 = 0;
	ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  V_6;
	memset((&V_6), 0, sizeof(V_6));
	ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC  V_7;
	memset((&V_7), 0, sizeof(V_7));
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* V_8 = NULL;
	int32_t V_9 = 0;
	ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  V_10;
	memset((&V_10), 0, sizeof(V_10));
	Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  V_11;
	memset((&V_11), 0, sizeof(V_11));
	Exception_t * V_12 = NULL;
	il2cpp::utils::ExceptionSupportStack<RuntimeObject*, 2> __active_exceptions;
	il2cpp::utils::ExceptionSupportStack<int32_t, 4> __leave_targets;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
	}

IL_0007:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_1 = V_0;
			if ((!(((uint32_t)L_1) > ((uint32_t)1))))
			{
				goto IL_0019;
			}
		}

IL_000b:
		{
			__this->set_U3CwrittenU3E5__2_4(0);
			__this->set_U3CrentedU3E5__3_5((ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)NULL);
		}

IL_0019:
		{
		}

IL_001a:
		try
		{ // begin try (depth: 2)
			{
				int32_t L_2 = V_0;
				if (!L_2)
				{
					goto IL_0101;
				}
			}

IL_0020:
			{
				int32_t L_3 = V_0;
				if ((((int32_t)L_3) == ((int32_t)1)))
				{
					goto IL_023d;
				}
			}

IL_0027:
			{
				ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_4;
				L_4 = JsonConstants_get_Utf8Bom_m3DC03C02C3987D2937211BF777AA50B8933BC778(/*hidden argument*/NULL);
				V_3 = L_4;
				int32_t L_5;
				L_5 = ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_inline((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(&V_3), /*hidden argument*/ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var);
				__this->set_U3Cutf8BomLengthU3E5__4_6(L_5);
				Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * L_6 = __this->get_stream_2();
				NullCheck(L_6);
				bool L_7;
				L_7 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean System.IO.Stream::get_CanSeek() */, L_6);
				if (!L_7)
				{
					goto IL_0084;
				}
			}

IL_0047:
			{
				int32_t L_8 = __this->get_U3Cutf8BomLengthU3E5__4_6();
				Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * L_9 = __this->get_stream_2();
				NullCheck(L_9);
				int64_t L_10;
				L_10 = VirtFuncInvoker0< int64_t >::Invoke(10 /* System.Int64 System.IO.Stream::get_Length() */, L_9);
				Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * L_11 = __this->get_stream_2();
				NullCheck(L_11);
				int64_t L_12;
				L_12 = VirtFuncInvoker0< int64_t >::Invoke(11 /* System.Int64 System.IO.Stream::get_Position() */, L_11);
				IL2CPP_RUNTIME_CLASS_INIT(Math_tA269614262430118C9FC5C4D9EF4F61C812568F0_il2cpp_TypeInfo_var);
				int64_t L_13;
				L_13 = Math_Max_m9CDC0B9CEA956A30F9B6BDA815DA307169C6E1C8(((int64_t)((int64_t)L_8)), ((int64_t)il2cpp_codegen_subtract((int64_t)L_10, (int64_t)L_12)), /*hidden argument*/NULL);
				V_4 = ((int64_t)il2cpp_codegen_add((int64_t)L_13, (int64_t)((int64_t)((int64_t)1))));
				ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_14;
				L_14 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
				int64_t L_15 = V_4;
				if ((int64_t)(L_15) > 2147483647LL) IL2CPP_RAISE_MANAGED_EXCEPTION(il2cpp_codegen_get_overflow_exception(), U3CReadToEndAsyncU3Ed__65_MoveNext_m6687BB75E19E97F8D89E828FA064629CB2F3390E_RuntimeMethod_var);
				NullCheck(L_14);
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_16;
				L_16 = VirtFuncInvoker1< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t >::Invoke(4 /* !0[] System.Buffers.ArrayPool`1<System.Byte>::Rent(System.Int32) */, L_14, ((int32_t)((int32_t)L_15)));
				__this->set_U3CrentedU3E5__3_5(L_16);
				goto IL_0099;
			}

IL_0084:
			{
				ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_17;
				L_17 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
				NullCheck(L_17);
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_18;
				L_18 = VirtFuncInvoker1< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t >::Invoke(4 /* !0[] System.Buffers.ArrayPool`1<System.Byte>::Rent(System.Int32) */, L_17, ((int32_t)4096));
				__this->set_U3CrentedU3E5__3_5(L_18);
			}

IL_0099:
			{
				Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * L_19 = __this->get_stream_2();
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_20 = __this->get_U3CrentedU3E5__3_5();
				int32_t L_21 = __this->get_U3CwrittenU3E5__2_4();
				int32_t L_22 = __this->get_U3Cutf8BomLengthU3E5__4_6();
				int32_t L_23 = __this->get_U3CwrittenU3E5__2_4();
				CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  L_24 = __this->get_cancellationToken_3();
				NullCheck(L_19);
				Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 * L_25;
				L_25 = VirtFuncInvoker4< Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 *, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t, int32_t, CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  >::Invoke(19 /* System.Threading.Tasks.Task`1<System.Int32> System.IO.Stream::ReadAsync(System.Byte[],System.Int32,System.Int32,System.Threading.CancellationToken) */, L_19, L_20, L_21, ((int32_t)il2cpp_codegen_subtract((int32_t)L_22, (int32_t)L_23)), L_24);
				NullCheck(L_25);
				ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC  L_26;
				L_26 = Task_1_ConfigureAwait_m9637E2990F98EDC90D1A03B57A4954CE2171C4E2(L_25, (bool)0, /*hidden argument*/Task_1_ConfigureAwait_m9637E2990F98EDC90D1A03B57A4954CE2171C4E2_RuntimeMethod_var);
				V_7 = L_26;
				ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  L_27;
				L_27 = ConfiguredTaskAwaitable_1_GetAwaiter_m8FA39505FC2099C60148C0F029CB49792690A0D5_inline((ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC *)(&V_7), /*hidden argument*/ConfiguredTaskAwaitable_1_GetAwaiter_m8FA39505FC2099C60148C0F029CB49792690A0D5_RuntimeMethod_var);
				V_6 = L_27;
				bool L_28;
				L_28 = ConfiguredTaskAwaiter_get_IsCompleted_m4192DC0E89B48FF93421FFF4EB52C21C42687999((ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 *)(&V_6), /*hidden argument*/ConfiguredTaskAwaiter_get_IsCompleted_m4192DC0E89B48FF93421FFF4EB52C21C42687999_RuntimeMethod_var);
				if (L_28)
				{
					goto IL_011e;
				}
			}

IL_00dd:
			{
				int32_t L_29 = 0;
				V_0 = L_29;
				__this->set_U3CU3E1__state_0(L_29);
				ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  L_30 = V_6;
				__this->set_U3CU3Eu__1_7(L_30);
				AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * L_31 = __this->get_address_of_U3CU3Et__builder_1();
				AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2_TisU3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B_m179843A0565EF49F48ABDF6635C3E041743C36B9((AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 *)L_31, (ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 *)(&V_6), (U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2_TisU3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B_m179843A0565EF49F48ABDF6635C3E041743C36B9_RuntimeMethod_var);
				goto IL_0302;
			}

IL_0101:
			{
				ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  L_32 = __this->get_U3CU3Eu__1_7();
				V_6 = L_32;
				ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 * L_33 = __this->get_address_of_U3CU3Eu__1_7();
				il2cpp_codegen_initobj(L_33, sizeof(ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 ));
				int32_t L_34 = (-1);
				V_0 = L_34;
				__this->set_U3CU3E1__state_0(L_34);
			}

IL_011e:
			{
				int32_t L_35;
				L_35 = ConfiguredTaskAwaiter_GetResult_m0927E49E03619C51620F396FE1DD5DBD41AC6681((ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 *)(&V_6), /*hidden argument*/ConfiguredTaskAwaiter_GetResult_m0927E49E03619C51620F396FE1DD5DBD41AC6681_RuntimeMethod_var);
				V_5 = L_35;
				int32_t L_36 = V_5;
				V_2 = L_36;
				int32_t L_37 = __this->get_U3CwrittenU3E5__2_4();
				int32_t L_38 = V_2;
				__this->set_U3CwrittenU3E5__2_4(((int32_t)il2cpp_codegen_add((int32_t)L_37, (int32_t)L_38)));
				int32_t L_39 = V_2;
				if ((((int32_t)L_39) <= ((int32_t)0)))
				{
					goto IL_014d;
				}
			}

IL_013c:
			{
				int32_t L_40 = __this->get_U3CwrittenU3E5__2_4();
				int32_t L_41 = __this->get_U3Cutf8BomLengthU3E5__4_6();
				if ((((int32_t)L_40) < ((int32_t)L_41)))
				{
					goto IL_0099;
				}
			}

IL_014d:
			{
				int32_t L_42 = __this->get_U3CwrittenU3E5__2_4();
				int32_t L_43 = __this->get_U3Cutf8BomLengthU3E5__4_6();
				if ((!(((uint32_t)L_42) == ((uint32_t)L_43))))
				{
					goto IL_0185;
				}
			}

IL_015b:
			{
				ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_44;
				L_44 = JsonConstants_get_Utf8Bom_m3DC03C02C3987D2937211BF777AA50B8933BC778(/*hidden argument*/NULL);
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_45 = __this->get_U3CrentedU3E5__3_5();
				int32_t L_46 = __this->get_U3Cutf8BomLengthU3E5__4_6();
				IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
				Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_47;
				L_47 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_inline(L_45, 0, L_46, /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var);
				ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_48;
				L_48 = Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5(L_47, /*hidden argument*/Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
				bool L_49;
				L_49 = MemoryExtensions_SequenceEqual_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mA47AE57649F12A2400FE13BDC84254F05A99D1AA_inline(L_44, L_48, /*hidden argument*/MemoryExtensions_SequenceEqual_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mA47AE57649F12A2400FE13BDC84254F05A99D1AA_RuntimeMethod_var);
				if (!L_49)
				{
					goto IL_0185;
				}
			}

IL_017e:
			{
				__this->set_U3CwrittenU3E5__2_4(0);
			}

IL_0185:
			{
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_50 = __this->get_U3CrentedU3E5__3_5();
				NullCheck(L_50);
				int32_t L_51 = __this->get_U3CwrittenU3E5__2_4();
				if ((!(((uint32_t)((int32_t)((int32_t)(((RuntimeArray*)L_50)->max_length)))) == ((uint32_t)L_51))))
				{
					goto IL_01d3;
				}
			}

IL_0195:
			{
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_52 = __this->get_U3CrentedU3E5__3_5();
				V_8 = L_52;
				ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_53;
				L_53 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_54 = V_8;
				NullCheck(L_54);
				NullCheck(L_53);
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_55;
				L_55 = VirtFuncInvoker1< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t >::Invoke(4 /* !0[] System.Buffers.ArrayPool`1<System.Byte>::Rent(System.Int32) */, L_53, ((int32_t)il2cpp_codegen_multiply((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_54)->max_length))), (int32_t)2)));
				__this->set_U3CrentedU3E5__3_5(L_55);
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_56 = V_8;
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_57 = __this->get_U3CrentedU3E5__3_5();
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_58 = V_8;
				NullCheck(L_58);
				Buffer_BlockCopy_mD01FC13D87078586714AA235261A9E786C351725((RuntimeArray *)(RuntimeArray *)L_56, 0, (RuntimeArray *)(RuntimeArray *)L_57, 0, ((int32_t)((int32_t)(((RuntimeArray*)L_58)->max_length))), /*hidden argument*/NULL);
				ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_59;
				L_59 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_60 = V_8;
				NullCheck(L_59);
				VirtActionInvoker2< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, bool >::Invoke(5 /* System.Void System.Buffers.ArrayPool`1<System.Byte>::Return(!0[],System.Boolean) */, L_59, L_60, (bool)1);
			}

IL_01d3:
			{
				Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * L_61 = __this->get_stream_2();
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_62 = __this->get_U3CrentedU3E5__3_5();
				int32_t L_63 = __this->get_U3CwrittenU3E5__2_4();
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_64 = __this->get_U3CrentedU3E5__3_5();
				NullCheck(L_64);
				int32_t L_65 = __this->get_U3CwrittenU3E5__2_4();
				CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  L_66 = __this->get_cancellationToken_3();
				NullCheck(L_61);
				Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 * L_67;
				L_67 = VirtFuncInvoker4< Task_1_tEF253D967DB628A9F8A389A9F2E4516871FD3725 *, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t, int32_t, CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  >::Invoke(19 /* System.Threading.Tasks.Task`1<System.Int32> System.IO.Stream::ReadAsync(System.Byte[],System.Int32,System.Int32,System.Threading.CancellationToken) */, L_61, L_62, L_63, ((int32_t)il2cpp_codegen_subtract((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_64)->max_length))), (int32_t)L_65)), L_66);
				NullCheck(L_67);
				ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC  L_68;
				L_68 = Task_1_ConfigureAwait_m9637E2990F98EDC90D1A03B57A4954CE2171C4E2(L_67, (bool)0, /*hidden argument*/Task_1_ConfigureAwait_m9637E2990F98EDC90D1A03B57A4954CE2171C4E2_RuntimeMethod_var);
				V_7 = L_68;
				ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  L_69;
				L_69 = ConfiguredTaskAwaitable_1_GetAwaiter_m8FA39505FC2099C60148C0F029CB49792690A0D5_inline((ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC *)(&V_7), /*hidden argument*/ConfiguredTaskAwaitable_1_GetAwaiter_m8FA39505FC2099C60148C0F029CB49792690A0D5_RuntimeMethod_var);
				V_10 = L_69;
				bool L_70;
				L_70 = ConfiguredTaskAwaiter_get_IsCompleted_m4192DC0E89B48FF93421FFF4EB52C21C42687999((ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 *)(&V_10), /*hidden argument*/ConfiguredTaskAwaiter_get_IsCompleted_m4192DC0E89B48FF93421FFF4EB52C21C42687999_RuntimeMethod_var);
				if (L_70)
				{
					goto IL_025a;
				}
			}

IL_0219:
			{
				int32_t L_71 = 1;
				V_0 = L_71;
				__this->set_U3CU3E1__state_0(L_71);
				ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  L_72 = V_10;
				__this->set_U3CU3Eu__1_7(L_72);
				AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * L_73 = __this->get_address_of_U3CU3Et__builder_1();
				AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2_TisU3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B_m179843A0565EF49F48ABDF6635C3E041743C36B9((AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 *)L_73, (ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 *)(&V_10), (U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2_TisU3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B_m179843A0565EF49F48ABDF6635C3E041743C36B9_RuntimeMethod_var);
				goto IL_0302;
			}

IL_023d:
			{
				ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  L_74 = __this->get_U3CU3Eu__1_7();
				V_10 = L_74;
				ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 * L_75 = __this->get_address_of_U3CU3Eu__1_7();
				il2cpp_codegen_initobj(L_75, sizeof(ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 ));
				int32_t L_76 = (-1);
				V_0 = L_76;
				__this->set_U3CU3E1__state_0(L_76);
			}

IL_025a:
			{
				int32_t L_77;
				L_77 = ConfiguredTaskAwaiter_GetResult_m0927E49E03619C51620F396FE1DD5DBD41AC6681((ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 *)(&V_10), /*hidden argument*/ConfiguredTaskAwaiter_GetResult_m0927E49E03619C51620F396FE1DD5DBD41AC6681_RuntimeMethod_var);
				V_9 = L_77;
				int32_t L_78 = V_9;
				V_2 = L_78;
				int32_t L_79 = __this->get_U3CwrittenU3E5__2_4();
				int32_t L_80 = V_2;
				__this->set_U3CwrittenU3E5__2_4(((int32_t)il2cpp_codegen_add((int32_t)L_79, (int32_t)L_80)));
				int32_t L_81 = V_2;
				if ((((int32_t)L_81) > ((int32_t)0)))
				{
					goto IL_0185;
				}
			}

IL_027b:
			{
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_82 = __this->get_U3CrentedU3E5__3_5();
				int32_t L_83 = __this->get_U3CwrittenU3E5__2_4();
				ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  L_84;
				memset((&L_84), 0, sizeof(L_84));
				ArraySegment_1__ctor_mAA780E22BB5AE07078510EDCE524DD1EA1E98E0D((&L_84), L_82, 0, L_83, /*hidden argument*/ArraySegment_1__ctor_mAA780E22BB5AE07078510EDCE524DD1EA1E98E0D_RuntimeMethod_var);
				V_1 = L_84;
				goto IL_02e7;
			}
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			if(il2cpp_codegen_class_is_assignable_from (((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&RuntimeObject_il2cpp_TypeInfo_var)), il2cpp_codegen_object_class(e.ex)))
			{
				IL2CPP_PUSH_ACTIVE_EXCEPTION(e.ex);
				goto CATCH_0290;
			}
			throw e;
		}

CATCH_0290:
		{ // begin catch(System.Object)
			{
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_85 = __this->get_U3CrentedU3E5__3_5();
				if (!L_85)
				{
					goto IL_02c5;
				}
			}

IL_0299:
			{
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_86 = __this->get_U3CrentedU3E5__3_5();
				int32_t L_87 = __this->get_U3CwrittenU3E5__2_4();
				IL2CPP_RUNTIME_CLASS_INIT(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var)));
				Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_88;
				L_88 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_inline(L_86, 0, L_87, /*hidden argument*/((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var)));
				V_11 = L_88;
				Span_1_Clear_mCD3767C2F151B946E3EEB3AD9CCD8EE0794F689C((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(&V_11), /*hidden argument*/((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Span_1_Clear_mCD3767C2F151B946E3EEB3AD9CCD8EE0794F689C_RuntimeMethod_var)));
				ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_89;
				L_89 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var)));
				ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_90 = __this->get_U3CrentedU3E5__3_5();
				NullCheck(L_89);
				VirtActionInvoker2< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, bool >::Invoke(5 /* System.Void System.Buffers.ArrayPool`1<System.Byte>::Return(!0[],System.Boolean) */, L_89, L_90, (bool)0);
			}

IL_02c5:
			{
				IL2CPP_RAISE_MANAGED_EXCEPTION(IL2CPP_GET_ACTIVE_EXCEPTION(Exception_t *), ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&U3CReadToEndAsyncU3Ed__65_MoveNext_m6687BB75E19E97F8D89E828FA064629CB2F3390E_RuntimeMethod_var)));
			}
		} // end catch (depth: 2)
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		if(il2cpp_codegen_class_is_assignable_from (((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Exception_t_il2cpp_TypeInfo_var)), il2cpp_codegen_object_class(e.ex)))
		{
			IL2CPP_PUSH_ACTIVE_EXCEPTION(e.ex);
			goto CATCH_02c7;
		}
		throw e;
	}

CATCH_02c7:
	{ // begin catch(System.Exception)
		V_12 = ((Exception_t *)IL2CPP_GET_ACTIVE_EXCEPTION(Exception_t *));
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		__this->set_U3CrentedU3E5__3_5((ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)NULL);
		AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * L_91 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_92 = V_12;
		AsyncTaskMethodBuilder_1_SetException_m9AEB12146F99A1F4E8F8992A49A6C3BC57AB5EBD((AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 *)L_91, L_92, /*hidden argument*/((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&AsyncTaskMethodBuilder_1_SetException_m9AEB12146F99A1F4E8F8992A49A6C3BC57AB5EBD_RuntimeMethod_var)));
		IL2CPP_POP_ACTIVE_EXCEPTION();
		goto IL_0302;
	} // end catch (depth: 1)

IL_02e7:
	{
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		__this->set_U3CrentedU3E5__3_5((ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)NULL);
		AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * L_93 = __this->get_address_of_U3CU3Et__builder_1();
		ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  L_94 = V_1;
		AsyncTaskMethodBuilder_1_SetResult_mB6426AE79AFDC2DCFDFD3F2CB765EA12494D7819((AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 *)L_93, L_94, /*hidden argument*/AsyncTaskMethodBuilder_1_SetResult_mB6426AE79AFDC2DCFDFD3F2CB765EA12494D7819_RuntimeMethod_var);
	}

IL_0302:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CReadToEndAsyncU3Ed__65_MoveNext_m6687BB75E19E97F8D89E828FA064629CB2F3390E_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B * _thisAdjusted = reinterpret_cast<U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B *>(__this + _offset);
	U3CReadToEndAsyncU3Ed__65_MoveNext_m6687BB75E19E97F8D89E828FA064629CB2F3390E(_thisAdjusted, method);
}
// System.Void System.Text.Json.JsonDocument/<ReadToEndAsync>d__65::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReadToEndAsyncU3Ed__65_SetStateMachine_m7B7DC4541C9CE1E4B20C91F17064C80477738C27 (U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&AsyncTaskMethodBuilder_1_SetStateMachine_m57FFFD41160014C16C21B3A3F4B9902B587CAE25_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_1_SetStateMachine_m57FFFD41160014C16C21B3A3F4B9902B587CAE25((AsyncTaskMethodBuilder_1_t8E9DBAAF78B292FA43800E4E4E522B546AF081F4 *)L_0, L_1, /*hidden argument*/AsyncTaskMethodBuilder_1_SetStateMachine_m57FFFD41160014C16C21B3A3F4B9902B587CAE25_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CReadToEndAsyncU3Ed__65_SetStateMachine_m7B7DC4541C9CE1E4B20C91F17064C80477738C27_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B * _thisAdjusted = reinterpret_cast<U3CReadToEndAsyncU3Ed__65_t7584142F15847ECE7140D53E7D986CADAB982C5B *>(__this + _offset);
	U3CReadToEndAsyncU3Ed__65_SetStateMachine_m7B7DC4541C9CE1E4B20C91F17064C80477738C27(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Int32 System.Text.Json.JsonDocument/DbRow::get_Location()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t DbRow_get_Location_m64A1FE8677C03A2ED3384727229059262AD3F149 (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__location_1();
		return L_0;
	}
}
IL2CPP_EXTERN_C  int32_t DbRow_get_Location_m64A1FE8677C03A2ED3384727229059262AD3F149_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * _thisAdjusted = reinterpret_cast<DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = DbRow_get_Location_m64A1FE8677C03A2ED3384727229059262AD3F149_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.Int32 System.Text.Json.JsonDocument/DbRow::get_SizeOrLength()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t DbRow_get_SizeOrLength_mD035DFC369AC701D3930C33A159A067B00913772 (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__sizeOrLengthUnion_2();
		return ((int32_t)((int32_t)L_0&(int32_t)((int32_t)2147483647LL)));
	}
}
IL2CPP_EXTERN_C  int32_t DbRow_get_SizeOrLength_mD035DFC369AC701D3930C33A159A067B00913772_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * _thisAdjusted = reinterpret_cast<DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = DbRow_get_SizeOrLength_mD035DFC369AC701D3930C33A159A067B00913772(_thisAdjusted, method);
	return _returnValue;
}
// System.Boolean System.Text.Json.JsonDocument/DbRow::get_IsUnknownSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DbRow_get_IsUnknownSize_mAB1898B5C44A75E8F3F5737B39E22A9829052B9E (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__sizeOrLengthUnion_2();
		return (bool)((((int32_t)L_0) == ((int32_t)(-1)))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool DbRow_get_IsUnknownSize_mAB1898B5C44A75E8F3F5737B39E22A9829052B9E_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * _thisAdjusted = reinterpret_cast<DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *>(__this + _offset);
	bool _returnValue;
	_returnValue = DbRow_get_IsUnknownSize_mAB1898B5C44A75E8F3F5737B39E22A9829052B9E(_thisAdjusted, method);
	return _returnValue;
}
// System.Boolean System.Text.Json.JsonDocument/DbRow::get_HasComplexChildren()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DbRow_get_HasComplexChildren_m7FB54FB106AA84F5168A030E00E21B2687C58D09 (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__sizeOrLengthUnion_2();
		return (bool)((((int32_t)L_0) < ((int32_t)0))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool DbRow_get_HasComplexChildren_m7FB54FB106AA84F5168A030E00E21B2687C58D09_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * _thisAdjusted = reinterpret_cast<DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *>(__this + _offset);
	bool _returnValue;
	_returnValue = DbRow_get_HasComplexChildren_m7FB54FB106AA84F5168A030E00E21B2687C58D09(_thisAdjusted, method);
	return _returnValue;
}
// System.Int32 System.Text.Json.JsonDocument/DbRow::get_NumberOfRows()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t DbRow_get_NumberOfRows_mB356515E008E677E4E79834F315165BD49A825DF (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__numberOfRowsAndTypeUnion_3();
		return ((int32_t)((int32_t)L_0&(int32_t)((int32_t)268435455)));
	}
}
IL2CPP_EXTERN_C  int32_t DbRow_get_NumberOfRows_mB356515E008E677E4E79834F315165BD49A825DF_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * _thisAdjusted = reinterpret_cast<DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = DbRow_get_NumberOfRows_mB356515E008E677E4E79834F315165BD49A825DF(_thisAdjusted, method);
	return _returnValue;
}
// System.Text.Json.JsonTokenType System.Text.Json.JsonDocument/DbRow::get_TokenType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t DbRow_get_TokenType_m25D3999BC52C9991FC22A97FEC677997068D1E7B (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__numberOfRowsAndTypeUnion_3();
		return (uint8_t)(((int32_t)((uint8_t)((int32_t)((uint32_t)L_0>>((int32_t)28))))));
	}
}
IL2CPP_EXTERN_C  uint8_t DbRow_get_TokenType_m25D3999BC52C9991FC22A97FEC677997068D1E7B_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * _thisAdjusted = reinterpret_cast<DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *>(__this + _offset);
	uint8_t _returnValue;
	_returnValue = DbRow_get_TokenType_m25D3999BC52C9991FC22A97FEC677997068D1E7B(_thisAdjusted, method);
	return _returnValue;
}
// System.Void System.Text.Json.JsonDocument/DbRow::.ctor(System.Text.Json.JsonTokenType,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DbRow__ctor_m83855B245AEDA3542D69D4181E26D625780729FF (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, uint8_t ___jsonTokenType0, int32_t ___location1, int32_t ___sizeOrLength2, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___location1;
		__this->set__location_1(L_0);
		int32_t L_1 = ___sizeOrLength2;
		__this->set__sizeOrLengthUnion_2(L_1);
		uint8_t L_2 = ___jsonTokenType0;
		__this->set__numberOfRowsAndTypeUnion_3(((int32_t)((int32_t)L_2<<(int32_t)((int32_t)28))));
		return;
	}
}
IL2CPP_EXTERN_C  void DbRow__ctor_m83855B245AEDA3542D69D4181E26D625780729FF_AdjustorThunk (RuntimeObject * __this, uint8_t ___jsonTokenType0, int32_t ___location1, int32_t ___sizeOrLength2, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * _thisAdjusted = reinterpret_cast<DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *>(__this + _offset);
	DbRow__ctor_m83855B245AEDA3542D69D4181E26D625780729FF(_thisAdjusted, ___jsonTokenType0, ___location1, ___sizeOrLength2, method);
}
// System.Boolean System.Text.Json.JsonDocument/DbRow::get_IsSimpleValue()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DbRow_get_IsSimpleValue_mF9C4D4A9AA674E10C15D23BFDCEE3B7A9CE78638 (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method)
{
	{
		uint8_t L_0;
		L_0 = DbRow_get_TokenType_m25D3999BC52C9991FC22A97FEC677997068D1E7B((DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *)__this, /*hidden argument*/NULL);
		return (bool)((((int32_t)((((int32_t)L_0) < ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool DbRow_get_IsSimpleValue_mF9C4D4A9AA674E10C15D23BFDCEE3B7A9CE78638_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * _thisAdjusted = reinterpret_cast<DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *>(__this + _offset);
	bool _returnValue;
	_returnValue = DbRow_get_IsSimpleValue_mF9C4D4A9AA674E10C15D23BFDCEE3B7A9CE78638(_thisAdjusted, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: System.Text.Json.JsonDocument/MetadataDb
IL2CPP_EXTERN_C void MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshal_pinvoke(const MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26& unmarshaled, MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshaled_pinvoke& marshaled)
{
	marshaled.___U3CLengthU3Ek__BackingField_2 = unmarshaled.get_U3CLengthU3Ek__BackingField_2();
	marshaled.____data_3 = il2cpp_codegen_com_marshal_safe_array(IL2CPP_VT_I1, unmarshaled.get__data_3());
}
IL2CPP_EXTERN_C void MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshal_pinvoke_back(const MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshaled_pinvoke& marshaled, MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t unmarshaled_U3CLengthU3Ek__BackingField_temp_0 = 0;
	unmarshaled_U3CLengthU3Ek__BackingField_temp_0 = marshaled.___U3CLengthU3Ek__BackingField_2;
	unmarshaled.set_U3CLengthU3Ek__BackingField_2(unmarshaled_U3CLengthU3Ek__BackingField_temp_0);
	unmarshaled.set__data_3((ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)il2cpp_codegen_com_marshal_safe_array_result(IL2CPP_VT_I1, Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_il2cpp_TypeInfo_var, marshaled.____data_3));
}
// Conversion method for clean up from marshalling of: System.Text.Json.JsonDocument/MetadataDb
IL2CPP_EXTERN_C void MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshal_pinvoke_cleanup(MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshaled_pinvoke& marshaled)
{
	il2cpp_codegen_com_destroy_safe_array(marshaled.____data_3);
	marshaled.____data_3 = NULL;
}
// Conversion methods for marshalling of: System.Text.Json.JsonDocument/MetadataDb
IL2CPP_EXTERN_C void MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshal_com(const MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26& unmarshaled, MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshaled_com& marshaled)
{
	marshaled.___U3CLengthU3Ek__BackingField_2 = unmarshaled.get_U3CLengthU3Ek__BackingField_2();
	marshaled.____data_3 = il2cpp_codegen_com_marshal_safe_array(IL2CPP_VT_I1, unmarshaled.get__data_3());
}
IL2CPP_EXTERN_C void MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshal_com_back(const MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshaled_com& marshaled, MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t unmarshaled_U3CLengthU3Ek__BackingField_temp_0 = 0;
	unmarshaled_U3CLengthU3Ek__BackingField_temp_0 = marshaled.___U3CLengthU3Ek__BackingField_2;
	unmarshaled.set_U3CLengthU3Ek__BackingField_2(unmarshaled_U3CLengthU3Ek__BackingField_temp_0);
	unmarshaled.set__data_3((ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)il2cpp_codegen_com_marshal_safe_array_result(IL2CPP_VT_I1, Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_il2cpp_TypeInfo_var, marshaled.____data_3));
}
// Conversion method for clean up from marshalling of: System.Text.Json.JsonDocument/MetadataDb
IL2CPP_EXTERN_C void MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshal_com_cleanup(MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26_marshaled_com& marshaled)
{
	il2cpp_codegen_com_destroy_safe_array(marshaled.____data_3);
	marshaled.____data_3 = NULL;
}
// System.Int32 System.Text.Json.JsonDocument/MetadataDb::get_Length()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_U3CLengthU3Ek__BackingField_2();
		return L_0;
	}
}
IL2CPP_EXTERN_C  int32_t MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline(_thisAdjusted, method);
	return _returnValue;
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::set_Length(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_set_Length_mDEED679131C22B2B98BD28E71CABB539B01E79C7 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_U3CLengthU3Ek__BackingField_2(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb_set_Length_mDEED679131C22B2B98BD28E71CABB539B01E79C7_AdjustorThunk (RuntimeObject * __this, int32_t ___value0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb_set_Length_mDEED679131C22B2B98BD28E71CABB539B01E79C7_inline(_thisAdjusted, ___value0, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::.ctor(System.Byte[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb__ctor_mF5690ADF4EA9661465EF315D0505E445C6E222FB (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___completeDb0, const RuntimeMethod* method)
{
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = ___completeDb0;
		__this->set__data_3(L_0);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_1 = ___completeDb0;
		NullCheck(L_1);
		MetadataDb_set_Length_mDEED679131C22B2B98BD28E71CABB539B01E79C7_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, ((int32_t)((int32_t)(((RuntimeArray*)L_1)->max_length))), /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb__ctor_mF5690ADF4EA9661465EF315D0505E445C6E222FB_AdjustorThunk (RuntimeObject * __this, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___completeDb0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb__ctor_mF5690ADF4EA9661465EF315D0505E445C6E222FB(_thisAdjusted, ___completeDb0, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb__ctor_mADDFB275C40C9946CEFB568AE37356AEB5FBE14D (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___payloadLength0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		int32_t L_0 = ___payloadLength0;
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)12), (int32_t)L_0));
		int32_t L_1 = V_0;
		if ((((int32_t)L_1) <= ((int32_t)((int32_t)1048576))))
		{
			goto IL_001b;
		}
	}
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) > ((int32_t)((int32_t)4194304))))
		{
			goto IL_001b;
		}
	}
	{
		V_0 = ((int32_t)1048576);
	}

IL_001b:
	{
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_3;
		L_3 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		int32_t L_4 = V_0;
		NullCheck(L_3);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_5;
		L_5 = VirtFuncInvoker1< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t >::Invoke(4 /* !0[] System.Buffers.ArrayPool`1<System.Byte>::Rent(System.Int32) */, L_3, L_4);
		__this->set__data_3(L_5);
		MetadataDb_set_Length_mDEED679131C22B2B98BD28E71CABB539B01E79C7_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, 0, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb__ctor_mADDFB275C40C9946CEFB568AE37356AEB5FBE14D_AdjustorThunk (RuntimeObject * __this, int32_t ___payloadLength0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb__ctor_mADDFB275C40C9946CEFB568AE37356AEB5FBE14D(_thisAdjusted, ___payloadLength0, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::.ctor(System.Text.Json.JsonDocument/MetadataDb,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb__ctor_mDFB25B7D23103882D8C1A5E006A56041CA1E783B (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  ___source0, bool ___useArrayPools1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_CopyTo_m78B5163997318B736E1238622FCBC09953798836_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_ToArray_m0E11A38D8E7A3ECF9716C30900DC2C34BB0CC7E4_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		int32_t L_0;
		L_0 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)(&___source0), /*hidden argument*/NULL);
		MetadataDb_set_Length_mDEED679131C22B2B98BD28E71CABB539B01E79C7_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, L_0, /*hidden argument*/NULL);
		bool L_1 = ___useArrayPools1;
		if (!L_1)
		{
			goto IL_004c;
		}
	}
	{
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_2;
		L_2 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		int32_t L_3;
		L_3 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		NullCheck(L_2);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_4;
		L_4 = VirtFuncInvoker1< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t >::Invoke(4 /* !0[] System.Buffers.ArrayPool`1<System.Byte>::Rent(System.Int32) */, L_2, L_3);
		__this->set__data_3(L_4);
		MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  L_5 = ___source0;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_6 = L_5.get__data_3();
		int32_t L_7;
		L_7 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_8;
		L_8 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_inline(L_6, 0, L_7, /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var);
		V_0 = L_8;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_9 = __this->get__data_3();
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_10;
		L_10 = Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4(L_9, /*hidden argument*/Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4_RuntimeMethod_var);
		Span_1_CopyTo_m78B5163997318B736E1238622FCBC09953798836((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(&V_0), L_10, /*hidden argument*/Span_1_CopyTo_m78B5163997318B736E1238622FCBC09953798836_RuntimeMethod_var);
		return;
	}

IL_004c:
	{
		MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  L_11 = ___source0;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_12 = L_11.get__data_3();
		int32_t L_13;
		L_13 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_14;
		L_14 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_inline(L_12, 0, L_13, /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var);
		V_0 = L_14;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_15;
		L_15 = Span_1_ToArray_m0E11A38D8E7A3ECF9716C30900DC2C34BB0CC7E4((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(&V_0), /*hidden argument*/Span_1_ToArray_m0E11A38D8E7A3ECF9716C30900DC2C34BB0CC7E4_RuntimeMethod_var);
		__this->set__data_3(L_15);
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb__ctor_mDFB25B7D23103882D8C1A5E006A56041CA1E783B_AdjustorThunk (RuntimeObject * __this, MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  ___source0, bool ___useArrayPools1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb__ctor_mDFB25B7D23103882D8C1A5E006A56041CA1E783B(_thisAdjusted, ___source0, ___useArrayPools1, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_Dispose_m65983FCE3C671C0E078BA5B7192D66EA6224D218 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* V_0 = NULL;
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726** L_0 = __this->get_address_of__data_3();
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_1;
		L_1 = InterlockedExchangeImpl<ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*>((ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726**)L_0, (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)NULL);
		V_0 = L_1;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_2 = V_0;
		if (L_2)
		{
			goto IL_0011;
		}
	}
	{
		return;
	}

IL_0011:
	{
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_3;
		L_3 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_4 = V_0;
		NullCheck(L_3);
		VirtActionInvoker2< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, bool >::Invoke(5 /* System.Void System.Buffers.ArrayPool`1<System.Byte>::Return(!0[],System.Boolean) */, L_3, L_4, (bool)0);
		MetadataDb_set_Length_mDEED679131C22B2B98BD28E71CABB539B01E79C7_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, 0, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb_Dispose_m65983FCE3C671C0E078BA5B7192D66EA6224D218_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb_Dispose_m65983FCE3C671C0E078BA5B7192D66EA6224D218(_thisAdjusted, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::TrimExcess()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_TrimExcess_m4BAD9F80840A78E601E56F2EAE6822A02267A1CD (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* V_0 = NULL;
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* V_1 = NULL;
	{
		int32_t L_0;
		L_0 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_1 = __this->get__data_3();
		NullCheck(L_1);
		if ((((int32_t)L_0) > ((int32_t)((int32_t)((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_1)->max_length)))/(int32_t)2)))))
		{
			goto IL_0060;
		}
	}
	{
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_2;
		L_2 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		int32_t L_3;
		L_3 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		NullCheck(L_2);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_4;
		L_4 = VirtFuncInvoker1< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t >::Invoke(4 /* !0[] System.Buffers.ArrayPool`1<System.Byte>::Rent(System.Int32) */, L_2, L_3);
		V_0 = L_4;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_5 = V_0;
		V_1 = L_5;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_6 = V_0;
		NullCheck(L_6);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_7 = __this->get__data_3();
		NullCheck(L_7);
		if ((((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_6)->max_length)))) >= ((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_7)->max_length))))))
		{
			goto IL_0054;
		}
	}
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_8 = __this->get__data_3();
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_9 = V_0;
		int32_t L_10;
		L_10 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		Buffer_BlockCopy_mD01FC13D87078586714AA235261A9E786C351725((RuntimeArray *)(RuntimeArray *)L_8, 0, (RuntimeArray *)(RuntimeArray *)L_9, 0, L_10, /*hidden argument*/NULL);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_11 = __this->get__data_3();
		V_1 = L_11;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_12 = V_0;
		__this->set__data_3(L_12);
	}

IL_0054:
	{
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_13;
		L_13 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_14 = V_1;
		NullCheck(L_13);
		VirtActionInvoker2< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, bool >::Invoke(5 /* System.Void System.Buffers.ArrayPool`1<System.Byte>::Return(!0[],System.Boolean) */, L_13, L_14, (bool)0);
	}

IL_0060:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb_TrimExcess_m4BAD9F80840A78E601E56F2EAE6822A02267A1CD_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb_TrimExcess_m4BAD9F80840A78E601E56F2EAE6822A02267A1CD(_thisAdjusted, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::Append(System.Text.Json.JsonTokenType,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_Append_m70BEF3B5C094C35F03E20E23CABEF3905616B61A (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, uint8_t ___tokenType0, int32_t ___startLocation1, int32_t ___length2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Write_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mBBD4DDE8A6973C64B3C4941610C05FA656A63B48_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		int32_t L_0;
		L_0 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_1 = __this->get__data_3();
		NullCheck(L_1);
		if ((((int32_t)L_0) < ((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_1)->max_length))), (int32_t)((int32_t)12))))))
		{
			goto IL_0019;
		}
	}
	{
		MetadataDb_Enlarge_m1D564D4B6A73CB588BBACAD06E20CAC2CC87BE91((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
	}

IL_0019:
	{
		uint8_t L_2 = ___tokenType0;
		int32_t L_3 = ___startLocation1;
		int32_t L_4 = ___length2;
		DbRow__ctor_m83855B245AEDA3542D69D4181E26D625780729FF((DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *)(&V_0), L_2, L_3, L_4, /*hidden argument*/NULL);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_5 = __this->get__data_3();
		int32_t L_6;
		L_6 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_7;
		L_7 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A(L_5, L_6, /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		MemoryMarshal_Write_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mBBD4DDE8A6973C64B3C4941610C05FA656A63B48_inline(L_7, (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *)(&V_0), /*hidden argument*/MemoryMarshal_Write_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mBBD4DDE8A6973C64B3C4941610C05FA656A63B48_RuntimeMethod_var);
		int32_t L_8;
		L_8 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		MetadataDb_set_Length_mDEED679131C22B2B98BD28E71CABB539B01E79C7_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, ((int32_t)il2cpp_codegen_add((int32_t)L_8, (int32_t)((int32_t)12))), /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb_Append_m70BEF3B5C094C35F03E20E23CABEF3905616B61A_AdjustorThunk (RuntimeObject * __this, uint8_t ___tokenType0, int32_t ___startLocation1, int32_t ___length2, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb_Append_m70BEF3B5C094C35F03E20E23CABEF3905616B61A(_thisAdjusted, ___tokenType0, ___startLocation1, ___length2, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::Enlarge()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_Enlarge_m1D564D4B6A73CB588BBACAD06E20CAC2CC87BE91 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* V_0 = NULL;
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = __this->get__data_3();
		V_0 = L_0;
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_1;
		L_1 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_2 = V_0;
		NullCheck(L_2);
		NullCheck(L_1);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_3;
		L_3 = VirtFuncInvoker1< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t >::Invoke(4 /* !0[] System.Buffers.ArrayPool`1<System.Byte>::Rent(System.Int32) */, L_1, ((int32_t)il2cpp_codegen_multiply((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_2)->max_length))), (int32_t)2)));
		__this->set__data_3(L_3);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_4 = V_0;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_5 = __this->get__data_3();
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_6 = V_0;
		NullCheck(L_6);
		Buffer_BlockCopy_mD01FC13D87078586714AA235261A9E786C351725((RuntimeArray *)(RuntimeArray *)L_4, 0, (RuntimeArray *)(RuntimeArray *)L_5, 0, ((int32_t)((int32_t)(((RuntimeArray*)L_6)->max_length))), /*hidden argument*/NULL);
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_7;
		L_7 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_8 = V_0;
		NullCheck(L_7);
		VirtActionInvoker2< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, bool >::Invoke(5 /* System.Void System.Buffers.ArrayPool`1<System.Byte>::Return(!0[],System.Boolean) */, L_7, L_8, (bool)0);
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb_Enlarge_m1D564D4B6A73CB588BBACAD06E20CAC2CC87BE91_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb_Enlarge_m1D564D4B6A73CB588BBACAD06E20CAC2CC87BE91(_thisAdjusted, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::AssertValidIndex(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_AssertValidIndex_m1F59B45473AF571F819E12A4D7D9BC7749846CF7 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	{
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb_AssertValidIndex_m1F59B45473AF571F819E12A4D7D9BC7749846CF7_AdjustorThunk (RuntimeObject * __this, int32_t ___index0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb_AssertValidIndex_m1F59B45473AF571F819E12A4D7D9BC7749846CF7(_thisAdjusted, ___index0, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::SetLength(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_SetLength_mF874FB9D92FF15E65645B752D2F16693FD85EA53 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, int32_t ___length1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = __this->get__data_3();
		int32_t L_1 = ___index0;
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_2;
		L_2 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A(L_0, ((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)4)), /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		V_0 = L_2;
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_3 = V_0;
		MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_inline(L_3, (int32_t*)(&___length1), /*hidden argument*/MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb_SetLength_mF874FB9D92FF15E65645B752D2F16693FD85EA53_AdjustorThunk (RuntimeObject * __this, int32_t ___index0, int32_t ___length1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb_SetLength_mF874FB9D92FF15E65645B752D2F16693FD85EA53(_thisAdjusted, ___index0, ___length1, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::SetNumberOfRows(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_SetNumberOfRows_mE9A9288F6CFE360E85CC8E0A50AE964D43C470E2 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, int32_t ___numberOfRows1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = __this->get__data_3();
		int32_t L_1 = ___index0;
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_2;
		L_2 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A(L_0, ((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)8)), /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		V_0 = L_2;
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_3 = V_0;
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_4;
		L_4 = Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5(L_3, /*hidden argument*/Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		int32_t L_5;
		L_5 = MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_inline(L_4, /*hidden argument*/MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_RuntimeMethod_var);
		V_1 = L_5;
		int32_t L_6 = V_1;
		int32_t L_7 = ___numberOfRows1;
		V_2 = ((int32_t)((int32_t)((int32_t)((int32_t)L_6&(int32_t)((int32_t)-268435456)))|(int32_t)L_7));
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_8 = V_0;
		MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_inline(L_8, (int32_t*)(&V_2), /*hidden argument*/MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb_SetNumberOfRows_mE9A9288F6CFE360E85CC8E0A50AE964D43C470E2_AdjustorThunk (RuntimeObject * __this, int32_t ___index0, int32_t ___numberOfRows1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb_SetNumberOfRows_mE9A9288F6CFE360E85CC8E0A50AE964D43C470E2(_thisAdjusted, ___index0, ___numberOfRows1, method);
}
// System.Void System.Text.Json.JsonDocument/MetadataDb::SetHasComplexChildren(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MetadataDb_SetHasComplexChildren_m23B89D6C169828F97B1138999C88AD2C334E46D9 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = __this->get__data_3();
		int32_t L_1 = ___index0;
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_2;
		L_2 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A(L_0, ((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)4)), /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		V_0 = L_2;
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_3 = V_0;
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_4;
		L_4 = Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5(L_3, /*hidden argument*/Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		int32_t L_5;
		L_5 = MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_inline(L_4, /*hidden argument*/MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_RuntimeMethod_var);
		V_1 = L_5;
		int32_t L_6 = V_1;
		V_2 = ((int32_t)((int32_t)L_6|(int32_t)((int32_t)-2147483648LL)));
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_7 = V_0;
		MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_inline(L_7, (int32_t*)(&V_2), /*hidden argument*/MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void MetadataDb_SetHasComplexChildren_m23B89D6C169828F97B1138999C88AD2C334E46D9_AdjustorThunk (RuntimeObject * __this, int32_t ___index0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb_SetHasComplexChildren_m23B89D6C169828F97B1138999C88AD2C334E46D9(_thisAdjusted, ___index0, method);
}
// System.Int32 System.Text.Json.JsonDocument/MetadataDb::FindIndexOfFirstUnsetSizeOrLength(System.Text.Json.JsonTokenType)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t MetadataDb_FindIndexOfFirstUnsetSizeOrLength_m93260D165FFDE321BC10AEB51ADA16EA571BDA92 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, uint8_t ___lookupType0, const RuntimeMethod* method)
{
	{
		uint8_t L_0 = ___lookupType0;
		int32_t L_1;
		L_1 = MetadataDb_FindOpenElement_m764A0CA02C9B76F9FB4501BEC77D157A87ADCC8C((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C  int32_t MetadataDb_FindIndexOfFirstUnsetSizeOrLength_m93260D165FFDE321BC10AEB51ADA16EA571BDA92_AdjustorThunk (RuntimeObject * __this, uint8_t ___lookupType0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = MetadataDb_FindIndexOfFirstUnsetSizeOrLength_m93260D165FFDE321BC10AEB51ADA16EA571BDA92(_thisAdjusted, ___lookupType0, method);
	return _returnValue;
}
// System.Int32 System.Text.Json.JsonDocument/MetadataDb::FindOpenElement(System.Text.Json.JsonTokenType)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t MetadataDb_FindOpenElement_m764A0CA02C9B76F9FB4501BEC77D157A87ADCC8C (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, uint8_t ___lookupType0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_Slice_mC8E25AC937B49CDD57AA85FF493D7F42595F8EAA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  V_2;
	memset((&V_2), 0, sizeof(V_2));
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = __this->get__data_3();
		int32_t L_1;
		L_1 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_2;
		L_2 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_inline(L_0, 0, L_1, /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var);
		V_0 = L_2;
		int32_t L_3;
		L_3 = MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, /*hidden argument*/NULL);
		V_1 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_3, (int32_t)((int32_t)12)));
		goto IL_004c;
	}

IL_001f:
	{
		int32_t L_4 = V_1;
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_5;
		L_5 = Span_1_Slice_mC8E25AC937B49CDD57AA85FF493D7F42595F8EAA_inline((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(&V_0), L_4, /*hidden argument*/Span_1_Slice_mC8E25AC937B49CDD57AA85FF493D7F42595F8EAA_RuntimeMethod_var);
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_6;
		L_6 = Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5(L_5, /*hidden argument*/Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  L_7;
		L_7 = MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_inline(L_6, /*hidden argument*/MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_RuntimeMethod_var);
		V_2 = L_7;
		bool L_8;
		L_8 = DbRow_get_IsUnknownSize_mAB1898B5C44A75E8F3F5737B39E22A9829052B9E((DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *)(&V_2), /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_0047;
		}
	}
	{
		uint8_t L_9;
		L_9 = DbRow_get_TokenType_m25D3999BC52C9991FC22A97FEC677997068D1E7B((DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *)(&V_2), /*hidden argument*/NULL);
		uint8_t L_10 = ___lookupType0;
		if ((!(((uint32_t)L_9) == ((uint32_t)L_10))))
		{
			goto IL_0047;
		}
	}
	{
		int32_t L_11 = V_1;
		return L_11;
	}

IL_0047:
	{
		int32_t L_12 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_12, (int32_t)((int32_t)12)));
	}

IL_004c:
	{
		int32_t L_13 = V_1;
		if ((((int32_t)L_13) >= ((int32_t)0)))
		{
			goto IL_001f;
		}
	}
	{
		return (-1);
	}
}
IL2CPP_EXTERN_C  int32_t MetadataDb_FindOpenElement_m764A0CA02C9B76F9FB4501BEC77D157A87ADCC8C_AdjustorThunk (RuntimeObject * __this, uint8_t ___lookupType0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	int32_t _returnValue;
	_returnValue = MetadataDb_FindOpenElement_m764A0CA02C9B76F9FB4501BEC77D157A87ADCC8C(_thisAdjusted, ___lookupType0, method);
	return _returnValue;
}
// System.Text.Json.JsonDocument/DbRow System.Text.Json.JsonDocument/MetadataDb::Get(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  MetadataDb_Get_m54EC69D0C0A5AFA94790823E043C9C5AF611E879 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = __this->get__data_3();
		int32_t L_1 = ___index0;
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_2;
		L_2 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A(L_0, L_1, /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_3;
		L_3 = Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5(L_2, /*hidden argument*/Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  L_4;
		L_4 = MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_inline(L_3, /*hidden argument*/MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_RuntimeMethod_var);
		return L_4;
	}
}
IL2CPP_EXTERN_C  DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  MetadataDb_Get_m54EC69D0C0A5AFA94790823E043C9C5AF611E879_AdjustorThunk (RuntimeObject * __this, int32_t ___index0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  _returnValue;
	_returnValue = MetadataDb_Get_m54EC69D0C0A5AFA94790823E043C9C5AF611E879(_thisAdjusted, ___index0, method);
	return _returnValue;
}
// System.Text.Json.JsonTokenType System.Text.Json.JsonDocument/MetadataDb::GetJsonTokenType(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t MetadataDb_GetJsonTokenType_mFE77CF70D471447224C7088BF78347AD9922BDD8 (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Read_TisUInt32_tE60352A06233E4E69DD198BCC67142159F686B15_m833630665CFD238E8565314AC52CFADD215AB189_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	uint32_t V_0 = 0;
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = __this->get__data_3();
		int32_t L_1 = ___index0;
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_2;
		L_2 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A(L_0, ((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)8)), /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_3;
		L_3 = Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5(L_2, /*hidden argument*/Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		uint32_t L_4;
		L_4 = MemoryMarshal_Read_TisUInt32_tE60352A06233E4E69DD198BCC67142159F686B15_m833630665CFD238E8565314AC52CFADD215AB189_inline(L_3, /*hidden argument*/MemoryMarshal_Read_TisUInt32_tE60352A06233E4E69DD198BCC67142159F686B15_m833630665CFD238E8565314AC52CFADD215AB189_RuntimeMethod_var);
		V_0 = L_4;
		uint32_t L_5 = V_0;
		return (uint8_t)(((int32_t)((uint8_t)((int32_t)((uint32_t)L_5>>((int32_t)28))))));
	}
}
IL2CPP_EXTERN_C  uint8_t MetadataDb_GetJsonTokenType_mFE77CF70D471447224C7088BF78347AD9922BDD8_AdjustorThunk (RuntimeObject * __this, int32_t ___index0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	uint8_t _returnValue;
	_returnValue = MetadataDb_GetJsonTokenType_mFE77CF70D471447224C7088BF78347AD9922BDD8(_thisAdjusted, ___index0, method);
	return _returnValue;
}
// System.Text.Json.JsonDocument/MetadataDb System.Text.Json.JsonDocument/MetadataDb::CopySegment(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  MetadataDb_CopySegment_mE2A805BC0A4A35436649F6DFF69A286C416A056C (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___startIndex0, int32_t ___endIndex1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Cast_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_mC0DBC30388A535C7844D1D37A59E519DA6751DFE_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_CopyTo_m78B5163997318B736E1238622FCBC09953798836_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_get_Item_mE8544DBC448A1E9D05A8AC89B0399CB9B0275A2C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* V_2 = NULL;
	Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526  V_3;
	memset((&V_3), 0, sizeof(V_3));
	int32_t V_4 = 0;
	Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  V_5;
	memset((&V_5), 0, sizeof(V_5));
	int32_t V_6 = 0;
	{
		int32_t L_0 = ___startIndex0;
		DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  L_1;
		L_1 = MetadataDb_Get_m54EC69D0C0A5AFA94790823E043C9C5AF611E879((MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *)__this, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		int32_t L_2 = ___endIndex1;
		int32_t L_3 = ___startIndex0;
		V_1 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_2, (int32_t)L_3));
		int32_t L_4 = V_1;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_5 = (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)SZArrayNew(ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726_il2cpp_TypeInfo_var, (uint32_t)L_4);
		V_2 = L_5;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_6 = __this->get__data_3();
		int32_t L_7 = ___startIndex0;
		int32_t L_8 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_9;
		L_9 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_inline(L_6, L_7, L_8, /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_RuntimeMethod_var);
		V_5 = L_9;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_10 = V_2;
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_11;
		L_11 = Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4(L_10, /*hidden argument*/Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4_RuntimeMethod_var);
		Span_1_CopyTo_m78B5163997318B736E1238622FCBC09953798836((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(&V_5), L_11, /*hidden argument*/Span_1_CopyTo_m78B5163997318B736E1238622FCBC09953798836_RuntimeMethod_var);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_12 = V_2;
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_13;
		L_13 = Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4(L_12, /*hidden argument*/Span_1_op_Implicit_m6FF1F56A00788AA87E5968446C6872D8F39A8AA4_RuntimeMethod_var);
		Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526  L_14;
		L_14 = MemoryMarshal_Cast_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_mC0DBC30388A535C7844D1D37A59E519DA6751DFE(L_13, /*hidden argument*/MemoryMarshal_Cast_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_mC0DBC30388A535C7844D1D37A59E519DA6751DFE_RuntimeMethod_var);
		V_3 = L_14;
		int32_t* L_15;
		L_15 = Span_1_get_Item_mE8544DBC448A1E9D05A8AC89B0399CB9B0275A2C_inline((Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526 *)(&V_3), 0, /*hidden argument*/Span_1_get_Item_mE8544DBC448A1E9D05A8AC89B0399CB9B0275A2C_RuntimeMethod_var);
		int32_t L_16 = *((int32_t*)L_15);
		V_4 = L_16;
		uint8_t L_17;
		L_17 = DbRow_get_TokenType_m25D3999BC52C9991FC22A97FEC677997068D1E7B((DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *)(&V_0), /*hidden argument*/NULL);
		if ((!(((uint32_t)L_17) == ((uint32_t)7))))
		{
			goto IL_0056;
		}
	}
	{
		int32_t L_18 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_18, (int32_t)1));
	}

IL_0056:
	{
		int32_t L_19 = V_1;
		V_6 = ((int32_t)((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_19, (int32_t)((int32_t)12)))/(int32_t)4));
		goto IL_0075;
	}

IL_0060:
	{
		int32_t L_20 = V_6;
		int32_t* L_21;
		L_21 = Span_1_get_Item_mE8544DBC448A1E9D05A8AC89B0399CB9B0275A2C_inline((Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526 *)(&V_3), L_20, /*hidden argument*/Span_1_get_Item_mE8544DBC448A1E9D05A8AC89B0399CB9B0275A2C_RuntimeMethod_var);
		int32_t* L_22 = L_21;
		int32_t L_23 = *((int32_t*)L_22);
		int32_t L_24 = V_4;
		*((int32_t*)L_22) = (int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_23, (int32_t)L_24));
		int32_t L_25 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_25, (int32_t)3));
	}

IL_0075:
	{
		int32_t L_26 = V_6;
		if ((((int32_t)L_26) >= ((int32_t)0)))
		{
			goto IL_0060;
		}
	}
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_27 = V_2;
		MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  L_28;
		memset((&L_28), 0, sizeof(L_28));
		MetadataDb__ctor_mF5690ADF4EA9661465EF315D0505E445C6E222FB((&L_28), L_27, /*hidden argument*/NULL);
		return L_28;
	}
}
IL2CPP_EXTERN_C  MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  MetadataDb_CopySegment_mE2A805BC0A4A35436649F6DFF69A286C416A056C_AdjustorThunk (RuntimeObject * __this, int32_t ___startIndex0, int32_t ___endIndex1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * _thisAdjusted = reinterpret_cast<MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 *>(__this + _offset);
	MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26  _returnValue;
	_returnValue = MetadataDb_CopySegment_mE2A805BC0A4A35436649F6DFF69A286C416A056C(_thisAdjusted, ___startIndex0, ___endIndex1, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Text.Json.JsonDocument/StackRow::.ctor(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StackRow__ctor_mE83A64F557423B2C1417CF2CAA47FCB6DAE79597 (StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA * __this, int32_t ___sizeOrLength0, int32_t ___numberOfRows1, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___sizeOrLength0;
		__this->set_SizeOrLength_1(L_0);
		int32_t L_1 = ___numberOfRows1;
		__this->set_NumberOfRows_2(L_1);
		return;
	}
}
IL2CPP_EXTERN_C  void StackRow__ctor_mE83A64F557423B2C1417CF2CAA47FCB6DAE79597_AdjustorThunk (RuntimeObject * __this, int32_t ___sizeOrLength0, int32_t ___numberOfRows1, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA * _thisAdjusted = reinterpret_cast<StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA *>(__this + _offset);
	StackRow__ctor_mE83A64F557423B2C1417CF2CAA47FCB6DAE79597(_thisAdjusted, ___sizeOrLength0, ___numberOfRows1, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: System.Text.Json.JsonDocument/StackRowStack
IL2CPP_EXTERN_C void StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshal_pinvoke(const StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C& unmarshaled, StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshaled_pinvoke& marshaled)
{
	marshaled.____rentedBuffer_0 = il2cpp_codegen_com_marshal_safe_array(IL2CPP_VT_I1, unmarshaled.get__rentedBuffer_0());
	marshaled.____topOfStack_1 = unmarshaled.get__topOfStack_1();
}
IL2CPP_EXTERN_C void StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshal_pinvoke_back(const StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshaled_pinvoke& marshaled, StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	unmarshaled.set__rentedBuffer_0((ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)il2cpp_codegen_com_marshal_safe_array_result(IL2CPP_VT_I1, Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_il2cpp_TypeInfo_var, marshaled.____rentedBuffer_0));
	int32_t unmarshaled__topOfStack_temp_1 = 0;
	unmarshaled__topOfStack_temp_1 = marshaled.____topOfStack_1;
	unmarshaled.set__topOfStack_1(unmarshaled__topOfStack_temp_1);
}
// Conversion method for clean up from marshalling of: System.Text.Json.JsonDocument/StackRowStack
IL2CPP_EXTERN_C void StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshal_pinvoke_cleanup(StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshaled_pinvoke& marshaled)
{
	il2cpp_codegen_com_destroy_safe_array(marshaled.____rentedBuffer_0);
	marshaled.____rentedBuffer_0 = NULL;
}
// Conversion methods for marshalling of: System.Text.Json.JsonDocument/StackRowStack
IL2CPP_EXTERN_C void StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshal_com(const StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C& unmarshaled, StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshaled_com& marshaled)
{
	marshaled.____rentedBuffer_0 = il2cpp_codegen_com_marshal_safe_array(IL2CPP_VT_I1, unmarshaled.get__rentedBuffer_0());
	marshaled.____topOfStack_1 = unmarshaled.get__topOfStack_1();
}
IL2CPP_EXTERN_C void StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshal_com_back(const StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshaled_com& marshaled, StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	unmarshaled.set__rentedBuffer_0((ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)il2cpp_codegen_com_marshal_safe_array_result(IL2CPP_VT_I1, Byte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_il2cpp_TypeInfo_var, marshaled.____rentedBuffer_0));
	int32_t unmarshaled__topOfStack_temp_1 = 0;
	unmarshaled__topOfStack_temp_1 = marshaled.____topOfStack_1;
	unmarshaled.set__topOfStack_1(unmarshaled__topOfStack_temp_1);
}
// Conversion method for clean up from marshalling of: System.Text.Json.JsonDocument/StackRowStack
IL2CPP_EXTERN_C void StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshal_com_cleanup(StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C_marshaled_com& marshaled)
{
	il2cpp_codegen_com_destroy_safe_array(marshaled.____rentedBuffer_0);
	marshaled.____rentedBuffer_0 = NULL;
}
// System.Void System.Text.Json.JsonDocument/StackRowStack::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StackRowStack__ctor_mC2D0A937968645C04762AE37C6F9196811FC60AD (StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * __this, int32_t ___initialSize0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_0;
		L_0 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		int32_t L_1 = ___initialSize0;
		NullCheck(L_0);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_2;
		L_2 = VirtFuncInvoker1< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t >::Invoke(4 /* !0[] System.Buffers.ArrayPool`1<System.Byte>::Rent(System.Int32) */, L_0, L_1);
		__this->set__rentedBuffer_0(L_2);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_3 = __this->get__rentedBuffer_0();
		NullCheck(L_3);
		__this->set__topOfStack_1(((int32_t)((int32_t)(((RuntimeArray*)L_3)->max_length))));
		return;
	}
}
IL2CPP_EXTERN_C  void StackRowStack__ctor_mC2D0A937968645C04762AE37C6F9196811FC60AD_AdjustorThunk (RuntimeObject * __this, int32_t ___initialSize0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * _thisAdjusted = reinterpret_cast<StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C *>(__this + _offset);
	StackRowStack__ctor_mC2D0A937968645C04762AE37C6F9196811FC60AD(_thisAdjusted, ___initialSize0, method);
}
// System.Void System.Text.Json.JsonDocument/StackRowStack::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StackRowStack_Dispose_mE69DCE4BA09A561767066C061517880FC9FD240E (StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* V_0 = NULL;
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = __this->get__rentedBuffer_0();
		V_0 = L_0;
		__this->set__rentedBuffer_0((ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)NULL);
		__this->set__topOfStack_1(0);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_1 = V_0;
		if (!L_1)
		{
			goto IL_0024;
		}
	}
	{
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_2;
		L_2 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_3 = V_0;
		NullCheck(L_2);
		VirtActionInvoker2< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, bool >::Invoke(5 /* System.Void System.Buffers.ArrayPool`1<System.Byte>::Return(!0[],System.Boolean) */, L_2, L_3, (bool)0);
	}

IL_0024:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void StackRowStack_Dispose_mE69DCE4BA09A561767066C061517880FC9FD240E_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * _thisAdjusted = reinterpret_cast<StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C *>(__this + _offset);
	StackRowStack_Dispose_mE69DCE4BA09A561767066C061517880FC9FD240E(_thisAdjusted, method);
}
// System.Void System.Text.Json.JsonDocument/StackRowStack::Push(System.Text.Json.JsonDocument/StackRow)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StackRowStack_Push_m2EB6DF0A8051783F40F7911AC981072DB6DF3AA0 (StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * __this, StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  ___row0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Write_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m53B95538AC301102BF79930E0E45D3300B903BC7_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		int32_t L_0 = __this->get__topOfStack_1();
		if ((((int32_t)L_0) >= ((int32_t)8)))
		{
			goto IL_000f;
		}
	}
	{
		StackRowStack_Enlarge_m9CAB452BCBA0F7795608ED801F3741F645037CF0((StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C *)__this, /*hidden argument*/NULL);
	}

IL_000f:
	{
		int32_t L_1 = __this->get__topOfStack_1();
		__this->set__topOfStack_1(((int32_t)il2cpp_codegen_subtract((int32_t)L_1, (int32_t)8)));
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_2 = __this->get__rentedBuffer_0();
		int32_t L_3 = __this->get__topOfStack_1();
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_4;
		L_4 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A(L_2, L_3, /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		MemoryMarshal_Write_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m53B95538AC301102BF79930E0E45D3300B903BC7_inline(L_4, (StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA *)(&___row0), /*hidden argument*/MemoryMarshal_Write_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m53B95538AC301102BF79930E0E45D3300B903BC7_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void StackRowStack_Push_m2EB6DF0A8051783F40F7911AC981072DB6DF3AA0_AdjustorThunk (RuntimeObject * __this, StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  ___row0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * _thisAdjusted = reinterpret_cast<StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C *>(__this + _offset);
	StackRowStack_Push_m2EB6DF0A8051783F40F7911AC981072DB6DF3AA0(_thisAdjusted, ___row0, method);
}
// System.Text.Json.JsonDocument/StackRow System.Text.Json.JsonDocument/StackRowStack::Pop()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  StackRowStack_Pop_mB7727C6BB4EF6384ADB6A055F63AE463231B3731 (StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_Read_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m4C4E201B0499E179319483CA0E299BBC4BFF6688_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = __this->get__rentedBuffer_0();
		int32_t L_1 = __this->get__topOfStack_1();
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_2;
		L_2 = MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A(L_0, L_1, /*hidden argument*/MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m62D300234B063221A97C508EA4ABC5C4F07B564A_RuntimeMethod_var);
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_3;
		L_3 = Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5(L_2, /*hidden argument*/Span_1_op_Implicit_m4DF231FE4EDB6F473374D63CC83755F09BF582F5_RuntimeMethod_var);
		StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  L_4;
		L_4 = MemoryMarshal_Read_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m4C4E201B0499E179319483CA0E299BBC4BFF6688_inline(L_3, /*hidden argument*/MemoryMarshal_Read_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m4C4E201B0499E179319483CA0E299BBC4BFF6688_RuntimeMethod_var);
		V_0 = L_4;
		int32_t L_5 = __this->get__topOfStack_1();
		__this->set__topOfStack_1(((int32_t)il2cpp_codegen_add((int32_t)L_5, (int32_t)8)));
		StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  L_6 = V_0;
		return L_6;
	}
}
IL2CPP_EXTERN_C  StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  StackRowStack_Pop_mB7727C6BB4EF6384ADB6A055F63AE463231B3731_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * _thisAdjusted = reinterpret_cast<StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C *>(__this + _offset);
	StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  _returnValue;
	_returnValue = StackRowStack_Pop_mB7727C6BB4EF6384ADB6A055F63AE463231B3731(_thisAdjusted, method);
	return _returnValue;
}
// System.Void System.Text.Json.JsonDocument/StackRowStack::Enlarge()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void StackRowStack_Enlarge_m9CAB452BCBA0F7795608ED801F3741F645037CF0 (StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* V_0 = NULL;
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = __this->get__rentedBuffer_0();
		V_0 = L_0;
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_1;
		L_1 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_2 = V_0;
		NullCheck(L_2);
		NullCheck(L_1);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_3;
		L_3 = VirtFuncInvoker1< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t >::Invoke(4 /* !0[] System.Buffers.ArrayPool`1<System.Byte>::Rent(System.Int32) */, L_1, ((int32_t)il2cpp_codegen_multiply((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_2)->max_length))), (int32_t)2)));
		__this->set__rentedBuffer_0(L_3);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_4 = V_0;
		int32_t L_5 = __this->get__topOfStack_1();
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_6 = __this->get__rentedBuffer_0();
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_7 = __this->get__rentedBuffer_0();
		NullCheck(L_7);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_8 = V_0;
		NullCheck(L_8);
		int32_t L_9 = __this->get__topOfStack_1();
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_10 = V_0;
		NullCheck(L_10);
		int32_t L_11 = __this->get__topOfStack_1();
		Buffer_BlockCopy_mD01FC13D87078586714AA235261A9E786C351725((RuntimeArray *)(RuntimeArray *)L_4, L_5, (RuntimeArray *)(RuntimeArray *)L_6, ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_7)->max_length))), (int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_8)->max_length))))), (int32_t)L_9)), ((int32_t)il2cpp_codegen_subtract((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_10)->max_length))), (int32_t)L_11)), /*hidden argument*/NULL);
		int32_t L_12 = __this->get__topOfStack_1();
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_13 = __this->get__rentedBuffer_0();
		NullCheck(L_13);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_14 = V_0;
		NullCheck(L_14);
		__this->set__topOfStack_1(((int32_t)il2cpp_codegen_add((int32_t)L_12, (int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_13)->max_length))), (int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_14)->max_length))))))));
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_15;
		L_15 = ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_inline(/*hidden argument*/ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_RuntimeMethod_var);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_16 = V_0;
		NullCheck(L_15);
		VirtActionInvoker2< ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, bool >::Invoke(5 /* System.Void System.Buffers.ArrayPool`1<System.Byte>::Return(!0[],System.Boolean) */, L_15, L_16, (bool)0);
		return;
	}
}
IL2CPP_EXTERN_C  void StackRowStack_Enlarge_m9CAB452BCBA0F7795608ED801F3741F645037CF0_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C * _thisAdjusted = reinterpret_cast<StackRowStack_t868FCBF0CC1CD9C5232FD9F1872B16DDC895C18C *>(__this + _offset);
	StackRowStack_Enlarge_m9CAB452BCBA0F7795608ED801F3741F645037CF0(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif


// Conversion methods for marshalling of: System.Text.Json.JsonElement/ArrayEnumerator
IL2CPP_EXTERN_C void ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshal_pinvoke(const ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0& unmarshaled, ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshaled_pinvoke& marshaled)
{
	Exception_t* ____target_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_target' of type 'ArrayEnumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____target_0Exception, NULL);
}
IL2CPP_EXTERN_C void ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshal_pinvoke_back(const ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshaled_pinvoke& marshaled, ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0& unmarshaled)
{
	Exception_t* ____target_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_target' of type 'ArrayEnumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____target_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: System.Text.Json.JsonElement/ArrayEnumerator
IL2CPP_EXTERN_C void ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshal_pinvoke_cleanup(ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshaled_pinvoke& marshaled)
{
}


// Conversion methods for marshalling of: System.Text.Json.JsonElement/ArrayEnumerator
IL2CPP_EXTERN_C void ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshal_com(const ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0& unmarshaled, ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshaled_com& marshaled)
{
	Exception_t* ____target_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_target' of type 'ArrayEnumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____target_0Exception, NULL);
}
IL2CPP_EXTERN_C void ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshal_com_back(const ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshaled_com& marshaled, ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0& unmarshaled)
{
	Exception_t* ____target_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_target' of type 'ArrayEnumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____target_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: System.Text.Json.JsonElement/ArrayEnumerator
IL2CPP_EXTERN_C void ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshal_com_cleanup(ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_marshaled_com& marshaled)
{
}
// System.Void System.Text.Json.JsonElement/ArrayEnumerator::.ctor(System.Text.Json.JsonElement)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayEnumerator__ctor_mE63EDB3BC6E93B2C7E2A40C824553B06F853E68C (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ___target0, const RuntimeMethod* method)
{
	{
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  L_0 = ___target0;
		__this->set__target_0(L_0);
		__this->set__curIdx_1((-1));
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  L_1 = ___target0;
		JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * L_2 = L_1.get__parent_0();
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * L_3 = __this->get_address_of__target_0();
		int32_t L_4 = L_3->get__idx_1();
		NullCheck(L_2);
		int32_t L_5;
		L_5 = JsonDocument_GetEndIndex_mCB49D234EB50A854CC608B35B030D317C6478A47(L_2, L_4, (bool)0, /*hidden argument*/NULL);
		__this->set__endIdxOrVersion_2(L_5);
		return;
	}
}
IL2CPP_EXTERN_C  void ArrayEnumerator__ctor_mE63EDB3BC6E93B2C7E2A40C824553B06F853E68C_AdjustorThunk (RuntimeObject * __this, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ___target0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * _thisAdjusted = reinterpret_cast<ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *>(__this + _offset);
	ArrayEnumerator__ctor_mE63EDB3BC6E93B2C7E2A40C824553B06F853E68C(_thisAdjusted, ___target0, method);
}
// System.Text.Json.JsonElement System.Text.Json.JsonElement/ArrayEnumerator::get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ArrayEnumerator_get_Current_mF52CB9638D47BF1F300A8D90DE72F16FE7760A50 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method)
{
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		int32_t L_0 = __this->get__curIdx_1();
		if ((((int32_t)L_0) >= ((int32_t)0)))
		{
			goto IL_0013;
		}
	}
	{
		il2cpp_codegen_initobj((&V_0), sizeof(JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 ));
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  L_1 = V_0;
		return L_1;
	}

IL_0013:
	{
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * L_2 = __this->get_address_of__target_0();
		JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * L_3 = L_2->get__parent_0();
		int32_t L_4 = __this->get__curIdx_1();
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  L_5;
		memset((&L_5), 0, sizeof(L_5));
		JsonElement__ctor_m08BBC84BCD6BF2156EEA51E7E367E772C44E8C9C((&L_5), L_3, L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
IL2CPP_EXTERN_C  JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ArrayEnumerator_get_Current_mF52CB9638D47BF1F300A8D90DE72F16FE7760A50_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * _thisAdjusted = reinterpret_cast<ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *>(__this + _offset);
	JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  _returnValue;
	_returnValue = ArrayEnumerator_get_Current_mF52CB9638D47BF1F300A8D90DE72F16FE7760A50(_thisAdjusted, method);
	return _returnValue;
}
// System.Text.Json.JsonElement/ArrayEnumerator System.Text.Json.JsonElement/ArrayEnumerator::GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  ArrayEnumerator_GetEnumerator_m84826411DC72414B035DD2383B98995030DC1D64 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method)
{
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  L_0 = (*(ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *)__this);
		V_0 = L_0;
		(&V_0)->set__curIdx_1((-1));
		ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  ArrayEnumerator_GetEnumerator_m84826411DC72414B035DD2383B98995030DC1D64_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * _thisAdjusted = reinterpret_cast<ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *>(__this + _offset);
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  _returnValue;
	_returnValue = ArrayEnumerator_GetEnumerator_m84826411DC72414B035DD2383B98995030DC1D64(_thisAdjusted, method);
	return _returnValue;
}
// System.Collections.IEnumerator System.Text.Json.JsonElement/ArrayEnumerator::System.Collections.IEnumerable.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* ArrayEnumerator_System_Collections_IEnumerable_GetEnumerator_mFA06CBD3D1326936DCA477D78774A7D5244051B2 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  L_0;
		L_0 = ArrayEnumerator_GetEnumerator_m84826411DC72414B035DD2383B98995030DC1D64((ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *)__this, /*hidden argument*/NULL);
		ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  L_1 = L_0;
		RuntimeObject * L_2 = Box(ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_il2cpp_TypeInfo_var, &L_1);
		return (RuntimeObject*)L_2;
	}
}
IL2CPP_EXTERN_C  RuntimeObject* ArrayEnumerator_System_Collections_IEnumerable_GetEnumerator_mFA06CBD3D1326936DCA477D78774A7D5244051B2_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * _thisAdjusted = reinterpret_cast<ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *>(__this + _offset);
	RuntimeObject* _returnValue;
	_returnValue = ArrayEnumerator_System_Collections_IEnumerable_GetEnumerator_mFA06CBD3D1326936DCA477D78774A7D5244051B2(_thisAdjusted, method);
	return _returnValue;
}
// System.Collections.Generic.IEnumerator`1<System.Text.Json.JsonElement> System.Text.Json.JsonElement/ArrayEnumerator::System.Collections.Generic.IEnumerable<System.Text.Json.JsonElement>.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* ArrayEnumerator_System_Collections_Generic_IEnumerableU3CSystem_Text_Json_JsonElementU3E_GetEnumerator_m7E27A28429F4B25E812197A40277394C3898FBF4 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  L_0;
		L_0 = ArrayEnumerator_GetEnumerator_m84826411DC72414B035DD2383B98995030DC1D64((ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *)__this, /*hidden argument*/NULL);
		ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0  L_1 = L_0;
		RuntimeObject * L_2 = Box(ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0_il2cpp_TypeInfo_var, &L_1);
		return (RuntimeObject*)L_2;
	}
}
IL2CPP_EXTERN_C  RuntimeObject* ArrayEnumerator_System_Collections_Generic_IEnumerableU3CSystem_Text_Json_JsonElementU3E_GetEnumerator_m7E27A28429F4B25E812197A40277394C3898FBF4_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * _thisAdjusted = reinterpret_cast<ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *>(__this + _offset);
	RuntimeObject* _returnValue;
	_returnValue = ArrayEnumerator_System_Collections_Generic_IEnumerableU3CSystem_Text_Json_JsonElementU3E_GetEnumerator_m7E27A28429F4B25E812197A40277394C3898FBF4(_thisAdjusted, method);
	return _returnValue;
}
// System.Void System.Text.Json.JsonElement/ArrayEnumerator::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayEnumerator_Dispose_m013242AA10DC5F3B889EF39004D9E62C88484F36 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__endIdxOrVersion_2();
		__this->set__curIdx_1(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void ArrayEnumerator_Dispose_m013242AA10DC5F3B889EF39004D9E62C88484F36_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * _thisAdjusted = reinterpret_cast<ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *>(__this + _offset);
	ArrayEnumerator_Dispose_m013242AA10DC5F3B889EF39004D9E62C88484F36(_thisAdjusted, method);
}
// System.Void System.Text.Json.JsonElement/ArrayEnumerator::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArrayEnumerator_Reset_m4E108783AA0C9538A0723F914B99F999D0907825 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method)
{
	{
		__this->set__curIdx_1((-1));
		return;
	}
}
IL2CPP_EXTERN_C  void ArrayEnumerator_Reset_m4E108783AA0C9538A0723F914B99F999D0907825_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * _thisAdjusted = reinterpret_cast<ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *>(__this + _offset);
	ArrayEnumerator_Reset_m4E108783AA0C9538A0723F914B99F999D0907825(_thisAdjusted, method);
}
// System.Object System.Text.Json.JsonElement/ArrayEnumerator::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * ArrayEnumerator_System_Collections_IEnumerator_get_Current_m0625474B01CE733D09EC696C2D3943FEBDA9D8B9 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  L_0;
		L_0 = ArrayEnumerator_get_Current_mF52CB9638D47BF1F300A8D90DE72F16FE7760A50((ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *)__this, /*hidden argument*/NULL);
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  L_1 = L_0;
		RuntimeObject * L_2 = Box(JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49_il2cpp_TypeInfo_var, &L_1);
		return L_2;
	}
}
IL2CPP_EXTERN_C  RuntimeObject * ArrayEnumerator_System_Collections_IEnumerator_get_Current_m0625474B01CE733D09EC696C2D3943FEBDA9D8B9_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * _thisAdjusted = reinterpret_cast<ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *>(__this + _offset);
	RuntimeObject * _returnValue;
	_returnValue = ArrayEnumerator_System_Collections_IEnumerator_get_Current_m0625474B01CE733D09EC696C2D3943FEBDA9D8B9(_thisAdjusted, method);
	return _returnValue;
}
// System.Boolean System.Text.Json.JsonElement/ArrayEnumerator::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ArrayEnumerator_MoveNext_m4A4255B7F6ADA0D569E1644355F8542007BC99E8 (ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__curIdx_1();
		int32_t L_1 = __this->get__endIdxOrVersion_2();
		if ((((int32_t)L_0) < ((int32_t)L_1)))
		{
			goto IL_0010;
		}
	}
	{
		return (bool)0;
	}

IL_0010:
	{
		int32_t L_2 = __this->get__curIdx_1();
		if ((((int32_t)L_2) >= ((int32_t)0)))
		{
			goto IL_002f;
		}
	}
	{
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * L_3 = __this->get_address_of__target_0();
		int32_t L_4 = L_3->get__idx_1();
		__this->set__curIdx_1(((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)((int32_t)12))));
		goto IL_004c;
	}

IL_002f:
	{
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * L_5 = __this->get_address_of__target_0();
		JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * L_6 = L_5->get__parent_0();
		int32_t L_7 = __this->get__curIdx_1();
		NullCheck(L_6);
		int32_t L_8;
		L_8 = JsonDocument_GetEndIndex_mCB49D234EB50A854CC608B35B030D317C6478A47(L_6, L_7, (bool)1, /*hidden argument*/NULL);
		__this->set__curIdx_1(L_8);
	}

IL_004c:
	{
		int32_t L_9 = __this->get__curIdx_1();
		int32_t L_10 = __this->get__endIdxOrVersion_2();
		return (bool)((((int32_t)L_9) < ((int32_t)L_10))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool ArrayEnumerator_MoveNext_m4A4255B7F6ADA0D569E1644355F8542007BC99E8_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 * _thisAdjusted = reinterpret_cast<ArrayEnumerator_t20A1E2484160186A78E0A58CF4F9E9B7075A71D0 *>(__this + _offset);
	bool _returnValue;
	_returnValue = ArrayEnumerator_MoveNext_m4A4255B7F6ADA0D569E1644355F8542007BC99E8(_thisAdjusted, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif


// Conversion methods for marshalling of: System.Text.Json.JsonElement/ObjectEnumerator
IL2CPP_EXTERN_C void ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshal_pinvoke(const ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812& unmarshaled, ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshaled_pinvoke& marshaled)
{
	Exception_t* ____target_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_target' of type 'ObjectEnumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____target_0Exception, NULL);
}
IL2CPP_EXTERN_C void ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshal_pinvoke_back(const ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshaled_pinvoke& marshaled, ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812& unmarshaled)
{
	Exception_t* ____target_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_target' of type 'ObjectEnumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____target_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: System.Text.Json.JsonElement/ObjectEnumerator
IL2CPP_EXTERN_C void ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshal_pinvoke_cleanup(ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshaled_pinvoke& marshaled)
{
}


// Conversion methods for marshalling of: System.Text.Json.JsonElement/ObjectEnumerator
IL2CPP_EXTERN_C void ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshal_com(const ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812& unmarshaled, ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshaled_com& marshaled)
{
	Exception_t* ____target_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_target' of type 'ObjectEnumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____target_0Exception, NULL);
}
IL2CPP_EXTERN_C void ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshal_com_back(const ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshaled_com& marshaled, ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812& unmarshaled)
{
	Exception_t* ____target_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '_target' of type 'ObjectEnumerator'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(____target_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: System.Text.Json.JsonElement/ObjectEnumerator
IL2CPP_EXTERN_C void ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshal_com_cleanup(ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_marshaled_com& marshaled)
{
}
// System.Void System.Text.Json.JsonElement/ObjectEnumerator::.ctor(System.Text.Json.JsonElement)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ObjectEnumerator__ctor_mE6CFBEE462A2DAD097E3CF38C5E1F93B3A72575A (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ___target0, const RuntimeMethod* method)
{
	{
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  L_0 = ___target0;
		__this->set__target_0(L_0);
		__this->set__curIdx_1((-1));
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  L_1 = ___target0;
		JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * L_2 = L_1.get__parent_0();
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * L_3 = __this->get_address_of__target_0();
		int32_t L_4 = L_3->get__idx_1();
		NullCheck(L_2);
		int32_t L_5;
		L_5 = JsonDocument_GetEndIndex_mCB49D234EB50A854CC608B35B030D317C6478A47(L_2, L_4, (bool)0, /*hidden argument*/NULL);
		__this->set__endIdxOrVersion_2(L_5);
		return;
	}
}
IL2CPP_EXTERN_C  void ObjectEnumerator__ctor_mE6CFBEE462A2DAD097E3CF38C5E1F93B3A72575A_AdjustorThunk (RuntimeObject * __this, JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  ___target0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * _thisAdjusted = reinterpret_cast<ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *>(__this + _offset);
	ObjectEnumerator__ctor_mE6CFBEE462A2DAD097E3CF38C5E1F93B3A72575A(_thisAdjusted, ___target0, method);
}
// System.Text.Json.JsonProperty System.Text.Json.JsonElement/ObjectEnumerator::get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043  ObjectEnumerator_get_Current_mEBA991658CFB79D8EC48C940587E8F56E5FCF6A6 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method)
{
	JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		int32_t L_0 = __this->get__curIdx_1();
		if ((((int32_t)L_0) >= ((int32_t)0)))
		{
			goto IL_0013;
		}
	}
	{
		il2cpp_codegen_initobj((&V_0), sizeof(JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043 ));
		JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043  L_1 = V_0;
		return L_1;
	}

IL_0013:
	{
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * L_2 = __this->get_address_of__target_0();
		JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * L_3 = L_2->get__parent_0();
		int32_t L_4 = __this->get__curIdx_1();
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49  L_5;
		memset((&L_5), 0, sizeof(L_5));
		JsonElement__ctor_m08BBC84BCD6BF2156EEA51E7E367E772C44E8C9C((&L_5), L_3, L_4, /*hidden argument*/NULL);
		JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043  L_6;
		memset((&L_6), 0, sizeof(L_6));
		JsonProperty__ctor_m0C3653F7D2BC6F745C523466CA7294E355FABB13((&L_6), L_5, (String_t*)NULL, /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_EXTERN_C  JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043  ObjectEnumerator_get_Current_mEBA991658CFB79D8EC48C940587E8F56E5FCF6A6_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * _thisAdjusted = reinterpret_cast<ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *>(__this + _offset);
	JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043  _returnValue;
	_returnValue = ObjectEnumerator_get_Current_mEBA991658CFB79D8EC48C940587E8F56E5FCF6A6(_thisAdjusted, method);
	return _returnValue;
}
// System.Text.Json.JsonElement/ObjectEnumerator System.Text.Json.JsonElement/ObjectEnumerator::GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  ObjectEnumerator_GetEnumerator_m6431E7E6BAF73BDCC9B211871E2046D8C5557C9F (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method)
{
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  L_0 = (*(ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *)__this);
		V_0 = L_0;
		(&V_0)->set__curIdx_1((-1));
		ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  L_1 = V_0;
		return L_1;
	}
}
IL2CPP_EXTERN_C  ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  ObjectEnumerator_GetEnumerator_m6431E7E6BAF73BDCC9B211871E2046D8C5557C9F_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * _thisAdjusted = reinterpret_cast<ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *>(__this + _offset);
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  _returnValue;
	_returnValue = ObjectEnumerator_GetEnumerator_m6431E7E6BAF73BDCC9B211871E2046D8C5557C9F(_thisAdjusted, method);
	return _returnValue;
}
// System.Collections.IEnumerator System.Text.Json.JsonElement/ObjectEnumerator::System.Collections.IEnumerable.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* ObjectEnumerator_System_Collections_IEnumerable_GetEnumerator_mFABC61E9837E42D4B98EDD2EB829169691151DA4 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  L_0;
		L_0 = ObjectEnumerator_GetEnumerator_m6431E7E6BAF73BDCC9B211871E2046D8C5557C9F((ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *)__this, /*hidden argument*/NULL);
		ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  L_1 = L_0;
		RuntimeObject * L_2 = Box(ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_il2cpp_TypeInfo_var, &L_1);
		return (RuntimeObject*)L_2;
	}
}
IL2CPP_EXTERN_C  RuntimeObject* ObjectEnumerator_System_Collections_IEnumerable_GetEnumerator_mFABC61E9837E42D4B98EDD2EB829169691151DA4_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * _thisAdjusted = reinterpret_cast<ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *>(__this + _offset);
	RuntimeObject* _returnValue;
	_returnValue = ObjectEnumerator_System_Collections_IEnumerable_GetEnumerator_mFABC61E9837E42D4B98EDD2EB829169691151DA4(_thisAdjusted, method);
	return _returnValue;
}
// System.Collections.Generic.IEnumerator`1<System.Text.Json.JsonProperty> System.Text.Json.JsonElement/ObjectEnumerator::System.Collections.Generic.IEnumerable<System.Text.Json.JsonProperty>.GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* ObjectEnumerator_System_Collections_Generic_IEnumerableU3CSystem_Text_Json_JsonPropertyU3E_GetEnumerator_m152A46470709CCB7745C15E69C8B5E3CC379F292 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  L_0;
		L_0 = ObjectEnumerator_GetEnumerator_m6431E7E6BAF73BDCC9B211871E2046D8C5557C9F((ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *)__this, /*hidden argument*/NULL);
		ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812  L_1 = L_0;
		RuntimeObject * L_2 = Box(ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812_il2cpp_TypeInfo_var, &L_1);
		return (RuntimeObject*)L_2;
	}
}
IL2CPP_EXTERN_C  RuntimeObject* ObjectEnumerator_System_Collections_Generic_IEnumerableU3CSystem_Text_Json_JsonPropertyU3E_GetEnumerator_m152A46470709CCB7745C15E69C8B5E3CC379F292_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * _thisAdjusted = reinterpret_cast<ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *>(__this + _offset);
	RuntimeObject* _returnValue;
	_returnValue = ObjectEnumerator_System_Collections_Generic_IEnumerableU3CSystem_Text_Json_JsonPropertyU3E_GetEnumerator_m152A46470709CCB7745C15E69C8B5E3CC379F292(_thisAdjusted, method);
	return _returnValue;
}
// System.Void System.Text.Json.JsonElement/ObjectEnumerator::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ObjectEnumerator_Dispose_m05CE64A63964F3D868775EC395EF5AFCBFD0C772 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__endIdxOrVersion_2();
		__this->set__curIdx_1(L_0);
		return;
	}
}
IL2CPP_EXTERN_C  void ObjectEnumerator_Dispose_m05CE64A63964F3D868775EC395EF5AFCBFD0C772_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * _thisAdjusted = reinterpret_cast<ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *>(__this + _offset);
	ObjectEnumerator_Dispose_m05CE64A63964F3D868775EC395EF5AFCBFD0C772(_thisAdjusted, method);
}
// System.Void System.Text.Json.JsonElement/ObjectEnumerator::Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ObjectEnumerator_Reset_m2375949AFCB32D333217A2F8674E48BF3A948DC7 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method)
{
	{
		__this->set__curIdx_1((-1));
		return;
	}
}
IL2CPP_EXTERN_C  void ObjectEnumerator_Reset_m2375949AFCB32D333217A2F8674E48BF3A948DC7_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * _thisAdjusted = reinterpret_cast<ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *>(__this + _offset);
	ObjectEnumerator_Reset_m2375949AFCB32D333217A2F8674E48BF3A948DC7(_thisAdjusted, method);
}
// System.Object System.Text.Json.JsonElement/ObjectEnumerator::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * ObjectEnumerator_System_Collections_IEnumerator_get_Current_m819E29B32A75D77D74B6CA9F65F28BDFF7C7E6BC (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043  L_0;
		L_0 = ObjectEnumerator_get_Current_mEBA991658CFB79D8EC48C940587E8F56E5FCF6A6((ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *)__this, /*hidden argument*/NULL);
		JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043  L_1 = L_0;
		RuntimeObject * L_2 = Box(JsonProperty_tCB1F3938C98F37487EAEE5CE83568B4E7E397043_il2cpp_TypeInfo_var, &L_1);
		return L_2;
	}
}
IL2CPP_EXTERN_C  RuntimeObject * ObjectEnumerator_System_Collections_IEnumerator_get_Current_m819E29B32A75D77D74B6CA9F65F28BDFF7C7E6BC_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * _thisAdjusted = reinterpret_cast<ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *>(__this + _offset);
	RuntimeObject * _returnValue;
	_returnValue = ObjectEnumerator_System_Collections_IEnumerator_get_Current_m819E29B32A75D77D74B6CA9F65F28BDFF7C7E6BC(_thisAdjusted, method);
	return _returnValue;
}
// System.Boolean System.Text.Json.JsonElement/ObjectEnumerator::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ObjectEnumerator_MoveNext_m9EF4007222C1BFD3D5BEF8CC03A76CE222F4D859 (ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__curIdx_1();
		int32_t L_1 = __this->get__endIdxOrVersion_2();
		if ((((int32_t)L_0) < ((int32_t)L_1)))
		{
			goto IL_0010;
		}
	}
	{
		return (bool)0;
	}

IL_0010:
	{
		int32_t L_2 = __this->get__curIdx_1();
		if ((((int32_t)L_2) >= ((int32_t)0)))
		{
			goto IL_002f;
		}
	}
	{
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * L_3 = __this->get_address_of__target_0();
		int32_t L_4 = L_3->get__idx_1();
		__this->set__curIdx_1(((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)((int32_t)12))));
		goto IL_004c;
	}

IL_002f:
	{
		JsonElement_tE672EEF882F0BE64187481F9A01ED59DC71A3A49 * L_5 = __this->get_address_of__target_0();
		JsonDocument_t9E34DA6C1FAC60E7537974DBA444E4240FDD3DF1 * L_6 = L_5->get__parent_0();
		int32_t L_7 = __this->get__curIdx_1();
		NullCheck(L_6);
		int32_t L_8;
		L_8 = JsonDocument_GetEndIndex_mCB49D234EB50A854CC608B35B030D317C6478A47(L_6, L_7, (bool)1, /*hidden argument*/NULL);
		__this->set__curIdx_1(L_8);
	}

IL_004c:
	{
		int32_t L_9 = __this->get__curIdx_1();
		__this->set__curIdx_1(((int32_t)il2cpp_codegen_add((int32_t)L_9, (int32_t)((int32_t)12))));
		int32_t L_10 = __this->get__curIdx_1();
		int32_t L_11 = __this->get__endIdxOrVersion_2();
		return (bool)((((int32_t)L_10) < ((int32_t)L_11))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool ObjectEnumerator_MoveNext_m9EF4007222C1BFD3D5BEF8CC03A76CE222F4D859_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 * _thisAdjusted = reinterpret_cast<ObjectEnumerator_t66BDC39C224ABC31BECA2237860C5FCB04EF7812 *>(__this + _offset);
	bool _returnValue;
	_returnValue = ObjectEnumerator_MoveNext_m9EF4007222C1BFD3D5BEF8CC03A76CE222F4D859(_thisAdjusted, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Boolean System.Text.Json.JsonHelpers/DateTimeParseData::get_OffsetNegative()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DateTimeParseData_get_OffsetNegative_m0D054B07A34B50D970C5751B503F342C14F5F3E9 (DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E * __this, const RuntimeMethod* method)
{
	{
		uint8_t L_0 = __this->get_OffsetToken_9();
		return (bool)((((int32_t)L_0) == ((int32_t)((int32_t)45)))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool DateTimeParseData_get_OffsetNegative_m0D054B07A34B50D970C5751B503F342C14F5F3E9_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E * _thisAdjusted = reinterpret_cast<DateTimeParseData_t0480CA6D27B3381D2F549A88484E89D4C6BE109E *>(__this + _offset);
	bool _returnValue;
	_returnValue = DateTimeParseData_get_OffsetNegative_m0D054B07A34B50D970C5751B503F342C14F5F3E9(_thisAdjusted, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Text.Json.Serialization.ReflectionMemberAccessor/<>c__DisplayClass0_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass0_0__ctor_m1949513CDEB192A289C6C414E182FEC9DBB766EC (U3CU3Ec__DisplayClass0_0_t22913487C669704BBF5B5C7D3EF3A55C52F8F60F * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m88880E0413421D13FD95325EDCE231707CE1F405(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Object System.Text.Json.Serialization.ReflectionMemberAccessor/<>c__DisplayClass0_0::<CreateConstructor>b__0()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * U3CU3Ec__DisplayClass0_0_U3CCreateConstructorU3Eb__0_mB23814DC9A2E875C3CDE33E6C86AA756C30B3B6D (U3CU3Ec__DisplayClass0_0_t22913487C669704BBF5B5C7D3EF3A55C52F8F60F * __this, const RuntimeMethod* method)
{
	{
		Type_t * L_0 = __this->get_type_0();
		RuntimeObject * L_1;
		L_1 = Activator_CreateInstance_m35ED39C8B9201D90292C1803022AEE106B69A295(L_0, (bool)0, /*hidden argument*/NULL);
		return L_1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif


// Conversion methods for marshalling of: System.Text.Json.Utf8JsonReader/PartialStateForRollback
IL2CPP_EXTERN_C void PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshal_pinvoke(const PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1& unmarshaled, PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshaled_pinvoke& marshaled)
{
	marshaled.____prevTotalConsumed_0 = unmarshaled.get__prevTotalConsumed_0();
	marshaled.____prevBytePositionInLine_1 = unmarshaled.get__prevBytePositionInLine_1();
	marshaled.____prevConsumed_2 = unmarshaled.get__prevConsumed_2();
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_pinvoke(unmarshaled.get__prevCurrentPosition_3(), marshaled.____prevCurrentPosition_3);
}
IL2CPP_EXTERN_C void PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshal_pinvoke_back(const PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshaled_pinvoke& marshaled, PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1& unmarshaled)
{
	int64_t unmarshaled__prevTotalConsumed_temp_0 = 0;
	unmarshaled__prevTotalConsumed_temp_0 = marshaled.____prevTotalConsumed_0;
	unmarshaled.set__prevTotalConsumed_0(unmarshaled__prevTotalConsumed_temp_0);
	int64_t unmarshaled__prevBytePositionInLine_temp_1 = 0;
	unmarshaled__prevBytePositionInLine_temp_1 = marshaled.____prevBytePositionInLine_1;
	unmarshaled.set__prevBytePositionInLine_1(unmarshaled__prevBytePositionInLine_temp_1);
	int32_t unmarshaled__prevConsumed_temp_2 = 0;
	unmarshaled__prevConsumed_temp_2 = marshaled.____prevConsumed_2;
	unmarshaled.set__prevConsumed_2(unmarshaled__prevConsumed_temp_2);
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  unmarshaled__prevCurrentPosition_temp_3;
	memset((&unmarshaled__prevCurrentPosition_temp_3), 0, sizeof(unmarshaled__prevCurrentPosition_temp_3));
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_pinvoke_back(marshaled.____prevCurrentPosition_3, unmarshaled__prevCurrentPosition_temp_3);
	unmarshaled.set__prevCurrentPosition_3(unmarshaled__prevCurrentPosition_temp_3);
}
// Conversion method for clean up from marshalling of: System.Text.Json.Utf8JsonReader/PartialStateForRollback
IL2CPP_EXTERN_C void PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshal_pinvoke_cleanup(PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshaled_pinvoke& marshaled)
{
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_pinvoke_cleanup(marshaled.____prevCurrentPosition_3);
}


// Conversion methods for marshalling of: System.Text.Json.Utf8JsonReader/PartialStateForRollback
IL2CPP_EXTERN_C void PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshal_com(const PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1& unmarshaled, PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshaled_com& marshaled)
{
	marshaled.____prevTotalConsumed_0 = unmarshaled.get__prevTotalConsumed_0();
	marshaled.____prevBytePositionInLine_1 = unmarshaled.get__prevBytePositionInLine_1();
	marshaled.____prevConsumed_2 = unmarshaled.get__prevConsumed_2();
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_com(unmarshaled.get__prevCurrentPosition_3(), marshaled.____prevCurrentPosition_3);
}
IL2CPP_EXTERN_C void PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshal_com_back(const PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshaled_com& marshaled, PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1& unmarshaled)
{
	int64_t unmarshaled__prevTotalConsumed_temp_0 = 0;
	unmarshaled__prevTotalConsumed_temp_0 = marshaled.____prevTotalConsumed_0;
	unmarshaled.set__prevTotalConsumed_0(unmarshaled__prevTotalConsumed_temp_0);
	int64_t unmarshaled__prevBytePositionInLine_temp_1 = 0;
	unmarshaled__prevBytePositionInLine_temp_1 = marshaled.____prevBytePositionInLine_1;
	unmarshaled.set__prevBytePositionInLine_1(unmarshaled__prevBytePositionInLine_temp_1);
	int32_t unmarshaled__prevConsumed_temp_2 = 0;
	unmarshaled__prevConsumed_temp_2 = marshaled.____prevConsumed_2;
	unmarshaled.set__prevConsumed_2(unmarshaled__prevConsumed_temp_2);
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  unmarshaled__prevCurrentPosition_temp_3;
	memset((&unmarshaled__prevCurrentPosition_temp_3), 0, sizeof(unmarshaled__prevCurrentPosition_temp_3));
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_com_back(marshaled.____prevCurrentPosition_3, unmarshaled__prevCurrentPosition_temp_3);
	unmarshaled.set__prevCurrentPosition_3(unmarshaled__prevCurrentPosition_temp_3);
}
// Conversion method for clean up from marshalling of: System.Text.Json.Utf8JsonReader/PartialStateForRollback
IL2CPP_EXTERN_C void PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshal_com_cleanup(PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1_marshaled_com& marshaled)
{
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A_marshal_com_cleanup(marshaled.____prevCurrentPosition_3);
}
// System.Void System.Text.Json.Utf8JsonReader/PartialStateForRollback::.ctor(System.Int64,System.Int64,System.Int32,System.SequencePosition)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PartialStateForRollback__ctor_m0A2CA55E0DA1307DCE07752039D69E1E171C6178 (PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1 * __this, int64_t ___totalConsumed0, int64_t ___bytePositionInLine1, int32_t ___consumed2, SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  ___currentPosition3, const RuntimeMethod* method)
{
	{
		int64_t L_0 = ___totalConsumed0;
		__this->set__prevTotalConsumed_0(L_0);
		int64_t L_1 = ___bytePositionInLine1;
		__this->set__prevBytePositionInLine_1(L_1);
		int32_t L_2 = ___consumed2;
		__this->set__prevConsumed_2(L_2);
		SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  L_3 = ___currentPosition3;
		__this->set__prevCurrentPosition_3(L_3);
		return;
	}
}
IL2CPP_EXTERN_C  void PartialStateForRollback__ctor_m0A2CA55E0DA1307DCE07752039D69E1E171C6178_AdjustorThunk (RuntimeObject * __this, int64_t ___totalConsumed0, int64_t ___bytePositionInLine1, int32_t ___consumed2, SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  ___currentPosition3, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1 * _thisAdjusted = reinterpret_cast<PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1 *>(__this + _offset);
	PartialStateForRollback__ctor_m0A2CA55E0DA1307DCE07752039D69E1E171C6178(_thisAdjusted, ___totalConsumed0, ___bytePositionInLine1, ___consumed2, ___currentPosition3, method);
}
// System.SequencePosition System.Text.Json.Utf8JsonReader/PartialStateForRollback::GetStartPosition(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  PartialStateForRollback_GetStartPosition_mD8F495352B433FEE2C9D27A58FDBAC331C418D63 (PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1 * __this, int32_t ___offset0, const RuntimeMethod* method)
{
	{
		SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A * L_0 = __this->get_address_of__prevCurrentPosition_3();
		RuntimeObject * L_1;
		L_1 = SequencePosition_GetObject_m33D4D02B2042DFCCC2549006639381910F1F3525_inline((SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A *)L_0, /*hidden argument*/NULL);
		SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A * L_2 = __this->get_address_of__prevCurrentPosition_3();
		int32_t L_3;
		L_3 = SequencePosition_GetInteger_mE4D2683EB441F31A3C1474845ABBD0FA78C130DE_inline((SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A *)L_2, /*hidden argument*/NULL);
		int32_t L_4 = __this->get__prevConsumed_2();
		int32_t L_5 = ___offset0;
		SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  L_6;
		memset((&L_6), 0, sizeof(L_6));
		SequencePosition__ctor_m881E247213B0B28B3903475A1FC0237C56B5F0B0((&L_6), L_1, ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)L_4)), (int32_t)L_5)), /*hidden argument*/NULL);
		return L_6;
	}
}
IL2CPP_EXTERN_C  SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  PartialStateForRollback_GetStartPosition_mD8F495352B433FEE2C9D27A58FDBAC331C418D63_AdjustorThunk (RuntimeObject * __this, int32_t ___offset0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1 * _thisAdjusted = reinterpret_cast<PartialStateForRollback_t2E18041EA3BC1766B260CDD441330401D6F4D7B1 *>(__this + _offset);
	SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A  _returnValue;
	_returnValue = PartialStateForRollback_GetStartPosition_mD8F495352B433FEE2C9D27A58FDBAC331C418D63(_thisAdjusted, ___offset0, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CDisposeAsyncU3Ed__35_MoveNext_mFE5C0EA2A27B3FC766BF6EBE70C6B330ADCA7E74 (U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&AsyncValueTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8_m89F9EBB43B233A95E8461140AC187B63D77F2F1F_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * V_1 = NULL;
	ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  V_2;
	memset((&V_2), 0, sizeof(V_2));
	CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  V_3;
	memset((&V_3), 0, sizeof(V_3));
	ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E  V_4;
	memset((&V_4), 0, sizeof(V_4));
	Exception_t * V_5 = NULL;
	il2cpp::utils::ExceptionSupportStack<RuntimeObject*, 1> __active_exceptions;
	il2cpp::utils::ExceptionSupportStack<int32_t, 4> __leave_targets;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_006e;
			}
		}

IL_0011:
		{
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_3 = V_1;
			NullCheck(L_3);
			Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * L_4 = L_3->get__stream_4();
			if (L_4)
			{
				goto IL_0026;
			}
		}

IL_0019:
		{
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_5 = V_1;
			NullCheck(L_5);
			RuntimeObject* L_6 = L_5->get__output_3();
			if (L_6)
			{
				goto IL_0026;
			}
		}

IL_0021:
		{
			goto IL_00c7;
		}

IL_0026:
		{
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_7 = V_1;
			il2cpp_codegen_initobj((&V_3), sizeof(CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD ));
			CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  L_8 = V_3;
			NullCheck(L_7);
			Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * L_9;
			L_9 = Utf8JsonWriter_FlushAsync_m9A2787600340AB5AE4C3FE80C58FA4BC65677B68(L_7, L_8, /*hidden argument*/NULL);
			NullCheck(L_9);
			ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E  L_10;
			L_10 = Task_ConfigureAwait_m0477031D48C23B8368049C62C53C33D32322EDCE(L_9, (bool)0, /*hidden argument*/NULL);
			V_4 = L_10;
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  L_11;
			L_11 = ConfiguredTaskAwaitable_GetAwaiter_m9F912D7DF74F087AFAF1F478CE59152DF22395A2_inline((ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E *)(&V_4), /*hidden argument*/NULL);
			V_2 = L_11;
			bool L_12;
			L_12 = ConfiguredTaskAwaiter_get_IsCompleted_m98056416CC6E5741A2201994591D27D127A17730((ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *)(&V_2), /*hidden argument*/NULL);
			if (L_12)
			{
				goto IL_008a;
			}
		}

IL_004e:
		{
			int32_t L_13 = 0;
			V_0 = L_13;
			__this->set_U3CU3E1__state_0(L_13);
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  L_14 = V_2;
			__this->set_U3CU3Eu__1_3(L_14);
			AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 * L_15 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncValueTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8_m89F9EBB43B233A95E8461140AC187B63D77F2F1F((AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 *)L_15, (ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *)(&V_2), (U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 *)__this, /*hidden argument*/AsyncValueTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8_m89F9EBB43B233A95E8461140AC187B63D77F2F1F_RuntimeMethod_var);
			goto IL_00da;
		}

IL_006e:
		{
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  L_16 = __this->get_U3CU3Eu__1_3();
			V_2 = L_16;
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * L_17 = __this->get_address_of_U3CU3Eu__1_3();
			il2cpp_codegen_initobj(L_17, sizeof(ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C ));
			int32_t L_18 = (-1);
			V_0 = L_18;
			__this->set_U3CU3E1__state_0(L_18);
		}

IL_008a:
		{
			ConfiguredTaskAwaiter_GetResult_m29A9880E9FCC4B8E9928B60E137FB53D0C8F0CE6((ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *)(&V_2), /*hidden argument*/NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_19 = V_1;
			NullCheck(L_19);
			Utf8JsonWriter_ResetHelper_m106A696B3EBF0175EF391F2DAEC5FA2F3DD5129A(L_19, /*hidden argument*/NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_20 = V_1;
			NullCheck(L_20);
			L_20->set__stream_4((Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB *)NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_21 = V_1;
			NullCheck(L_21);
			L_21->set__arrayBufferWriter_5((ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 *)NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_22 = V_1;
			NullCheck(L_22);
			L_22->set__output_3((RuntimeObject*)NULL);
			goto IL_00c7;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		if(il2cpp_codegen_class_is_assignable_from (((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Exception_t_il2cpp_TypeInfo_var)), il2cpp_codegen_object_class(e.ex)))
		{
			IL2CPP_PUSH_ACTIVE_EXCEPTION(e.ex);
			goto CATCH_00ae;
		}
		throw e;
	}

CATCH_00ae:
	{ // begin catch(System.Exception)
		V_5 = ((Exception_t *)IL2CPP_GET_ACTIVE_EXCEPTION(Exception_t *));
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 * L_23 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_24 = V_5;
		AsyncValueTaskMethodBuilder_SetException_m9B47529F90B538885E5FE9B831021AB356858933((AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 *)L_23, L_24, /*hidden argument*/NULL);
		IL2CPP_POP_ACTIVE_EXCEPTION();
		goto IL_00da;
	} // end catch (depth: 1)

IL_00c7:
	{
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 * L_25 = __this->get_address_of_U3CU3Et__builder_1();
		AsyncValueTaskMethodBuilder_SetResult_m965DBAD8BBA26DB5B979D5CE7A8D30B2ED6D4AA1((AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 *)L_25, /*hidden argument*/NULL);
	}

IL_00da:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CDisposeAsyncU3Ed__35_MoveNext_mFE5C0EA2A27B3FC766BF6EBE70C6B330ADCA7E74_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 * _thisAdjusted = reinterpret_cast<U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 *>(__this + _offset);
	U3CDisposeAsyncU3Ed__35_MoveNext_mFE5C0EA2A27B3FC766BF6EBE70C6B330ADCA7E74(_thisAdjusted, method);
}
// System.Void System.Text.Json.Utf8JsonWriter/<DisposeAsync>d__35::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CDisposeAsyncU3Ed__35_SetStateMachine_mBF71AD303A810C158035E8C0C2A0658EA152E188 (U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	{
		AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncValueTaskMethodBuilder_SetStateMachine_m3188B03A10264F946C66E4219B762F5E8DA834DF((AsyncValueTaskMethodBuilder_t0D3628A9C8312F3AD587AE82AF4D8A170103B1E8 *)L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CDisposeAsyncU3Ed__35_SetStateMachine_mBF71AD303A810C158035E8C0C2A0658EA152E188_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 * _thisAdjusted = reinterpret_cast<U3CDisposeAsyncU3Ed__35_t6A5A23C047E0581E908CCB4F6163E39F9640ECD8 *>(__this + _offset);
	U3CDisposeAsyncU3Ed__35_SetStateMachine_mBF71AD303A810C158035E8C0C2A0658EA152E188(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CFlushAsyncU3Ed__36_MoveNext_m8912AC13068F93D8A40A2321928DB63BC7D32790 (U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayBufferWriter_1_Advance_m1F8E2CF2769D083066B3C2737AF52719EACD523A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayBufferWriter_1_Clear_m561DC03769B8C169BFFEB40FF3AAD308B4320805_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayBufferWriter_1_get_WrittenCount_m934380C81D0FF8B55609D3E68D229EE5C74E6C53_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArrayBufferWriter_1_get_WrittenMemory_m52E7F598C012BE7766DE9D809E7F7DAD8DB10F58_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySegment_1_get_Count_mC13AC26CCFD0EACBCC08F24F2A7BB22841B44C32_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySegment_1_get_Offset_m13F255A2A7A730982F330A448FCB32239782C505_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80_m26462E59FBB44A9CE56618666C19EF4C882860E0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IBufferWriter_1_t63F02C77711682A2CEF308B05BA53D9A7AB05ABD_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_TryGetArray_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m44A80C61AC6C2697DC2C11372DF211AED4DA945E_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * V_1 = NULL;
	bool V_2 = false;
	ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  V_3;
	memset((&V_3), 0, sizeof(V_3));
	ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  V_4;
	memset((&V_4), 0, sizeof(V_4));
	ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E  V_5;
	memset((&V_5), 0, sizeof(V_5));
	ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  V_6;
	memset((&V_6), 0, sizeof(V_6));
	Exception_t * V_7 = NULL;
	il2cpp::utils::ExceptionSupportStack<RuntimeObject*, 1> __active_exceptions;
	il2cpp::utils::ExceptionSupportStack<int32_t, 4> __leave_targets;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_00d2;
			}
		}

IL_0014:
		{
			int32_t L_3 = V_0;
			if ((((int32_t)L_3) == ((int32_t)1)))
			{
				goto IL_0169;
			}
		}

IL_001b:
		{
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_4 = V_1;
			NullCheck(L_4);
			Utf8JsonWriter_CheckNotDisposed_m83F234E5126E68BAD92D6145BF87189C78E8FF33(L_4, /*hidden argument*/NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_5 = V_1;
			NullCheck(L_5);
			Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9 * L_6 = L_5->get_address_of__memory_6();
			il2cpp_codegen_initobj(L_6, sizeof(Memory_1_tDC1BB2007CC49B78C6C191A260FD818418D9E1D9 ));
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_7 = V_1;
			NullCheck(L_7);
			Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * L_8 = L_7->get__stream_4();
			if (!L_8)
			{
				goto IL_018f;
			}
		}

IL_0038:
		{
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_9 = V_1;
			NullCheck(L_9);
			int32_t L_10;
			L_10 = Utf8JsonWriter_get_BytesPending_m3972ECDA5A4E7DBC6A17F7AA0610CB20AB58EF2C_inline(L_9, /*hidden argument*/NULL);
			if (!L_10)
			{
				goto IL_011a;
			}
		}

IL_0043:
		{
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_11 = V_1;
			NullCheck(L_11);
			ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * L_12 = L_11->get__arrayBufferWriter_5();
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_13 = V_1;
			NullCheck(L_13);
			int32_t L_14;
			L_14 = Utf8JsonWriter_get_BytesPending_m3972ECDA5A4E7DBC6A17F7AA0610CB20AB58EF2C_inline(L_13, /*hidden argument*/NULL);
			NullCheck(L_12);
			ArrayBufferWriter_1_Advance_m1F8E2CF2769D083066B3C2737AF52719EACD523A(L_12, L_14, /*hidden argument*/ArrayBufferWriter_1_Advance_m1F8E2CF2769D083066B3C2737AF52719EACD523A_RuntimeMethod_var);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_15 = V_1;
			NullCheck(L_15);
			Utf8JsonWriter_set_BytesPending_m21E09C8027465D1AD0C46E31DD91C8C83524DB10_inline(L_15, 0, /*hidden argument*/NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_16 = V_1;
			NullCheck(L_16);
			ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * L_17 = L_16->get__arrayBufferWriter_5();
			NullCheck(L_17);
			ReadOnlyMemory_1_tCB124A3C39BEB06AC2DA373EBF5A3BECA0168133  L_18;
			L_18 = ArrayBufferWriter_1_get_WrittenMemory_m52E7F598C012BE7766DE9D809E7F7DAD8DB10F58(L_17, /*hidden argument*/ArrayBufferWriter_1_get_WrittenMemory_m52E7F598C012BE7766DE9D809E7F7DAD8DB10F58_RuntimeMethod_var);
			bool L_19;
			L_19 = MemoryMarshal_TryGetArray_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m44A80C61AC6C2697DC2C11372DF211AED4DA945E(L_18, (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(&V_3), /*hidden argument*/MemoryMarshal_TryGetArray_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m44A80C61AC6C2697DC2C11372DF211AED4DA945E_RuntimeMethod_var);
			V_2 = L_19;
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_20 = V_1;
			NullCheck(L_20);
			Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * L_21 = L_20->get__stream_4();
			ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_22;
			L_22 = ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_inline((ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(&V_3), /*hidden argument*/ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_RuntimeMethod_var);
			int32_t L_23;
			L_23 = ArraySegment_1_get_Offset_m13F255A2A7A730982F330A448FCB32239782C505_inline((ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(&V_3), /*hidden argument*/ArraySegment_1_get_Offset_m13F255A2A7A730982F330A448FCB32239782C505_RuntimeMethod_var);
			int32_t L_24;
			L_24 = ArraySegment_1_get_Count_mC13AC26CCFD0EACBCC08F24F2A7BB22841B44C32_inline((ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(&V_3), /*hidden argument*/ArraySegment_1_get_Count_mC13AC26CCFD0EACBCC08F24F2A7BB22841B44C32_RuntimeMethod_var);
			CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  L_25 = __this->get_cancellationToken_3();
			NullCheck(L_21);
			Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * L_26;
			L_26 = VirtFuncInvoker4< Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 *, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*, int32_t, int32_t, CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  >::Invoke(22 /* System.Threading.Tasks.Task System.IO.Stream::WriteAsync(System.Byte[],System.Int32,System.Int32,System.Threading.CancellationToken) */, L_21, L_22, L_23, L_24, L_25);
			NullCheck(L_26);
			ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E  L_27;
			L_27 = Task_ConfigureAwait_m0477031D48C23B8368049C62C53C33D32322EDCE(L_26, (bool)0, /*hidden argument*/NULL);
			V_5 = L_27;
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  L_28;
			L_28 = ConfiguredTaskAwaitable_GetAwaiter_m9F912D7DF74F087AFAF1F478CE59152DF22395A2_inline((ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E *)(&V_5), /*hidden argument*/NULL);
			V_4 = L_28;
			bool L_29;
			L_29 = ConfiguredTaskAwaiter_get_IsCompleted_m98056416CC6E5741A2201994591D27D127A17730((ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *)(&V_4), /*hidden argument*/NULL);
			if (L_29)
			{
				goto IL_00ef;
			}
		}

IL_00ae:
		{
			int32_t L_30 = 0;
			V_0 = L_30;
			__this->set_U3CU3E1__state_0(L_30);
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  L_31 = V_4;
			__this->set_U3CU3Eu__1_4(L_31);
			AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * L_32 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80_m26462E59FBB44A9CE56618666C19EF4C882860E0((AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B *)L_32, (ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *)(&V_4), (U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80_m26462E59FBB44A9CE56618666C19EF4C882860E0_RuntimeMethod_var);
			goto IL_01f1;
		}

IL_00d2:
		{
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  L_33 = __this->get_U3CU3Eu__1_4();
			V_4 = L_33;
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * L_34 = __this->get_address_of_U3CU3Eu__1_4();
			il2cpp_codegen_initobj(L_34, sizeof(ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C ));
			int32_t L_35 = (-1);
			V_0 = L_35;
			__this->set_U3CU3E1__state_0(L_35);
		}

IL_00ef:
		{
			ConfiguredTaskAwaiter_GetResult_m29A9880E9FCC4B8E9928B60E137FB53D0C8F0CE6((ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *)(&V_4), /*hidden argument*/NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_36 = V_1;
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_37 = V_1;
			NullCheck(L_37);
			int64_t L_38;
			L_38 = Utf8JsonWriter_get_BytesCommitted_m4647460AF1A97E6805CF12393C978FE240CCB076_inline(L_37, /*hidden argument*/NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_39 = V_1;
			NullCheck(L_39);
			ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * L_40 = L_39->get__arrayBufferWriter_5();
			NullCheck(L_40);
			int32_t L_41;
			L_41 = ArrayBufferWriter_1_get_WrittenCount_m934380C81D0FF8B55609D3E68D229EE5C74E6C53_inline(L_40, /*hidden argument*/ArrayBufferWriter_1_get_WrittenCount_m934380C81D0FF8B55609D3E68D229EE5C74E6C53_RuntimeMethod_var);
			NullCheck(L_36);
			Utf8JsonWriter_set_BytesCommitted_m05CFA019A22B21A6E59B688CCD22B1C76C42E9B3_inline(L_36, ((int64_t)il2cpp_codegen_add((int64_t)L_38, (int64_t)((int64_t)((int64_t)L_41)))), /*hidden argument*/NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_42 = V_1;
			NullCheck(L_42);
			ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * L_43 = L_42->get__arrayBufferWriter_5();
			NullCheck(L_43);
			ArrayBufferWriter_1_Clear_m561DC03769B8C169BFFEB40FF3AAD308B4320805(L_43, /*hidden argument*/ArrayBufferWriter_1_Clear_m561DC03769B8C169BFFEB40FF3AAD308B4320805_RuntimeMethod_var);
		}

IL_011a:
		{
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_44 = V_1;
			NullCheck(L_44);
			Stream_t5DC87DD578C2C5298D98E7802E92DEABB66E2ECB * L_45 = L_44->get__stream_4();
			CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  L_46 = __this->get_cancellationToken_3();
			NullCheck(L_45);
			Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 * L_47;
			L_47 = VirtFuncInvoker1< Task_t804B25CFE3FC13AAEE16C8FA3BF52513F2A8DB60 *, CancellationToken_tC9D68381C9164A4BA10397257E87ADC832AF5FFD  >::Invoke(16 /* System.Threading.Tasks.Task System.IO.Stream::FlushAsync(System.Threading.CancellationToken) */, L_45, L_46);
			NullCheck(L_47);
			ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E  L_48;
			L_48 = Task_ConfigureAwait_m0477031D48C23B8368049C62C53C33D32322EDCE(L_47, (bool)0, /*hidden argument*/NULL);
			V_5 = L_48;
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  L_49;
			L_49 = ConfiguredTaskAwaitable_GetAwaiter_m9F912D7DF74F087AFAF1F478CE59152DF22395A2_inline((ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E *)(&V_5), /*hidden argument*/NULL);
			V_6 = L_49;
			bool L_50;
			L_50 = ConfiguredTaskAwaiter_get_IsCompleted_m98056416CC6E5741A2201994591D27D127A17730((ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *)(&V_6), /*hidden argument*/NULL);
			if (L_50)
			{
				goto IL_0186;
			}
		}

IL_0145:
		{
			int32_t L_51 = 1;
			V_0 = L_51;
			__this->set_U3CU3E1__state_0(L_51);
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  L_52 = V_6;
			__this->set_U3CU3Eu__1_4(L_52);
			AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * L_53 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80_m26462E59FBB44A9CE56618666C19EF4C882860E0((AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B *)L_53, (ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *)(&V_6), (U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C_TisU3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80_m26462E59FBB44A9CE56618666C19EF4C882860E0_RuntimeMethod_var);
			goto IL_01f1;
		}

IL_0169:
		{
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  L_54 = __this->get_U3CU3Eu__1_4();
			V_6 = L_54;
			ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C * L_55 = __this->get_address_of_U3CU3Eu__1_4();
			il2cpp_codegen_initobj(L_55, sizeof(ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C ));
			int32_t L_56 = (-1);
			V_0 = L_56;
			__this->set_U3CU3E1__state_0(L_56);
		}

IL_0186:
		{
			ConfiguredTaskAwaiter_GetResult_m29A9880E9FCC4B8E9928B60E137FB53D0C8F0CE6((ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C *)(&V_6), /*hidden argument*/NULL);
			goto IL_01c3;
		}

IL_018f:
		{
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_57 = V_1;
			NullCheck(L_57);
			int32_t L_58;
			L_58 = Utf8JsonWriter_get_BytesPending_m3972ECDA5A4E7DBC6A17F7AA0610CB20AB58EF2C_inline(L_57, /*hidden argument*/NULL);
			if (!L_58)
			{
				goto IL_01c3;
			}
		}

IL_0197:
		{
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_59 = V_1;
			NullCheck(L_59);
			RuntimeObject* L_60 = L_59->get__output_3();
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_61 = V_1;
			NullCheck(L_61);
			int32_t L_62;
			L_62 = Utf8JsonWriter_get_BytesPending_m3972ECDA5A4E7DBC6A17F7AA0610CB20AB58EF2C_inline(L_61, /*hidden argument*/NULL);
			NullCheck(L_60);
			InterfaceActionInvoker1< int32_t >::Invoke(0 /* System.Void System.Buffers.IBufferWriter`1<System.Byte>::Advance(System.Int32) */, IBufferWriter_1_t63F02C77711682A2CEF308B05BA53D9A7AB05ABD_il2cpp_TypeInfo_var, L_60, L_62);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_63 = V_1;
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_64 = V_1;
			NullCheck(L_64);
			int64_t L_65;
			L_65 = Utf8JsonWriter_get_BytesCommitted_m4647460AF1A97E6805CF12393C978FE240CCB076_inline(L_64, /*hidden argument*/NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_66 = V_1;
			NullCheck(L_66);
			int32_t L_67;
			L_67 = Utf8JsonWriter_get_BytesPending_m3972ECDA5A4E7DBC6A17F7AA0610CB20AB58EF2C_inline(L_66, /*hidden argument*/NULL);
			NullCheck(L_63);
			Utf8JsonWriter_set_BytesCommitted_m05CFA019A22B21A6E59B688CCD22B1C76C42E9B3_inline(L_63, ((int64_t)il2cpp_codegen_add((int64_t)L_65, (int64_t)((int64_t)((int64_t)L_67)))), /*hidden argument*/NULL);
			Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * L_68 = V_1;
			NullCheck(L_68);
			Utf8JsonWriter_set_BytesPending_m21E09C8027465D1AD0C46E31DD91C8C83524DB10_inline(L_68, 0, /*hidden argument*/NULL);
		}

IL_01c3:
		{
			goto IL_01de;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		if(il2cpp_codegen_class_is_assignable_from (((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Exception_t_il2cpp_TypeInfo_var)), il2cpp_codegen_object_class(e.ex)))
		{
			IL2CPP_PUSH_ACTIVE_EXCEPTION(e.ex);
			goto CATCH_01c5;
		}
		throw e;
	}

CATCH_01c5:
	{ // begin catch(System.Exception)
		V_7 = ((Exception_t *)IL2CPP_GET_ACTIVE_EXCEPTION(Exception_t *));
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * L_69 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_70 = V_7;
		AsyncTaskMethodBuilder_SetException_m54A9FC97C33C9AC4E514923F7C58D76B94D344C4((AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B *)L_69, L_70, /*hidden argument*/NULL);
		IL2CPP_POP_ACTIVE_EXCEPTION();
		goto IL_01f1;
	} // end catch (depth: 1)

IL_01de:
	{
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * L_71 = __this->get_address_of_U3CU3Et__builder_1();
		AsyncTaskMethodBuilder_SetResult_m89AF7435D1B349EE8A377B5DFFC082999D9F8CD9((AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B *)L_71, /*hidden argument*/NULL);
	}

IL_01f1:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CFlushAsyncU3Ed__36_MoveNext_m8912AC13068F93D8A40A2321928DB63BC7D32790_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 * _thisAdjusted = reinterpret_cast<U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 *>(__this + _offset);
	U3CFlushAsyncU3Ed__36_MoveNext_m8912AC13068F93D8A40A2321928DB63BC7D32790(_thisAdjusted, method);
}
// System.Void System.Text.Json.Utf8JsonWriter/<FlushAsync>d__36::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CFlushAsyncU3Ed__36_SetStateMachine_m18624CF1FEFE83DD9B7E9250A954B72BE3C094A2 (U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	{
		AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_SetStateMachine_m68788E9C6C30BBAA030DEC1963E8A6C6B2C8A3E6((AsyncTaskMethodBuilder_t7A010673279CD8726E70047F1D15B3D17C56503B *)L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CFlushAsyncU3Ed__36_SetStateMachine_m18624CF1FEFE83DD9B7E9250A954B72BE3C094A2_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 * _thisAdjusted = reinterpret_cast<U3CFlushAsyncU3Ed__36_tC052FB3203AB6EF861B6B4E81A616C252FFB5E80 *>(__this + _offset);
	U3CFlushAsyncU3Ed__36_SetStateMachine_m18624CF1FEFE83DD9B7E9250A954B72BE3C094A2(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * JsonClassInfo_get_PropertyInfoForClassInfo_m43DD25A15635FAD68648F55AD79A8B6FB15433FC_inline (JsonClassInfo_t1F7C9730029369449C401FA477693844B283CB18 * __this, const RuntimeMethod* method)
{
	{
		JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * L_0 = __this->get_U3CPropertyInfoForClassInfoU3Ek__BackingField_9();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  JsonPropertyInfo_get_NumberHandling_m3F57EC55C9CC7CE9C1017CBF1B737759673F3947_inline (JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * __this, const RuntimeMethod* method)
{
	{
		Nullable_1_tD7EBB4FB658382E735D08AC4DCD5B61517848B58  L_0 = __this->get_U3CNumberHandlingU3Ek__BackingField_19();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * JsonSerializerOptions_get_ReferenceHandler_m0617CB46B783371338540A3A470133DE6CB5CD9A_inline (JsonSerializerOptions_t77B1FC04F2E8F2FB6884E3A0DCBAC3B5B0067904 * __this, const RuntimeMethod* method)
{
	{
		ReferenceHandler_t8489FE77ED8ABB51919798A3F1AEEBB59D7FCA6F * L_0 = __this->get__referenceHandler_13();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR MemberInfo_t * JsonPropertyInfo_get_MemberInfo_mDB50F867A36435920C12ED71CA72580FF7EB3A8E_inline (JsonPropertyInfo_t4ECFDE458350897F1300CC958DE8A6777F13920F * __this, const RuntimeMethod* method)
{
	{
		MemberInfo_t * L_0 = __this->get_U3CMemberInfoU3Ek__BackingField_14();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * StringComparer_get_OrdinalIgnoreCase_m8FD38206B6FFE866E97CE4DF84B037F0DF175288_inline (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_il2cpp_TypeInfo_var);
		StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6 * L_0 = ((StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_StaticFields*)il2cpp_codegen_static_fields_for(StringComparer_t69EC059128AD0CAE268CA1A1C33125DAC9D7F8D6_il2cpp_TypeInfo_var))->get__ordinalIgnoreCase_3();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR String_t* ParameterLookupKey_get_Name_m048FB355797E2E00063B62A5FDB6A30CE1C543CC_inline (ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_U3CNameU3Ek__BackingField_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Type_t * ParameterLookupKey_get_Type_m66F89A37473AEEDE2674D17D6FD97C773D54B23A_inline (ParameterLookupKey_t256E425DFF067FB4EADE144D16CE9F71AB8FF6F9 * __this, const RuntimeMethod* method)
{
	{
		Type_t * L_0 = __this->get_U3CTypeU3Ek__BackingField_1();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t DbRow_get_Location_m64A1FE8677C03A2ED3384727229059262AD3F149_inline (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__location_1();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t MetadataDb_get_Length_m358C82F2ACD118F1A31750A408DE4A80D9706AC1_inline (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_U3CLengthU3Ek__BackingField_2();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void MetadataDb_set_Length_mDEED679131C22B2B98BD28E71CABB539B01E79C7_inline (MetadataDb_t5CA7F8F87B7B358F3B574C7E142142511EB67E26 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_U3CLengthU3Ek__BackingField_2(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject * SequencePosition_GetObject_m33D4D02B2042DFCCC2549006639381910F1F3525_inline (SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject * L_0 = __this->get__object_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t SequencePosition_GetInteger_mE4D2683EB441F31A3C1474845ABBD0FA78C130DE_inline (SequencePosition_t60FFA8E61B4E8F902C0B0F1F6DC4494561396F2A * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__integer_1();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  ConfiguredTaskAwaitable_GetAwaiter_m9F912D7DF74F087AFAF1F478CE59152DF22395A2_inline (ConfiguredTaskAwaitable_t4B703D7D241C339E7814EFFE5D266424E90BCE1E * __this, const RuntimeMethod* method)
{
	{
		ConfiguredTaskAwaiter_tF5D70726C84CD1BBDFC5E58FFB1000C5750EA28C  L_0 = __this->get_m_configuredTaskAwaiter_0();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Utf8JsonWriter_get_BytesPending_m3972ECDA5A4E7DBC6A17F7AA0610CB20AB58EF2C_inline (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_U3CBytesPendingU3Ek__BackingField_12();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Utf8JsonWriter_set_BytesPending_m21E09C8027465D1AD0C46E31DD91C8C83524DB10_inline (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_U3CBytesPendingU3Ek__BackingField_12(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int64_t Utf8JsonWriter_get_BytesCommitted_m4647460AF1A97E6805CF12393C978FE240CCB076_inline (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, const RuntimeMethod* method)
{
	{
		int64_t L_0 = __this->get_U3CBytesCommittedU3Ek__BackingField_13();
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Utf8JsonWriter_set_BytesCommitted_m05CFA019A22B21A6E59B688CCD22B1C76C42E9B3_inline (Utf8JsonWriter_t93EB29BFC60D7BEB75A4B67A20EB67FDABAF4D0C * __this, int64_t ___value0, const RuntimeMethod* method)
{
	{
		int64_t L_0 = ___value0;
		__this->set_U3CBytesCommittedU3Ek__BackingField_13(L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_mAF5A5D24EE6E3206F64DF2764D69FE6EEDB40E90_gshared_inline (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__size_2();
		return (int32_t)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Nullable_1_get_HasValue_m4C033F49F5318E94BC8CBA9CE5175EFDBFADEF9C_gshared_inline (Nullable_1_t64244F99361E39CBE565C5E89436C898F18DF5DC * __this, const RuntimeMethod* method)
{
	{
		bool L_0 = (bool)__this->get_has_value_1();
		return (bool)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  List_1_get_Item_mAB5EA3A07A26FD1029B2FF62C17A95ABCB5F55F8_gshared_inline (List_1_tF2499087CC60A2FD258D436202FF0BAE1EEFACE5 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___index0;
		int32_t L_1 = (int32_t)__this->get__size_2();
		if ((!(((uint32_t)L_0) >= ((uint32_t)L_1))))
		{
			goto IL_000e;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m4841366ABC2B2AFA37C10900551D7E07522C0929(/*hidden argument*/NULL);
	}

IL_000e:
	{
		WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A* L_2 = (WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A*)__this->get__items_1();
		int32_t L_3 = ___index0;
		WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9  L_4;
		L_4 = IL2CPP_ARRAY_UNSAFE_LOAD((WriteStackFrameU5BU5D_tE74679CF32F08F498E6F3505D865052E408A9F9A*)L_2, (int32_t)L_3);
		return (WriteStackFrame_t417CDBE27C42D3F13F553AF5E88DFE6EDA7C63C9 )L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  ConfiguredTaskAwaitable_1_GetAwaiter_m80F1877E5304C1EB51E7F1E92D2C4CA3A9A3AC6D_gshared_inline (ConfiguredTaskAwaitable_1_tE42D30E9F9657F20F7553A66296B3105F5F75AF8 * __this, const RuntimeMethod* method)
{
	{
		ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C  L_0 = (ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C )__this->get_m_configuredTaskAwaiter_0();
		return (ConfiguredTaskAwaiter_t263979B372CD16DB1D31D22859E450E737FD8E3C )L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_gshared_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, const RuntimeMethod* method)
{
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)__this->get__array_0();
		return (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mD932D4A4EC20A3549450351374B5D165258B0C91_gshared_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE  ___segment0, const RuntimeMethod* method)
{
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0;
		L_0 = ArraySegment_1_get_Array_m3D83A2CFF4D51F8ED83C89538616FF0A700F463C_inline((ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(&___segment0), /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		int32_t L_1;
		L_1 = ArraySegment_1_get_Offset_m13F255A2A7A730982F330A448FCB32239782C505_inline((ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(&___segment0), /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 1));
		int32_t L_2;
		L_2 = ArraySegment_1_get_Count_mC13AC26CCFD0EACBCC08F24F2A7BB22841B44C32_inline((ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE *)(&___segment0), /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2));
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_3;
		memset((&L_3), 0, sizeof(L_3));
		Span_1__ctor_m9DE8211969D97AFD415F2998D3789BA642B8A85D_inline((&L_3), (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)L_0, (int32_t)L_1, (int32_t)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 4));
		return (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 )L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * ArrayPool_1_get_Shared_m2AA7C1F464F378C57D751F50D6A2DACB49423177_gshared_inline (const RuntimeMethod* method)
{
	ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * G_B2_0 = NULL;
	ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * G_B1_0 = NULL;
	{
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_0;
		L_0 = VolatileRead((ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E **)(ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E **)(((ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E_StaticFields*)il2cpp_codegen_static_fields_for(IL2CPP_RGCTX_DATA(InitializedTypeInfo(method->klass)->rgctx_data, 0)))->get_address_of_s_sharedInstance_0()));
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_1 = (ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E *)L_0;
		G_B1_0 = L_1;
		if (L_1)
		{
			G_B2_0 = L_1;
			goto IL_0013;
		}
	}
	{
		ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * L_2;
		L_2 = ((  ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E * (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 2)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 2));
		G_B2_0 = L_2;
	}

IL_0013:
	{
		return (ArrayPool_1_t9EAF325673306B25516CA1931E3F970C7EFE8E9E *)G_B2_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__length_2();
		return (int32_t)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  ConfiguredTaskAwaitable_1_GetAwaiter_m8FA39505FC2099C60148C0F029CB49792690A0D5_gshared_inline (ConfiguredTaskAwaitable_1_t95CB4612A5B70DDFE0643FA38A73D6B984DD68EC * __this, const RuntimeMethod* method)
{
	{
		ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2  L_0 = (ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 )__this->get_m_configuredTaskAwaiter_0();
		return (ConfiguredTaskAwaiter_tC61B5622274D0DD1DDBFA197A90CBDAF40F230C2 )L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  MemoryExtensions_AsSpan_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m6955BA619EE2853DF64EE18CF1A0C12ECCB873DE_gshared_inline (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, int32_t ___start1, int32_t ___length2, const RuntimeMethod* method)
{
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = ___array0;
		int32_t L_1 = ___start1;
		int32_t L_2 = ___length2;
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_3;
		memset((&L_3), 0, sizeof(L_3));
		Span_1__ctor_m9DE8211969D97AFD415F2998D3789BA642B8A85D_inline((&L_3), (ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726*)L_0, (int32_t)L_1, (int32_t)L_2, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 1));
		return (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 )L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool MemoryExtensions_SequenceEqual_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_mA47AE57649F12A2400FE13BDC84254F05A99D1AA_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___span0, ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___other1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  V_1;
	memset((&V_1), 0, sizeof(V_1));
	uint8_t V_2 = 0x0;
	{
		int32_t L_0;
		L_0 = ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_inline((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(&___span0), /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		V_0 = (int32_t)L_0;
		il2cpp_codegen_initobj((&V_2), sizeof(uint8_t));
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(MemoryExtensions_t3692531D647148747BC65C4610E740AEE9983A40_il2cpp_TypeInfo_var);
		bool L_2;
		L_2 = ((  bool (*) (NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5 *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2)->methodPointer)((NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5 *)(NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5 *)(&V_1), /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2));
		if (!L_2)
		{
			goto IL_0055;
		}
	}
	{
		int32_t L_3 = V_0;
		int32_t L_4;
		L_4 = ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_inline((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(&___other1), /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		if ((!(((uint32_t)L_3) == ((uint32_t)L_4))))
		{
			goto IL_0053;
		}
	}
	{
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_5 = ___span0;
		uint8_t* L_6;
		L_6 = ((  uint8_t* (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 )L_5, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		uint8_t* L_7;
		L_7 = ((  uint8_t* (*) (uint8_t*, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 4)->methodPointer)((uint8_t*)(uint8_t*)L_6, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 4));
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_8 = ___other1;
		uint8_t* L_9;
		L_9 = ((  uint8_t* (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 )L_8, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		uint8_t* L_10;
		L_10 = ((  uint8_t* (*) (uint8_t*, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 4)->methodPointer)((uint8_t*)(uint8_t*)L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 4));
		int32_t L_11 = V_0;
		NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  L_12;
		L_12 = NUInt_op_Explicit_m680513883587956D1452B1EB6D321D4C3A0C8366((int32_t)L_11, /*hidden argument*/NULL);
		NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  L_13 = V_1;
		NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  L_14;
		L_14 = NUInt_op_Multiply_mABFB3E10A51F74FDC0CD9B799B7BF35C2C5D8D85_inline((NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5 )L_12, (NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5 )L_13, /*hidden argument*/NULL);
		bool L_15;
		L_15 = SpanHelpers_SequenceEqual_mDEB0F358BB173EA24BEEB0609454A997E9273A89((uint8_t*)(uint8_t*)L_7, (uint8_t*)(uint8_t*)L_10, (NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5 )L_14, /*hidden argument*/NULL);
		return (bool)L_15;
	}

IL_0053:
	{
		return (bool)0;
	}

IL_0055:
	{
		int32_t L_16 = V_0;
		int32_t L_17;
		L_17 = ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_inline((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(&___other1), /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		if ((!(((uint32_t)L_16) == ((uint32_t)L_17))))
		{
			goto IL_0072;
		}
	}
	{
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_18 = ___span0;
		uint8_t* L_19;
		L_19 = ((  uint8_t* (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 )L_18, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_20 = ___other1;
		uint8_t* L_21;
		L_21 = ((  uint8_t* (*) (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 )L_20, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		int32_t L_22 = V_0;
		bool L_23;
		L_23 = ((  bool (*) (uint8_t*, uint8_t*, int32_t, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 5)->methodPointer)((uint8_t*)(uint8_t*)L_19, (uint8_t*)(uint8_t*)L_21, (int32_t)L_22, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 5));
		return (bool)L_23;
	}

IL_0072:
	{
		return (bool)0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void MemoryMarshal_Write_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mBBD4DDE8A6973C64B3C4941610C05FA656A63B48_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * ___value1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Type_t_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0;
		L_0 = ((  bool (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  L_1 = { reinterpret_cast<intptr_t> (IL2CPP_RGCTX_TYPE(method->rgctx_data, 1)) };
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2;
		L_2 = Type_GetTypeFromHandle_m8BB57524FF7F9DB1803BC561D2B3A4DBACEB385E((RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9 )L_1, /*hidden argument*/NULL);
		ThrowHelper_ThrowArgumentException_InvalidTypeWithPointersNotSupported_m4A71872D4B069AF36758A61E4CA3FB663B4E8EC4((Type_t *)L_2, /*hidden argument*/NULL);
	}

IL_0016:
	{
		int32_t L_3;
		L_3 = ((  int32_t (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2));
		int32_t L_4;
		L_4 = Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_inline((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(&___destination0), /*hidden argument*/Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_RuntimeMethod_var);
		if ((!(((uint32_t)L_3) > ((uint32_t)L_4))))
		{
			goto IL_002a;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5((int32_t)0, /*hidden argument*/NULL);
	}

IL_002a:
	{
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_5 = ___destination0;
		uint8_t* L_6;
		L_6 = MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 )L_5, /*hidden argument*/MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226_RuntimeMethod_var);
		DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F * L_7 = ___value1;
		DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  L_8 = (*(DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F *)L_7);
		((  void (*) (uint8_t*, DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((uint8_t*)(uint8_t*)L_6, (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F )L_8, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void MemoryMarshal_Write_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m3546F4E6B8C44B6A72900AA10EEECE219C984A33_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, int32_t* ___value1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Type_t_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0;
		L_0 = ((  bool (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  L_1 = { reinterpret_cast<intptr_t> (IL2CPP_RGCTX_TYPE(method->rgctx_data, 1)) };
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2;
		L_2 = Type_GetTypeFromHandle_m8BB57524FF7F9DB1803BC561D2B3A4DBACEB385E((RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9 )L_1, /*hidden argument*/NULL);
		ThrowHelper_ThrowArgumentException_InvalidTypeWithPointersNotSupported_m4A71872D4B069AF36758A61E4CA3FB663B4E8EC4((Type_t *)L_2, /*hidden argument*/NULL);
	}

IL_0016:
	{
		int32_t L_3;
		L_3 = ((  int32_t (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2));
		int32_t L_4;
		L_4 = Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_inline((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(&___destination0), /*hidden argument*/Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_RuntimeMethod_var);
		if ((!(((uint32_t)L_3) > ((uint32_t)L_4))))
		{
			goto IL_002a;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5((int32_t)0, /*hidden argument*/NULL);
	}

IL_002a:
	{
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_5 = ___destination0;
		uint8_t* L_6;
		L_6 = MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 )L_5, /*hidden argument*/MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226_RuntimeMethod_var);
		int32_t* L_7 = ___value1;
		int32_t L_8 = (*(int32_t*)L_7);
		((  void (*) (uint8_t*, int32_t, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((uint8_t*)(uint8_t*)L_6, (int32_t)L_8, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t MemoryMarshal_Read_TisInt32_tFDE5F8CD43D10453F6A2E0C77FE48C6CC7009046_m1FFB9B012B4A9FE5B0706BCE11741E837018D950_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Type_t_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0;
		L_0 = ((  bool (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  L_1 = { reinterpret_cast<intptr_t> (IL2CPP_RGCTX_TYPE(method->rgctx_data, 1)) };
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2;
		L_2 = Type_GetTypeFromHandle_m8BB57524FF7F9DB1803BC561D2B3A4DBACEB385E((RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9 )L_1, /*hidden argument*/NULL);
		ThrowHelper_ThrowArgumentException_InvalidTypeWithPointersNotSupported_m4A71872D4B069AF36758A61E4CA3FB663B4E8EC4((Type_t *)L_2, /*hidden argument*/NULL);
	}

IL_0016:
	{
		int32_t L_3;
		L_3 = ((  int32_t (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2));
		int32_t L_4;
		L_4 = ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_inline((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(&___source0), /*hidden argument*/ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var);
		if ((((int32_t)L_3) <= ((int32_t)L_4)))
		{
			goto IL_002a;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5((int32_t)0, /*hidden argument*/NULL);
	}

IL_002a:
	{
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_5 = ___source0;
		uint8_t* L_6;
		L_6 = MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 )L_5, /*hidden argument*/MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_RuntimeMethod_var);
		int32_t L_7;
		L_7 = ((  int32_t (*) (uint8_t*, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((uint8_t*)(uint8_t*)L_6, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		return (int32_t)L_7;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  Span_1_Slice_mC8E25AC937B49CDD57AA85FF493D7F42595F8EAA_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, int32_t ___start0, const RuntimeMethod* method)
{
	intptr_t V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	{
		int32_t L_0 = ___start0;
		int32_t L_1 = (int32_t)__this->get__length_2();
		if ((!(((uint32_t)L_0) > ((uint32_t)L_1))))
		{
			goto IL_000f;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5((int32_t)1, /*hidden argument*/NULL);
	}

IL_000f:
	{
		intptr_t L_2 = (intptr_t)__this->get__byteOffset_1();
		int32_t L_3 = ___start0;
		intptr_t L_4;
		L_4 = ((  intptr_t (*) (intptr_t, int32_t, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 14)->methodPointer)((intptr_t)L_2, (int32_t)L_3, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 14));
		V_0 = (intptr_t)L_4;
		int32_t L_5 = (int32_t)__this->get__length_2();
		int32_t L_6 = ___start0;
		V_1 = (int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_5, (int32_t)L_6));
		Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * L_7 = (Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 *)__this->get__pinnable_0();
		intptr_t L_8 = V_0;
		int32_t L_9 = V_1;
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_10;
		memset((&L_10), 0, sizeof(L_10));
		Span_1__ctor_mFF8F544A7E3798F8239A0FEB4D32301758CBFCCA_inline((&L_10), (Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 *)L_7, (intptr_t)L_8, (int32_t)L_9, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 15));
		return (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 )L_10;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  MemoryMarshal_Read_TisDbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F_mDC4072A886419038116613EC75045133A12F639E_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Type_t_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0;
		L_0 = ((  bool (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  L_1 = { reinterpret_cast<intptr_t> (IL2CPP_RGCTX_TYPE(method->rgctx_data, 1)) };
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2;
		L_2 = Type_GetTypeFromHandle_m8BB57524FF7F9DB1803BC561D2B3A4DBACEB385E((RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9 )L_1, /*hidden argument*/NULL);
		ThrowHelper_ThrowArgumentException_InvalidTypeWithPointersNotSupported_m4A71872D4B069AF36758A61E4CA3FB663B4E8EC4((Type_t *)L_2, /*hidden argument*/NULL);
	}

IL_0016:
	{
		int32_t L_3;
		L_3 = ((  int32_t (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2));
		int32_t L_4;
		L_4 = ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_inline((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(&___source0), /*hidden argument*/ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var);
		if ((((int32_t)L_3) <= ((int32_t)L_4)))
		{
			goto IL_002a;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5((int32_t)0, /*hidden argument*/NULL);
	}

IL_002a:
	{
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_5 = ___source0;
		uint8_t* L_6;
		L_6 = MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 )L_5, /*hidden argument*/MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_RuntimeMethod_var);
		DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  L_7;
		L_7 = ((  DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F  (*) (uint8_t*, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((uint8_t*)(uint8_t*)L_6, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		return (DbRow_tAF1E82E152D2383E60EEAD13C1907E86A169560F )L_7;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t MemoryMarshal_Read_TisUInt32_tE60352A06233E4E69DD198BCC67142159F686B15_m833630665CFD238E8565314AC52CFADD215AB189_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Type_t_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0;
		L_0 = ((  bool (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  L_1 = { reinterpret_cast<intptr_t> (IL2CPP_RGCTX_TYPE(method->rgctx_data, 1)) };
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2;
		L_2 = Type_GetTypeFromHandle_m8BB57524FF7F9DB1803BC561D2B3A4DBACEB385E((RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9 )L_1, /*hidden argument*/NULL);
		ThrowHelper_ThrowArgumentException_InvalidTypeWithPointersNotSupported_m4A71872D4B069AF36758A61E4CA3FB663B4E8EC4((Type_t *)L_2, /*hidden argument*/NULL);
	}

IL_0016:
	{
		int32_t L_3;
		L_3 = ((  int32_t (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2));
		int32_t L_4;
		L_4 = ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_inline((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(&___source0), /*hidden argument*/ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var);
		if ((((int32_t)L_3) <= ((int32_t)L_4)))
		{
			goto IL_002a;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5((int32_t)0, /*hidden argument*/NULL);
	}

IL_002a:
	{
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_5 = ___source0;
		uint8_t* L_6;
		L_6 = MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 )L_5, /*hidden argument*/MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_RuntimeMethod_var);
		uint32_t L_7;
		L_7 = ((  uint32_t (*) (uint8_t*, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((uint8_t*)(uint8_t*)L_6, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		return (uint32_t)L_7;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t* Span_1_get_Item_mE8544DBC448A1E9D05A8AC89B0399CB9B0275A2C_gshared_inline (Span_1_t5B9CA8F9159D1D514608F712D98F78424DC22526 * __this, int32_t ___index0, const RuntimeMethod* method)
{
	intptr_t V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		int32_t L_0 = ___index0;
		int32_t L_1 = (int32_t)__this->get__length_2();
		if ((!(((uint32_t)L_0) >= ((uint32_t)L_1))))
		{
			goto IL_000e;
		}
	}
	{
		ThrowHelper_ThrowIndexOutOfRangeException_m4D1EB8558F17DFE372ECF87D9BCAD112A7F5E6BC(/*hidden argument*/NULL);
	}

IL_000e:
	{
		Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D * L_2 = (Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D *)__this->get__pinnable_0();
		if (L_2)
		{
			goto IL_0030;
		}
	}
	{
		intptr_t L_3 = (intptr_t)__this->get__byteOffset_1();
		V_0 = (intptr_t)L_3;
		void* L_4;
		L_4 = IntPtr_ToPointer_m5C7CE32B14B6E30467B378052FEA25300833C61F_inline((intptr_t*)(intptr_t*)(&V_0), /*hidden argument*/NULL);
		int32_t* L_5;
		L_5 = ((  int32_t* (*) (void*, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 18)->methodPointer)((void*)(void*)L_4, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 18));
		int32_t L_6 = ___index0;
		int32_t* L_7;
		L_7 = ((  int32_t* (*) (int32_t*, int32_t, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 19)->methodPointer)((int32_t*)(int32_t*)L_5, (int32_t)L_6, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 19));
		return (int32_t*)(L_7);
	}

IL_0030:
	{
		Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D * L_8 = (Pinnable_1_t2B5818FCEB043409BD3A4AB321D09A4F2DF97C2D *)__this->get__pinnable_0();
		NullCheck(L_8);
		int32_t* L_9 = (int32_t*)L_8->get_address_of_Data_0();
		intptr_t L_10 = (intptr_t)__this->get__byteOffset_1();
		int32_t* L_11;
		L_11 = ((  int32_t* (*) (int32_t*, intptr_t, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 20)->methodPointer)((int32_t*)(int32_t*)L_9, (intptr_t)L_10, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 20));
		int32_t L_12 = ___index0;
		int32_t* L_13;
		L_13 = ((  int32_t* (*) (int32_t*, int32_t, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 19)->methodPointer)((int32_t*)(int32_t*)L_11, (int32_t)L_12, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 19));
		return (int32_t*)(L_13);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void MemoryMarshal_Write_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m53B95538AC301102BF79930E0E45D3300B903BC7_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  ___destination0, StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA * ___value1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Type_t_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0;
		L_0 = ((  bool (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  L_1 = { reinterpret_cast<intptr_t> (IL2CPP_RGCTX_TYPE(method->rgctx_data, 1)) };
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2;
		L_2 = Type_GetTypeFromHandle_m8BB57524FF7F9DB1803BC561D2B3A4DBACEB385E((RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9 )L_1, /*hidden argument*/NULL);
		ThrowHelper_ThrowArgumentException_InvalidTypeWithPointersNotSupported_m4A71872D4B069AF36758A61E4CA3FB663B4E8EC4((Type_t *)L_2, /*hidden argument*/NULL);
	}

IL_0016:
	{
		int32_t L_3;
		L_3 = ((  int32_t (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2));
		int32_t L_4;
		L_4 = Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_inline((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 *)(&___destination0), /*hidden argument*/Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_RuntimeMethod_var);
		if ((!(((uint32_t)L_3) > ((uint32_t)L_4))))
		{
			goto IL_002a;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5((int32_t)0, /*hidden argument*/NULL);
	}

IL_002a:
	{
		Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83  L_5 = ___destination0;
		uint8_t* L_6;
		L_6 = MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226((Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 )L_5, /*hidden argument*/MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m7579CCE6AC3903FE1E738D4C53729B00A806C226_RuntimeMethod_var);
		StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA * L_7 = ___value1;
		StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  L_8 = (*(StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA *)L_7);
		((  void (*) (uint8_t*, StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA , const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((uint8_t*)(uint8_t*)L_6, (StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA )L_8, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  MemoryMarshal_Read_TisStackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA_m4C4E201B0499E179319483CA0E299BBC4BFF6688_gshared_inline (ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  ___source0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Type_t_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0;
		L_0 = ((  bool (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 0));
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  L_1 = { reinterpret_cast<intptr_t> (IL2CPP_RGCTX_TYPE(method->rgctx_data, 1)) };
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2;
		L_2 = Type_GetTypeFromHandle_m8BB57524FF7F9DB1803BC561D2B3A4DBACEB385E((RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9 )L_1, /*hidden argument*/NULL);
		ThrowHelper_ThrowArgumentException_InvalidTypeWithPointersNotSupported_m4A71872D4B069AF36758A61E4CA3FB663B4E8EC4((Type_t *)L_2, /*hidden argument*/NULL);
	}

IL_0016:
	{
		int32_t L_3;
		L_3 = ((  int32_t (*) (const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2)->methodPointer)(/*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 2));
		int32_t L_4;
		L_4 = ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_inline((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 *)(&___source0), /*hidden argument*/ReadOnlySpan_1_get_Length_m0D02A059B63020F14BCD1DDD5F72D4EBA34B3955_RuntimeMethod_var);
		if ((((int32_t)L_3) <= ((int32_t)L_4)))
		{
			goto IL_002a;
		}
	}
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5((int32_t)0, /*hidden argument*/NULL);
	}

IL_002a:
	{
		ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726  L_5 = ___source0;
		uint8_t* L_6;
		L_6 = MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824((ReadOnlySpan_1_t03DDF1A13DD7F8143C692DB7B68817A086932726 )L_5, /*hidden argument*/MemoryMarshal_GetReference_TisByte_t0111FAB8B8685667EDDAF77683F0D8F86B659056_m9855119A435C11C8E1E288C0CC4FAD02E4CF2824_RuntimeMethod_var);
		StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  L_7;
		L_7 = ((  StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA  (*) (uint8_t*, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3)->methodPointer)((uint8_t*)(uint8_t*)L_6, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(method->rgctx_data, 3));
		return (StackRow_t85DCC8407BFD0E874409B2291750CA8B1E11A6FA )L_7;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ArraySegment_1_get_Offset_m13F255A2A7A730982F330A448FCB32239782C505_gshared_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__offset_1();
		return (int32_t)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ArraySegment_1_get_Count_mC13AC26CCFD0EACBCC08F24F2A7BB22841B44C32_gshared_inline (ArraySegment_1_t89782CFC3178DB9FD8FFCCC398B4575AE8D740AE * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__count_2();
		return (int32_t)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ArrayBufferWriter_1_get_WrittenCount_m934380C81D0FF8B55609D3E68D229EE5C74E6C53_gshared_inline (ArrayBufferWriter_1_t80C6937C4A9FA04FBE17C5693E0A5ECF15864717 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__index_1();
		return (int32_t)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  NUInt_op_Multiply_mABFB3E10A51F74FDC0CD9B799B7BF35C2C5D8D85_inline (NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  ___left0, NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  ___right1, const RuntimeMethod* method)
{
	{
		uint32_t L_0 = sizeof(intptr_t);
		if ((((int32_t)L_0) == ((int32_t)4)))
		{
			goto IL_001e;
		}
	}
	{
		NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  L_1 = ___left0;
		void* L_2 = L_1.get__value_0();
		NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  L_3 = ___right1;
		void* L_4 = L_3.get__value_0();
		NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  L_5;
		memset((&L_5), 0, sizeof(L_5));
		NUInt__ctor_mBD99E19E274774DF07488C672C5DFC90F4B21973((&L_5), ((int64_t)il2cpp_codegen_multiply((int64_t)((int64_t)((uint64_t)(intptr_t)L_2)), (int64_t)((int64_t)((uint64_t)(intptr_t)L_4)))), /*hidden argument*/NULL);
		return L_5;
	}

IL_001e:
	{
		NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  L_6 = ___left0;
		void* L_7 = L_6.get__value_0();
		NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  L_8 = ___right1;
		void* L_9 = L_8.get__value_0();
		NUInt_t6097F6D5A9138404C7786F1B3E1654AD18E030F5  L_10;
		memset((&L_10), 0, sizeof(L_10));
		NUInt__ctor_m34A1178C5D59B395E905B670FCF390D1AA5DC85E((&L_10), ((int32_t)il2cpp_codegen_multiply((int32_t)((int32_t)((uint32_t)(intptr_t)L_7)), (int32_t)((int32_t)((uint32_t)(intptr_t)L_9)))), /*hidden argument*/NULL);
		return L_10;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void* IntPtr_ToPointer_m5C7CE32B14B6E30467B378052FEA25300833C61F_inline (intptr_t* __this, const RuntimeMethod* method)
{
	{
		intptr_t L_0 = *__this;
		return (void*)(L_0);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Span_1__ctor_m9DE8211969D97AFD415F2998D3789BA642B8A85D_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* ___array0, int32_t ___start1, int32_t ___length2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Type_t_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	uint8_t V_0 = 0x0;
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_0 = ___array0;
		if (L_0)
		{
			goto IL_0017;
		}
	}
	{
		int32_t L_1 = ___start1;
		if (L_1)
		{
			goto IL_0009;
		}
	}
	{
		int32_t L_2 = ___length2;
		if (!L_2)
		{
			goto IL_000f;
		}
	}

IL_0009:
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5((int32_t)1, /*hidden argument*/NULL);
	}

IL_000f:
	{
		il2cpp_codegen_initobj(__this, sizeof(Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 ));
		return;
	}

IL_0017:
	{
		il2cpp_codegen_initobj((&V_0), sizeof(uint8_t));
		goto IL_0043;
	}
	{
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_4 = ___array0;
		NullCheck((RuntimeObject *)(RuntimeObject *)L_4);
		Type_t * L_5;
		L_5 = Object_GetType_m571FE8360C10B98C23AAF1F066D92C08CC94F45B((RuntimeObject *)(RuntimeObject *)L_4, /*hidden argument*/NULL);
		RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9  L_6 = { reinterpret_cast<intptr_t> (IL2CPP_RGCTX_TYPE(InitializedTypeInfo(method->klass)->rgctx_data, 11)) };
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_7;
		L_7 = Type_GetTypeFromHandle_m8BB57524FF7F9DB1803BC561D2B3A4DBACEB385E((RuntimeTypeHandle_tC33965ADA3E041E0C94AF05E5CB527B56482CEF9 )L_6, /*hidden argument*/NULL);
		bool L_8;
		L_8 = Type_op_Inequality_m6DDC5E923203A79BF505F9275B694AD3FAA36DB0((Type_t *)L_5, (Type_t *)L_7, /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_0043;
		}
	}
	{
		ThrowHelper_ThrowArrayTypeMismatchException_mFC0D7756FD2EA1A7E41D8426D819369FDBD728FC(/*hidden argument*/NULL);
	}

IL_0043:
	{
		int32_t L_9 = ___start1;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_10 = ___array0;
		NullCheck(L_10);
		if ((!(((uint32_t)L_9) <= ((uint32_t)((int32_t)((int32_t)(((RuntimeArray*)L_10)->max_length)))))))
		{
			goto IL_0051;
		}
	}
	{
		int32_t L_11 = ___length2;
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_12 = ___array0;
		NullCheck(L_12);
		int32_t L_13 = ___start1;
		if ((!(((uint32_t)L_11) > ((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)((int32_t)((int32_t)(((RuntimeArray*)L_12)->max_length))), (int32_t)L_13))))))
		{
			goto IL_0057;
		}
	}

IL_0051:
	{
		ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5((int32_t)1, /*hidden argument*/NULL);
	}

IL_0057:
	{
		int32_t L_14 = ___length2;
		__this->set__length_2(L_14);
		ByteU5BU5D_tDBBEB0E8362242FA7223000D978B0DD19D4B0726* L_15 = ___array0;
		Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * L_16;
		L_16 = ((  Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * (*) (RuntimeObject *, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 12)->methodPointer)((RuntimeObject *)(RuntimeObject *)L_15, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 12));
		__this->set__pinnable_0(L_16);
		IL2CPP_RUNTIME_CLASS_INIT(IL2CPP_RGCTX_DATA(InitializedTypeInfo(method->klass)->rgctx_data, 13));
		intptr_t L_17 = ((PerTypeValues_1_tB073195618B2A7CB0FE31C31919AF7A3BB10C376_StaticFields*)il2cpp_codegen_static_fields_for(IL2CPP_RGCTX_DATA(InitializedTypeInfo(method->klass)->rgctx_data, 13)))->get_ArrayAdjustment_2();
		int32_t L_18 = ___start1;
		intptr_t L_19;
		L_19 = ((  intptr_t (*) (intptr_t, int32_t, const RuntimeMethod*))IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 14)->methodPointer)((intptr_t)L_17, (int32_t)L_18, /*hidden argument*/IL2CPP_RGCTX_METHOD_INFO(InitializedTypeInfo(method->klass)->rgctx_data, 14));
		__this->set__byteOffset_1((intptr_t)L_19);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Span_1_get_Length_m4BFDA5E41279728ADF75E310F780E357ECB1923B_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__length_2();
		return (int32_t)L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Span_1__ctor_mFF8F544A7E3798F8239A0FEB4D32301758CBFCCA_gshared_inline (Span_1_tA2AD9FB303A0BA36B1129534451F6EAE74DFEA83 * __this, Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * ___pinnable0, intptr_t ___byteOffset1, int32_t ___length2, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___length2;
		__this->set__length_2(L_0);
		Pinnable_1_t3FA89DC88CD7499604577377AB0B618C80108110 * L_1 = ___pinnable0;
		__this->set__pinnable_0(L_1);
		intptr_t L_2 = ___byteOffset1;
		__this->set__byteOffset_1((intptr_t)L_2);
		return;
	}
}
