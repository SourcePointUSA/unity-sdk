﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Resources.ResourceManager System.SR::get_ResourceManager()
extern void SR_get_ResourceManager_m2E8BFCBBF4B740DEFFC087C879574EF7D63B4485 (void);
// 0x00000002 System.Boolean System.SR::UsingResourceKeys()
extern void SR_UsingResourceKeys_mB066E94D44D7C9F1DD570C9FBB56C6BB8199DE01 (void);
// 0x00000003 System.String System.SR::GetResourceString(System.String,System.String)
extern void SR_GetResourceString_mAA184D7F3179E9326E264BE59C4ECF75F7FF3193 (void);
// 0x00000004 System.String System.SR::Format(System.String,System.Object)
extern void SR_Format_m8F6679858A5001C6AE411DA33BB9B7691CB324DD (void);
// 0x00000005 System.Type System.SR::get_ResourceType()
extern void SR_get_ResourceType_m917F70622A70B40CE00485CF37432F872429E461 (void);
// 0x00000006 System.String System.SR::get_Arg_ArgumentOutOfRangeException()
extern void SR_get_Arg_ArgumentOutOfRangeException_m107D6DDD321DC2D208C3F62CDBB87C81D391874F (void);
// 0x00000007 System.String System.SR::get_Arg_TypeNotSupported()
extern void SR_get_Arg_TypeNotSupported_m13D86686F063FFDA1531131C28D26B8C2E716B84 (void);
// 0x00000008 System.Void System.SR::.cctor()
extern void SR__cctor_m52040F30C8E789A881A26776EA5838C296E4A467 (void);
// 0x00000009 System.Void System.Runtime.CompilerServices.IntrinsicAttribute::.ctor()
extern void IntrinsicAttribute__ctor_m83E6B70F8E070052F3D601515E6545A3C63B3129 (void);
// 0x0000000A System.Byte System.Numerics.ConstantHelper::GetByteWithAllBitsSet()
extern void ConstantHelper_GetByteWithAllBitsSet_mC621377D31994C35BC2781D56BDF1A19C243773D (void);
// 0x0000000B System.SByte System.Numerics.ConstantHelper::GetSByteWithAllBitsSet()
extern void ConstantHelper_GetSByteWithAllBitsSet_m75AF740C7BDD4B3B8CDEA46816A5FE2405D73BDF (void);
// 0x0000000C System.UInt16 System.Numerics.ConstantHelper::GetUInt16WithAllBitsSet()
extern void ConstantHelper_GetUInt16WithAllBitsSet_m6BC81A6D0805883E62E3BD9B5A196F563B16FFEA (void);
// 0x0000000D System.Int16 System.Numerics.ConstantHelper::GetInt16WithAllBitsSet()
extern void ConstantHelper_GetInt16WithAllBitsSet_m996824CAE155A7996EF9F1FA14611324CE8DF3BA (void);
// 0x0000000E System.UInt32 System.Numerics.ConstantHelper::GetUInt32WithAllBitsSet()
extern void ConstantHelper_GetUInt32WithAllBitsSet_mF9264BB241E20A8A05FF9E0C06F6F81F0E1B1C8A (void);
// 0x0000000F System.Int32 System.Numerics.ConstantHelper::GetInt32WithAllBitsSet()
extern void ConstantHelper_GetInt32WithAllBitsSet_mCD59C2ABC660E81C63629C36496ABDCD4E55C76E (void);
// 0x00000010 System.UInt64 System.Numerics.ConstantHelper::GetUInt64WithAllBitsSet()
extern void ConstantHelper_GetUInt64WithAllBitsSet_m6BE10E8A52D5EB5FDA506D564F08A6323CCB28B0 (void);
// 0x00000011 System.Int64 System.Numerics.ConstantHelper::GetInt64WithAllBitsSet()
extern void ConstantHelper_GetInt64WithAllBitsSet_m92CD89D686AC24C659A4E6560F08097CDFB776E4 (void);
// 0x00000012 System.Single System.Numerics.ConstantHelper::GetSingleWithAllBitsSet()
extern void ConstantHelper_GetSingleWithAllBitsSet_mBBFCC36D478F698EC003C47B7BF4825BE8C697A1 (void);
// 0x00000013 System.Double System.Numerics.ConstantHelper::GetDoubleWithAllBitsSet()
extern void ConstantHelper_GetDoubleWithAllBitsSet_m996D27D3A1B9C7A7CD7363D753D37C13B5DF4E04 (void);
// 0x00000014 System.Int32 System.Numerics.Vector`1::get_Count()
// 0x00000015 System.Numerics.Vector`1<T> System.Numerics.Vector`1::get_Zero()
// 0x00000016 System.Int32 System.Numerics.Vector`1::InitializeCount()
// 0x00000017 System.Void System.Numerics.Vector`1::.ctor(T)
// 0x00000018 System.Void System.Numerics.Vector`1::.ctor(System.Void*)
// 0x00000019 System.Void System.Numerics.Vector`1::.ctor(System.Void*,System.Int32)
// 0x0000001A System.Void System.Numerics.Vector`1::.ctor(System.Numerics.Register&)
// 0x0000001B T System.Numerics.Vector`1::get_Item(System.Int32)
// 0x0000001C System.Boolean System.Numerics.Vector`1::Equals(System.Object)
// 0x0000001D System.Boolean System.Numerics.Vector`1::Equals(System.Numerics.Vector`1<T>)
// 0x0000001E System.Int32 System.Numerics.Vector`1::GetHashCode()
// 0x0000001F System.String System.Numerics.Vector`1::ToString()
// 0x00000020 System.String System.Numerics.Vector`1::ToString(System.String,System.IFormatProvider)
// 0x00000021 System.Numerics.Vector`1<T> System.Numerics.Vector`1::op_BitwiseOr(System.Numerics.Vector`1<T>,System.Numerics.Vector`1<T>)
// 0x00000022 System.Boolean System.Numerics.Vector`1::op_Equality(System.Numerics.Vector`1<T>,System.Numerics.Vector`1<T>)
// 0x00000023 System.Boolean System.Numerics.Vector`1::op_Inequality(System.Numerics.Vector`1<T>,System.Numerics.Vector`1<T>)
// 0x00000024 System.Numerics.Vector`1<System.Byte> System.Numerics.Vector`1::op_Explicit(System.Numerics.Vector`1<T>)
// 0x00000025 System.Numerics.Vector`1<System.UInt64> System.Numerics.Vector`1::op_Explicit(System.Numerics.Vector`1<T>)
// 0x00000026 System.Numerics.Vector`1<T> System.Numerics.Vector`1::Equals(System.Numerics.Vector`1<T>,System.Numerics.Vector`1<T>)
// 0x00000027 System.Numerics.Vector`1<T> System.Numerics.Vector`1::LessThan(System.Numerics.Vector`1<T>,System.Numerics.Vector`1<T>)
// 0x00000028 System.Boolean System.Numerics.Vector`1::ScalarEquals(T,T)
// 0x00000029 System.Boolean System.Numerics.Vector`1::ScalarLessThan(T,T)
// 0x0000002A T System.Numerics.Vector`1::GetOneValue()
// 0x0000002B T System.Numerics.Vector`1::GetAllBitsSetValue()
// 0x0000002C System.Void System.Numerics.Vector`1::.cctor()
// 0x0000002D System.Numerics.Vector`1<T> System.Numerics.Vector::Equals(System.Numerics.Vector`1<T>,System.Numerics.Vector`1<T>)
// 0x0000002E System.Numerics.Vector`1<T> System.Numerics.Vector::LessThan(System.Numerics.Vector`1<T>,System.Numerics.Vector`1<T>)
// 0x0000002F System.Boolean System.Numerics.Vector::get_IsHardwareAccelerated()
extern void Vector_get_IsHardwareAccelerated_mB84D27741489DA479C0DAE61A7B37219DB4EC257 (void);
// 0x00000030 System.Numerics.Vector`1<T> System.Numerics.Vector::BitwiseOr(System.Numerics.Vector`1<T>,System.Numerics.Vector`1<T>)
// 0x00000031 System.Numerics.Vector`1<System.Byte> System.Numerics.Vector::AsVectorByte(System.Numerics.Vector`1<T>)
// 0x00000032 System.Numerics.Vector`1<System.UInt64> System.Numerics.Vector::AsVectorUInt64(System.Numerics.Vector`1<T>)
// 0x00000033 System.Int32 System.Numerics.Hashing.HashHelpers::Combine(System.Int32,System.Int32)
extern void HashHelpers_Combine_m3E699C96E71851B56A7935D13882E899F7B3405A (void);
// 0x00000034 System.Void System.Numerics.Hashing.HashHelpers::.cctor()
extern void HashHelpers__cctor_m11F485381A0F59DFD3F4E68611E0740286922AF6 (void);
static Il2CppMethodPointer s_methodPointers[52] = 
{
	SR_get_ResourceManager_m2E8BFCBBF4B740DEFFC087C879574EF7D63B4485,
	SR_UsingResourceKeys_mB066E94D44D7C9F1DD570C9FBB56C6BB8199DE01,
	SR_GetResourceString_mAA184D7F3179E9326E264BE59C4ECF75F7FF3193,
	SR_Format_m8F6679858A5001C6AE411DA33BB9B7691CB324DD,
	SR_get_ResourceType_m917F70622A70B40CE00485CF37432F872429E461,
	SR_get_Arg_ArgumentOutOfRangeException_m107D6DDD321DC2D208C3F62CDBB87C81D391874F,
	SR_get_Arg_TypeNotSupported_m13D86686F063FFDA1531131C28D26B8C2E716B84,
	SR__cctor_m52040F30C8E789A881A26776EA5838C296E4A467,
	IntrinsicAttribute__ctor_m83E6B70F8E070052F3D601515E6545A3C63B3129,
	ConstantHelper_GetByteWithAllBitsSet_mC621377D31994C35BC2781D56BDF1A19C243773D,
	ConstantHelper_GetSByteWithAllBitsSet_m75AF740C7BDD4B3B8CDEA46816A5FE2405D73BDF,
	ConstantHelper_GetUInt16WithAllBitsSet_m6BC81A6D0805883E62E3BD9B5A196F563B16FFEA,
	ConstantHelper_GetInt16WithAllBitsSet_m996824CAE155A7996EF9F1FA14611324CE8DF3BA,
	ConstantHelper_GetUInt32WithAllBitsSet_mF9264BB241E20A8A05FF9E0C06F6F81F0E1B1C8A,
	ConstantHelper_GetInt32WithAllBitsSet_mCD59C2ABC660E81C63629C36496ABDCD4E55C76E,
	ConstantHelper_GetUInt64WithAllBitsSet_m6BE10E8A52D5EB5FDA506D564F08A6323CCB28B0,
	ConstantHelper_GetInt64WithAllBitsSet_m92CD89D686AC24C659A4E6560F08097CDFB776E4,
	ConstantHelper_GetSingleWithAllBitsSet_mBBFCC36D478F698EC003C47B7BF4825BE8C697A1,
	ConstantHelper_GetDoubleWithAllBitsSet_m996D27D3A1B9C7A7CD7363D753D37C13B5DF4E04,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Vector_get_IsHardwareAccelerated_mB84D27741489DA479C0DAE61A7B37219DB4EC257,
	NULL,
	NULL,
	NULL,
	HashHelpers_Combine_m3E699C96E71851B56A7935D13882E899F7B3405A,
	HashHelpers__cctor_m11F485381A0F59DFD3F4E68611E0740286922AF6,
};
static const int32_t s_InvokerIndices[52] = 
{
	2929,
	2935,
	2466,
	2466,
	2929,
	2929,
	2929,
	2941,
	1782,
	2935,
	2935,
	2923,
	2923,
	2924,
	2924,
	2925,
	2925,
	2936,
	2921,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	2935,
	-1,
	-1,
	-1,
	2414,
	2941,
};
static const Il2CppTokenRangePair s_rgctxIndices[6] = 
{
	{ 0x02000007, { 0, 18 } },
	{ 0x0600002D, { 18, 2 } },
	{ 0x0600002E, { 20, 2 } },
	{ 0x06000030, { 22, 2 } },
	{ 0x06000031, { 24, 2 } },
	{ 0x06000032, { 26, 2 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[28] = 
{
	{ (Il2CppRGCTXDataType)2, 2346 },
	{ (Il2CppRGCTXDataType)1, 452 },
	{ (Il2CppRGCTXDataType)2, 452 },
	{ (Il2CppRGCTXDataType)3, 10355 },
	{ (Il2CppRGCTXDataType)3, 10347 },
	{ (Il2CppRGCTXDataType)2, 2346 },
	{ (Il2CppRGCTXDataType)3, 10348 },
	{ (Il2CppRGCTXDataType)3, 10356 },
	{ (Il2CppRGCTXDataType)3, 10352 },
	{ (Il2CppRGCTXDataType)3, 10354 },
	{ (Il2CppRGCTXDataType)3, 10357 },
	{ (Il2CppRGCTXDataType)3, 10346 },
	{ (Il2CppRGCTXDataType)3, 10345 },
	{ (Il2CppRGCTXDataType)3, 10353 },
	{ (Il2CppRGCTXDataType)3, 10351 },
	{ (Il2CppRGCTXDataType)3, 10350 },
	{ (Il2CppRGCTXDataType)3, 10344 },
	{ (Il2CppRGCTXDataType)3, 10349 },
	{ (Il2CppRGCTXDataType)3, 10342 },
	{ (Il2CppRGCTXDataType)2, 2344 },
	{ (Il2CppRGCTXDataType)3, 10343 },
	{ (Il2CppRGCTXDataType)2, 2345 },
	{ (Il2CppRGCTXDataType)3, 10341 },
	{ (Il2CppRGCTXDataType)2, 2343 },
	{ (Il2CppRGCTXDataType)3, 10339 },
	{ (Il2CppRGCTXDataType)2, 2341 },
	{ (Il2CppRGCTXDataType)3, 10340 },
	{ (Il2CppRGCTXDataType)2, 2342 },
};
extern const CustomAttributesCacheGenerator g_System_Numerics_Vectors_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_System_Numerics_Vectors_CodeGenModule;
const Il2CppCodeGenModule g_System_Numerics_Vectors_CodeGenModule = 
{
	"System.Numerics.Vectors.dll",
	52,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	6,
	s_rgctxIndices,
	28,
	s_rgctxValues,
	NULL,
	g_System_Numerics_Vectors_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
