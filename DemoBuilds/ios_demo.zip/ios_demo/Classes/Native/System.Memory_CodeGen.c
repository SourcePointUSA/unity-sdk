﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Microsoft.CodeAnalysis.EmbeddedAttribute::.ctor()
extern void EmbeddedAttribute__ctor_m7D7D024DA2EA05AEDF8B8C470F678A5DA96C8EB8 (void);
// 0x00000002 System.Void System.Runtime.CompilerServices.IsReadOnlyAttribute::.ctor()
extern void IsReadOnlyAttribute__ctor_m07A8C937D13DE79AF8ED555F18E5AE9FDA6C3879 (void);
// 0x00000003 System.Void System.Runtime.CompilerServices.IsByRefLikeAttribute::.ctor()
extern void IsByRefLikeAttribute__ctor_m3F813C04C0FAF02B5AF712ED98929300CD6E44DD (void);
// 0x00000004 System.Void System.SequencePosition::.ctor(System.Object,System.Int32)
extern void SequencePosition__ctor_m881E247213B0B28B3903475A1FC0237C56B5F0B0 (void);
// 0x00000005 System.Object System.SequencePosition::GetObject()
extern void SequencePosition_GetObject_m33D4D02B2042DFCCC2549006639381910F1F3525 (void);
// 0x00000006 System.Int32 System.SequencePosition::GetInteger()
extern void SequencePosition_GetInteger_mE4D2683EB441F31A3C1474845ABBD0FA78C130DE (void);
// 0x00000007 System.Boolean System.SequencePosition::Equals(System.SequencePosition)
extern void SequencePosition_Equals_mEA7C1FF9F5C4661547A30C192DC3702CB7647795 (void);
// 0x00000008 System.Boolean System.SequencePosition::Equals(System.Object)
extern void SequencePosition_Equals_mEA56903889413D851A4F93FC2C96D0A6BA823A58 (void);
// 0x00000009 System.Int32 System.SequencePosition::GetHashCode()
extern void SequencePosition_GetHashCode_m1BEFA85FBA8965A92F4A2408AA491758C0CD7DF2 (void);
// 0x0000000A System.Void System.ThrowHelper::ThrowArgumentNullException(System.ExceptionArgument)
extern void ThrowHelper_ThrowArgumentNullException_m3B4D674B817C817E97F4687F0130007D315F8B34 (void);
// 0x0000000B System.Exception System.ThrowHelper::CreateArgumentNullException(System.ExceptionArgument)
extern void ThrowHelper_CreateArgumentNullException_mA70D942EBA7503962BA72170F026A966513590FC (void);
// 0x0000000C System.Void System.ThrowHelper::ThrowArrayTypeMismatchException()
extern void ThrowHelper_ThrowArrayTypeMismatchException_mFC0D7756FD2EA1A7E41D8426D819369FDBD728FC (void);
// 0x0000000D System.Exception System.ThrowHelper::CreateArrayTypeMismatchException()
extern void ThrowHelper_CreateArrayTypeMismatchException_m23F27BF82F951A64682A2CF14E0EDE9F3B54C93F (void);
// 0x0000000E System.Void System.ThrowHelper::ThrowArgumentException_InvalidTypeWithPointersNotSupported(System.Type)
extern void ThrowHelper_ThrowArgumentException_InvalidTypeWithPointersNotSupported_m4A71872D4B069AF36758A61E4CA3FB663B4E8EC4 (void);
// 0x0000000F System.Exception System.ThrowHelper::CreateArgumentException_InvalidTypeWithPointersNotSupported(System.Type)
extern void ThrowHelper_CreateArgumentException_InvalidTypeWithPointersNotSupported_m4019588ED8511C985604C8CC9AD4AB6414676945 (void);
// 0x00000010 System.Void System.ThrowHelper::ThrowArgumentException_DestinationTooShort()
extern void ThrowHelper_ThrowArgumentException_DestinationTooShort_mD9C82D6A62948DA443166283990BF760F77C76C8 (void);
// 0x00000011 System.Exception System.ThrowHelper::CreateArgumentException_DestinationTooShort()
extern void ThrowHelper_CreateArgumentException_DestinationTooShort_m75CF4B3D7F56B0383E0BC84D86C085AA0CE90CD1 (void);
// 0x00000012 System.Void System.ThrowHelper::ThrowIndexOutOfRangeException()
extern void ThrowHelper_ThrowIndexOutOfRangeException_m4D1EB8558F17DFE372ECF87D9BCAD112A7F5E6BC (void);
// 0x00000013 System.Exception System.ThrowHelper::CreateIndexOutOfRangeException()
extern void ThrowHelper_CreateIndexOutOfRangeException_m8C8886676269B09CC5241BA6F5330D78B26F527B (void);
// 0x00000014 System.Void System.ThrowHelper::ThrowArgumentOutOfRangeException()
extern void ThrowHelper_ThrowArgumentOutOfRangeException_mB72471F11341E214DA380AF2B87C3F28EC51CA59 (void);
// 0x00000015 System.Exception System.ThrowHelper::CreateArgumentOutOfRangeException()
extern void ThrowHelper_CreateArgumentOutOfRangeException_m0841E9BF864372D7BF0512A13456F985C53FC03D (void);
// 0x00000016 System.Void System.ThrowHelper::ThrowArgumentOutOfRangeException(System.ExceptionArgument)
extern void ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5 (void);
// 0x00000017 System.Exception System.ThrowHelper::CreateArgumentOutOfRangeException(System.ExceptionArgument)
extern void ThrowHelper_CreateArgumentOutOfRangeException_m3ED3DA6D593699354BA4D397790440F3BFE84AEA (void);
// 0x00000018 System.Void System.ThrowHelper::ThrowArgumentOutOfRangeException_PrecisionTooLarge()
extern void ThrowHelper_ThrowArgumentOutOfRangeException_PrecisionTooLarge_mAC345A1F72DBC919354CCB54CC6C24EF44BE48C1 (void);
// 0x00000019 System.Exception System.ThrowHelper::CreateArgumentOutOfRangeException_PrecisionTooLarge()
extern void ThrowHelper_CreateArgumentOutOfRangeException_PrecisionTooLarge_mC1889FF89FD22816EB8D105C942166D0BF6ADFAD (void);
// 0x0000001A System.Void System.ThrowHelper::ThrowArgumentOutOfRangeException_SymbolDoesNotFit()
extern void ThrowHelper_ThrowArgumentOutOfRangeException_SymbolDoesNotFit_m601A3BCC469FE8A7420CC33708307189B6C48B61 (void);
// 0x0000001B System.Exception System.ThrowHelper::CreateArgumentOutOfRangeException_SymbolDoesNotFit()
extern void ThrowHelper_CreateArgumentOutOfRangeException_SymbolDoesNotFit_m903F8FB8357FE1BAB8BF450E0F95A79117EF2D19 (void);
// 0x0000001C System.Void System.ThrowHelper::ThrowInvalidOperationException()
extern void ThrowHelper_ThrowInvalidOperationException_mC18897E999FE00AE3ACC3543A468201068A217F8 (void);
// 0x0000001D System.Exception System.ThrowHelper::CreateInvalidOperationException()
extern void ThrowHelper_CreateInvalidOperationException_mAA36D488898B83C836372B8D095EFEC4136121B3 (void);
// 0x0000001E System.Void System.ThrowHelper::ThrowInvalidOperationException_EndPositionNotReached()
extern void ThrowHelper_ThrowInvalidOperationException_EndPositionNotReached_m67B5DCC8C43494E0A491781D118E147337664DB0 (void);
// 0x0000001F System.Exception System.ThrowHelper::CreateInvalidOperationException_EndPositionNotReached()
extern void ThrowHelper_CreateInvalidOperationException_EndPositionNotReached_m35A30B605551B8CACAE6B842C8B525BC7078FE72 (void);
// 0x00000020 System.Void System.ThrowHelper::ThrowArgumentOutOfRangeException_PositionOutOfRange()
extern void ThrowHelper_ThrowArgumentOutOfRangeException_PositionOutOfRange_mE66B589C0CE79CD3252C96D133A4DA6BFF64228D (void);
// 0x00000021 System.Exception System.ThrowHelper::CreateArgumentOutOfRangeException_PositionOutOfRange()
extern void ThrowHelper_CreateArgumentOutOfRangeException_PositionOutOfRange_m09B8EF6F30DDB19BF9AD63605556AED12E7DE03A (void);
// 0x00000022 System.Void System.ThrowHelper::ThrowArgumentOutOfRangeException_OffsetOutOfRange()
extern void ThrowHelper_ThrowArgumentOutOfRangeException_OffsetOutOfRange_m33BB375A469C5D43F27FAF1E1573659C8D6D46B6 (void);
// 0x00000023 System.Exception System.ThrowHelper::CreateArgumentOutOfRangeException_OffsetOutOfRange()
extern void ThrowHelper_CreateArgumentOutOfRangeException_OffsetOutOfRange_m4006B68C0940F1864B48E9E2CAE0A62FE91910F9 (void);
// 0x00000024 System.Void System.ThrowHelper::ThrowFormatException_BadFormatSpecifier()
extern void ThrowHelper_ThrowFormatException_BadFormatSpecifier_m1E35DA4BEAAC3A721CFB9CE82029EBABF763EA8D (void);
// 0x00000025 System.Exception System.ThrowHelper::CreateFormatException_BadFormatSpecifier()
extern void ThrowHelper_CreateFormatException_BadFormatSpecifier_mA1D2DB12AB680960531A3C1A97098925F5154FDB (void);
// 0x00000026 System.Boolean System.ThrowHelper::TryFormatThrowFormatException(System.Int32&)
extern void ThrowHelper_TryFormatThrowFormatException_mAE469FD4BD034BFD4FB18C512DAD188188AADFCA (void);
// 0x00000027 System.Boolean System.ThrowHelper::TryParseThrowFormatException(T&,System.Int32&)
// 0x00000028 System.Void System.ThrowHelper::ThrowArgumentValidationException(System.Buffers.ReadOnlySequenceSegment`1<T>,System.Int32,System.Buffers.ReadOnlySequenceSegment`1<T>)
// 0x00000029 System.Exception System.ThrowHelper::CreateArgumentValidationException(System.Buffers.ReadOnlySequenceSegment`1<T>,System.Int32,System.Buffers.ReadOnlySequenceSegment`1<T>)
// 0x0000002A System.Void System.ThrowHelper::ThrowArgumentValidationException(System.Array,System.Int32)
extern void ThrowHelper_ThrowArgumentValidationException_m02E99F21139D9C2446BCF31922E6B9A1FB6CBFE9 (void);
// 0x0000002B System.Exception System.ThrowHelper::CreateArgumentValidationException(System.Array,System.Int32)
extern void ThrowHelper_CreateArgumentValidationException_mA1BAB2087749EF0A3433426D6B4886903B64C893 (void);
// 0x0000002C System.Void System.ThrowHelper::ThrowStartOrEndArgumentValidationException(System.Int64)
extern void ThrowHelper_ThrowStartOrEndArgumentValidationException_m0BB9EBD3A2B133B27075024CE04996C5626E7C38 (void);
// 0x0000002D System.Exception System.ThrowHelper::CreateStartOrEndArgumentValidationException(System.Int64)
extern void ThrowHelper_CreateStartOrEndArgumentValidationException_mC18923AF89FCBE538463BC90C517FA9E4691734C (void);
// 0x0000002E System.UInt32 System.DecimalDecCalc::D32DivMod1E9(System.UInt32,System.UInt32&)
extern void DecimalDecCalc_D32DivMod1E9_mAD8A67341D4FAFC5C7B8166220023AA68003ABBF (void);
// 0x0000002F System.UInt32 System.DecimalDecCalc::DecDivMod1E9(System.MutableDecimal&)
extern void DecimalDecCalc_DecDivMod1E9_mEBD288904D9655A6FFF62BA3620C6C55FF28B8B6 (void);
// 0x00000030 System.Void System.DecimalDecCalc::DecAddInt32(System.MutableDecimal&,System.UInt32)
extern void DecimalDecCalc_DecAddInt32_mCA42EB3D01D859FA31D304138E4BEF39FEB549AE (void);
// 0x00000031 System.Boolean System.DecimalDecCalc::D32AddCarry(System.UInt32&,System.UInt32)
extern void DecimalDecCalc_D32AddCarry_m12237332B16193F0B942AEFC955A62400D3F51B9 (void);
// 0x00000032 System.Void System.DecimalDecCalc::DecMul10(System.MutableDecimal&)
extern void DecimalDecCalc_DecMul10_m937563702D52CBD29F01CC75B62F626BEC117892 (void);
// 0x00000033 System.Void System.DecimalDecCalc::DecShiftLeft(System.MutableDecimal&)
extern void DecimalDecCalc_DecShiftLeft_m63A7A170CA5CF4A864BAAD95D88C299D5AFB71F3 (void);
// 0x00000034 System.Void System.DecimalDecCalc::DecAdd(System.MutableDecimal&,System.MutableDecimal)
extern void DecimalDecCalc_DecAdd_m52E651ADFE94ACFD0CDDC8C14A50D2830E46E3D5 (void);
// 0x00000035 System.Void System.Number::RoundNumber(System.NumberBuffer&,System.Int32)
extern void Number_RoundNumber_mEC3B9B63F68460A64F6F6913BB80F3BEBB780F07 (void);
// 0x00000036 System.Boolean System.Number::NumberBufferToDouble(System.NumberBuffer&,System.Double&)
extern void Number_NumberBufferToDouble_mA943AD6BA0AE626079DBC29F9B659D26D4E1D424 (void);
// 0x00000037 System.Boolean System.Number::NumberBufferToDecimal(System.NumberBuffer&,System.Decimal&)
extern void Number_NumberBufferToDecimal_m9EC553B819A7A5F0260E71EE5684E7EA7CEE6D42 (void);
// 0x00000038 System.Void System.Number::DecimalToNumber(System.Decimal,System.NumberBuffer&)
extern void Number_DecimalToNumber_mDB370C6FEDCCE206F35651207AE2E13ABF525408 (void);
// 0x00000039 System.UInt32 System.Number::DigitsToInt(System.ReadOnlySpan`1<System.Byte>,System.Int32)
extern void Number_DigitsToInt_mF9D8FE36B186C206448E7489A7AFC2EDEF604BD2 (void);
// 0x0000003A System.UInt64 System.Number::Mul32x32To64(System.UInt32,System.UInt32)
extern void Number_Mul32x32To64_mE1E983CFD213FF07619AEDA39C30700B6213EE13 (void);
// 0x0000003B System.UInt64 System.Number::Mul64Lossy(System.UInt64,System.UInt64,System.Int32&)
extern void Number_Mul64Lossy_m62FA4C0FD0DFB698403843BF67DFED5D0881DD9D (void);
// 0x0000003C System.Int32 System.Number::abs(System.Int32)
extern void Number_abs_m602E755F75A75A2F98CFEB174046DA2213A30DB5 (void);
// 0x0000003D System.Double System.Number::NumberToDouble(System.NumberBuffer&)
extern void Number_NumberToDouble_m8DE02F8F5A4B55ED6EC5995419C9D4AE9BB0802E (void);
// 0x0000003E System.Void System.Number::.cctor()
extern void Number__cctor_m13165024FAE32EB10AAF002D913A479A756870CB (void);
// 0x0000003F System.UInt32 System.Number/DoubleHelper::Exponent(System.Double)
extern void DoubleHelper_Exponent_m030E2C0AF265E2CA0ACEA5E4C9E66C1EAB462D5C (void);
// 0x00000040 System.UInt64 System.Number/DoubleHelper::Mantissa(System.Double)
extern void DoubleHelper_Mantissa_m5275E987A447C0B2F0F10D1E08B0A73DB121A6BE (void);
// 0x00000041 System.Span`1<System.Byte> System.NumberBuffer::get_Digits()
extern void NumberBuffer_get_Digits_m77F55E994E325F745CBEE5598D24263834F34F3B (void);
// 0x00000042 System.Byte* System.NumberBuffer::get_UnsafeDigits()
extern void NumberBuffer_get_UnsafeDigits_m95B0D74B60926B0E8788E7E6FDC551E7240F40FE (void);
// 0x00000043 System.Int32 System.NumberBuffer::get_NumDigits()
extern void NumberBuffer_get_NumDigits_mC0AF0400D548D41907EA3204965C78A10DB463D5 (void);
// 0x00000044 System.String System.NumberBuffer::ToString()
extern void NumberBuffer_ToString_m64B3ED10515B329DDED1167F97E5BE0B297955AD (void);
// 0x00000045 System.Void System.Memory`1::.ctor(T[])
// 0x00000046 System.Void System.Memory`1::.ctor(T[],System.Int32)
// 0x00000047 System.Void System.Memory`1::.ctor(T[],System.Int32,System.Int32)
// 0x00000048 System.Void System.Memory`1::.ctor(System.Buffers.MemoryManager`1<T>,System.Int32)
// 0x00000049 System.Void System.Memory`1::.ctor(System.Buffers.MemoryManager`1<T>,System.Int32,System.Int32)
// 0x0000004A System.Void System.Memory`1::.ctor(System.Object,System.Int32,System.Int32)
// 0x0000004B System.Memory`1<T> System.Memory`1::op_Implicit(T[])
// 0x0000004C System.Memory`1<T> System.Memory`1::op_Implicit(System.ArraySegment`1<T>)
// 0x0000004D System.ReadOnlyMemory`1<T> System.Memory`1::op_Implicit(System.Memory`1<T>)
// 0x0000004E System.Memory`1<T> System.Memory`1::get_Empty()
// 0x0000004F System.Int32 System.Memory`1::get_Length()
// 0x00000050 System.Boolean System.Memory`1::get_IsEmpty()
// 0x00000051 System.String System.Memory`1::ToString()
// 0x00000052 System.Memory`1<T> System.Memory`1::Slice(System.Int32)
// 0x00000053 System.Memory`1<T> System.Memory`1::Slice(System.Int32,System.Int32)
// 0x00000054 System.Span`1<T> System.Memory`1::get_Span()
// 0x00000055 System.Void System.Memory`1::CopyTo(System.Memory`1<T>)
// 0x00000056 System.Boolean System.Memory`1::TryCopyTo(System.Memory`1<T>)
// 0x00000057 System.Buffers.MemoryHandle System.Memory`1::Pin()
// 0x00000058 T[] System.Memory`1::ToArray()
// 0x00000059 System.Boolean System.Memory`1::Equals(System.Object)
// 0x0000005A System.Boolean System.Memory`1::Equals(System.Memory`1<T>)
// 0x0000005B System.Int32 System.Memory`1::GetHashCode()
// 0x0000005C System.Int32 System.Memory`1::CombineHashCodes(System.Int32,System.Int32)
// 0x0000005D System.Int32 System.Memory`1::CombineHashCodes(System.Int32,System.Int32,System.Int32)
// 0x0000005E System.Void System.MemoryDebugView`1::.ctor(System.Memory`1<T>)
// 0x0000005F System.Void System.MemoryDebugView`1::.ctor(System.ReadOnlyMemory`1<T>)
// 0x00000060 T[] System.MemoryDebugView`1::get_Items()
// 0x00000061 System.Int32 System.MemoryExtensions::IndexOf(System.Span`1<T>,T)
// 0x00000062 System.Boolean System.MemoryExtensions::SequenceEqual(System.Span`1<T>,System.ReadOnlySpan`1<T>)
// 0x00000063 System.Int32 System.MemoryExtensions::IndexOf(System.ReadOnlySpan`1<T>,T)
// 0x00000064 System.Int32 System.MemoryExtensions::IndexOf(System.ReadOnlySpan`1<T>,System.ReadOnlySpan`1<T>)
// 0x00000065 System.Int32 System.MemoryExtensions::IndexOfAny(System.ReadOnlySpan`1<T>,T,T,T)
// 0x00000066 System.Boolean System.MemoryExtensions::SequenceEqual(System.ReadOnlySpan`1<T>,System.ReadOnlySpan`1<T>)
// 0x00000067 System.Boolean System.MemoryExtensions::StartsWith(System.Span`1<T>,System.ReadOnlySpan`1<T>)
// 0x00000068 System.Boolean System.MemoryExtensions::StartsWith(System.ReadOnlySpan`1<T>,System.ReadOnlySpan`1<T>)
// 0x00000069 System.Span`1<T> System.MemoryExtensions::AsSpan(T[])
// 0x0000006A System.Span`1<T> System.MemoryExtensions::AsSpan(T[],System.Int32,System.Int32)
// 0x0000006B System.Span`1<T> System.MemoryExtensions::AsSpan(System.ArraySegment`1<T>)
// 0x0000006C System.Memory`1<T> System.MemoryExtensions::AsMemory(T[],System.Int32)
// 0x0000006D System.Memory`1<T> System.MemoryExtensions::AsMemory(T[],System.Int32,System.Int32)
// 0x0000006E System.Memory`1<T> System.MemoryExtensions::AsMemory(System.ArraySegment`1<T>)
// 0x0000006F System.Void System.MemoryExtensions::CopyTo(T[],System.Span`1<T>)
// 0x00000070 System.Boolean System.MemoryExtensions::IsTypeComparableAsBytes(System.NUInt&)
// 0x00000071 System.Span`1<T> System.MemoryExtensions::AsSpan(T[],System.Int32)
// 0x00000072 System.ReadOnlySpan`1<System.Char> System.MemoryExtensions::AsSpan(System.String)
extern void MemoryExtensions_AsSpan_m7527C7806D1DD24C012DC60C12280A9E1AEA8F15 (void);
// 0x00000073 System.ReadOnlyMemory`1<System.Char> System.MemoryExtensions::AsMemory(System.String)
extern void MemoryExtensions_AsMemory_mDE1615649DE907A3C22F6BEBBF0C8F80E4652B0D (void);
// 0x00000074 System.ReadOnlyMemory`1<System.Char> System.MemoryExtensions::AsMemory(System.String,System.Int32,System.Int32)
extern void MemoryExtensions_AsMemory_m9F2378B1710076CA61B1FC3E687A06BC6063A9DC (void);
// 0x00000075 System.IntPtr System.MemoryExtensions::MeasureStringAdjustment()
extern void MemoryExtensions_MeasureStringAdjustment_m8E2719E3CCAD24803BEF8B9C9873DDFAA528C762 (void);
// 0x00000076 System.Void System.MemoryExtensions::.cctor()
extern void MemoryExtensions__cctor_mC634116818572F66DC5A4416FB29AFBFCE859EBE (void);
// 0x00000077 System.Void System.ReadOnlyMemory`1::.ctor(T[])
// 0x00000078 System.Void System.ReadOnlyMemory`1::.ctor(T[],System.Int32,System.Int32)
// 0x00000079 System.Void System.ReadOnlyMemory`1::.ctor(System.Object,System.Int32,System.Int32)
// 0x0000007A System.ReadOnlyMemory`1<T> System.ReadOnlyMemory`1::op_Implicit(T[])
// 0x0000007B System.ReadOnlyMemory`1<T> System.ReadOnlyMemory`1::op_Implicit(System.ArraySegment`1<T>)
// 0x0000007C System.ReadOnlyMemory`1<T> System.ReadOnlyMemory`1::get_Empty()
// 0x0000007D System.Int32 System.ReadOnlyMemory`1::get_Length()
// 0x0000007E System.Boolean System.ReadOnlyMemory`1::get_IsEmpty()
// 0x0000007F System.String System.ReadOnlyMemory`1::ToString()
// 0x00000080 System.ReadOnlyMemory`1<T> System.ReadOnlyMemory`1::Slice(System.Int32)
// 0x00000081 System.ReadOnlyMemory`1<T> System.ReadOnlyMemory`1::Slice(System.Int32,System.Int32)
// 0x00000082 System.ReadOnlySpan`1<T> System.ReadOnlyMemory`1::get_Span()
// 0x00000083 System.Void System.ReadOnlyMemory`1::CopyTo(System.Memory`1<T>)
// 0x00000084 System.Boolean System.ReadOnlyMemory`1::TryCopyTo(System.Memory`1<T>)
// 0x00000085 System.Buffers.MemoryHandle System.ReadOnlyMemory`1::Pin()
// 0x00000086 T[] System.ReadOnlyMemory`1::ToArray()
// 0x00000087 System.Boolean System.ReadOnlyMemory`1::Equals(System.Object)
// 0x00000088 System.Boolean System.ReadOnlyMemory`1::Equals(System.ReadOnlyMemory`1<T>)
// 0x00000089 System.Int32 System.ReadOnlyMemory`1::GetHashCode()
// 0x0000008A System.Int32 System.ReadOnlyMemory`1::CombineHashCodes(System.Int32,System.Int32)
// 0x0000008B System.Int32 System.ReadOnlyMemory`1::CombineHashCodes(System.Int32,System.Int32,System.Int32)
// 0x0000008C System.Object System.ReadOnlyMemory`1::GetObjectStartLength(System.Int32&,System.Int32&)
// 0x0000008D System.Int32 System.ReadOnlySpan`1::get_Length()
// 0x0000008E System.Boolean System.ReadOnlySpan`1::get_IsEmpty()
// 0x0000008F System.Boolean System.ReadOnlySpan`1::op_Inequality(System.ReadOnlySpan`1<T>,System.ReadOnlySpan`1<T>)
// 0x00000090 System.Boolean System.ReadOnlySpan`1::Equals(System.Object)
// 0x00000091 System.Int32 System.ReadOnlySpan`1::GetHashCode()
// 0x00000092 System.ReadOnlySpan`1<T> System.ReadOnlySpan`1::op_Implicit(T[])
// 0x00000093 System.ReadOnlySpan`1<T> System.ReadOnlySpan`1::op_Implicit(System.ArraySegment`1<T>)
// 0x00000094 System.ReadOnlySpan`1<T> System.ReadOnlySpan`1::get_Empty()
// 0x00000095 System.ReadOnlySpan`1/Enumerator<T> System.ReadOnlySpan`1::GetEnumerator()
// 0x00000096 System.Void System.ReadOnlySpan`1::.ctor(T[])
// 0x00000097 System.Void System.ReadOnlySpan`1::.ctor(T[],System.Int32,System.Int32)
// 0x00000098 System.Void System.ReadOnlySpan`1::.ctor(System.Void*,System.Int32)
// 0x00000099 System.Void System.ReadOnlySpan`1::.ctor(System.Pinnable`1<T>,System.IntPtr,System.Int32)
// 0x0000009A T& modreq(System.Runtime.InteropServices.InAttribute) System.ReadOnlySpan`1::get_Item(System.Int32)
// 0x0000009B T& modreq(System.Runtime.InteropServices.InAttribute) System.ReadOnlySpan`1::GetPinnableReference()
// 0x0000009C System.Void System.ReadOnlySpan`1::CopyTo(System.Span`1<T>)
// 0x0000009D System.Boolean System.ReadOnlySpan`1::TryCopyTo(System.Span`1<T>)
// 0x0000009E System.Boolean System.ReadOnlySpan`1::op_Equality(System.ReadOnlySpan`1<T>,System.ReadOnlySpan`1<T>)
// 0x0000009F System.String System.ReadOnlySpan`1::ToString()
// 0x000000A0 System.ReadOnlySpan`1<T> System.ReadOnlySpan`1::Slice(System.Int32)
// 0x000000A1 System.ReadOnlySpan`1<T> System.ReadOnlySpan`1::Slice(System.Int32,System.Int32)
// 0x000000A2 T[] System.ReadOnlySpan`1::ToArray()
// 0x000000A3 T& System.ReadOnlySpan`1::DangerousGetPinnableReference()
// 0x000000A4 System.Pinnable`1<T> System.ReadOnlySpan`1::get_Pinnable()
// 0x000000A5 System.IntPtr System.ReadOnlySpan`1::get_ByteOffset()
// 0x000000A6 System.Void System.ReadOnlySpan`1/Enumerator::.ctor(System.ReadOnlySpan`1<T>)
// 0x000000A7 System.Int32 System.Span`1::get_Length()
// 0x000000A8 System.Boolean System.Span`1::get_IsEmpty()
// 0x000000A9 System.Boolean System.Span`1::op_Inequality(System.Span`1<T>,System.Span`1<T>)
// 0x000000AA System.Boolean System.Span`1::Equals(System.Object)
// 0x000000AB System.Int32 System.Span`1::GetHashCode()
// 0x000000AC System.Span`1<T> System.Span`1::op_Implicit(T[])
// 0x000000AD System.Span`1<T> System.Span`1::op_Implicit(System.ArraySegment`1<T>)
// 0x000000AE System.Span`1<T> System.Span`1::get_Empty()
// 0x000000AF System.Span`1/Enumerator<T> System.Span`1::GetEnumerator()
// 0x000000B0 System.Void System.Span`1::.ctor(T[])
// 0x000000B1 System.Span`1<T> System.Span`1::Create(T[],System.Int32)
// 0x000000B2 System.Void System.Span`1::.ctor(T[],System.Int32,System.Int32)
// 0x000000B3 System.Void System.Span`1::.ctor(System.Void*,System.Int32)
// 0x000000B4 System.Void System.Span`1::.ctor(System.Pinnable`1<T>,System.IntPtr,System.Int32)
// 0x000000B5 T& System.Span`1::get_Item(System.Int32)
// 0x000000B6 T& System.Span`1::GetPinnableReference()
// 0x000000B7 System.Void System.Span`1::Clear()
// 0x000000B8 System.Void System.Span`1::Fill(T)
// 0x000000B9 System.Void System.Span`1::CopyTo(System.Span`1<T>)
// 0x000000BA System.Boolean System.Span`1::TryCopyTo(System.Span`1<T>)
// 0x000000BB System.Boolean System.Span`1::op_Equality(System.Span`1<T>,System.Span`1<T>)
// 0x000000BC System.ReadOnlySpan`1<T> System.Span`1::op_Implicit(System.Span`1<T>)
// 0x000000BD System.String System.Span`1::ToString()
// 0x000000BE System.Span`1<T> System.Span`1::Slice(System.Int32)
// 0x000000BF System.Span`1<T> System.Span`1::Slice(System.Int32,System.Int32)
// 0x000000C0 T[] System.Span`1::ToArray()
// 0x000000C1 T& System.Span`1::DangerousGetPinnableReference()
// 0x000000C2 System.Pinnable`1<T> System.Span`1::get_Pinnable()
// 0x000000C3 System.IntPtr System.Span`1::get_ByteOffset()
// 0x000000C4 System.Void System.Span`1/Enumerator::.ctor(System.Span`1<T>)
// 0x000000C5 System.Void System.SpanDebugView`1::.ctor(System.Span`1<T>)
// 0x000000C6 System.Void System.SpanDebugView`1::.ctor(System.ReadOnlySpan`1<T>)
// 0x000000C7 T[] System.SpanDebugView`1::get_Items()
// 0x000000C8 System.Int32 System.SpanHelpers::IndexOf(System.Byte&,System.Int32,System.Byte&,System.Int32)
extern void SpanHelpers_IndexOf_mAB424C62A4FBD5BA1CF460354CF232B8D7855CE6 (void);
// 0x000000C9 System.Int32 System.SpanHelpers::IndexOf(System.Byte&,System.Byte,System.Int32)
extern void SpanHelpers_IndexOf_m996881920138B2EC72C814473789D6AB958B92F2 (void);
// 0x000000CA System.Int32 System.SpanHelpers::IndexOfAny(System.Byte&,System.Byte,System.Byte,System.Byte,System.Int32)
extern void SpanHelpers_IndexOfAny_m08EBFBAA90222E41BD0E0BECA675C836CDF8B459 (void);
// 0x000000CB System.Boolean System.SpanHelpers::SequenceEqual(System.Byte&,System.Byte&,System.NUInt)
extern void SpanHelpers_SequenceEqual_mDEB0F358BB173EA24BEEB0609454A997E9273A89 (void);
// 0x000000CC System.Int32 System.SpanHelpers::LocateFirstFoundByte(System.Numerics.Vector`1<System.Byte>)
extern void SpanHelpers_LocateFirstFoundByte_m62E17AF3E4C9F8689DB23B9E54311BD8B540B4EF (void);
// 0x000000CD System.Int32 System.SpanHelpers::LocateFirstFoundByte(System.UInt64)
extern void SpanHelpers_LocateFirstFoundByte_m6AEEBF64B95585D577D0041CE56E0BE6F28AEFE4 (void);
// 0x000000CE System.Numerics.Vector`1<System.Byte> System.SpanHelpers::GetVector(System.Byte)
extern void SpanHelpers_GetVector_m02FA6D466B651ECA2610E80030F25D5C54364724 (void);
// 0x000000CF System.Int32 System.SpanHelpers::IndexOf(System.Char&,System.Char,System.Int32)
extern void SpanHelpers_IndexOf_m0740DDBBE5723E3595EADF2552551F636C18A259 (void);
// 0x000000D0 System.Int32 System.SpanHelpers::LocateFirstFoundChar(System.Numerics.Vector`1<System.UInt16>)
extern void SpanHelpers_LocateFirstFoundChar_mC9FF98473ACDD92571AF535184DF5E286E532FAB (void);
// 0x000000D1 System.Int32 System.SpanHelpers::LocateFirstFoundChar(System.UInt64)
extern void SpanHelpers_LocateFirstFoundChar_m7B3D3FD47EB5BA8837CE3E8CE2D2BBA7BFC62CE3 (void);
// 0x000000D2 System.Int32 System.SpanHelpers::IndexOf(T&,System.Int32,T&,System.Int32)
// 0x000000D3 System.Int32 System.SpanHelpers::IndexOf(T&,T,System.Int32)
// 0x000000D4 System.Int32 System.SpanHelpers::IndexOfAny(T&,T,T,T,System.Int32)
// 0x000000D5 System.Boolean System.SpanHelpers::SequenceEqual(T&,T&,System.Int32)
// 0x000000D6 System.Void System.SpanHelpers::CopyTo(T&,System.Int32,T&,System.Int32)
// 0x000000D7 System.IntPtr System.SpanHelpers::Add(System.IntPtr,System.Int32)
// 0x000000D8 System.Boolean System.SpanHelpers::IsReferenceOrContainsReferences()
// 0x000000D9 System.Boolean System.SpanHelpers::IsReferenceOrContainsReferencesCore(System.Type)
extern void SpanHelpers_IsReferenceOrContainsReferencesCore_m4046A8EAD00DA02AA423C292A8FCBB08268AD781 (void);
// 0x000000DA System.Void System.SpanHelpers::ClearLessThanPointerSized(System.Byte*,System.UIntPtr)
extern void SpanHelpers_ClearLessThanPointerSized_m257390BAE1A54335F742BD17D85AF6D8FC03C831 (void);
// 0x000000DB System.Void System.SpanHelpers::ClearLessThanPointerSized(System.Byte&,System.UIntPtr)
extern void SpanHelpers_ClearLessThanPointerSized_mDD75E922D42E70B6F76DB1A1EC1A96F59CAFF0B5 (void);
// 0x000000DC System.Void System.SpanHelpers::ClearPointerSizedWithoutReferences(System.Byte&,System.UIntPtr)
extern void SpanHelpers_ClearPointerSizedWithoutReferences_mC6EF2B959C4B0E58F8D4B8C9A5EF341F948FFAAA (void);
// 0x000000DD System.Void System.SpanHelpers::ClearPointerSizedWithReferences(System.IntPtr&,System.UIntPtr)
extern void SpanHelpers_ClearPointerSizedWithReferences_m45CDDDFAE259A9678B759645C7AB467860D44BAE (void);
// 0x000000DE System.Boolean System.SpanHelpers::LessThanEqual(System.IntPtr,System.UIntPtr)
extern void SpanHelpers_LessThanEqual_mCFA5E9CC05F428B1EDA65967FEF81267F917E88C (void);
// 0x000000DF System.IntPtr System.SpanHelpers/PerTypeValues`1::MeasureArrayAdjustment()
// 0x000000E0 System.Void System.SpanHelpers/PerTypeValues`1::.cctor()
// 0x000000E1 System.Void System.NUInt::.ctor(System.UInt32)
extern void NUInt__ctor_m34A1178C5D59B395E905B670FCF390D1AA5DC85E (void);
// 0x000000E2 System.Void System.NUInt::.ctor(System.UInt64)
extern void NUInt__ctor_mBD99E19E274774DF07488C672C5DFC90F4B21973 (void);
// 0x000000E3 System.NUInt System.NUInt::op_Explicit(System.Int32)
extern void NUInt_op_Explicit_m680513883587956D1452B1EB6D321D4C3A0C8366 (void);
// 0x000000E4 System.Void* System.NUInt::op_Explicit(System.NUInt)
extern void NUInt_op_Explicit_mAC8186F05FC1F16BAEB9A73957491CB24A067D46 (void);
// 0x000000E5 System.NUInt System.NUInt::op_Multiply(System.NUInt,System.NUInt)
extern void NUInt_op_Multiply_mABFB3E10A51F74FDC0CD9B799B7BF35C2C5D8D85 (void);
// 0x000000E6 System.Boolean System.MutableDecimal::get_IsNegative()
extern void MutableDecimal_get_IsNegative_m6CC9630C1FE5DAABD29CEE9EF5281C37D12CE702 (void);
// 0x000000E7 System.Void System.MutableDecimal::set_IsNegative(System.Boolean)
extern void MutableDecimal_set_IsNegative_mF373061A5BA3F192A2AA544BCB933C81BF71AC67 (void);
// 0x000000E8 System.Int32 System.MutableDecimal::get_Scale()
extern void MutableDecimal_get_Scale_mD47D52938E7026D2EC3AA837BABF7162C4F727A3 (void);
// 0x000000E9 System.Void System.MutableDecimal::set_Scale(System.Int32)
extern void MutableDecimal_set_Scale_m9253E0BBFF59D428FF76EA0A530D644053C3075C (void);
// 0x000000EA System.Resources.ResourceManager System.SR::get_ResourceManager()
extern void SR_get_ResourceManager_m18A791F4D611559D5B214B3020BAB11F2AC869EC (void);
// 0x000000EB System.Boolean System.SR::UsingResourceKeys()
extern void SR_UsingResourceKeys_m08DBDDDDF80E9F0013615CAB611F552F836BB526 (void);
// 0x000000EC System.String System.SR::GetResourceString(System.String,System.String)
extern void SR_GetResourceString_mEC79B3C28B26B1540E26C3CD899938CC955A4748 (void);
// 0x000000ED System.String System.SR::Format(System.String,System.Object)
extern void SR_Format_m4480ECD777F2A905A368094827DDCB43478A8053 (void);
// 0x000000EE System.Type System.SR::get_ResourceType()
extern void SR_get_ResourceType_mA677195FD1721150495B84739EFFDCB9366A5541 (void);
// 0x000000EF System.String System.SR::get_NotSupported_CannotCallEqualsOnSpan()
extern void SR_get_NotSupported_CannotCallEqualsOnSpan_mACE24A88A0ADF9880C315FDC0963BA17E66B0394 (void);
// 0x000000F0 System.String System.SR::get_NotSupported_CannotCallGetHashCodeOnSpan()
extern void SR_get_NotSupported_CannotCallGetHashCodeOnSpan_m4BC3D1B6994913E69BDD4028026F18A279A9DBDB (void);
// 0x000000F1 System.String System.SR::get_Argument_InvalidTypeWithPointersNotSupported()
extern void SR_get_Argument_InvalidTypeWithPointersNotSupported_m2FD2DCBFF1853C8F9616D4C55DD1C14163A06B75 (void);
// 0x000000F2 System.String System.SR::get_Argument_DestinationTooShort()
extern void SR_get_Argument_DestinationTooShort_mDD536A55FFA1BD1CF5C34D9E074420C183905559 (void);
// 0x000000F3 System.String System.SR::get_Argument_BadFormatSpecifier()
extern void SR_get_Argument_BadFormatSpecifier_mFE81E4F926274AB402B890E679E6CAB600E61433 (void);
// 0x000000F4 System.String System.SR::get_Argument_GWithPrecisionNotSupported()
extern void SR_get_Argument_GWithPrecisionNotSupported_mF77D1EF96FE22465E62C65C5895E968E7FB10019 (void);
// 0x000000F5 System.String System.SR::get_Argument_PrecisionTooLarge()
extern void SR_get_Argument_PrecisionTooLarge_m42EED38BF28506133A0AB30447E3C35CCA120A7F (void);
// 0x000000F6 System.String System.SR::get_EndPositionNotReached()
extern void SR_get_EndPositionNotReached_m26E126334F58B1570EEAAA53A48B9518F3C17913 (void);
// 0x000000F7 System.Void System.SR::.cctor()
extern void SR__cctor_m4CA77DF9E538A3B432DD3F12C4D3E655983629DB (void);
// 0x000000F8 System.Int32 System.Numerics.Hashing.HashHelpers::Combine(System.Int32,System.Int32)
extern void HashHelpers_Combine_m0B422F3A90AC3CD046375C8195F8ED339B83ED46 (void);
// 0x000000F9 System.Void System.Numerics.Hashing.HashHelpers::.cctor()
extern void HashHelpers__cctor_mE4D846284DBD325D39520B0D94CE6D08B7A937E2 (void);
// 0x000000FA System.Boolean System.Runtime.InteropServices.SequenceMarshal::TryGetString(System.Buffers.ReadOnlySequence`1<System.Char>,System.String&,System.Int32&,System.Int32&)
extern void SequenceMarshal_TryGetString_mBA81A10F83642193C6BB3862B3E847222BE88F7B (void);
// 0x000000FB System.Boolean System.Runtime.InteropServices.MemoryMarshal::TryGetArray(System.ReadOnlyMemory`1<T>,System.ArraySegment`1<T>&)
// 0x000000FC System.Boolean System.Runtime.InteropServices.MemoryMarshal::TryGetMemoryManager(System.ReadOnlyMemory`1<T>,TManager&,System.Int32&,System.Int32&)
// 0x000000FD System.Boolean System.Runtime.InteropServices.MemoryMarshal::TryGetString(System.ReadOnlyMemory`1<System.Char>,System.String&,System.Int32&,System.Int32&)
extern void MemoryMarshal_TryGetString_mF59A4FBC01B0F61BFCAD2BA3960B9670FADB0C09 (void);
// 0x000000FE T System.Runtime.InteropServices.MemoryMarshal::Read(System.ReadOnlySpan`1<System.Byte>)
// 0x000000FF System.Void System.Runtime.InteropServices.MemoryMarshal::Write(System.Span`1<System.Byte>,T&)
// 0x00000100 System.Boolean System.Runtime.InteropServices.MemoryMarshal::TryWrite(System.Span`1<System.Byte>,T&)
// 0x00000101 System.ReadOnlySpan`1<System.Byte> System.Runtime.InteropServices.MemoryMarshal::AsBytes(System.ReadOnlySpan`1<T>)
// 0x00000102 T& System.Runtime.InteropServices.MemoryMarshal::GetReference(System.Span`1<T>)
// 0x00000103 T& System.Runtime.InteropServices.MemoryMarshal::GetReference(System.ReadOnlySpan`1<T>)
// 0x00000104 System.Span`1<TTo> System.Runtime.InteropServices.MemoryMarshal::Cast(System.Span`1<TFrom>)
// 0x00000105 System.ReadOnlySpan`1<TTo> System.Runtime.InteropServices.MemoryMarshal::Cast(System.ReadOnlySpan`1<TFrom>)
// 0x00000106 System.Void System.Buffers.BuffersExtensions::CopyTo(System.Buffers.ReadOnlySequence`1<T>&,System.Span`1<T>)
// 0x00000107 System.Void System.Buffers.BuffersExtensions::CopyToMultiSegment(System.Buffers.ReadOnlySequence`1<T>&,System.Span`1<T>)
// 0x00000108 T[] System.Buffers.BuffersExtensions::ToArray(System.Buffers.ReadOnlySequence`1<T>&)
// 0x00000109 System.Void System.Buffers.IBufferWriter`1::Advance(System.Int32)
// 0x0000010A System.Memory`1<T> System.Buffers.IBufferWriter`1::GetMemory(System.Int32)
// 0x0000010B System.Int64 System.Buffers.ReadOnlySequence`1::get_Length()
// 0x0000010C System.Boolean System.Buffers.ReadOnlySequence`1::get_IsEmpty()
// 0x0000010D System.Boolean System.Buffers.ReadOnlySequence`1::get_IsSingleSegment()
// 0x0000010E System.ReadOnlyMemory`1<T> System.Buffers.ReadOnlySequence`1::get_First()
// 0x0000010F System.SequencePosition System.Buffers.ReadOnlySequence`1::get_Start()
// 0x00000110 System.SequencePosition System.Buffers.ReadOnlySequence`1::get_End()
// 0x00000111 System.Void System.Buffers.ReadOnlySequence`1::.ctor(System.Object,System.Int32,System.Object,System.Int32)
// 0x00000112 System.Void System.Buffers.ReadOnlySequence`1::.ctor(System.Buffers.ReadOnlySequenceSegment`1<T>,System.Int32,System.Buffers.ReadOnlySequenceSegment`1<T>,System.Int32)
// 0x00000113 System.Void System.Buffers.ReadOnlySequence`1::.ctor(T[])
// 0x00000114 System.Void System.Buffers.ReadOnlySequence`1::.ctor(T[],System.Int32,System.Int32)
// 0x00000115 System.Void System.Buffers.ReadOnlySequence`1::.ctor(System.ReadOnlyMemory`1<T>)
// 0x00000116 System.Buffers.ReadOnlySequence`1<T> System.Buffers.ReadOnlySequence`1::Slice(System.Int64,System.Int64)
// 0x00000117 System.Buffers.ReadOnlySequence`1<T> System.Buffers.ReadOnlySequence`1::Slice(System.Int64,System.SequencePosition)
// 0x00000118 System.Buffers.ReadOnlySequence`1<T> System.Buffers.ReadOnlySequence`1::Slice(System.SequencePosition,System.Int64)
// 0x00000119 System.Buffers.ReadOnlySequence`1<T> System.Buffers.ReadOnlySequence`1::Slice(System.Int32,System.Int32)
// 0x0000011A System.Buffers.ReadOnlySequence`1<T> System.Buffers.ReadOnlySequence`1::Slice(System.Int32,System.SequencePosition)
// 0x0000011B System.Buffers.ReadOnlySequence`1<T> System.Buffers.ReadOnlySequence`1::Slice(System.SequencePosition,System.Int32)
// 0x0000011C System.Buffers.ReadOnlySequence`1<T> System.Buffers.ReadOnlySequence`1::Slice(System.SequencePosition,System.SequencePosition)
// 0x0000011D System.Buffers.ReadOnlySequence`1<T> System.Buffers.ReadOnlySequence`1::Slice(System.SequencePosition)
// 0x0000011E System.Buffers.ReadOnlySequence`1<T> System.Buffers.ReadOnlySequence`1::Slice(System.Int64)
// 0x0000011F System.String System.Buffers.ReadOnlySequence`1::ToString()
// 0x00000120 System.Buffers.ReadOnlySequence`1/Enumerator<T> System.Buffers.ReadOnlySequence`1::GetEnumerator()
// 0x00000121 System.SequencePosition System.Buffers.ReadOnlySequence`1::GetPosition(System.Int64)
// 0x00000122 System.SequencePosition System.Buffers.ReadOnlySequence`1::GetPosition(System.Int64,System.SequencePosition)
// 0x00000123 System.Boolean System.Buffers.ReadOnlySequence`1::TryGet(System.SequencePosition&,System.ReadOnlyMemory`1<T>&,System.Boolean)
// 0x00000124 System.Boolean System.Buffers.ReadOnlySequence`1::TryGetBuffer(System.SequencePosition&,System.ReadOnlyMemory`1<T>&,System.SequencePosition&)
// 0x00000125 System.ReadOnlyMemory`1<T> System.Buffers.ReadOnlySequence`1::GetFirstBuffer()
// 0x00000126 System.SequencePosition System.Buffers.ReadOnlySequence`1::Seek(System.SequencePosition&,System.SequencePosition&,System.Int64,System.ExceptionArgument)
// 0x00000127 System.SequencePosition System.Buffers.ReadOnlySequence`1::SeekMultiSegment(System.Buffers.ReadOnlySequenceSegment`1<T>,System.Object,System.Int32,System.Int64,System.ExceptionArgument)
// 0x00000128 System.Void System.Buffers.ReadOnlySequence`1::BoundsCheck(System.SequencePosition&)
// 0x00000129 System.Void System.Buffers.ReadOnlySequence`1::BoundsCheck(System.UInt32,System.Object,System.UInt32,System.Object)
// 0x0000012A System.SequencePosition System.Buffers.ReadOnlySequence`1::GetEndPosition(System.Buffers.ReadOnlySequenceSegment`1<T>,System.Object,System.Int32,System.Object,System.Int32,System.Int64)
// 0x0000012B System.Buffers.ReadOnlySequence`1/SequenceType<T> System.Buffers.ReadOnlySequence`1::GetSequenceType()
// 0x0000012C System.Int32 System.Buffers.ReadOnlySequence`1::GetIndex(System.SequencePosition&)
// 0x0000012D System.Buffers.ReadOnlySequence`1<T> System.Buffers.ReadOnlySequence`1::SliceImpl(System.SequencePosition&,System.SequencePosition&)
// 0x0000012E System.Int64 System.Buffers.ReadOnlySequence`1::GetLength()
// 0x0000012F System.Boolean System.Buffers.ReadOnlySequence`1::TryGetReadOnlySequenceSegment(System.Buffers.ReadOnlySequenceSegment`1<T>&,System.Int32&,System.Buffers.ReadOnlySequenceSegment`1<T>&,System.Int32&)
// 0x00000130 System.Boolean System.Buffers.ReadOnlySequence`1::TryGetArray(System.ArraySegment`1<T>&)
// 0x00000131 System.Boolean System.Buffers.ReadOnlySequence`1::TryGetString(System.String&,System.Int32&,System.Int32&)
// 0x00000132 System.Boolean System.Buffers.ReadOnlySequence`1::InRange(System.UInt32,System.UInt32,System.UInt32)
// 0x00000133 System.Boolean System.Buffers.ReadOnlySequence`1::InRange(System.UInt64,System.UInt64,System.UInt64)
// 0x00000134 System.Void System.Buffers.ReadOnlySequence`1::.cctor()
// 0x00000135 System.Void System.Buffers.ReadOnlySequence`1/Enumerator::.ctor(System.Buffers.ReadOnlySequence`1<T>&)
// 0x00000136 System.ReadOnlyMemory`1<T> System.Buffers.ReadOnlySequence`1/Enumerator::get_Current()
// 0x00000137 System.Boolean System.Buffers.ReadOnlySequence`1/Enumerator::MoveNext()
// 0x00000138 System.Int32 System.Buffers.ReadOnlySequence::SegmentToSequenceStart(System.Int32)
extern void ReadOnlySequence_SegmentToSequenceStart_mEE6CF5E985234E355289D641D4E49D4BAA9E3083 (void);
// 0x00000139 System.Int32 System.Buffers.ReadOnlySequence::SegmentToSequenceEnd(System.Int32)
extern void ReadOnlySequence_SegmentToSequenceEnd_mFFDFAE7585A75266241B8973C55046431260BBDE (void);
// 0x0000013A System.Int32 System.Buffers.ReadOnlySequence::ArrayToSequenceStart(System.Int32)
extern void ReadOnlySequence_ArrayToSequenceStart_mCEAF0855FE164270628814C10B531646278E0855 (void);
// 0x0000013B System.Int32 System.Buffers.ReadOnlySequence::ArrayToSequenceEnd(System.Int32)
extern void ReadOnlySequence_ArrayToSequenceEnd_mFF69FF0508B383A32C7EF9F89E701787D112BAB6 (void);
// 0x0000013C System.Int32 System.Buffers.ReadOnlySequence::MemoryManagerToSequenceStart(System.Int32)
extern void ReadOnlySequence_MemoryManagerToSequenceStart_mFD1015C3FF75727F14979508EE405C50AA456138 (void);
// 0x0000013D System.Int32 System.Buffers.ReadOnlySequence::MemoryManagerToSequenceEnd(System.Int32)
extern void ReadOnlySequence_MemoryManagerToSequenceEnd_m85705DE4E192CFB7B915CFDFE2DC5C47870E895D (void);
// 0x0000013E System.Int32 System.Buffers.ReadOnlySequence::StringToSequenceStart(System.Int32)
extern void ReadOnlySequence_StringToSequenceStart_mBB3640B275AF4DFA2FDBEA7CFAE5D539FB4D6B6A (void);
// 0x0000013F System.Int32 System.Buffers.ReadOnlySequence::StringToSequenceEnd(System.Int32)
extern void ReadOnlySequence_StringToSequenceEnd_m969959A7F05E83C60ECC577C1EACF3C2ECA6DE91 (void);
// 0x00000140 System.Void System.Buffers.ReadOnlySequenceDebugView`1::.ctor(System.Buffers.ReadOnlySequence`1<T>)
// 0x00000141 System.Buffers.ReadOnlySequenceDebugView`1/ReadOnlySequenceDebugViewSegments<T> System.Buffers.ReadOnlySequenceDebugView`1::get_BufferSegments()
// 0x00000142 T[] System.Buffers.ReadOnlySequenceDebugView`1::get_Items()
// 0x00000143 System.ReadOnlyMemory`1<T>[] System.Buffers.ReadOnlySequenceDebugView`1/ReadOnlySequenceDebugViewSegments::get_Segments()
// 0x00000144 System.Void System.Buffers.ReadOnlySequenceDebugView`1/ReadOnlySequenceDebugViewSegments::set_Segments(System.ReadOnlyMemory`1<T>[])
// 0x00000145 System.ReadOnlyMemory`1<T> System.Buffers.ReadOnlySequenceSegment`1::get_Memory()
// 0x00000146 System.Buffers.ReadOnlySequenceSegment`1<T> System.Buffers.ReadOnlySequenceSegment`1::get_Next()
// 0x00000147 System.Int64 System.Buffers.ReadOnlySequenceSegment`1::get_RunningIndex()
// 0x00000148 System.Char System.Buffers.StandardFormat::get_Symbol()
extern void StandardFormat_get_Symbol_mF8A6168808E4EEB455E2F8695DD243231285B0F2 (void);
// 0x00000149 System.Byte System.Buffers.StandardFormat::get_Precision()
extern void StandardFormat_get_Precision_m0080A4421E19B1702147DF794C3D4C2D1035C5B6 (void);
// 0x0000014A System.Boolean System.Buffers.StandardFormat::get_HasPrecision()
extern void StandardFormat_get_HasPrecision_m512C556F8EABC1880A4057A0255D42C5008F322E (void);
// 0x0000014B System.Boolean System.Buffers.StandardFormat::get_IsDefault()
extern void StandardFormat_get_IsDefault_mA235EA7D61B74384AF56AEC5174D2ACD568AE144 (void);
// 0x0000014C System.Void System.Buffers.StandardFormat::.ctor(System.Char,System.Byte)
extern void StandardFormat__ctor_mEDC33761CDF50C5F7D01BF0DD6D673658931D43F (void);
// 0x0000014D System.Buffers.StandardFormat System.Buffers.StandardFormat::op_Implicit(System.Char)
extern void StandardFormat_op_Implicit_mC7AEDB177670024F660C1AA4BA07616FB27B29BD (void);
// 0x0000014E System.Boolean System.Buffers.StandardFormat::Equals(System.Object)
extern void StandardFormat_Equals_mB63E4B0879F9B74C0783E32117A22592050C887A (void);
// 0x0000014F System.Int32 System.Buffers.StandardFormat::GetHashCode()
extern void StandardFormat_GetHashCode_mA2398AB63B3856075F7E8F9A26D142878DDAB119 (void);
// 0x00000150 System.Boolean System.Buffers.StandardFormat::Equals(System.Buffers.StandardFormat)
extern void StandardFormat_Equals_m6AAD6931E6B7620BC5676B60FDE95DEBDCC6A011 (void);
// 0x00000151 System.String System.Buffers.StandardFormat::ToString()
extern void StandardFormat_ToString_m1391A69E60EF500E59D59A29124BAD2C1D28CE6D (void);
// 0x00000152 System.Void System.Buffers.IPinnable::Unpin()
// 0x00000153 System.Void System.Buffers.MemoryHandle::.ctor(System.Void*,System.Runtime.InteropServices.GCHandle,System.Buffers.IPinnable)
extern void MemoryHandle__ctor_mD254CBC13788969FCC315DF2B1C8615A945F18B3 (void);
// 0x00000154 System.Void System.Buffers.MemoryHandle::Dispose()
extern void MemoryHandle_Dispose_mE19418148935D11619DD13966114889837089E9A (void);
// 0x00000155 System.Memory`1<T> System.Buffers.MemoryManager`1::get_Memory()
// 0x00000156 System.Span`1<T> System.Buffers.MemoryManager`1::GetSpan()
// 0x00000157 System.Buffers.MemoryHandle System.Buffers.MemoryManager`1::Pin(System.Int32)
// 0x00000158 System.Void System.Buffers.MemoryManager`1::Unpin()
// 0x00000159 System.Boolean System.Buffers.MemoryManager`1::TryGetArray(System.ArraySegment`1<T>&)
// 0x0000015A System.Void System.Buffers.MemoryManager`1::System.IDisposable.Dispose()
// 0x0000015B System.Void System.Buffers.MemoryManager`1::Dispose(System.Boolean)
// 0x0000015C System.Buffers.OperationStatus System.Buffers.Text.Base64::DecodeFromUtf8(System.ReadOnlySpan`1<System.Byte>,System.Span`1<System.Byte>,System.Int32&,System.Int32&,System.Boolean)
extern void Base64_DecodeFromUtf8_m42C42D1F4690C787AD2060F743AF9016346B9AD2 (void);
// 0x0000015D System.Int32 System.Buffers.Text.Base64::GetMaxDecodedFromUtf8Length(System.Int32)
extern void Base64_GetMaxDecodedFromUtf8Length_m006256FEA6BF678C4F127180F8B1332F064F502F (void);
// 0x0000015E System.Buffers.OperationStatus System.Buffers.Text.Base64::DecodeFromUtf8InPlace(System.Span`1<System.Byte>,System.Int32&)
extern void Base64_DecodeFromUtf8InPlace_mEBB97003AC863B73FCFAF272CED3A805F3F4309E (void);
// 0x0000015F System.Int32 System.Buffers.Text.Base64::Decode(System.Byte&,System.SByte&)
extern void Base64_Decode_m9255647C748D2E5A658B306FF1CB018A3518E3EB (void);
// 0x00000160 System.Void System.Buffers.Text.Base64::WriteThreeLowOrderBytes(System.Byte&,System.Int32)
extern void Base64_WriteThreeLowOrderBytes_mEA9D70EF786F6B007B97DC740E9B2D6335A257D2 (void);
// 0x00000161 System.Buffers.OperationStatus System.Buffers.Text.Base64::EncodeToUtf8(System.ReadOnlySpan`1<System.Byte>,System.Span`1<System.Byte>,System.Int32&,System.Int32&,System.Boolean)
extern void Base64_EncodeToUtf8_m577D7216DE2808F843877387142BEFC4E23EC796 (void);
// 0x00000162 System.Int32 System.Buffers.Text.Base64::GetMaxEncodedToUtf8Length(System.Int32)
extern void Base64_GetMaxEncodedToUtf8Length_mCE09C90A3306E4E5812A354474AD5CBF972971A9 (void);
// 0x00000163 System.Int32 System.Buffers.Text.Base64::Encode(System.Byte&,System.Byte&)
extern void Base64_Encode_mF7004599E680812FB2DC7744AD0EE802A17B449A (void);
// 0x00000164 System.Int32 System.Buffers.Text.Base64::EncodeAndPadOne(System.Byte&,System.Byte&)
extern void Base64_EncodeAndPadOne_m2240A53CE28BE8A0A955A7E467B0E7E9A8A0DD7C (void);
// 0x00000165 System.Int32 System.Buffers.Text.Base64::EncodeAndPadTwo(System.Byte&,System.Byte&)
extern void Base64_EncodeAndPadTwo_mCC772FF69A3BEFE27CB02697DD37F08417EC1EA2 (void);
// 0x00000166 System.Void System.Buffers.Text.Base64::.cctor()
extern void Base64__cctor_m3B098734F3F8EF762B0E391849C528627DA77BED (void);
// 0x00000167 System.Void System.Buffers.Text.Utf8Constants::.cctor()
extern void Utf8Constants__cctor_m312B1DFF8FBB89F5601299D0146E152F40AA82EC (void);
// 0x00000168 System.Char System.Buffers.Text.FormattingHelpers::GetSymbolOrDefault(System.Buffers.StandardFormat&,System.Char)
extern void FormattingHelpers_GetSymbolOrDefault_m26DC14293CBF28446BFD5991B0BC6D55D199281E (void);
// 0x00000169 System.Void System.Buffers.Text.FormattingHelpers::FillWithAsciiZeros(System.Span`1<System.Byte>)
extern void FormattingHelpers_FillWithAsciiZeros_m3A29E363C6C25E65720EA654150D6199298C3A5E (void);
// 0x0000016A System.Void System.Buffers.Text.FormattingHelpers::WriteHexByte(System.Byte,System.Span`1<System.Byte>,System.Int32,System.Buffers.Text.FormattingHelpers/HexCasing)
extern void FormattingHelpers_WriteHexByte_m74A433852D66F62FF7174EF4F40B0E0EC1E7088B (void);
// 0x0000016B System.Void System.Buffers.Text.FormattingHelpers::WriteDigits(System.UInt64,System.Span`1<System.Byte>)
extern void FormattingHelpers_WriteDigits_mB84E216D8FDAAEE250F7E833F1886CF7352CD243 (void);
// 0x0000016C System.Void System.Buffers.Text.FormattingHelpers::WriteDigitsWithGroupSeparator(System.UInt64,System.Span`1<System.Byte>)
extern void FormattingHelpers_WriteDigitsWithGroupSeparator_m47961A365046CD674E315B8366DCC3A6C563F1F9 (void);
// 0x0000016D System.Void System.Buffers.Text.FormattingHelpers::WriteDigits(System.UInt32,System.Span`1<System.Byte>)
extern void FormattingHelpers_WriteDigits_mB294245C1C40A39A6FADC68FD44FDE93489329DE (void);
// 0x0000016E System.Void System.Buffers.Text.FormattingHelpers::WriteFourDecimalDigits(System.UInt32,System.Span`1<System.Byte>,System.Int32)
extern void FormattingHelpers_WriteFourDecimalDigits_m2C9CE9DD697E21513F53A059A6E8A67411C49300 (void);
// 0x0000016F System.Void System.Buffers.Text.FormattingHelpers::WriteTwoDecimalDigits(System.UInt32,System.Span`1<System.Byte>,System.Int32)
extern void FormattingHelpers_WriteTwoDecimalDigits_mBA9DF0C24B6CB962499015EC49E99779A540C95E (void);
// 0x00000170 System.Int32 System.Buffers.Text.FormattingHelpers::CountDigits(System.UInt64)
extern void FormattingHelpers_CountDigits_m675BA657779A2850D4C7B0DE8FFF5D53DCF95144 (void);
// 0x00000171 System.Int32 System.Buffers.Text.FormattingHelpers::CountDigits(System.UInt32)
extern void FormattingHelpers_CountDigits_mA676272B50F0CE205CC72EA4455298AE722FE53E (void);
// 0x00000172 System.Int32 System.Buffers.Text.FormattingHelpers::CountHexDigits(System.UInt64)
extern void FormattingHelpers_CountHexDigits_mC892DDD16C175A09E028D0CAC2F1FD4EBEFFE3BE (void);
// 0x00000173 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormat(System.Boolean,System.Span`1<System.Byte>,System.Int32&,System.Buffers.StandardFormat)
extern void Utf8Formatter_TryFormat_m801A1D1F29220D08560601466D8F88608FB9FB28 (void);
// 0x00000174 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormat(System.DateTimeOffset,System.Span`1<System.Byte>,System.Int32&,System.Buffers.StandardFormat)
extern void Utf8Formatter_TryFormat_mB5A5D29E1AB53EF943A7517ED41865FFD6D49E40 (void);
// 0x00000175 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormat(System.DateTime,System.Span`1<System.Byte>,System.Int32&,System.Buffers.StandardFormat)
extern void Utf8Formatter_TryFormat_m2ABA3915E51ED1976E85ABA15699790E0D5DB675 (void);
// 0x00000176 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatDateTimeG(System.DateTime,System.TimeSpan,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatDateTimeG_m73A2E1DA59D9006A5809628F5516C74FDAAAB354 (void);
// 0x00000177 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatDateTimeO(System.DateTime,System.TimeSpan,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatDateTimeO_mBA169648C706917AA22CB978323C578DB48DEE28 (void);
// 0x00000178 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatDateTimeR(System.DateTime,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatDateTimeR_m6F450413D5D0670CDEF033B957C41352450AEFCB (void);
// 0x00000179 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatDateTimeL(System.DateTime,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatDateTimeL_m34A3FE15768F3A1B0C1CC2A746B46D40922E856A (void);
// 0x0000017A System.Boolean System.Buffers.Text.Utf8Formatter::TryFormat(System.Decimal,System.Span`1<System.Byte>,System.Int32&,System.Buffers.StandardFormat)
extern void Utf8Formatter_TryFormat_m6791AE969A684DF1A5141E89B2748A0491B16DA1 (void);
// 0x0000017B System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatDecimalE(System.NumberBuffer&,System.Span`1<System.Byte>,System.Int32&,System.Byte,System.Byte)
extern void Utf8Formatter_TryFormatDecimalE_m5EE850421F5ECD53EB303F5E20F42E989BC7B679 (void);
// 0x0000017C System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatDecimalF(System.NumberBuffer&,System.Span`1<System.Byte>,System.Int32&,System.Byte)
extern void Utf8Formatter_TryFormatDecimalF_mB3F592FC02FDB10D2F065AAC4993754DCE801384 (void);
// 0x0000017D System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatDecimalG(System.NumberBuffer&,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatDecimalG_m9209EBD3DB9F8ADBD39C4F69246BF2D2B7E2B86B (void);
// 0x0000017E System.Boolean System.Buffers.Text.Utf8Formatter::TryFormat(System.Guid,System.Span`1<System.Byte>,System.Int32&,System.Buffers.StandardFormat)
extern void Utf8Formatter_TryFormat_mAF103F9E49F131C60F65F3ECF97732AA828E141A (void);
// 0x0000017F System.Boolean System.Buffers.Text.Utf8Formatter::TryFormat(System.Byte,System.Span`1<System.Byte>,System.Int32&,System.Buffers.StandardFormat)
extern void Utf8Formatter_TryFormat_m9511892FD3132F76B90E0089072BDF8F11884BC4 (void);
// 0x00000180 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormat(System.UInt64,System.Span`1<System.Byte>,System.Int32&,System.Buffers.StandardFormat)
extern void Utf8Formatter_TryFormat_mF00E41768123B7B47C2427C6327C2045B074BE0A (void);
// 0x00000181 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormat(System.Int64,System.Span`1<System.Byte>,System.Int32&,System.Buffers.StandardFormat)
extern void Utf8Formatter_TryFormat_m3DAF77915AA8455CAFC49F4457FE35B2EC00DF3E (void);
// 0x00000182 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatInt64(System.Int64,System.UInt64,System.Span`1<System.Byte>,System.Int32&,System.Buffers.StandardFormat)
extern void Utf8Formatter_TryFormatInt64_m61A954CEB254D25C2F681CF707F80AD856F73750 (void);
// 0x00000183 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatInt64D(System.Int64,System.Byte,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatInt64D_mB8F5C4DDAA08332F924D62C0B426C1D414C4ABCA (void);
// 0x00000184 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatInt64Default(System.Int64,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatInt64Default_mF4B334DF6319D35C0B33A6572F7FF0EA3CE7C2A8 (void);
// 0x00000185 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatInt32MultipleDigits(System.Int32,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatInt32MultipleDigits_m006E2F6B25667EE3B58402D5101CE6BCA787A391 (void);
// 0x00000186 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatInt64MultipleDigits(System.Int64,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatInt64MultipleDigits_mB1689643467ACA69DA8BBE4FE8C9272C127D4FBB (void);
// 0x00000187 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatInt64MoreThanNegativeBillionMaxUInt(System.Int64,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatInt64MoreThanNegativeBillionMaxUInt_m66C6074F21CCD770F792503E660A59CCE7B0E5F7 (void);
// 0x00000188 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatInt64LessThanNegativeBillionMaxUInt(System.Int64,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatInt64LessThanNegativeBillionMaxUInt_m8B5E903509AF6881879B14886D005900E04B295C (void);
// 0x00000189 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatInt64N(System.Int64,System.Byte,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatInt64N_m78109B8A854CD414F3883A4F54F2828D65E03A9E (void);
// 0x0000018A System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatUInt64(System.UInt64,System.Span`1<System.Byte>,System.Int32&,System.Buffers.StandardFormat)
extern void Utf8Formatter_TryFormatUInt64_m903D18A13B3D28E3301BE4AA8CF22DA85694EB3A (void);
// 0x0000018B System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatUInt64D(System.UInt64,System.Byte,System.Span`1<System.Byte>,System.Boolean,System.Int32&)
extern void Utf8Formatter_TryFormatUInt64D_m9CC93A27892C98CDC584E3A9A211BE4BCD9C47BC (void);
// 0x0000018C System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatUInt64Default(System.UInt64,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatUInt64Default_mC66DA768AC3B8933EA96384412E1D8CFB51D64F2 (void);
// 0x0000018D System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatUInt32SingleDigit(System.UInt32,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatUInt32SingleDigit_m640F93E5FC560A68BD27039E9C864C9C5D582335 (void);
// 0x0000018E System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatUInt32MultipleDigits(System.UInt32,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatUInt32MultipleDigits_m8EE0BA7509C7951049017B0E1C3BB6E911CD7863 (void);
// 0x0000018F System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatUInt64MultipleDigits(System.UInt64,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatUInt64MultipleDigits_mF63FC4B51EE923E000733252A9E705D25531919B (void);
// 0x00000190 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatUInt64LessThanBillionMaxUInt(System.UInt64,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatUInt64LessThanBillionMaxUInt_mD0B30477DD0CE3DDAE2E87395EA417EE44806626 (void);
// 0x00000191 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatUInt64MoreThanBillionMaxUInt(System.UInt64,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatUInt64MoreThanBillionMaxUInt_m906E75BFEC07873FC07898B6F41592B5F0F439A8 (void);
// 0x00000192 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatUInt64N(System.UInt64,System.Byte,System.Span`1<System.Byte>,System.Boolean,System.Int32&)
extern void Utf8Formatter_TryFormatUInt64N_mCF9B963233A1FD9750B0EA2F8CF833980C18826D (void);
// 0x00000193 System.Boolean System.Buffers.Text.Utf8Formatter::TryFormatUInt64X(System.UInt64,System.Byte,System.Boolean,System.Span`1<System.Byte>,System.Int32&)
extern void Utf8Formatter_TryFormatUInt64X_m873913C215B45BE56870D7EFEFF57F558F1B79F1 (void);
// 0x00000194 System.Void System.Buffers.Text.Utf8Formatter::.cctor()
extern void Utf8Formatter__cctor_mB078801DA1AF49D670C5D6813AFECBF5C0691DCD (void);
// 0x00000195 System.Boolean System.Buffers.Text.ParserHelpers::IsDigit(System.Int32)
extern void ParserHelpers_IsDigit_m741C974EC477EA1F49439BA55D1C3142EA1D784D (void);
// 0x00000196 System.Void System.Buffers.Text.ParserHelpers::.cctor()
extern void ParserHelpers__cctor_m98371EB2AB06474B2928A3F9F4B8A598E17CEAB1 (void);
// 0x00000197 System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.Boolean&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_m7D7E4C95A96C051D3AC51B7CA3294481DA5C3A35 (void);
// 0x00000198 System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.Decimal&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_m90A0F8BFE5C3044C00DB5155FF340B6AF68E74FE (void);
// 0x00000199 System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.Single&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_m83ECFE8C76A9905B80E887F9414D41A319C2AA00 (void);
// 0x0000019A System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.Double&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_m24053FD013B5A4736E222DF29C9F6A79B13F21FE (void);
// 0x0000019B System.Boolean System.Buffers.Text.Utf8Parser::TryParseNormalAsFloatingPoint(System.ReadOnlySpan`1<System.Byte>,System.Double&,System.Int32&,System.Char)
extern void Utf8Parser_TryParseNormalAsFloatingPoint_m9B7C74F1C7BEA1EA70A86E8E98E7BE7A33366DAB (void);
// 0x0000019C System.Boolean System.Buffers.Text.Utf8Parser::TryParseAsSpecialFloatingPoint(System.ReadOnlySpan`1<System.Byte>,T,T,T,T&,System.Int32&)
// 0x0000019D System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.Guid&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_mAFC6FFA0BF8733D2C6156C4F7F9DDDE77528983C (void);
// 0x0000019E System.Boolean System.Buffers.Text.Utf8Parser::TryParseGuidN(System.ReadOnlySpan`1<System.Byte>,System.Guid&,System.Int32&)
extern void Utf8Parser_TryParseGuidN_mF063301B3928C30520E3DA9EBB8CD0AAEE3F921F (void);
// 0x0000019F System.Boolean System.Buffers.Text.Utf8Parser::TryParseGuidCore(System.ReadOnlySpan`1<System.Byte>,System.Boolean,System.Char,System.Char,System.Guid&,System.Int32&)
extern void Utf8Parser_TryParseGuidCore_m3B32BF426D81A189B437FC286C7EB49989A35463 (void);
// 0x000001A0 System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.SByte&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_mEC708A21A90BD9288ABBD948316F13851423ABCB (void);
// 0x000001A1 System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.Int16&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_mBCAC213B7DBE37664B717A7BBB3165E32478AAA0 (void);
// 0x000001A2 System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.Int32&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_mAF1471EBA73DEBEF88625109A459CD0D0B7EDCE6 (void);
// 0x000001A3 System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.Int64&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_m960CA85130DF531A15E65CDC72A0EB0D9CE89333 (void);
// 0x000001A4 System.Boolean System.Buffers.Text.Utf8Parser::TryParseSByteD(System.ReadOnlySpan`1<System.Byte>,System.SByte&,System.Int32&)
extern void Utf8Parser_TryParseSByteD_mBDA10E37645BABA381ADB839C659F7E2D67919AE (void);
// 0x000001A5 System.Boolean System.Buffers.Text.Utf8Parser::TryParseInt16D(System.ReadOnlySpan`1<System.Byte>,System.Int16&,System.Int32&)
extern void Utf8Parser_TryParseInt16D_mBF1EEA65F0A3022F85C509138EDE17C2C9544A5D (void);
// 0x000001A6 System.Boolean System.Buffers.Text.Utf8Parser::TryParseInt32D(System.ReadOnlySpan`1<System.Byte>,System.Int32&,System.Int32&)
extern void Utf8Parser_TryParseInt32D_mFD173F33096EB860929AAB5FD430804EEE5CEAB0 (void);
// 0x000001A7 System.Boolean System.Buffers.Text.Utf8Parser::TryParseInt64D(System.ReadOnlySpan`1<System.Byte>,System.Int64&,System.Int32&)
extern void Utf8Parser_TryParseInt64D_m88F7248F8771F6896EE62D8C9DC13FA432B8C578 (void);
// 0x000001A8 System.Boolean System.Buffers.Text.Utf8Parser::TryParseSByteN(System.ReadOnlySpan`1<System.Byte>,System.SByte&,System.Int32&)
extern void Utf8Parser_TryParseSByteN_m5B96DC92A5BCDF5E4F3AAC786C1635305F49860A (void);
// 0x000001A9 System.Boolean System.Buffers.Text.Utf8Parser::TryParseInt16N(System.ReadOnlySpan`1<System.Byte>,System.Int16&,System.Int32&)
extern void Utf8Parser_TryParseInt16N_mC9897FD17E244A60C51D0A679F479C3FDB1CF97C (void);
// 0x000001AA System.Boolean System.Buffers.Text.Utf8Parser::TryParseInt32N(System.ReadOnlySpan`1<System.Byte>,System.Int32&,System.Int32&)
extern void Utf8Parser_TryParseInt32N_mB3B2357B645EBF15F4EDC2F1439F22820731545E (void);
// 0x000001AB System.Boolean System.Buffers.Text.Utf8Parser::TryParseInt64N(System.ReadOnlySpan`1<System.Byte>,System.Int64&,System.Int32&)
extern void Utf8Parser_TryParseInt64N_m1611AB42B1D6292EBAA21283402E2A8A913683D1 (void);
// 0x000001AC System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.Byte&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_m871E02CF3B4E341654E39CEAD3906176C98F479E (void);
// 0x000001AD System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.UInt16&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_m982791E79287807CB4084CFA9C5616AE2AD3195B (void);
// 0x000001AE System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.UInt32&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_m0E064C38A9620714FA7D710481D8A4FF6B33E8B8 (void);
// 0x000001AF System.Boolean System.Buffers.Text.Utf8Parser::TryParse(System.ReadOnlySpan`1<System.Byte>,System.UInt64&,System.Int32&,System.Char)
extern void Utf8Parser_TryParse_m35EB26BDA5A60061CA5D07F6977CE49C395B8E4E (void);
// 0x000001B0 System.Boolean System.Buffers.Text.Utf8Parser::TryParseByteD(System.ReadOnlySpan`1<System.Byte>,System.Byte&,System.Int32&)
extern void Utf8Parser_TryParseByteD_m376276FCE8C1FA0C657D2DD34E43761B807CC55F (void);
// 0x000001B1 System.Boolean System.Buffers.Text.Utf8Parser::TryParseUInt16D(System.ReadOnlySpan`1<System.Byte>,System.UInt16&,System.Int32&)
extern void Utf8Parser_TryParseUInt16D_m74190A035D81353E29530A4214FDD097DF5E815F (void);
// 0x000001B2 System.Boolean System.Buffers.Text.Utf8Parser::TryParseUInt32D(System.ReadOnlySpan`1<System.Byte>,System.UInt32&,System.Int32&)
extern void Utf8Parser_TryParseUInt32D_m5F723DCD7B0E8614C4BC8DC76816B62AAFED195E (void);
// 0x000001B3 System.Boolean System.Buffers.Text.Utf8Parser::TryParseUInt64D(System.ReadOnlySpan`1<System.Byte>,System.UInt64&,System.Int32&)
extern void Utf8Parser_TryParseUInt64D_mC99A2680DB62D181EA8E3F95897534A6EC1E13D6 (void);
// 0x000001B4 System.Boolean System.Buffers.Text.Utf8Parser::TryParseByteN(System.ReadOnlySpan`1<System.Byte>,System.Byte&,System.Int32&)
extern void Utf8Parser_TryParseByteN_mBDB9BB1D68D98E31FFF2100709F739233E1387E6 (void);
// 0x000001B5 System.Boolean System.Buffers.Text.Utf8Parser::TryParseUInt16N(System.ReadOnlySpan`1<System.Byte>,System.UInt16&,System.Int32&)
extern void Utf8Parser_TryParseUInt16N_m11C73A328EEF91EDFF923F1260353E2484ACA045 (void);
// 0x000001B6 System.Boolean System.Buffers.Text.Utf8Parser::TryParseUInt32N(System.ReadOnlySpan`1<System.Byte>,System.UInt32&,System.Int32&)
extern void Utf8Parser_TryParseUInt32N_mFC1CFB606F749984EA6D59C6F9AC11169001F092 (void);
// 0x000001B7 System.Boolean System.Buffers.Text.Utf8Parser::TryParseUInt64N(System.ReadOnlySpan`1<System.Byte>,System.UInt64&,System.Int32&)
extern void Utf8Parser_TryParseUInt64N_m63810A3876355C4D37E833FB9346C70518943733 (void);
// 0x000001B8 System.Boolean System.Buffers.Text.Utf8Parser::TryParseByteX(System.ReadOnlySpan`1<System.Byte>,System.Byte&,System.Int32&)
extern void Utf8Parser_TryParseByteX_mF0B28DB6A2F5DB17CBE1B931D51E2AEDE441ED99 (void);
// 0x000001B9 System.Boolean System.Buffers.Text.Utf8Parser::TryParseUInt16X(System.ReadOnlySpan`1<System.Byte>,System.UInt16&,System.Int32&)
extern void Utf8Parser_TryParseUInt16X_mD5F4C39EA831AEA324D505F21B6934B6CB0D7501 (void);
// 0x000001BA System.Boolean System.Buffers.Text.Utf8Parser::TryParseUInt32X(System.ReadOnlySpan`1<System.Byte>,System.UInt32&,System.Int32&)
extern void Utf8Parser_TryParseUInt32X_m95FB8E312302F97F801E9A6EE4ACEFB27F4F8DB4 (void);
// 0x000001BB System.Boolean System.Buffers.Text.Utf8Parser::TryParseUInt64X(System.ReadOnlySpan`1<System.Byte>,System.UInt64&,System.Int32&)
extern void Utf8Parser_TryParseUInt64X_mD4A57526AF186501CCC19166EA60395A49ADC507 (void);
// 0x000001BC System.Boolean System.Buffers.Text.Utf8Parser::TryParseNumber(System.ReadOnlySpan`1<System.Byte>,System.NumberBuffer&,System.Int32&,System.Buffers.Text.Utf8Parser/ParseNumberOptions,System.Boolean&)
extern void Utf8Parser_TryParseNumber_m18BE8E49AA5F029B6111509C59D74FFA0F35E38C (void);
// 0x000001BD System.Void System.Buffers.Text.Utf8Parser::.cctor()
extern void Utf8Parser__cctor_m60590923BE3CD9DCD3E31445BC4773C99A9EBF61 (void);
// 0x000001BE System.UInt32 System.Buffers.Binary.BinaryPrimitives::ReverseEndianness(System.UInt32)
extern void BinaryPrimitives_ReverseEndianness_m7C562C76F215F77432B9600686CB25A54E88CC20 (void);
// 0x000001BF System.UInt32 System.Buffers.Binary.BinaryPrimitives::ReadUInt32LittleEndian(System.ReadOnlySpan`1<System.Byte>)
extern void BinaryPrimitives_ReadUInt32LittleEndian_mEE46641BC73CAACA64F2952CD791BE96F5DB44F4 (void);
// 0x000001C0 System.Void System.Buffers.Binary.BinaryPrimitives::WriteUInt32BigEndian(System.Span`1<System.Byte>,System.UInt32)
extern void BinaryPrimitives_WriteUInt32BigEndian_m9EB6A671EA25CC201F502FA157F3B0514364714D (void);
// 0x000001C1 System.Boolean System.Buffers.Binary.BinaryPrimitives::TryWriteUInt32BigEndian(System.Span`1<System.Byte>,System.UInt32)
extern void BinaryPrimitives_TryWriteUInt32BigEndian_mBC99343DFDA11632132FB4E6A8E355478F251310 (void);
static Il2CppMethodPointer s_methodPointers[449] = 
{
	EmbeddedAttribute__ctor_m7D7D024DA2EA05AEDF8B8C470F678A5DA96C8EB8,
	IsReadOnlyAttribute__ctor_m07A8C937D13DE79AF8ED555F18E5AE9FDA6C3879,
	IsByRefLikeAttribute__ctor_m3F813C04C0FAF02B5AF712ED98929300CD6E44DD,
	SequencePosition__ctor_m881E247213B0B28B3903475A1FC0237C56B5F0B0,
	SequencePosition_GetObject_m33D4D02B2042DFCCC2549006639381910F1F3525,
	SequencePosition_GetInteger_mE4D2683EB441F31A3C1474845ABBD0FA78C130DE,
	SequencePosition_Equals_mEA7C1FF9F5C4661547A30C192DC3702CB7647795,
	SequencePosition_Equals_mEA56903889413D851A4F93FC2C96D0A6BA823A58,
	SequencePosition_GetHashCode_m1BEFA85FBA8965A92F4A2408AA491758C0CD7DF2,
	ThrowHelper_ThrowArgumentNullException_m3B4D674B817C817E97F4687F0130007D315F8B34,
	ThrowHelper_CreateArgumentNullException_mA70D942EBA7503962BA72170F026A966513590FC,
	ThrowHelper_ThrowArrayTypeMismatchException_mFC0D7756FD2EA1A7E41D8426D819369FDBD728FC,
	ThrowHelper_CreateArrayTypeMismatchException_m23F27BF82F951A64682A2CF14E0EDE9F3B54C93F,
	ThrowHelper_ThrowArgumentException_InvalidTypeWithPointersNotSupported_m4A71872D4B069AF36758A61E4CA3FB663B4E8EC4,
	ThrowHelper_CreateArgumentException_InvalidTypeWithPointersNotSupported_m4019588ED8511C985604C8CC9AD4AB6414676945,
	ThrowHelper_ThrowArgumentException_DestinationTooShort_mD9C82D6A62948DA443166283990BF760F77C76C8,
	ThrowHelper_CreateArgumentException_DestinationTooShort_m75CF4B3D7F56B0383E0BC84D86C085AA0CE90CD1,
	ThrowHelper_ThrowIndexOutOfRangeException_m4D1EB8558F17DFE372ECF87D9BCAD112A7F5E6BC,
	ThrowHelper_CreateIndexOutOfRangeException_m8C8886676269B09CC5241BA6F5330D78B26F527B,
	ThrowHelper_ThrowArgumentOutOfRangeException_mB72471F11341E214DA380AF2B87C3F28EC51CA59,
	ThrowHelper_CreateArgumentOutOfRangeException_m0841E9BF864372D7BF0512A13456F985C53FC03D,
	ThrowHelper_ThrowArgumentOutOfRangeException_m86EB6B05BDE45B6F92A7599E80E0179C17391AB5,
	ThrowHelper_CreateArgumentOutOfRangeException_m3ED3DA6D593699354BA4D397790440F3BFE84AEA,
	ThrowHelper_ThrowArgumentOutOfRangeException_PrecisionTooLarge_mAC345A1F72DBC919354CCB54CC6C24EF44BE48C1,
	ThrowHelper_CreateArgumentOutOfRangeException_PrecisionTooLarge_mC1889FF89FD22816EB8D105C942166D0BF6ADFAD,
	ThrowHelper_ThrowArgumentOutOfRangeException_SymbolDoesNotFit_m601A3BCC469FE8A7420CC33708307189B6C48B61,
	ThrowHelper_CreateArgumentOutOfRangeException_SymbolDoesNotFit_m903F8FB8357FE1BAB8BF450E0F95A79117EF2D19,
	ThrowHelper_ThrowInvalidOperationException_mC18897E999FE00AE3ACC3543A468201068A217F8,
	ThrowHelper_CreateInvalidOperationException_mAA36D488898B83C836372B8D095EFEC4136121B3,
	ThrowHelper_ThrowInvalidOperationException_EndPositionNotReached_m67B5DCC8C43494E0A491781D118E147337664DB0,
	ThrowHelper_CreateInvalidOperationException_EndPositionNotReached_m35A30B605551B8CACAE6B842C8B525BC7078FE72,
	ThrowHelper_ThrowArgumentOutOfRangeException_PositionOutOfRange_mE66B589C0CE79CD3252C96D133A4DA6BFF64228D,
	ThrowHelper_CreateArgumentOutOfRangeException_PositionOutOfRange_m09B8EF6F30DDB19BF9AD63605556AED12E7DE03A,
	ThrowHelper_ThrowArgumentOutOfRangeException_OffsetOutOfRange_m33BB375A469C5D43F27FAF1E1573659C8D6D46B6,
	ThrowHelper_CreateArgumentOutOfRangeException_OffsetOutOfRange_m4006B68C0940F1864B48E9E2CAE0A62FE91910F9,
	ThrowHelper_ThrowFormatException_BadFormatSpecifier_m1E35DA4BEAAC3A721CFB9CE82029EBABF763EA8D,
	ThrowHelper_CreateFormatException_BadFormatSpecifier_mA1D2DB12AB680960531A3C1A97098925F5154FDB,
	ThrowHelper_TryFormatThrowFormatException_mAE469FD4BD034BFD4FB18C512DAD188188AADFCA,
	NULL,
	NULL,
	NULL,
	ThrowHelper_ThrowArgumentValidationException_m02E99F21139D9C2446BCF31922E6B9A1FB6CBFE9,
	ThrowHelper_CreateArgumentValidationException_mA1BAB2087749EF0A3433426D6B4886903B64C893,
	ThrowHelper_ThrowStartOrEndArgumentValidationException_m0BB9EBD3A2B133B27075024CE04996C5626E7C38,
	ThrowHelper_CreateStartOrEndArgumentValidationException_mC18923AF89FCBE538463BC90C517FA9E4691734C,
	DecimalDecCalc_D32DivMod1E9_mAD8A67341D4FAFC5C7B8166220023AA68003ABBF,
	DecimalDecCalc_DecDivMod1E9_mEBD288904D9655A6FFF62BA3620C6C55FF28B8B6,
	DecimalDecCalc_DecAddInt32_mCA42EB3D01D859FA31D304138E4BEF39FEB549AE,
	DecimalDecCalc_D32AddCarry_m12237332B16193F0B942AEFC955A62400D3F51B9,
	DecimalDecCalc_DecMul10_m937563702D52CBD29F01CC75B62F626BEC117892,
	DecimalDecCalc_DecShiftLeft_m63A7A170CA5CF4A864BAAD95D88C299D5AFB71F3,
	DecimalDecCalc_DecAdd_m52E651ADFE94ACFD0CDDC8C14A50D2830E46E3D5,
	Number_RoundNumber_mEC3B9B63F68460A64F6F6913BB80F3BEBB780F07,
	Number_NumberBufferToDouble_mA943AD6BA0AE626079DBC29F9B659D26D4E1D424,
	Number_NumberBufferToDecimal_m9EC553B819A7A5F0260E71EE5684E7EA7CEE6D42,
	Number_DecimalToNumber_mDB370C6FEDCCE206F35651207AE2E13ABF525408,
	Number_DigitsToInt_mF9D8FE36B186C206448E7489A7AFC2EDEF604BD2,
	Number_Mul32x32To64_mE1E983CFD213FF07619AEDA39C30700B6213EE13,
	Number_Mul64Lossy_m62FA4C0FD0DFB698403843BF67DFED5D0881DD9D,
	Number_abs_m602E755F75A75A2F98CFEB174046DA2213A30DB5,
	Number_NumberToDouble_m8DE02F8F5A4B55ED6EC5995419C9D4AE9BB0802E,
	Number__cctor_m13165024FAE32EB10AAF002D913A479A756870CB,
	DoubleHelper_Exponent_m030E2C0AF265E2CA0ACEA5E4C9E66C1EAB462D5C,
	DoubleHelper_Mantissa_m5275E987A447C0B2F0F10D1E08B0A73DB121A6BE,
	NumberBuffer_get_Digits_m77F55E994E325F745CBEE5598D24263834F34F3B,
	NumberBuffer_get_UnsafeDigits_m95B0D74B60926B0E8788E7E6FDC551E7240F40FE,
	NumberBuffer_get_NumDigits_mC0AF0400D548D41907EA3204965C78A10DB463D5,
	NumberBuffer_ToString_m64B3ED10515B329DDED1167F97E5BE0B297955AD,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	MemoryExtensions_AsSpan_m7527C7806D1DD24C012DC60C12280A9E1AEA8F15,
	MemoryExtensions_AsMemory_mDE1615649DE907A3C22F6BEBBF0C8F80E4652B0D,
	MemoryExtensions_AsMemory_m9F2378B1710076CA61B1FC3E687A06BC6063A9DC,
	MemoryExtensions_MeasureStringAdjustment_m8E2719E3CCAD24803BEF8B9C9873DDFAA528C762,
	MemoryExtensions__cctor_mC634116818572F66DC5A4416FB29AFBFCE859EBE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	SpanHelpers_IndexOf_mAB424C62A4FBD5BA1CF460354CF232B8D7855CE6,
	SpanHelpers_IndexOf_m996881920138B2EC72C814473789D6AB958B92F2,
	SpanHelpers_IndexOfAny_m08EBFBAA90222E41BD0E0BECA675C836CDF8B459,
	SpanHelpers_SequenceEqual_mDEB0F358BB173EA24BEEB0609454A997E9273A89,
	SpanHelpers_LocateFirstFoundByte_m62E17AF3E4C9F8689DB23B9E54311BD8B540B4EF,
	SpanHelpers_LocateFirstFoundByte_m6AEEBF64B95585D577D0041CE56E0BE6F28AEFE4,
	SpanHelpers_GetVector_m02FA6D466B651ECA2610E80030F25D5C54364724,
	SpanHelpers_IndexOf_m0740DDBBE5723E3595EADF2552551F636C18A259,
	SpanHelpers_LocateFirstFoundChar_mC9FF98473ACDD92571AF535184DF5E286E532FAB,
	SpanHelpers_LocateFirstFoundChar_m7B3D3FD47EB5BA8837CE3E8CE2D2BBA7BFC62CE3,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	SpanHelpers_IsReferenceOrContainsReferencesCore_m4046A8EAD00DA02AA423C292A8FCBB08268AD781,
	SpanHelpers_ClearLessThanPointerSized_m257390BAE1A54335F742BD17D85AF6D8FC03C831,
	SpanHelpers_ClearLessThanPointerSized_mDD75E922D42E70B6F76DB1A1EC1A96F59CAFF0B5,
	SpanHelpers_ClearPointerSizedWithoutReferences_mC6EF2B959C4B0E58F8D4B8C9A5EF341F948FFAAA,
	SpanHelpers_ClearPointerSizedWithReferences_m45CDDDFAE259A9678B759645C7AB467860D44BAE,
	SpanHelpers_LessThanEqual_mCFA5E9CC05F428B1EDA65967FEF81267F917E88C,
	NULL,
	NULL,
	NUInt__ctor_m34A1178C5D59B395E905B670FCF390D1AA5DC85E,
	NUInt__ctor_mBD99E19E274774DF07488C672C5DFC90F4B21973,
	NUInt_op_Explicit_m680513883587956D1452B1EB6D321D4C3A0C8366,
	NUInt_op_Explicit_mAC8186F05FC1F16BAEB9A73957491CB24A067D46,
	NUInt_op_Multiply_mABFB3E10A51F74FDC0CD9B799B7BF35C2C5D8D85,
	MutableDecimal_get_IsNegative_m6CC9630C1FE5DAABD29CEE9EF5281C37D12CE702,
	MutableDecimal_set_IsNegative_mF373061A5BA3F192A2AA544BCB933C81BF71AC67,
	MutableDecimal_get_Scale_mD47D52938E7026D2EC3AA837BABF7162C4F727A3,
	MutableDecimal_set_Scale_m9253E0BBFF59D428FF76EA0A530D644053C3075C,
	SR_get_ResourceManager_m18A791F4D611559D5B214B3020BAB11F2AC869EC,
	SR_UsingResourceKeys_m08DBDDDDF80E9F0013615CAB611F552F836BB526,
	SR_GetResourceString_mEC79B3C28B26B1540E26C3CD899938CC955A4748,
	SR_Format_m4480ECD777F2A905A368094827DDCB43478A8053,
	SR_get_ResourceType_mA677195FD1721150495B84739EFFDCB9366A5541,
	SR_get_NotSupported_CannotCallEqualsOnSpan_mACE24A88A0ADF9880C315FDC0963BA17E66B0394,
	SR_get_NotSupported_CannotCallGetHashCodeOnSpan_m4BC3D1B6994913E69BDD4028026F18A279A9DBDB,
	SR_get_Argument_InvalidTypeWithPointersNotSupported_m2FD2DCBFF1853C8F9616D4C55DD1C14163A06B75,
	SR_get_Argument_DestinationTooShort_mDD536A55FFA1BD1CF5C34D9E074420C183905559,
	SR_get_Argument_BadFormatSpecifier_mFE81E4F926274AB402B890E679E6CAB600E61433,
	SR_get_Argument_GWithPrecisionNotSupported_mF77D1EF96FE22465E62C65C5895E968E7FB10019,
	SR_get_Argument_PrecisionTooLarge_m42EED38BF28506133A0AB30447E3C35CCA120A7F,
	SR_get_EndPositionNotReached_m26E126334F58B1570EEAAA53A48B9518F3C17913,
	SR__cctor_m4CA77DF9E538A3B432DD3F12C4D3E655983629DB,
	HashHelpers_Combine_m0B422F3A90AC3CD046375C8195F8ED339B83ED46,
	HashHelpers__cctor_mE4D846284DBD325D39520B0D94CE6D08B7A937E2,
	SequenceMarshal_TryGetString_mBA81A10F83642193C6BB3862B3E847222BE88F7B,
	NULL,
	NULL,
	MemoryMarshal_TryGetString_mF59A4FBC01B0F61BFCAD2BA3960B9670FADB0C09,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ReadOnlySequence_SegmentToSequenceStart_mEE6CF5E985234E355289D641D4E49D4BAA9E3083,
	ReadOnlySequence_SegmentToSequenceEnd_mFFDFAE7585A75266241B8973C55046431260BBDE,
	ReadOnlySequence_ArrayToSequenceStart_mCEAF0855FE164270628814C10B531646278E0855,
	ReadOnlySequence_ArrayToSequenceEnd_mFF69FF0508B383A32C7EF9F89E701787D112BAB6,
	ReadOnlySequence_MemoryManagerToSequenceStart_mFD1015C3FF75727F14979508EE405C50AA456138,
	ReadOnlySequence_MemoryManagerToSequenceEnd_m85705DE4E192CFB7B915CFDFE2DC5C47870E895D,
	ReadOnlySequence_StringToSequenceStart_mBB3640B275AF4DFA2FDBEA7CFAE5D539FB4D6B6A,
	ReadOnlySequence_StringToSequenceEnd_m969959A7F05E83C60ECC577C1EACF3C2ECA6DE91,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	StandardFormat_get_Symbol_mF8A6168808E4EEB455E2F8695DD243231285B0F2,
	StandardFormat_get_Precision_m0080A4421E19B1702147DF794C3D4C2D1035C5B6,
	StandardFormat_get_HasPrecision_m512C556F8EABC1880A4057A0255D42C5008F322E,
	StandardFormat_get_IsDefault_mA235EA7D61B74384AF56AEC5174D2ACD568AE144,
	StandardFormat__ctor_mEDC33761CDF50C5F7D01BF0DD6D673658931D43F,
	StandardFormat_op_Implicit_mC7AEDB177670024F660C1AA4BA07616FB27B29BD,
	StandardFormat_Equals_mB63E4B0879F9B74C0783E32117A22592050C887A,
	StandardFormat_GetHashCode_mA2398AB63B3856075F7E8F9A26D142878DDAB119,
	StandardFormat_Equals_m6AAD6931E6B7620BC5676B60FDE95DEBDCC6A011,
	StandardFormat_ToString_m1391A69E60EF500E59D59A29124BAD2C1D28CE6D,
	NULL,
	MemoryHandle__ctor_mD254CBC13788969FCC315DF2B1C8615A945F18B3,
	MemoryHandle_Dispose_mE19418148935D11619DD13966114889837089E9A,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Base64_DecodeFromUtf8_m42C42D1F4690C787AD2060F743AF9016346B9AD2,
	Base64_GetMaxDecodedFromUtf8Length_m006256FEA6BF678C4F127180F8B1332F064F502F,
	Base64_DecodeFromUtf8InPlace_mEBB97003AC863B73FCFAF272CED3A805F3F4309E,
	Base64_Decode_m9255647C748D2E5A658B306FF1CB018A3518E3EB,
	Base64_WriteThreeLowOrderBytes_mEA9D70EF786F6B007B97DC740E9B2D6335A257D2,
	Base64_EncodeToUtf8_m577D7216DE2808F843877387142BEFC4E23EC796,
	Base64_GetMaxEncodedToUtf8Length_mCE09C90A3306E4E5812A354474AD5CBF972971A9,
	Base64_Encode_mF7004599E680812FB2DC7744AD0EE802A17B449A,
	Base64_EncodeAndPadOne_m2240A53CE28BE8A0A955A7E467B0E7E9A8A0DD7C,
	Base64_EncodeAndPadTwo_mCC772FF69A3BEFE27CB02697DD37F08417EC1EA2,
	Base64__cctor_m3B098734F3F8EF762B0E391849C528627DA77BED,
	Utf8Constants__cctor_m312B1DFF8FBB89F5601299D0146E152F40AA82EC,
	FormattingHelpers_GetSymbolOrDefault_m26DC14293CBF28446BFD5991B0BC6D55D199281E,
	FormattingHelpers_FillWithAsciiZeros_m3A29E363C6C25E65720EA654150D6199298C3A5E,
	FormattingHelpers_WriteHexByte_m74A433852D66F62FF7174EF4F40B0E0EC1E7088B,
	FormattingHelpers_WriteDigits_mB84E216D8FDAAEE250F7E833F1886CF7352CD243,
	FormattingHelpers_WriteDigitsWithGroupSeparator_m47961A365046CD674E315B8366DCC3A6C563F1F9,
	FormattingHelpers_WriteDigits_mB294245C1C40A39A6FADC68FD44FDE93489329DE,
	FormattingHelpers_WriteFourDecimalDigits_m2C9CE9DD697E21513F53A059A6E8A67411C49300,
	FormattingHelpers_WriteTwoDecimalDigits_mBA9DF0C24B6CB962499015EC49E99779A540C95E,
	FormattingHelpers_CountDigits_m675BA657779A2850D4C7B0DE8FFF5D53DCF95144,
	FormattingHelpers_CountDigits_mA676272B50F0CE205CC72EA4455298AE722FE53E,
	FormattingHelpers_CountHexDigits_mC892DDD16C175A09E028D0CAC2F1FD4EBEFFE3BE,
	Utf8Formatter_TryFormat_m801A1D1F29220D08560601466D8F88608FB9FB28,
	Utf8Formatter_TryFormat_mB5A5D29E1AB53EF943A7517ED41865FFD6D49E40,
	Utf8Formatter_TryFormat_m2ABA3915E51ED1976E85ABA15699790E0D5DB675,
	Utf8Formatter_TryFormatDateTimeG_m73A2E1DA59D9006A5809628F5516C74FDAAAB354,
	Utf8Formatter_TryFormatDateTimeO_mBA169648C706917AA22CB978323C578DB48DEE28,
	Utf8Formatter_TryFormatDateTimeR_m6F450413D5D0670CDEF033B957C41352450AEFCB,
	Utf8Formatter_TryFormatDateTimeL_m34A3FE15768F3A1B0C1CC2A746B46D40922E856A,
	Utf8Formatter_TryFormat_m6791AE969A684DF1A5141E89B2748A0491B16DA1,
	Utf8Formatter_TryFormatDecimalE_m5EE850421F5ECD53EB303F5E20F42E989BC7B679,
	Utf8Formatter_TryFormatDecimalF_mB3F592FC02FDB10D2F065AAC4993754DCE801384,
	Utf8Formatter_TryFormatDecimalG_m9209EBD3DB9F8ADBD39C4F69246BF2D2B7E2B86B,
	Utf8Formatter_TryFormat_mAF103F9E49F131C60F65F3ECF97732AA828E141A,
	Utf8Formatter_TryFormat_m9511892FD3132F76B90E0089072BDF8F11884BC4,
	Utf8Formatter_TryFormat_mF00E41768123B7B47C2427C6327C2045B074BE0A,
	Utf8Formatter_TryFormat_m3DAF77915AA8455CAFC49F4457FE35B2EC00DF3E,
	Utf8Formatter_TryFormatInt64_m61A954CEB254D25C2F681CF707F80AD856F73750,
	Utf8Formatter_TryFormatInt64D_mB8F5C4DDAA08332F924D62C0B426C1D414C4ABCA,
	Utf8Formatter_TryFormatInt64Default_mF4B334DF6319D35C0B33A6572F7FF0EA3CE7C2A8,
	Utf8Formatter_TryFormatInt32MultipleDigits_m006E2F6B25667EE3B58402D5101CE6BCA787A391,
	Utf8Formatter_TryFormatInt64MultipleDigits_mB1689643467ACA69DA8BBE4FE8C9272C127D4FBB,
	Utf8Formatter_TryFormatInt64MoreThanNegativeBillionMaxUInt_m66C6074F21CCD770F792503E660A59CCE7B0E5F7,
	Utf8Formatter_TryFormatInt64LessThanNegativeBillionMaxUInt_m8B5E903509AF6881879B14886D005900E04B295C,
	Utf8Formatter_TryFormatInt64N_m78109B8A854CD414F3883A4F54F2828D65E03A9E,
	Utf8Formatter_TryFormatUInt64_m903D18A13B3D28E3301BE4AA8CF22DA85694EB3A,
	Utf8Formatter_TryFormatUInt64D_m9CC93A27892C98CDC584E3A9A211BE4BCD9C47BC,
	Utf8Formatter_TryFormatUInt64Default_mC66DA768AC3B8933EA96384412E1D8CFB51D64F2,
	Utf8Formatter_TryFormatUInt32SingleDigit_m640F93E5FC560A68BD27039E9C864C9C5D582335,
	Utf8Formatter_TryFormatUInt32MultipleDigits_m8EE0BA7509C7951049017B0E1C3BB6E911CD7863,
	Utf8Formatter_TryFormatUInt64MultipleDigits_mF63FC4B51EE923E000733252A9E705D25531919B,
	Utf8Formatter_TryFormatUInt64LessThanBillionMaxUInt_mD0B30477DD0CE3DDAE2E87395EA417EE44806626,
	Utf8Formatter_TryFormatUInt64MoreThanBillionMaxUInt_m906E75BFEC07873FC07898B6F41592B5F0F439A8,
	Utf8Formatter_TryFormatUInt64N_mCF9B963233A1FD9750B0EA2F8CF833980C18826D,
	Utf8Formatter_TryFormatUInt64X_m873913C215B45BE56870D7EFEFF57F558F1B79F1,
	Utf8Formatter__cctor_mB078801DA1AF49D670C5D6813AFECBF5C0691DCD,
	ParserHelpers_IsDigit_m741C974EC477EA1F49439BA55D1C3142EA1D784D,
	ParserHelpers__cctor_m98371EB2AB06474B2928A3F9F4B8A598E17CEAB1,
	Utf8Parser_TryParse_m7D7E4C95A96C051D3AC51B7CA3294481DA5C3A35,
	Utf8Parser_TryParse_m90A0F8BFE5C3044C00DB5155FF340B6AF68E74FE,
	Utf8Parser_TryParse_m83ECFE8C76A9905B80E887F9414D41A319C2AA00,
	Utf8Parser_TryParse_m24053FD013B5A4736E222DF29C9F6A79B13F21FE,
	Utf8Parser_TryParseNormalAsFloatingPoint_m9B7C74F1C7BEA1EA70A86E8E98E7BE7A33366DAB,
	NULL,
	Utf8Parser_TryParse_mAFC6FFA0BF8733D2C6156C4F7F9DDDE77528983C,
	Utf8Parser_TryParseGuidN_mF063301B3928C30520E3DA9EBB8CD0AAEE3F921F,
	Utf8Parser_TryParseGuidCore_m3B32BF426D81A189B437FC286C7EB49989A35463,
	Utf8Parser_TryParse_mEC708A21A90BD9288ABBD948316F13851423ABCB,
	Utf8Parser_TryParse_mBCAC213B7DBE37664B717A7BBB3165E32478AAA0,
	Utf8Parser_TryParse_mAF1471EBA73DEBEF88625109A459CD0D0B7EDCE6,
	Utf8Parser_TryParse_m960CA85130DF531A15E65CDC72A0EB0D9CE89333,
	Utf8Parser_TryParseSByteD_mBDA10E37645BABA381ADB839C659F7E2D67919AE,
	Utf8Parser_TryParseInt16D_mBF1EEA65F0A3022F85C509138EDE17C2C9544A5D,
	Utf8Parser_TryParseInt32D_mFD173F33096EB860929AAB5FD430804EEE5CEAB0,
	Utf8Parser_TryParseInt64D_m88F7248F8771F6896EE62D8C9DC13FA432B8C578,
	Utf8Parser_TryParseSByteN_m5B96DC92A5BCDF5E4F3AAC786C1635305F49860A,
	Utf8Parser_TryParseInt16N_mC9897FD17E244A60C51D0A679F479C3FDB1CF97C,
	Utf8Parser_TryParseInt32N_mB3B2357B645EBF15F4EDC2F1439F22820731545E,
	Utf8Parser_TryParseInt64N_m1611AB42B1D6292EBAA21283402E2A8A913683D1,
	Utf8Parser_TryParse_m871E02CF3B4E341654E39CEAD3906176C98F479E,
	Utf8Parser_TryParse_m982791E79287807CB4084CFA9C5616AE2AD3195B,
	Utf8Parser_TryParse_m0E064C38A9620714FA7D710481D8A4FF6B33E8B8,
	Utf8Parser_TryParse_m35EB26BDA5A60061CA5D07F6977CE49C395B8E4E,
	Utf8Parser_TryParseByteD_m376276FCE8C1FA0C657D2DD34E43761B807CC55F,
	Utf8Parser_TryParseUInt16D_m74190A035D81353E29530A4214FDD097DF5E815F,
	Utf8Parser_TryParseUInt32D_m5F723DCD7B0E8614C4BC8DC76816B62AAFED195E,
	Utf8Parser_TryParseUInt64D_mC99A2680DB62D181EA8E3F95897534A6EC1E13D6,
	Utf8Parser_TryParseByteN_mBDB9BB1D68D98E31FFF2100709F739233E1387E6,
	Utf8Parser_TryParseUInt16N_m11C73A328EEF91EDFF923F1260353E2484ACA045,
	Utf8Parser_TryParseUInt32N_mFC1CFB606F749984EA6D59C6F9AC11169001F092,
	Utf8Parser_TryParseUInt64N_m63810A3876355C4D37E833FB9346C70518943733,
	Utf8Parser_TryParseByteX_mF0B28DB6A2F5DB17CBE1B931D51E2AEDE441ED99,
	Utf8Parser_TryParseUInt16X_mD5F4C39EA831AEA324D505F21B6934B6CB0D7501,
	Utf8Parser_TryParseUInt32X_m95FB8E312302F97F801E9A6EE4ACEFB27F4F8DB4,
	Utf8Parser_TryParseUInt64X_mD4A57526AF186501CCC19166EA60395A49ADC507,
	Utf8Parser_TryParseNumber_m18BE8E49AA5F029B6111509C59D74FFA0F35E38C,
	Utf8Parser__cctor_m60590923BE3CD9DCD3E31445BC4773C99A9EBF61,
	BinaryPrimitives_ReverseEndianness_m7C562C76F215F77432B9600686CB25A54E88CC20,
	BinaryPrimitives_ReadUInt32LittleEndian_mEE46641BC73CAACA64F2952CD791BE96F5DB44F4,
	BinaryPrimitives_WriteUInt32BigEndian_m9EB6A671EA25CC201F502FA157F3B0514364714D,
	BinaryPrimitives_TryWriteUInt32BigEndian_mBC99343DFDA11632132FB4E6A8E355478F251310,
};
extern void SequencePosition__ctor_m881E247213B0B28B3903475A1FC0237C56B5F0B0_AdjustorThunk (void);
extern void SequencePosition_GetObject_m33D4D02B2042DFCCC2549006639381910F1F3525_AdjustorThunk (void);
extern void SequencePosition_GetInteger_mE4D2683EB441F31A3C1474845ABBD0FA78C130DE_AdjustorThunk (void);
extern void SequencePosition_Equals_mEA7C1FF9F5C4661547A30C192DC3702CB7647795_AdjustorThunk (void);
extern void SequencePosition_Equals_mEA56903889413D851A4F93FC2C96D0A6BA823A58_AdjustorThunk (void);
extern void SequencePosition_GetHashCode_m1BEFA85FBA8965A92F4A2408AA491758C0CD7DF2_AdjustorThunk (void);
extern void NumberBuffer_get_Digits_m77F55E994E325F745CBEE5598D24263834F34F3B_AdjustorThunk (void);
extern void NumberBuffer_get_UnsafeDigits_m95B0D74B60926B0E8788E7E6FDC551E7240F40FE_AdjustorThunk (void);
extern void NumberBuffer_get_NumDigits_mC0AF0400D548D41907EA3204965C78A10DB463D5_AdjustorThunk (void);
extern void NumberBuffer_ToString_m64B3ED10515B329DDED1167F97E5BE0B297955AD_AdjustorThunk (void);
extern void NUInt__ctor_m34A1178C5D59B395E905B670FCF390D1AA5DC85E_AdjustorThunk (void);
extern void NUInt__ctor_mBD99E19E274774DF07488C672C5DFC90F4B21973_AdjustorThunk (void);
extern void MutableDecimal_get_IsNegative_m6CC9630C1FE5DAABD29CEE9EF5281C37D12CE702_AdjustorThunk (void);
extern void MutableDecimal_set_IsNegative_mF373061A5BA3F192A2AA544BCB933C81BF71AC67_AdjustorThunk (void);
extern void MutableDecimal_get_Scale_mD47D52938E7026D2EC3AA837BABF7162C4F727A3_AdjustorThunk (void);
extern void MutableDecimal_set_Scale_m9253E0BBFF59D428FF76EA0A530D644053C3075C_AdjustorThunk (void);
extern void StandardFormat_get_Symbol_mF8A6168808E4EEB455E2F8695DD243231285B0F2_AdjustorThunk (void);
extern void StandardFormat_get_Precision_m0080A4421E19B1702147DF794C3D4C2D1035C5B6_AdjustorThunk (void);
extern void StandardFormat_get_HasPrecision_m512C556F8EABC1880A4057A0255D42C5008F322E_AdjustorThunk (void);
extern void StandardFormat_get_IsDefault_mA235EA7D61B74384AF56AEC5174D2ACD568AE144_AdjustorThunk (void);
extern void StandardFormat__ctor_mEDC33761CDF50C5F7D01BF0DD6D673658931D43F_AdjustorThunk (void);
extern void StandardFormat_Equals_mB63E4B0879F9B74C0783E32117A22592050C887A_AdjustorThunk (void);
extern void StandardFormat_GetHashCode_mA2398AB63B3856075F7E8F9A26D142878DDAB119_AdjustorThunk (void);
extern void StandardFormat_Equals_m6AAD6931E6B7620BC5676B60FDE95DEBDCC6A011_AdjustorThunk (void);
extern void StandardFormat_ToString_m1391A69E60EF500E59D59A29124BAD2C1D28CE6D_AdjustorThunk (void);
extern void MemoryHandle__ctor_mD254CBC13788969FCC315DF2B1C8615A945F18B3_AdjustorThunk (void);
extern void MemoryHandle_Dispose_mE19418148935D11619DD13966114889837089E9A_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[27] = 
{
	{ 0x06000004, SequencePosition__ctor_m881E247213B0B28B3903475A1FC0237C56B5F0B0_AdjustorThunk },
	{ 0x06000005, SequencePosition_GetObject_m33D4D02B2042DFCCC2549006639381910F1F3525_AdjustorThunk },
	{ 0x06000006, SequencePosition_GetInteger_mE4D2683EB441F31A3C1474845ABBD0FA78C130DE_AdjustorThunk },
	{ 0x06000007, SequencePosition_Equals_mEA7C1FF9F5C4661547A30C192DC3702CB7647795_AdjustorThunk },
	{ 0x06000008, SequencePosition_Equals_mEA56903889413D851A4F93FC2C96D0A6BA823A58_AdjustorThunk },
	{ 0x06000009, SequencePosition_GetHashCode_m1BEFA85FBA8965A92F4A2408AA491758C0CD7DF2_AdjustorThunk },
	{ 0x06000041, NumberBuffer_get_Digits_m77F55E994E325F745CBEE5598D24263834F34F3B_AdjustorThunk },
	{ 0x06000042, NumberBuffer_get_UnsafeDigits_m95B0D74B60926B0E8788E7E6FDC551E7240F40FE_AdjustorThunk },
	{ 0x06000043, NumberBuffer_get_NumDigits_mC0AF0400D548D41907EA3204965C78A10DB463D5_AdjustorThunk },
	{ 0x06000044, NumberBuffer_ToString_m64B3ED10515B329DDED1167F97E5BE0B297955AD_AdjustorThunk },
	{ 0x060000E1, NUInt__ctor_m34A1178C5D59B395E905B670FCF390D1AA5DC85E_AdjustorThunk },
	{ 0x060000E2, NUInt__ctor_mBD99E19E274774DF07488C672C5DFC90F4B21973_AdjustorThunk },
	{ 0x060000E6, MutableDecimal_get_IsNegative_m6CC9630C1FE5DAABD29CEE9EF5281C37D12CE702_AdjustorThunk },
	{ 0x060000E7, MutableDecimal_set_IsNegative_mF373061A5BA3F192A2AA544BCB933C81BF71AC67_AdjustorThunk },
	{ 0x060000E8, MutableDecimal_get_Scale_mD47D52938E7026D2EC3AA837BABF7162C4F727A3_AdjustorThunk },
	{ 0x060000E9, MutableDecimal_set_Scale_m9253E0BBFF59D428FF76EA0A530D644053C3075C_AdjustorThunk },
	{ 0x06000148, StandardFormat_get_Symbol_mF8A6168808E4EEB455E2F8695DD243231285B0F2_AdjustorThunk },
	{ 0x06000149, StandardFormat_get_Precision_m0080A4421E19B1702147DF794C3D4C2D1035C5B6_AdjustorThunk },
	{ 0x0600014A, StandardFormat_get_HasPrecision_m512C556F8EABC1880A4057A0255D42C5008F322E_AdjustorThunk },
	{ 0x0600014B, StandardFormat_get_IsDefault_mA235EA7D61B74384AF56AEC5174D2ACD568AE144_AdjustorThunk },
	{ 0x0600014C, StandardFormat__ctor_mEDC33761CDF50C5F7D01BF0DD6D673658931D43F_AdjustorThunk },
	{ 0x0600014E, StandardFormat_Equals_mB63E4B0879F9B74C0783E32117A22592050C887A_AdjustorThunk },
	{ 0x0600014F, StandardFormat_GetHashCode_mA2398AB63B3856075F7E8F9A26D142878DDAB119_AdjustorThunk },
	{ 0x06000150, StandardFormat_Equals_m6AAD6931E6B7620BC5676B60FDE95DEBDCC6A011_AdjustorThunk },
	{ 0x06000151, StandardFormat_ToString_m1391A69E60EF500E59D59A29124BAD2C1D28CE6D_AdjustorThunk },
	{ 0x06000153, MemoryHandle__ctor_mD254CBC13788969FCC315DF2B1C8615A945F18B3_AdjustorThunk },
	{ 0x06000154, MemoryHandle_Dispose_mE19418148935D11619DD13966114889837089E9A_AdjustorThunk },
};
static const int32_t s_InvokerIndices[449] = 
{
	1782,
	1782,
	1782,
	976,
	1745,
	1727,
	1382,
	1362,
	1727,
	2871,
	2806,
	2941,
	2929,
	2874,
	2809,
	2941,
	2929,
	2941,
	2929,
	2941,
	2929,
	2871,
	2806,
	2941,
	2929,
	2941,
	2929,
	2941,
	2929,
	2941,
	2929,
	2941,
	2929,
	2941,
	2929,
	2941,
	2929,
	2824,
	-1,
	-1,
	-1,
	2626,
	2462,
	2872,
	2807,
	2413,
	2758,
	2600,
	2516,
	2867,
	2867,
	2603,
	2600,
	2512,
	2512,
	2609,
	2397,
	2425,
	2191,
	2762,
	2729,
	2941,
	2760,
	2772,
	1693,
	1704,
	1727,
	1745,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	2671,
	2660,
	2151,
	2926,
	2941,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	1981,
	2173,
	1891,
	2247,
	2756,
	2763,
	2700,
	2169,
	2757,
	2763,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	2831,
	2602,
	2602,
	2602,
	2602,
	2539,
	-1,
	-1,
	1516,
	1517,
	2790,
	2715,
	2444,
	1768,
	1550,
	1727,
	1516,
	2929,
	2935,
	2466,
	2466,
	2929,
	2929,
	2929,
	2929,
	2929,
	2929,
	2929,
	2929,
	2929,
	2941,
	2414,
	2941,
	2063,
	-1,
	-1,
	2061,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	2762,
	2762,
	2762,
	2762,
	2762,
	2762,
	2762,
	2762,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	1726,
	1768,
	1768,
	1768,
	857,
	2847,
	1362,
	1727,
	1386,
	1745,
	1782,
	530,
	1782,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	1887,
	2762,
	2405,
	2408,
	2600,
	1887,
	2762,
	2408,
	2408,
	2408,
	2941,
	2941,
	2390,
	2865,
	2139,
	2619,
	2619,
	2612,
	2313,
	2313,
	2763,
	2762,
	2763,
	2099,
	2076,
	2073,
	2075,
	2075,
	2254,
	2254,
	2077,
	1932,
	2065,
	2244,
	2078,
	2099,
	2082,
	2082,
	1936,
	2083,
	2260,
	2258,
	2260,
	2260,
	2260,
	2083,
	2082,
	1937,
	2260,
	2258,
	2258,
	2260,
	2260,
	2260,
	1937,
	1938,
	2941,
	2828,
	2941,
	2064,
	2064,
	2064,
	2064,
	2064,
	-1,
	2064,
	2240,
	1861,
	2064,
	2064,
	2064,
	2064,
	2240,
	2240,
	2240,
	2240,
	2240,
	2240,
	2240,
	2240,
	2064,
	2064,
	2064,
	2064,
	2240,
	2240,
	2240,
	2240,
	2240,
	2240,
	2240,
	2240,
	2240,
	2240,
	2240,
	2240,
	1931,
	2941,
	2762,
	2754,
	2594,
	2500,
};
static const Il2CppTokenRangePair s_rgctxIndices[50] = 
{
	{ 0x0200000D, { 4, 36 } },
	{ 0x0200000E, { 40, 3 } },
	{ 0x02000010, { 117, 36 } },
	{ 0x02000011, { 153, 30 } },
	{ 0x02000013, { 183, 34 } },
	{ 0x02000015, { 217, 2 } },
	{ 0x0200001A, { 241, 6 } },
	{ 0x02000025, { 327, 50 } },
	{ 0x02000026, { 377, 2 } },
	{ 0x02000029, { 379, 6 } },
	{ 0x0200002F, { 385, 5 } },
	{ 0x06000028, { 0, 1 } },
	{ 0x06000029, { 1, 3 } },
	{ 0x06000061, { 43, 6 } },
	{ 0x06000062, { 49, 8 } },
	{ 0x06000063, { 57, 6 } },
	{ 0x06000064, { 63, 5 } },
	{ 0x06000065, { 68, 5 } },
	{ 0x06000066, { 73, 6 } },
	{ 0x06000067, { 79, 8 } },
	{ 0x06000068, { 87, 6 } },
	{ 0x06000069, { 93, 2 } },
	{ 0x0600006A, { 95, 2 } },
	{ 0x0600006B, { 97, 5 } },
	{ 0x0600006C, { 102, 2 } },
	{ 0x0600006D, { 104, 2 } },
	{ 0x0600006E, { 106, 5 } },
	{ 0x0600006F, { 111, 3 } },
	{ 0x06000070, { 114, 1 } },
	{ 0x06000071, { 115, 2 } },
	{ 0x060000D2, { 219, 3 } },
	{ 0x060000D3, { 222, 4 } },
	{ 0x060000D4, { 226, 4 } },
	{ 0x060000D5, { 230, 5 } },
	{ 0x060000D6, { 235, 4 } },
	{ 0x060000D7, { 239, 1 } },
	{ 0x060000D8, { 240, 1 } },
	{ 0x060000FB, { 247, 10 } },
	{ 0x060000FC, { 257, 2 } },
	{ 0x060000FE, { 259, 4 } },
	{ 0x060000FF, { 263, 4 } },
	{ 0x06000100, { 267, 4 } },
	{ 0x06000101, { 271, 6 } },
	{ 0x06000102, { 277, 4 } },
	{ 0x06000103, { 281, 4 } },
	{ 0x06000104, { 285, 12 } },
	{ 0x06000105, { 297, 12 } },
	{ 0x06000106, { 309, 7 } },
	{ 0x06000107, { 316, 6 } },
	{ 0x06000108, { 322, 5 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[390] = 
{
	{ (Il2CppRGCTXDataType)3, 12362 },
	{ (Il2CppRGCTXDataType)3, 9160 },
	{ (Il2CppRGCTXDataType)3, 9159 },
	{ (Il2CppRGCTXDataType)3, 9072 },
	{ (Il2CppRGCTXDataType)2, 384 },
	{ (Il2CppRGCTXDataType)1, 2792 },
	{ (Il2CppRGCTXDataType)2, 1980 },
	{ (Il2CppRGCTXDataType)3, 8139 },
	{ (Il2CppRGCTXDataType)3, 500 },
	{ (Il2CppRGCTXDataType)3, 502 },
	{ (Il2CppRGCTXDataType)3, 501 },
	{ (Il2CppRGCTXDataType)3, 8140 },
	{ (Il2CppRGCTXDataType)3, 12480 },
	{ (Il2CppRGCTXDataType)1, 384 },
	{ (Il2CppRGCTXDataType)3, 8145 },
	{ (Il2CppRGCTXDataType)2, 2207 },
	{ (Il2CppRGCTXDataType)3, 8141 },
	{ (Il2CppRGCTXDataType)2, 1970 },
	{ (Il2CppRGCTXDataType)3, 8115 },
	{ (Il2CppRGCTXDataType)3, 9553 },
	{ (Il2CppRGCTXDataType)3, 12446 },
	{ (Il2CppRGCTXDataType)3, 9550 },
	{ (Il2CppRGCTXDataType)2, 2792 },
	{ (Il2CppRGCTXDataType)3, 9551 },
	{ (Il2CppRGCTXDataType)3, 9552 },
	{ (Il2CppRGCTXDataType)3, 9555 },
	{ (Il2CppRGCTXDataType)3, 8116 },
	{ (Il2CppRGCTXDataType)3, 12411 },
	{ (Il2CppRGCTXDataType)3, 9556 },
	{ (Il2CppRGCTXDataType)2, 2207 },
	{ (Il2CppRGCTXDataType)3, 12095 },
	{ (Il2CppRGCTXDataType)3, 12523 },
	{ (Il2CppRGCTXDataType)3, 9554 },
	{ (Il2CppRGCTXDataType)2, 2118 },
	{ (Il2CppRGCTXDataType)3, 8146 },
	{ (Il2CppRGCTXDataType)2, 1980 },
	{ (Il2CppRGCTXDataType)3, 9075 },
	{ (Il2CppRGCTXDataType)3, 8144 },
	{ (Il2CppRGCTXDataType)3, 8143 },
	{ (Il2CppRGCTXDataType)3, 8142 },
	{ (Il2CppRGCTXDataType)3, 8137 },
	{ (Il2CppRGCTXDataType)2, 1978 },
	{ (Il2CppRGCTXDataType)3, 9074 },
	{ (Il2CppRGCTXDataType)1, 166 },
	{ (Il2CppRGCTXDataType)3, 12093 },
	{ (Il2CppRGCTXDataType)3, 12464 },
	{ (Il2CppRGCTXDataType)3, 9537 },
	{ (Il2CppRGCTXDataType)3, 12465 },
	{ (Il2CppRGCTXDataType)3, 12311 },
	{ (Il2CppRGCTXDataType)3, 9535 },
	{ (Il2CppRGCTXDataType)2, 161 },
	{ (Il2CppRGCTXDataType)3, 12067 },
	{ (Il2CppRGCTXDataType)3, 9332 },
	{ (Il2CppRGCTXDataType)3, 12087 },
	{ (Il2CppRGCTXDataType)3, 12458 },
	{ (Il2CppRGCTXDataType)3, 12086 },
	{ (Il2CppRGCTXDataType)3, 12342 },
	{ (Il2CppRGCTXDataType)1, 165 },
	{ (Il2CppRGCTXDataType)3, 12092 },
	{ (Il2CppRGCTXDataType)3, 12462 },
	{ (Il2CppRGCTXDataType)3, 9336 },
	{ (Il2CppRGCTXDataType)3, 12463 },
	{ (Il2CppRGCTXDataType)3, 12310 },
	{ (Il2CppRGCTXDataType)1, 164 },
	{ (Il2CppRGCTXDataType)3, 12091 },
	{ (Il2CppRGCTXDataType)3, 12461 },
	{ (Il2CppRGCTXDataType)3, 9335 },
	{ (Il2CppRGCTXDataType)3, 12316 },
	{ (Il2CppRGCTXDataType)1, 167 },
	{ (Il2CppRGCTXDataType)3, 12094 },
	{ (Il2CppRGCTXDataType)3, 12466 },
	{ (Il2CppRGCTXDataType)3, 9337 },
	{ (Il2CppRGCTXDataType)3, 12320 },
	{ (Il2CppRGCTXDataType)3, 9331 },
	{ (Il2CppRGCTXDataType)2, 160 },
	{ (Il2CppRGCTXDataType)3, 12066 },
	{ (Il2CppRGCTXDataType)3, 12085 },
	{ (Il2CppRGCTXDataType)3, 12457 },
	{ (Il2CppRGCTXDataType)3, 12341 },
	{ (Il2CppRGCTXDataType)3, 9334 },
	{ (Il2CppRGCTXDataType)2, 163 },
	{ (Il2CppRGCTXDataType)3, 12069 },
	{ (Il2CppRGCTXDataType)3, 9536 },
	{ (Il2CppRGCTXDataType)3, 12090 },
	{ (Il2CppRGCTXDataType)3, 12460 },
	{ (Il2CppRGCTXDataType)3, 12089 },
	{ (Il2CppRGCTXDataType)3, 12344 },
	{ (Il2CppRGCTXDataType)3, 9333 },
	{ (Il2CppRGCTXDataType)2, 162 },
	{ (Il2CppRGCTXDataType)3, 12068 },
	{ (Il2CppRGCTXDataType)3, 12088 },
	{ (Il2CppRGCTXDataType)3, 12459 },
	{ (Il2CppRGCTXDataType)3, 12343 },
	{ (Il2CppRGCTXDataType)2, 2199 },
	{ (Il2CppRGCTXDataType)3, 9539 },
	{ (Il2CppRGCTXDataType)2, 2201 },
	{ (Il2CppRGCTXDataType)3, 9541 },
	{ (Il2CppRGCTXDataType)3, 492 },
	{ (Il2CppRGCTXDataType)3, 494 },
	{ (Il2CppRGCTXDataType)3, 493 },
	{ (Il2CppRGCTXDataType)2, 2198 },
	{ (Il2CppRGCTXDataType)3, 9538 },
	{ (Il2CppRGCTXDataType)2, 1974 },
	{ (Il2CppRGCTXDataType)3, 8134 },
	{ (Il2CppRGCTXDataType)2, 1975 },
	{ (Il2CppRGCTXDataType)3, 8135 },
	{ (Il2CppRGCTXDataType)3, 489 },
	{ (Il2CppRGCTXDataType)3, 491 },
	{ (Il2CppRGCTXDataType)3, 490 },
	{ (Il2CppRGCTXDataType)2, 1973 },
	{ (Il2CppRGCTXDataType)3, 8133 },
	{ (Il2CppRGCTXDataType)2, 2158 },
	{ (Il2CppRGCTXDataType)3, 9338 },
	{ (Il2CppRGCTXDataType)3, 9339 },
	{ (Il2CppRGCTXDataType)1, 159 },
	{ (Il2CppRGCTXDataType)3, 9540 },
	{ (Il2CppRGCTXDataType)2, 2200 },
	{ (Il2CppRGCTXDataType)2, 2119 },
	{ (Il2CppRGCTXDataType)3, 9076 },
	{ (Il2CppRGCTXDataType)3, 503 },
	{ (Il2CppRGCTXDataType)3, 505 },
	{ (Il2CppRGCTXDataType)3, 504 },
	{ (Il2CppRGCTXDataType)3, 9077 },
	{ (Il2CppRGCTXDataType)1, 404 },
	{ (Il2CppRGCTXDataType)3, 9082 },
	{ (Il2CppRGCTXDataType)2, 2163 },
	{ (Il2CppRGCTXDataType)3, 9078 },
	{ (Il2CppRGCTXDataType)2, 1971 },
	{ (Il2CppRGCTXDataType)3, 8117 },
	{ (Il2CppRGCTXDataType)3, 9557 },
	{ (Il2CppRGCTXDataType)3, 9558 },
	{ (Il2CppRGCTXDataType)2, 2208 },
	{ (Il2CppRGCTXDataType)3, 12447 },
	{ (Il2CppRGCTXDataType)3, 9348 },
	{ (Il2CppRGCTXDataType)3, 9351 },
	{ (Il2CppRGCTXDataType)2, 2801 },
	{ (Il2CppRGCTXDataType)3, 9349 },
	{ (Il2CppRGCTXDataType)3, 8147 },
	{ (Il2CppRGCTXDataType)3, 9350 },
	{ (Il2CppRGCTXDataType)3, 9353 },
	{ (Il2CppRGCTXDataType)3, 8118 },
	{ (Il2CppRGCTXDataType)3, 12412 },
	{ (Il2CppRGCTXDataType)3, 9559 },
	{ (Il2CppRGCTXDataType)3, 12096 },
	{ (Il2CppRGCTXDataType)3, 12524 },
	{ (Il2CppRGCTXDataType)3, 9352 },
	{ (Il2CppRGCTXDataType)3, 9081 },
	{ (Il2CppRGCTXDataType)2, 1981 },
	{ (Il2CppRGCTXDataType)3, 8148 },
	{ (Il2CppRGCTXDataType)2, 1981 },
	{ (Il2CppRGCTXDataType)3, 9080 },
	{ (Il2CppRGCTXDataType)2, 2119 },
	{ (Il2CppRGCTXDataType)3, 9079 },
	{ (Il2CppRGCTXDataType)3, 9360 },
	{ (Il2CppRGCTXDataType)2, 2164 },
	{ (Il2CppRGCTXDataType)2, 2164 },
	{ (Il2CppRGCTXDataType)3, 9354 },
	{ (Il2CppRGCTXDataType)3, 510 },
	{ (Il2CppRGCTXDataType)3, 512 },
	{ (Il2CppRGCTXDataType)3, 511 },
	{ (Il2CppRGCTXDataType)3, 9356 },
	{ (Il2CppRGCTXDataType)2, 1013 },
	{ (Il2CppRGCTXDataType)3, 2715 },
	{ (Il2CppRGCTXDataType)3, 12448 },
	{ (Il2CppRGCTXDataType)2, 2059 },
	{ (Il2CppRGCTXDataType)3, 12296 },
	{ (Il2CppRGCTXDataType)3, 12330 },
	{ (Il2CppRGCTXDataType)1, 408 },
	{ (Il2CppRGCTXDataType)3, 12530 },
	{ (Il2CppRGCTXDataType)3, 12413 },
	{ (Il2CppRGCTXDataType)3, 12430 },
	{ (Il2CppRGCTXDataType)3, 9359 },
	{ (Il2CppRGCTXDataType)3, 9561 },
	{ (Il2CppRGCTXDataType)3, 9358 },
	{ (Il2CppRGCTXDataType)3, 9560 },
	{ (Il2CppRGCTXDataType)3, 12303 },
	{ (Il2CppRGCTXDataType)3, 12438 },
	{ (Il2CppRGCTXDataType)3, 12476 },
	{ (Il2CppRGCTXDataType)3, 9355 },
	{ (Il2CppRGCTXDataType)2, 2805 },
	{ (Il2CppRGCTXDataType)3, 9562 },
	{ (Il2CppRGCTXDataType)2, 2209 },
	{ (Il2CppRGCTXDataType)3, 9357 },
	{ (Il2CppRGCTXDataType)3, 9570 },
	{ (Il2CppRGCTXDataType)2, 2211 },
	{ (Il2CppRGCTXDataType)2, 2211 },
	{ (Il2CppRGCTXDataType)3, 9564 },
	{ (Il2CppRGCTXDataType)3, 513 },
	{ (Il2CppRGCTXDataType)3, 515 },
	{ (Il2CppRGCTXDataType)3, 514 },
	{ (Il2CppRGCTXDataType)3, 9566 },
	{ (Il2CppRGCTXDataType)2, 1014 },
	{ (Il2CppRGCTXDataType)3, 2716 },
	{ (Il2CppRGCTXDataType)2, 417 },
	{ (Il2CppRGCTXDataType)1, 2808 },
	{ (Il2CppRGCTXDataType)3, 12449 },
	{ (Il2CppRGCTXDataType)2, 2060 },
	{ (Il2CppRGCTXDataType)3, 12297 },
	{ (Il2CppRGCTXDataType)3, 9565 },
	{ (Il2CppRGCTXDataType)3, 12331 },
	{ (Il2CppRGCTXDataType)1, 417 },
	{ (Il2CppRGCTXDataType)3, 12531 },
	{ (Il2CppRGCTXDataType)3, 12414 },
	{ (Il2CppRGCTXDataType)3, 12431 },
	{ (Il2CppRGCTXDataType)3, 12565 },
	{ (Il2CppRGCTXDataType)3, 12477 },
	{ (Il2CppRGCTXDataType)3, 9568 },
	{ (Il2CppRGCTXDataType)3, 12479 },
	{ (Il2CppRGCTXDataType)3, 9569 },
	{ (Il2CppRGCTXDataType)3, 12304 },
	{ (Il2CppRGCTXDataType)3, 12439 },
	{ (Il2CppRGCTXDataType)2, 2166 },
	{ (Il2CppRGCTXDataType)3, 9362 },
	{ (Il2CppRGCTXDataType)3, 12478 },
	{ (Il2CppRGCTXDataType)2, 2808 },
	{ (Il2CppRGCTXDataType)3, 9571 },
	{ (Il2CppRGCTXDataType)3, 9567 },
	{ (Il2CppRGCTXDataType)3, 9563 },
	{ (Il2CppRGCTXDataType)3, 9361 },
	{ (Il2CppRGCTXDataType)3, 12407 },
	{ (Il2CppRGCTXDataType)3, 12312 },
	{ (Il2CppRGCTXDataType)3, 12345 },
	{ (Il2CppRGCTXDataType)3, 12408 },
	{ (Il2CppRGCTXDataType)2, 213 },
	{ (Il2CppRGCTXDataType)2, 1470 },
	{ (Il2CppRGCTXDataType)3, 4163 },
	{ (Il2CppRGCTXDataType)3, 12409 },
	{ (Il2CppRGCTXDataType)2, 214 },
	{ (Il2CppRGCTXDataType)2, 1471 },
	{ (Il2CppRGCTXDataType)3, 4164 },
	{ (Il2CppRGCTXDataType)3, 12437 },
	{ (Il2CppRGCTXDataType)3, 12406 },
	{ (Il2CppRGCTXDataType)2, 211 },
	{ (Il2CppRGCTXDataType)2, 1468 },
	{ (Il2CppRGCTXDataType)3, 4162 },
	{ (Il2CppRGCTXDataType)3, 12410 },
	{ (Il2CppRGCTXDataType)3, 12537 },
	{ (Il2CppRGCTXDataType)3, 12327 },
	{ (Il2CppRGCTXDataType)3, 12467 },
	{ (Il2CppRGCTXDataType)3, 12562 },
	{ (Il2CppRGCTXDataType)2, 2057 },
	{ (Il2CppRGCTXDataType)2, 2821 },
	{ (Il2CppRGCTXDataType)3, 12450 },
	{ (Il2CppRGCTXDataType)3, 12538 },
	{ (Il2CppRGCTXDataType)1, 514 },
	{ (Il2CppRGCTXDataType)2, 2061 },
	{ (Il2CppRGCTXDataType)3, 8841 },
	{ (Il2CppRGCTXDataType)3, 9071 },
	{ (Il2CppRGCTXDataType)2, 1968 },
	{ (Il2CppRGCTXDataType)3, 8112 },
	{ (Il2CppRGCTXDataType)3, 497 },
	{ (Il2CppRGCTXDataType)3, 498 },
	{ (Il2CppRGCTXDataType)2, 772 },
	{ (Il2CppRGCTXDataType)3, 496 },
	{ (Il2CppRGCTXDataType)2, 2758 },
	{ (Il2CppRGCTXDataType)2, 2056 },
	{ (Il2CppRGCTXDataType)3, 495 },
	{ (Il2CppRGCTXDataType)3, 9073 },
	{ (Il2CppRGCTXDataType)2, 542 },
	{ (Il2CppRGCTXDataType)3, 12326 },
	{ (Il2CppRGCTXDataType)1, 180 },
	{ (Il2CppRGCTXDataType)3, 12561 },
	{ (Il2CppRGCTXDataType)3, 12548 },
	{ (Il2CppRGCTXDataType)3, 12325 },
	{ (Il2CppRGCTXDataType)1, 179 },
	{ (Il2CppRGCTXDataType)3, 12560 },
	{ (Il2CppRGCTXDataType)3, 12577 },
	{ (Il2CppRGCTXDataType)3, 12323 },
	{ (Il2CppRGCTXDataType)1, 177 },
	{ (Il2CppRGCTXDataType)3, 12558 },
	{ (Il2CppRGCTXDataType)3, 12576 },
	{ (Il2CppRGCTXDataType)3, 12324 },
	{ (Il2CppRGCTXDataType)1, 178 },
	{ (Il2CppRGCTXDataType)3, 9341 },
	{ (Il2CppRGCTXDataType)3, 12559 },
	{ (Il2CppRGCTXDataType)3, 9342 },
	{ (Il2CppRGCTXDataType)3, 9340 },
	{ (Il2CppRGCTXDataType)3, 9543 },
	{ (Il2CppRGCTXDataType)3, 9542 },
	{ (Il2CppRGCTXDataType)3, 12529 },
	{ (Il2CppRGCTXDataType)3, 12429 },
	{ (Il2CppRGCTXDataType)3, 9344 },
	{ (Il2CppRGCTXDataType)3, 9343 },
	{ (Il2CppRGCTXDataType)3, 12528 },
	{ (Il2CppRGCTXDataType)3, 12428 },
	{ (Il2CppRGCTXDataType)3, 12329 },
	{ (Il2CppRGCTXDataType)1, 271 },
	{ (Il2CppRGCTXDataType)3, 12333 },
	{ (Il2CppRGCTXDataType)1, 544 },
	{ (Il2CppRGCTXDataType)3, 9545 },
	{ (Il2CppRGCTXDataType)3, 12564 },
	{ (Il2CppRGCTXDataType)3, 12567 },
	{ (Il2CppRGCTXDataType)3, 9546 },
	{ (Il2CppRGCTXDataType)3, 12452 },
	{ (Il2CppRGCTXDataType)3, 9544 },
	{ (Il2CppRGCTXDataType)2, 2214 },
	{ (Il2CppRGCTXDataType)3, 9572 },
	{ (Il2CppRGCTXDataType)3, 12328 },
	{ (Il2CppRGCTXDataType)1, 270 },
	{ (Il2CppRGCTXDataType)3, 12332 },
	{ (Il2CppRGCTXDataType)1, 543 },
	{ (Il2CppRGCTXDataType)3, 9346 },
	{ (Il2CppRGCTXDataType)3, 12563 },
	{ (Il2CppRGCTXDataType)3, 12566 },
	{ (Il2CppRGCTXDataType)3, 9347 },
	{ (Il2CppRGCTXDataType)3, 12451 },
	{ (Il2CppRGCTXDataType)3, 9345 },
	{ (Il2CppRGCTXDataType)2, 2169 },
	{ (Il2CppRGCTXDataType)3, 9363 },
	{ (Il2CppRGCTXDataType)3, 9175 },
	{ (Il2CppRGCTXDataType)3, 9532 },
	{ (Il2CppRGCTXDataType)3, 9174 },
	{ (Il2CppRGCTXDataType)3, 9173 },
	{ (Il2CppRGCTXDataType)3, 9069 },
	{ (Il2CppRGCTXDataType)3, 9328 },
	{ (Il2CppRGCTXDataType)3, 11741 },
	{ (Il2CppRGCTXDataType)3, 9177 },
	{ (Il2CppRGCTXDataType)3, 9176 },
	{ (Il2CppRGCTXDataType)3, 9070 },
	{ (Il2CppRGCTXDataType)3, 9329 },
	{ (Il2CppRGCTXDataType)3, 9330 },
	{ (Il2CppRGCTXDataType)3, 9533 },
	{ (Il2CppRGCTXDataType)3, 9178 },
	{ (Il2CppRGCTXDataType)2, 2744 },
	{ (Il2CppRGCTXDataType)3, 9534 },
	{ (Il2CppRGCTXDataType)2, 2194 },
	{ (Il2CppRGCTXDataType)3, 11737 },
	{ (Il2CppRGCTXDataType)3, 9187 },
	{ (Il2CppRGCTXDataType)3, 9199 },
	{ (Il2CppRGCTXDataType)3, 9185 },
	{ (Il2CppRGCTXDataType)3, 9163 },
	{ (Il2CppRGCTXDataType)3, 9161 },
	{ (Il2CppRGCTXDataType)3, 9086 },
	{ (Il2CppRGCTXDataType)3, 12366 },
	{ (Il2CppRGCTXDataType)3, 12111 },
	{ (Il2CppRGCTXDataType)3, 12107 },
	{ (Il2CppRGCTXDataType)3, 507 },
	{ (Il2CppRGCTXDataType)3, 509 },
	{ (Il2CppRGCTXDataType)3, 508 },
	{ (Il2CppRGCTXDataType)1, 407 },
	{ (Il2CppRGCTXDataType)2, 2123 },
	{ (Il2CppRGCTXDataType)3, 9186 },
	{ (Il2CppRGCTXDataType)2, 2142 },
	{ (Il2CppRGCTXDataType)2, 2137 },
	{ (Il2CppRGCTXDataType)3, 9184 },
	{ (Il2CppRGCTXDataType)3, 9162 },
	{ (Il2CppRGCTXDataType)3, 9193 },
	{ (Il2CppRGCTXDataType)3, 9197 },
	{ (Il2CppRGCTXDataType)3, 9190 },
	{ (Il2CppRGCTXDataType)3, 9191 },
	{ (Il2CppRGCTXDataType)3, 9194 },
	{ (Il2CppRGCTXDataType)3, 9195 },
	{ (Il2CppRGCTXDataType)3, 9196 },
	{ (Il2CppRGCTXDataType)3, 9183 },
	{ (Il2CppRGCTXDataType)3, 9182 },
	{ (Il2CppRGCTXDataType)3, 9192 },
	{ (Il2CppRGCTXDataType)3, 12484 },
	{ (Il2CppRGCTXDataType)2, 1012 },
	{ (Il2CppRGCTXDataType)3, 2714 },
	{ (Il2CppRGCTXDataType)3, 9188 },
	{ (Il2CppRGCTXDataType)3, 9198 },
	{ (Il2CppRGCTXDataType)3, 9189 },
	{ (Il2CppRGCTXDataType)3, 9084 },
	{ (Il2CppRGCTXDataType)3, 9085 },
	{ (Il2CppRGCTXDataType)2, 2804 },
	{ (Il2CppRGCTXDataType)3, 9083 },
	{ (Il2CppRGCTXDataType)2, 1972 },
	{ (Il2CppRGCTXDataType)3, 8119 },
	{ (Il2CppRGCTXDataType)3, 8149 },
	{ (Il2CppRGCTXDataType)3, 8150 },
	{ (Il2CppRGCTXDataType)2, 1982 },
	{ (Il2CppRGCTXDataType)2, 2142 },
	{ (Il2CppRGCTXDataType)3, 9181 },
	{ (Il2CppRGCTXDataType)2, 777 },
	{ (Il2CppRGCTXDataType)3, 506 },
	{ (Il2CppRGCTXDataType)2, 2058 },
	{ (Il2CppRGCTXDataType)3, 9180 },
	{ (Il2CppRGCTXDataType)3, 9201 },
	{ (Il2CppRGCTXDataType)3, 9200 },
	{ (Il2CppRGCTXDataType)3, 11745 },
	{ (Il2CppRGCTXDataType)3, 9179 },
	{ (Il2CppRGCTXDataType)3, 2713 },
	{ (Il2CppRGCTXDataType)3, 2712 },
	{ (Il2CppRGCTXDataType)2, 2849 },
	{ (Il2CppRGCTXDataType)3, 9153 },
	{ (Il2CppRGCTXDataType)3, 8114 },
	{ (Il2CppRGCTXDataType)3, 9549 },
	{ (Il2CppRGCTXDataType)2, 1979 },
	{ (Il2CppRGCTXDataType)3, 8138 },
	{ (Il2CppRGCTXDataType)3, 8113 },
};
extern const CustomAttributesCacheGenerator g_System_Memory_AttributeGenerators[];
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_System_Memory_CodeGenModule;
const Il2CppCodeGenModule g_System_Memory_CodeGenModule = 
{
	"System.Memory.dll",
	449,
	s_methodPointers,
	27,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	50,
	s_rgctxIndices,
	390,
	s_rgctxValues,
	NULL,
	g_System_Memory_AttributeGenerators,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
