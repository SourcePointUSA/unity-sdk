#if IL2CPP_GOOGLE_BENCHMARK

#pragma once

void il2cpp_benchmark_initialize(int argc, const Il2CppChar* const* argv);
void il2cpp_benchmark_initialize(int argc, const char* const* argv);

#endif
