#pragma once

#include "il2cpp-config.h"
#include "il2cpp-object-internals.h"
#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "utils/StringUtils.h"

#if defined(_MSC_VER)
#include <intrin.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <limits>
#include <cmath>
#include <assert.h>
